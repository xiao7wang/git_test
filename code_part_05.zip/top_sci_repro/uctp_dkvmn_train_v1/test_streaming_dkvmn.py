"""Checks adapter against user-supplied pyKT DKVMN on small synthetic cases."""
import copy,importlib.util,unittest
from pathlib import Path
import torch
from streaming_dkvmn import initial_memory,forward_chunk
path=Path(__file__).resolve().parent/'pykt/models/dkvmn.py'
spec=importlib.util.spec_from_file_location('verified_pykt_dkvmn',path);up=importlib.util.module_from_spec(spec);spec.loader.exec_module(up)

class Tests(unittest.TestCase):
 def setUp(self):
  torch.manual_seed(0);self.m=up.DKVMN(num_c=5,dim_s=8,size_m=4,dropout=0).eval()
  self.q=torch.tensor([[1,2,1,3,2,4],[4,1,0,2,2,1]])
  self.r=torch.tensor([[1,0,1,1,0,1],[0,1,0,1,1,0]])
  self.mask=torch.ones_like(self.q,dtype=torch.bool)
 def test_matches_official_forward_and_chunks(self):
  expected=self.m(self.q,self.r);actual,state=forward_chunk(self.m,self.q,self.r,self.mask,self.mask,initial_memory(self.m,2))
  self.assertTrue(torch.allclose(expected,actual,atol=1e-7))
  a,mid=forward_chunk(self.m,self.q[:,:3],self.r[:,:3],self.mask[:,:3],self.mask[:,:3],initial_memory(self.m,2))
  b,last=forward_chunk(self.m,self.q[:,3:],self.r[:,3:],self.mask[:,3:],self.mask[:,3:],mid)
  self.assertTrue(torch.allclose(actual,torch.cat((a,b),1),atol=1e-7));self.assertTrue(torch.allclose(state,last,atol=1e-7))
 def test_gradients_match_upstream_without_dropout(self):
  other=copy.deepcopy(self.m);self.m.zero_grad();other.zero_grad()
  upstream=self.m(self.q,self.r);adapted,_=forward_chunk(other,self.q,self.r,self.mask,self.mask,initial_memory(other,2))
  upstream.sum().backward();adapted.sum().backward()
  for (name,a),(name2,b) in zip(self.m.named_parameters(),other.named_parameters()):
   self.assertEqual(name,name2);self.assertTrue(torch.allclose(a.grad,b.grad,atol=2e-6,rtol=1e-5),name)
 def test_predict_before_feedback(self):
  actual,_=forward_chunk(self.m,self.q,self.r,self.mask,self.mask,initial_memory(self.m,2))
  alt=self.r.clone();alt[:,2]=1-alt[:,2]
  changed,_=forward_chunk(self.m,self.q,alt,self.mask,self.mask,initial_memory(self.m,2))
  self.assertTrue(torch.allclose(actual[:,:3],changed[:,:3],atol=1e-7))
 def test_padding_and_unavailable_feedback(self):
  q=self.q[:1,:];r=self.r[:1,:];active=self.mask[:1,:].clone();active[:,3:]=False
  padded=q.clone();padded[:,3:]=-1;feedback=active.clone();r2=r.clone();r2[:,3:]=-77
  result,state=forward_chunk(self.m,padded,r2,active,feedback,initial_memory(self.m,1))
  prefix,pstate=forward_chunk(self.m,q[:,:3],r[:,:3],active[:,:3],feedback[:,:3],initial_memory(self.m,1))
  self.assertTrue(torch.allclose(result[:,:3],prefix,atol=1e-7));self.assertTrue(torch.allclose(state,pstate,atol=1e-7))
  blocked=torch.zeros_like(active);sentinel=torch.full_like(r,-77)
  a,s=forward_chunk(self.m,q,sentinel,active,blocked,initial_memory(self.m,1))
  b,t=forward_chunk(self.m,q,torch.zeros_like(r),active,blocked,initial_memory(self.m,1))
  self.assertTrue(torch.allclose(a,b,atol=1e-7));self.assertTrue(torch.allclose(s,t,atol=1e-7))
if __name__=='__main__':unittest.main()
