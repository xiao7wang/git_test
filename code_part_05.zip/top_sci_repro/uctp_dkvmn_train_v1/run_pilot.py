"""DKVMN timing and protocol pilot: selected development students, one epoch."""
import argparse,importlib.util,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics
from streaming_dkvmn import initial_memory,forward_chunk
ROOT=Path(__file__).resolve().parent

def load_upstream():
 path=ROOT/'pykt/models/dkvmn.py';source=read(ROOT/'source_manifest.json')
 if sha(path)!=source['files']['pykt/models/dkvmn.py'] or sha(ROOT/'LICENSE')!=source['files']['LICENSE']:raise ValueError('Upstream DKVMN or license changed')
 spec=importlib.util.spec_from_file_location('user_pykt_dkvmn',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module.DKVMN,source

def selected_sequences(data,users,view):
 a=data.arrays;offsets=a['user_offsets'];max_split=0 if view=='train' else 1;seq=[]
 for user in users:
  idx=np.arange(offsets[user],offsets[user+1]);seq.append(idx[a['split'][idx]<=max_split])
 return seq

def batches(data,users,view,batch_size):
 for start in range(0,len(users),batch_size):
  group=users[start:start+batch_size];seq=selected_sequences(data,group,view)
  if any(len(x) for x in seq):yield group,seq

def evaluate(model,data,users,device,chunk_size,batch_size):
 model.eval();records=[];start=time.monotonic()
 with torch.no_grad():
  for chosen,seq in batches(data,users,'valid',batch_size):
   state=initial_memory(model,len(chosen))
   for b,idx in data.chunks(chosen,seq,'valid',chunk_size,device):
    p,state=forward_chunk(model,b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)
    mask=b['target_mask'].cpu().numpy()
    if mask.any():
     ids=idx[mask];records.append(pd.DataFrame({'record_idx':ids,'student_idx':data.arrays['student_idx'][ids],
       'label':data.arrays['label'][ids],'probability':p.cpu().numpy()[mask]}))
 if not records:raise ValueError('No development events in sampled students')
 frame=pd.concat(records,ignore_index=True).sort_values('record_idx').reset_index(drop=True)
 return frame,time.monotonic()-start

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if a.students<2 or a.batch_size<1 or a.chunk_size<1:raise ValueError('Invalid pilot settings')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
 status={'status':'running','phase':'source_verify','test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  p1=Path(a.p1_dir);lock=read(ROOT/'locked_p1.json')
  for n,h in lock['p1_files'].items():
   if sha(p1/n)!=h:raise ValueError('P1 source changed: '+n)
  old=read(p1/'config.json')
  if read(p1/'status.json')['status']!='complete' or old['test_evaluated'] or old['holdout_evaluated'] or old['feedback']!='row immediate assumption':raise ValueError('P1 protocol mismatch')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  DKVMN,source=load_upstream();data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Pilot requires binary single-KC items')
  dev=sorted(dev_users(arr['student_idx'][arr['split']==1]))
  if len(dev)<a.students:raise ValueError('Not enough development students')
  users=np.sort(np.random.default_rng(20261109).choice(dev,size=a.students,replace=False).astype(np.int64))
  selected_valid=np.flatnonzero((arr['split']==1)&np.isin(arr['student_idx'],users))
  reference=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  ref=reference[reference.student_idx.isin(users)].sort_values('record_idx').reset_index(drop=True)
  for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
   expected=selected_valid if key=='record_idx' else arr[key][selected_valid]
   if not np.array_equal(ref[col].to_numpy(),expected):raise ValueError('P1 sampled event mismatch: '+col)
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(0)
  if device.type=='cuda':torch.cuda.manual_seed_all(0)
  torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  model=DKVMN(num_c=int(dims:=data.manifest['summary']['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
  cfg={'purpose':'timing and protocol pilot only, not model comparison', 'data_fingerprint':data.fingerprint,'student_partition_salt':SALT,
   'sample':'64 or requested development users uniformly sampled without replacement with NumPy seed 20261109; train and score only these users',
   'feedback':'row immediate assumption; predict before feedback; past training and selected-user prior validation only',
   'features':'KC and prior binary responses only; no student, item, time or response-time features; not matched-feature model vs R2',
   'source_archive_sha256':source['archive_sha256'],'source_version':source['version_from_setup'],'source_commit':source['git_commit'],
   'source_dkvmn_sha256':sha(ROOT/'pykt/models/dkvmn.py'),'source_license_sha256':sha(ROOT/'LICENSE'),
   'code_sha256':{n:sha(ROOT/n) for n in ('run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')},
   'source_p1_files':lock['p1_files'],'sample_students':len(users),'sample_student_ids':users.tolist(),'known_kcs':dims,
   'model':'pyKT DKVMN, streaming adapter; qid=single knowledge component, not item ID','dim_s':32,'memory_slots':20,'dropout':.2,
   'batch_size':a.batch_size,'train_chunk_size':a.chunk_size,'validation_chunk_sizes':[17,a.chunk_size],
   'training':'one epoch, Adam lr .001, truncated backprop at chunks; optimizer step per chunk; state detached across chunks',
   'seed':0,'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg)
  # On real training-prefix data, compare original full forward against adapter on the target device.
  status['phase']='upstream_bridge';write(out/'status.json',status);model.eval()
  seqs=selected_sequences(data,users,'train');check=next((x[:64] for x in seqs if len(x)>=2),None)
  if check is None:raise ValueError('No train sequence with two events for bridge')
  kcs=q.argmax(1)[arr['item_idx'][check]]
  kt=torch.as_tensor(kcs[None,:],device=device,dtype=torch.long);yt=torch.as_tensor(arr['label'][check][None,:],device=device,dtype=torch.long);mask=torch.ones_like(kt,dtype=torch.bool)
  with torch.no_grad():
   orig=model(kt,yt);stream,_=forward_chunk(model,kt,yt,mask,mask,initial_memory(model,1))
  diff=float(torch.max(torch.abs(orig-stream)).item())
  if diff>1e-6:raise ValueError(f'Upstream bridge failed: {diff}')
  print('Upstream bridge passed; starting one-epoch sampled training',flush=True)
  status['phase']='training';write(out/'status.json',status);model.train();opt=torch.optim.Adam(model.parameters(),lr=.001)
  if device.type=='cuda':torch.cuda.synchronize()
  start=time.monotonic();loss_total=0.;train_n=0;steps=0;bcount=0
  for chosen,seq in batches(data,users,'train',a.batch_size):
   bcount+=1;state=initial_memory(model,len(chosen))
   for b,idx in data.chunks(chosen,seq,'train',a.chunk_size,device):
    opt.zero_grad(set_to_none=True);p,state=forward_chunk(model,b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)
    mask=b['target_mask'];n=int(mask.sum().item())
    if n:
     loss=F.binary_cross_entropy(p[mask].clamp(1e-6,1-1e-6),b['label'][mask])
     if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
     loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();loss_total+=float(loss.detach())*n;train_n+=n;steps+=1
    state=state.detach()
   print(json.dumps({'phase':'training','batch':bcount,'total_batches':(len(users)+a.batch_size-1)//a.batch_size,'train_events':train_n}),flush=True)
  if device.type=='cuda':torch.cuda.synchronize()
  train_sec=time.monotonic()-start
  if train_n==0:raise ValueError('No training events')
  status['phase']='development_replay';write(out/'status.json',status);print('Starting sampled development replay',flush=True)
  frame,eval_sec=evaluate(model,data,users,device,a.chunk_size,a.batch_size)
  frame17,eval17_sec=evaluate(model,data,users,device,17,a.batch_size)
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(frame[col].to_numpy(),ref[col].to_numpy()) or not np.array_equal(frame[col].to_numpy(),frame17[col].to_numpy()):raise ValueError('Development alignment differs: '+col)
  chunk_diff=float(np.max(np.abs(frame.probability.to_numpy(float)-frame17.probability.to_numpy(float)),initial=0))
  if chunk_diff>1e-6:raise ValueError(f'Chunk replay discrepancy: {chunk_diff}')
  pred_metrics=metrics(frame.label.to_numpy(),frame.probability.to_numpy());frame.to_csv(out/'pilot_predictions.csv.gz',index=False,compression='gzip')
  torch.save({'model_state':model.state_dict(),'model':'pykt_dkvmn_pilot','students':users.tolist(),'data_fingerprint':data.fingerprint},out/'pilot_model.pt')
  summary={'status':'complete','pilot_only':True,'test_evaluated':False,'holdout_evaluated':False,
   'train_students':len(users),'train_events':train_n,'optimizer_steps':steps,'train_seconds':train_sec,'train_bce':loss_total/train_n,
   'validation_events':len(frame),'validation_students':int(frame.student_idx.nunique()),'dev_metrics_not_full_comparison':pred_metrics,
   'validation_seconds':eval_sec,'validation_chunk17_seconds':eval17_sec,'upstream_bridge_max_abs':diff,'chunk17_max_abs':chunk_diff,
   'checkpoint_sha256':sha(out/'pilot_model.pt'),'seconds':time.monotonic()-begin}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-begin);write(out/'status.json',status);print('DKVMN PILOT COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--students',type=int,default=64);p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
