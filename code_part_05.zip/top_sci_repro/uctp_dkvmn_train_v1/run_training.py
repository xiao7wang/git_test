"""One-seed full DKVMN training with dev NLL early stopping; no test/holdout."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics,losses,cluster_intervals
from streaming_dkvmn import initial_memory,forward_chunk
from run_pilot import load_upstream,selected_sequences,batches,evaluate
ROOT=Path(__file__).resolve().parent

def save_checkpoint(out,name,contents):
 tmp=out/(name+'.pending');torch.save(contents,tmp);tmp.replace(out/name)

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if min(a.batch_size,a.chunk_size,a.epochs,a.patience)<1:raise ValueError('Invalid settings')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
 status={'status':'running','phase':'source_verify','epoch':0,'test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  p1=Path(a.p1_dir);timing=Path(a.timing_dir);p1lock=read(ROOT/'locked_p1.json');tlock=read(ROOT/'locked_timing.json')
  for name,digest in p1lock['p1_files'].items():
   if sha(p1/name)!=digest:raise ValueError('P1 source changed: '+name)
  for name,digest in tlock['timing_files'].items():
   if sha(timing/name)!=digest:raise ValueError('Timing source changed: '+name)
  old=read(p1/'config.json');tcfg=read(timing/'config.json');tsum=read(timing/'summary.json')
  if read(p1/'status.json')['status']!='complete' or read(timing/'status.json')['status']!='complete' or not tsum['one_epoch_timing_only'] or tsum['upstream_bridge_max_abs']>1e-6 or tsum['chunk17_max_abs']>1e-6:raise ValueError('Prior timing did not pass')
  if old['test_evaluated'] or old['holdout_evaluated'] or tcfg['test_evaluated'] or tcfg['holdout_evaluated'] or old['feedback']!='row immediate assumption':raise ValueError('Prior protocol mismatch')
  if tcfg['batch_size']!=a.batch_size or tcfg['train_chunk_size']!=a.chunk_size or tcfg['validation_chunk_size']!=a.chunk_size or tcfg['seed']!=0:raise ValueError('Epoch-one bridge requires identical batch/chunk/seed')
  for name,digest in tcfg['code_sha256'].items():
   if sha(ROOT/name)!=digest:raise ValueError('Timing source differs: '+name)
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old['data_fingerprint']!=spec['data_fingerprint'] or tcfg['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  DKVMN,source=load_upstream();data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires binary single-KC items')
  train_users=np.unique(arr['student_idx'][arr['split']==0]).astype(np.int64);dev=np.asarray(sorted(dev_users(arr['student_idx'][arr['split']==1])),dtype=np.int64)
  ids=np.flatnonzero((arr['split']==1)&np.isin(arr['student_idx'],dev));ref=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip');first=pd.read_csv(timing/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
   expected=ids if key=='record_idx' else arr[key][ids]
   if not np.array_equal(ref[col].to_numpy(),expected) or not np.array_equal(first[col].to_numpy(),expected):raise ValueError('Development identity mismatch: '+col)
  train_expected=int(np.sum(arr['split']==0))
  if train_expected!=old['train_rows'] or len(ids)!=old['development_rows'] or train_expected!=tcfg['train_expected_events']:raise ValueError('Event coverage differs')
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(0)
  if device.type=='cuda':torch.cuda.manual_seed_all(0)
  torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  model=DKVMN(num_c=int(data.manifest['summary']['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
  cfg={'purpose':'one-seed development-screened full DKVMN; no test or holdout', 'data_fingerprint':data.fingerprint,'student_partition_salt':SALT,
   'feedback':'row immediate assumption; predict before feedback; train history plus selected development users prior validation answers',
   'features':'KC and prior binary answers only; no item, student or time features; input privileges differ from log-count R2',
   'source_archive_sha256':source['archive_sha256'],'source_version':source['version_from_setup'],'source_commit':source['git_commit'],
   'source_p1_files':p1lock['p1_files'],'source_timing_files':tlock['timing_files'],'source_dkvmn_sha256':sha(ROOT/'pykt/models/dkvmn.py'),
   'source_license_sha256':sha(ROOT/'LICENSE'),'code_sha256':{n:sha(ROOT/n) for n in ('run_training.py','run_full_timing.py','run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')},
   'model':'user pyKT DKVMN with streaming adapter','dim_s':32,'memory_slots':20,'dropout':.2,'optimizer':'Adam','lr':.001,
   'batch_size':a.batch_size,'chunk_size':a.chunk_size,'gradient_clip':5,'epochs_max':a.epochs,'patience':a.patience,
   'training':'all train events each epoch; user order per epoch RNG seed epoch-1; train state detached at chunk boundaries; optimizer step per chunk',
   'selection':'development event NLL, strict improvement; stop after patience non-improving epochs',
   'seed':0,'train_students':len(train_users),'train_expected_events':train_expected,'development_students':len(dev),'development_events':len(ids),
   'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg)
  # Match the non-random eval bridge performed by the timing run before training.
  model.eval();check=next((x[:64] for x in selected_sequences(data,train_users,'train') if len(x)>=2),None)
  if check is None:raise ValueError('No suitable train sequence')
  kt=torch.as_tensor(q.argmax(1)[arr['item_idx'][check]][None,:],device=device,dtype=torch.long);yt=torch.as_tensor(arr['label'][check][None,:],device=device,dtype=torch.long);mask=torch.ones_like(kt,dtype=torch.bool)
  with torch.no_grad():orig=model(kt,yt);stream,_=forward_chunk(model,kt,yt,mask,mask,initial_memory(model,1))
  bridge=float(torch.max(torch.abs(orig-stream)).item())
  if bridge>1e-6:raise ValueError('Upstream prediction bridge differs')
  opt=torch.optim.Adam(model.parameters(),lr=.001);history=[];best=float('inf');best_epoch=None;stale=0;epoch1_diff=None
  for epoch in range(1,a.epochs+1):
   status.update(phase='training',epoch=epoch,best_epoch=best_epoch);write(out/'status.json',status);print(json.dumps({'phase':'training_start','epoch':epoch}),flush=True)
   users=np.random.default_rng(epoch-1).permutation(train_users);model.train()
   if device.type=='cuda':torch.cuda.synchronize()
   train_start=time.monotonic();total=0.;train_n=0;steps=0;batch_n=0
   for chosen,seq in batches(data,users,'train',a.batch_size):
    batch_n+=1;state=initial_memory(model,len(chosen))
    for b,_ in data.chunks(chosen,seq,'train',a.chunk_size,device):
     opt.zero_grad(set_to_none=True);p,state=forward_chunk(model,b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state);m=b['target_mask'];n=int(m.sum().item())
     if n:
      loss=F.binary_cross_entropy(p[m].clamp(1e-6,1-1e-6),b['label'][m])
      if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
      loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*n;train_n+=n;steps+=1
     state=state.detach()
    if batch_n%40==0:print(json.dumps({'phase':'training','epoch':epoch,'batch':batch_n,'total_batches':int((len(users)+a.batch_size-1)//a.batch_size),'train_events':train_n,'elapsed_seconds':time.monotonic()-train_start}),flush=True)
   if device.type=='cuda':torch.cuda.synchronize()
   train_sec=time.monotonic()-train_start
   if train_n!=train_expected:raise ValueError(f'Training coverage mismatch: {train_n}')
   status['phase']='development_replay';write(out/'status.json',status);print(json.dumps({'phase':'development_replay','epoch':epoch,'train_seconds':train_sec}),flush=True)
   frame,eval_sec=evaluate(model,data,dev,device,a.chunk_size,a.batch_size)
   for col in ('record_idx','student_idx','label'):
    if not np.array_equal(frame[col].to_numpy(),ref[col].to_numpy()):raise ValueError('Development identity mismatch: '+col)
   if epoch==1:
    epoch1_diff=float(np.max(np.abs(frame.probability.to_numpy(np.float32).astype(float)-first.probability.to_numpy(np.float32).astype(float)),initial=0))
    if epoch1_diff>1e-6:raise ValueError(f'Epoch-one timing bridge differs: {epoch1_diff}')
   met=metrics(frame.label.to_numpy(),frame.probability.to_numpy());nll=float(met['nll'])
   if not np.isfinite(nll):raise FloatingPointError('Nonfinite development NLL')
   improved=nll<best
   if improved:
    best=nll;best_epoch=epoch;stale=0
    save_checkpoint(out,'best_model.pt',{'model_state':model.state_dict(),'epoch':epoch,'data_fingerprint':data.fingerprint,'dev_nll':nll})
    frame.assign(reference_log_count_R2=ref.R2.to_numpy(dtype=np.float32)).to_csv(out/'best_dev_predictions.csv.gz',index=False,compression='gzip')
   else:stale+=1
   h={'epoch':epoch,'train_events':train_n,'optimizer_steps':steps,'train_bce':total/train_n,'train_seconds':train_sec,'dev':met,'dev_seconds':eval_sec,'improved':improved,'best_epoch':best_epoch,'stale':stale}
   history.append(h);write(out/'history.json',history)
   save_checkpoint(out,'last_epoch.pt',{'model_state':model.state_dict(),'optimizer_state':opt.state_dict(),'epoch':epoch,'best_epoch':best_epoch,'best_nll':best,'stale':stale,'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if device.type=='cuda' else None,'data_fingerprint':data.fingerprint})
   print(json.dumps({'phase':'epoch_complete',**h}),flush=True)
   if stale>=a.patience:break
  status['phase']='summary';write(out/'status.json',status)
  df=pd.read_csv(out/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip');y=df.label.to_numpy();students=df.student_idx.to_numpy()
  p=df.probability.to_numpy(dtype=np.float32);r=df.reference_log_count_R2.to_numpy(dtype=np.float32);dl=losses(y,p)[:,0]-losses(y,r)[:,0]
  paired=cluster_intervals(students,dl[:,None],1000,20261109)['comparisons'][0]
  _,inv,counts=np.unique(students,return_inverse=True,return_counts=True)
  summary={'status':'complete','epochs':len(history),'best_epoch':best_epoch,'best_dev':metrics(y,p),'best_student_macro_nll':float(np.mean(np.bincount(inv,weights=losses(y,p)[:,0])/counts)),
   'reference_log_count_R2_dev':metrics(y,r),'dkvmn_minus_R2_conditional':paired,'epoch1_vs_full_timing_max_abs':epoch1_diff,'upstream_bridge_max_abs':bridge,
   'stop_reason':'early_stopping' if stale>=a.patience else 'epoch_limit','scope':'exploratory reused development; one seed, one DKVMN config; unequal input features; no test or holdout',
   'confidence_interval':'student-cluster bootstrap conditional on trained selected models; excludes training and selection uncertainty',
   'best_checkpoint_sha256':sha(out/'best_model.pt'),'last_checkpoint_sha256':sha(out/'last_epoch.pt'),
   'test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-begin}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,epoch=len(history),best_epoch=best_epoch,seconds=time.monotonic()-begin);write(out/'status.json',status);print('DKVMN TRAINING COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','timing-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
