"""One full training epoch + development replay to measure real DKVMN cost."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics
from streaming_dkvmn import initial_memory,forward_chunk
from run_pilot import load_upstream,selected_sequences,batches,evaluate
ROOT=Path(__file__).resolve().parent

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if min(a.batch_size,a.chunk_size)<1:raise ValueError('Invalid batch or chunk')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
 status={'status':'running','phase':'source_verify','test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  p1=Path(a.p1_dir);pilot=Path(a.pilot_dir);lock=read(ROOT/'locked_p1.json');plock=read(ROOT/'locked_pilot.json')
  for name,digest in lock['p1_files'].items():
   if sha(p1/name)!=digest:raise ValueError('P1 source changed: '+name)
  for name,digest in plock['pilot_files'].items():
   if sha(pilot/name)!=digest:raise ValueError('Pilot source changed: '+name)
  old=read(p1/'config.json');pcfg=read(pilot/'config.json');psum=read(pilot/'summary.json')
  if read(p1/'status.json')['status']!='complete' or read(pilot/'status.json')['status']!='complete' or not psum['pilot_only'] or psum['upstream_bridge_max_abs']>1e-6 or psum['chunk17_max_abs']>1e-6:raise ValueError('Preceding runs not complete or pilot checks failed')
  if old['test_evaluated'] or old['holdout_evaluated'] or old['feedback']!='row immediate assumption' or pcfg['feedback']!='row immediate assumption; predict before feedback; past training and selected-user prior validation only':raise ValueError('Prior protocol mismatch')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old['data_fingerprint']!=spec['data_fingerprint'] or pcfg['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  for name,digest in pcfg['code_sha256'].items():
   if sha(ROOT/name)!=digest:raise ValueError('Pilot source differs: '+name)
  DKVMN,source=load_upstream();data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires binary single-KC items')
  train_users=np.unique(arr['student_idx'][arr['split']==0]).astype(np.int64);dev=np.asarray(sorted(dev_users(arr['student_idx'][arr['split']==1])),dtype=np.int64)
  if not len(train_users) or not len(dev):raise ValueError('Empty train or development')
  ids=np.flatnonzero((arr['split']==1)&np.isin(arr['student_idx'],dev));ref=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
   expected=ids if key=='record_idx' else arr[key][ids]
   if not np.array_equal(ref[col].to_numpy(),expected):raise ValueError('P1 development identity mismatch: '+col)
  if int(np.sum(arr['split']==0))!=old['train_rows'] or len(ids)!=old['development_rows']:raise ValueError('P1 row counts differ')
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(0)
  if device.type=='cuda':torch.cuda.manual_seed_all(0)
  torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  model=DKVMN(num_c=int(data.manifest['summary']['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
  cfg={'purpose':'one full training epoch plus full development replay for timing and protocol, not final comparison','data_fingerprint':data.fingerprint,
   'student_partition_salt':SALT,'training':'all train events; one epoch; training-user order RNG seed 0; Adam .001; truncated backprop at chunks, state detached',
   'feedback':'row immediate assumption; predict before feedback; train history plus only selected development users prior validation answers',
   'features':'KC and prior binary responses only; no student, item, time or response-time features; features differ from log-count R2',
   'model':'user pyKT DKVMN with streaming adapter','source_archive_sha256':source['archive_sha256'],'source_version':source['version_from_setup'],'source_commit':source['git_commit'],
   'source_dkvmn_sha256':sha(ROOT/'pykt/models/dkvmn.py'),'source_license_sha256':sha(ROOT/'LICENSE'),
   'code_sha256':{n:sha(ROOT/n) for n in ('run_full_timing.py','run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')},
   'source_p1_files':lock['p1_files'],'source_pilot_files':plock['pilot_files'],'dim_s':32,'memory_slots':20,'dropout':.2,
   'batch_size':a.batch_size,'train_chunk_size':a.chunk_size,'validation_chunk_size':a.chunk_size,'gradient_clip':5,'seed':0,
   'train_students':len(train_users),'train_expected_events':int(np.sum(arr['split']==0)),'development_students':len(dev),'development_expected_events':len(ids),
   'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg);status['phase']='upstream_bridge';write(out/'status.json',status);model.eval()
  check=next((x[:64] for x in selected_sequences(data,train_users,'train') if len(x)>=2),None)
  if check is None:raise ValueError('No suitable train sequence')
  kt=torch.as_tensor(q.argmax(1)[arr['item_idx'][check]][None,:],device=device,dtype=torch.long);yt=torch.as_tensor(arr['label'][check][None,:],device=device,dtype=torch.long);mask=torch.ones_like(kt,dtype=torch.bool)
  with torch.no_grad():orig=model(kt,yt);stream,_=forward_chunk(model,kt,yt,mask,mask,initial_memory(model,1))
  bridge=float(torch.max(torch.abs(orig-stream)).item())
  if bridge>1e-6:raise ValueError('Upstream prediction bridge differs')
  status['phase']='training';write(out/'status.json',status);print('Upstream bridge passed; training one full epoch',flush=True)
  users=np.random.default_rng(0).permutation(train_users);model.train();opt=torch.optim.Adam(model.parameters(),lr=.001)
  if device.type=='cuda':torch.cuda.synchronize()
  start=time.monotonic();total=0.;train_n=0;steps=0;batch_n=0
  for chosen,seq in batches(data,users,'train',a.batch_size):
   batch_n+=1;state=initial_memory(model,len(chosen))
   for b,_ in data.chunks(chosen,seq,'train',a.chunk_size,device):
    opt.zero_grad(set_to_none=True);p,state=forward_chunk(model,b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)
    mask=b['target_mask'];n=int(mask.sum().item())
    if n:
     loss=F.binary_cross_entropy(p[mask].clamp(1e-6,1-1e-6),b['label'][mask])
     if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
     loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*n;train_n+=n;steps+=1
    state=state.detach()
   if batch_n%20==0:print(json.dumps({'phase':'training','batch':batch_n,'total_batches':int((len(users)+a.batch_size-1)//a.batch_size),'train_events':train_n,'elapsed_seconds':time.monotonic()-start}),flush=True)
  if device.type=='cuda':torch.cuda.synchronize()
  train_seconds=time.monotonic()-start
  if train_n!=cfg['train_expected_events']:raise ValueError(f'Training event coverage mismatch: {train_n}')
  status['phase']='chunk_preflight';write(out/'status.json',status);sample=dev[:min(32,len(dev))]
  f50,_=evaluate(model,data,sample,device,a.chunk_size,a.batch_size);f17,_=evaluate(model,data,sample,device,17,a.batch_size)
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(f50[col].to_numpy(),f17[col].to_numpy()):raise ValueError('Chunk preflight identity mismatch')
  chunk_diff=float(np.max(np.abs(f50.probability.to_numpy(float)-f17.probability.to_numpy(float)),initial=0))
  if chunk_diff>1e-6:raise ValueError(f'Chunk preflight discrepancy: {chunk_diff}')
  status['phase']='development_replay';write(out/'status.json',status);print('Starting full development replay',flush=True)
  frame,eval_seconds=evaluate(model,data,dev,device,a.chunk_size,a.batch_size)
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(frame[col].to_numpy(),ref[col].to_numpy()):raise ValueError('Full dev event identity mismatch: '+col)
  met=metrics(frame.label.to_numpy(),frame.probability.to_numpy());frame.to_csv(out/'dev_predictions.csv.gz',index=False,compression='gzip')
  torch.save({'model_state':model.state_dict(),'model':'pykt_dkvmn_full_one_epoch_timing','data_fingerprint':data.fingerprint},out/'model_epoch1.pt')
  summary={'status':'complete','one_epoch_timing_only':True,'test_evaluated':False,'holdout_evaluated':False,
   'train_students':len(train_users),'train_events':train_n,'optimizer_steps':steps,'train_seconds':train_seconds,'train_bce':total/train_n,
   'validation_events':len(frame),'validation_students':int(frame.student_idx.nunique()),'dev_metrics_not_final_comparison':met,'validation_seconds':eval_seconds,
   'upstream_bridge_max_abs':bridge,'chunk_preflight_students':len(sample),'chunk17_max_abs':chunk_diff,'checkpoint_sha256':sha(out/'model_epoch1.pt'),'seconds':time.monotonic()-begin}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-begin);write(out/'status.json',status);print('ONE FULL EPOCH TIMING COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','pilot-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
