"""Chunk-aware adapter around the unmodified pyKT DKVMN module.

The caller owns state and decides which answers are available. No dataset loader
or training/evaluation protocol is implemented here. MIT license for upstream
DKVMN is in LICENSE in this directory.
"""
import torch

def initial_memory(model,batch_size):
    return model.Mv0.unsqueeze(0).expand(batch_size,-1,-1).clone()

def forward_chunk(model,q,answers,active_mask,feedback_mask,state):
    """Predict before feedback, preserve state across chunks, ignore padded rows."""
    if q.ndim!=2 or q.shape!=answers.shape or q.shape!=active_mask.shape or q.shape!=feedback_mask.shape:
        raise ValueError('Input shapes differ')
    if model.emb_type!='qid':raise ValueError('Adapter supports qid only')
    active=active_mask.bool();update=active & feedback_mask.bool()
    # Unavailable answers are replaced before embedding lookup, including sentinels.
    safe_q=torch.where(active,q,torch.zeros_like(q));safe_r=torch.where(update,answers,torch.zeros_like(answers))
    if bool(((safe_q<0)|(safe_q>=model.num_c)).any()) or bool(((safe_r<0)|(safe_r>1)).any()):raise ValueError('Invalid concept or feedback')
    key=model.k_emb_layer(safe_q);value=model.v_emb_layer(safe_q+model.num_c*safe_r)
    weights=torch.softmax(torch.matmul(key,model.Mk.T),dim=-1)
    erase=torch.sigmoid(model.e_layer(value));add=torch.tanh(model.a_layer(value))
    outputs=[]
    for t in range(q.shape[1]):
        wt=weights[:,t];read=(wt.unsqueeze(-1)*state).sum(-2)
        hidden=torch.tanh(model.f_layer(torch.cat([read,key[:,t]],dim=-1)))
        outputs.append(torch.sigmoid(model.p_layer(model.dropout_layer(hidden))).squeeze(-1))
        w=wt.unsqueeze(-1);updated=state*(1-w*erase[:,t].unsqueeze(1))+w*add[:,t].unsqueeze(1)
        state=torch.where(update[:,t,None,None],updated,state)
    if not outputs:raise ValueError('Empty chunk')
    return torch.stack(outputs,dim=1),state
