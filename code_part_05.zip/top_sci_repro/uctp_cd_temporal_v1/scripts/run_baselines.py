"""Compatibility entry point in the NEW project; stage-2 defaults apply."""
from run_temporal_matrix import main

if __name__ == "__main__":
    main()
