import argparse
import json
import platform
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import new_output_dir, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    import numpy as np
    import pandas as pd
    import torch
    from train import choose_device
    device = choose_device(a.device)
    x = torch.ones((32, 32), device=device, requires_grad=True)
    (x @ x).mean().backward()
    if not torch.isfinite(x.grad).all():
        raise RuntimeError("Tensor backward check failed")
    info = {"python": platform.python_version(), "executable": sys.executable,
            "numpy": np.__version__, "pandas": pd.__version__, "torch": str(torch.__version__),
            "cuda_build": torch.version.cuda, "cuda_available": torch.cuda.is_available(),
            "device": str(device), "forward_backward_ok": True,
            "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None}
    out = new_output_dir(a.output_dir)
    write_json(out / "environment.json", info)
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
