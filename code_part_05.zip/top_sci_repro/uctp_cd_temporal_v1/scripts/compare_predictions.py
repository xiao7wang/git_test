import argparse
import sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import new_output_dir, write_json


def main():
    p = argparse.ArgumentParser(description="Check independent evaluation / chunk invariance")
    p.add_argument("--left", required=True)
    p.add_argument("--right", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--atol", type=float, default=1e-6)
    a = p.parse_args()
    if a.atol < 0:
        p.error("atol must be non-negative")
    left, right = [pd.read_csv(path).sort_values("record_idx").reset_index(drop=True) for path in (a.left, a.right)]
    if left.record_idx.duplicated().any() or right.record_idx.duplicated().any():
        raise ValueError("Duplicate event identifiers")
    keys = ["record_idx", "student_idx", "item_idx", "source_row", "split", "label", "timestamp"]
    if not left[keys].equals(right[keys]):
        raise ValueError("Different events, labels or ordering: cannot compare probabilities")
    differences = {}
    for key in ("probability", "uncertainty", "evidence"):
        values = np.abs(left[key].to_numpy()-right[key].to_numpy())
        if not np.isfinite(values).all():
            raise ValueError("Non-finite comparison values")
        differences[key] = float(values.max()) if len(values) else 0
    success = bool(len(left)) and all(value <= a.atol for value in differences.values())
    report = {"success": success, "n": len(left), "atol": a.atol, "max_absolute_difference": differences}
    out = new_output_dir(a.output_dir)
    write_json(out / "comparison.json", report)
    print(report)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
