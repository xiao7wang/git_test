"""Read-only progress: saved 'running' status does not prove a live process."""
import argparse
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import read_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--run-root", required=True)
    a = p.parse_args()
    root = Path(a.run_root)
    plan = read_json(root / "plan.json")
    jobs = {x["name"]: x["returncode"] for x in read_json(root / "jobs.json")} if (root / "jobs.json").exists() else {}
    done = 0
    print(f"{'Run':<35} {'Status':<13} {'Epochs':>6} {'Best':>5} {'Valid AUC':>10} {'Valid NLL':>10}")
    for job in plan:
        name = job["name"]
        if Path(name).name != name:
            raise ValueError("Unexpected run name in plan")
        run = root / name
        status = read_json(run / "status.json") if (run / "status.json").exists() else {}
        history = read_json(run / "history.json") if (run / "history.json").exists() else []
        state = status.get("status", "no_status" if run.exists() else "not_started")
        if jobs.get(name, 0) != 0:
            state = "failed"
        metrics = read_json(run / "validation_metrics.json") if state == "complete" else {}
        fmt = lambda v: "-" if v is None else f"{v:.6f}"
        done += state == "complete"
        print(f"{name:<35} {state:<13} {len(history):>6} {str(status.get('best_epoch', '-')):>5} "
              f"{fmt(metrics.get('auc')):>10} {fmt(metrics.get('nll')):>10}")
    print(f"Completed: {done}/{len(plan)}; running is a saved status, not proof of a live process.")


if __name__ == "__main__":
    main()
