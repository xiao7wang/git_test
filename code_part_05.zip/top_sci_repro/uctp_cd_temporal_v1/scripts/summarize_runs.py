import argparse
from collections import defaultdict
import json
import statistics
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import new_output_dir, read_json, write_json


def main():
    p = argparse.ArgumentParser(description="Summarize completed baseline jobs; reject incomplete/mixed runs")
    p.add_argument("--run-root", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--expected-seeds", type=int, default=3)
    p.add_argument("--view", choices=("valid", "test"), default="valid")
    a = p.parse_args()
    root = Path(a.run_root)
    plan = read_json(root / "plan.json")
    groups = defaultdict(list)
    rows = []
    common_signature = None
    seen_names = set()
    for job in plan:
        if job["name"] in seen_names:
            raise ValueError("Duplicate run in plan")
        seen_names.add(job["name"])
        directory = root / job["name"]
        status = read_json(directory / "status.json")
        if status["status"] != "complete":
            raise ValueError(f"Incomplete job: {directory}")
        config = read_json(directory / "run_config.json")
        metrics = read_json(directory / ("validation_metrics.json" if a.view == "valid" else "test_metrics.json"))
        args = config["args"]
        signature = {key: args[key] for key in ("variant", "time_mode", "decay_rate_per_hour",
                     "epochs", "batch_size", "chunk_size", "eval_chunk_size", "ncd_hidden_dim",
                     "lr", "weight_decay", "patience", "eval_update_targets")}
        signature["view"] = a.view
        signature["data_fingerprint"] = config["data_fingerprint"]
        signature["source_code"] = {k: v for k, v in config["source_code"].items() if k.startswith("src/") or k == "train.py"}
        shared = {k: v for k, v in signature.items() if k not in ("variant", "time_mode", "decay_rate_per_hour")}
        if common_signature is None:
            common_signature = shared
        elif common_signature != shared:
            raise ValueError("Mixed data, core code, or common training protocol across matrix cells")
        key = json.dumps(signature, sort_keys=True)
        row = {"run": job["name"], "variant": args["variant"], "seed": args["seed"],
               "time_mode": args["time_mode"], "decay_rate_per_hour": args["decay_rate_per_hour"],
               "best_epoch": status["best_epoch"], "metrics": metrics}
        rows.append(row)
        groups[key].append(row)
    summary = []
    for key, group in groups.items():
        seeds = [row["seed"] for row in group]
        if len(seeds) != a.expected_seeds or len(set(seeds)) != len(seeds):
            raise ValueError(f"Expected {a.expected_seeds} distinct seeds, found {seeds}")
        result = {"configuration": json.loads(key), "seeds": seeds, "metrics": {}}
        for metric in ("auc", "nll", "brier", "acc", "ece"):
            values = [row["metrics"][metric] for row in group if row["metrics"][metric] is not None]
            result["metrics"][metric] = {"n_seeds_available": len(values),
                                       "mean": statistics.mean(values) if values else None,
                                       "sample_std": statistics.stdev(values) if len(values) > 1 else None}
        summary.append(result)
    out = new_output_dir(a.output_dir)
    write_json(out / "summary.json", {"runs": rows, "groups": summary,
               "note": "Seed standard deviation is not a student-cluster confidence interval or a significance test."})
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
