import argparse
import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, new_output_dir, write_json, source_hashes


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    os.environ["UCTP_TEST_DEVICE"] = a.device
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    import torch
    from train import set_seed
    torch.set_num_threads(1)
    set_seed(0)
    if a.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA tests requested but CUDA is unavailable")
    out = new_output_dir(a.output_dir)
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"), top_level_dir=str(ROOT))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    summary = {"success": result.wasSuccessful() and not result.skipped,
               "tests_run": result.testsRun, "failures": [(str(t), trace) for t, trace in result.failures],
               "errors": [(str(t), trace) for t, trace in result.errors], "skipped": [(str(t), why) for t, why in result.skipped],
               "device": a.device, "torch": str(torch.__version__), "source_code": source_hashes()}
    write_json(out / "test_results.json", summary)
    print(f"Test report: {out / 'test_results.json'}")
    sys.exit(0 if summary["success"] else 1)


if __name__ == "__main__":
    main()
