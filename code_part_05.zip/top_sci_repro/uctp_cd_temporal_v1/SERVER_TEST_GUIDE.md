# 第二阶段服务器测试指南

本轮目标：确认新时间机制的实现、旧基线等价性和分块一致性。不是正式性能实验。
只执行下面的环境检查、单元测试、旧模型桥接和 12 个小样本作业。
不要先跑 full 数据，不改半衰期，不增加模块，不根据 test 指标选模型。

## 0. 新旧目录与基本规则

旧目录：/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research

新目录：/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1

新程序只读旧目录的 data/assist_smoke 和 data/ednet_smoke；不重新准备数据，不复制大数据。
原 baseline 的代码、checkpoint 和结果保留。新结果只写在新项目 outputs 下。
所有命令使用 yydw 的绝对 Python 路径；即使终端显示 (base)，也不会误用 base Python。
不要升级或重新安装已经验证过的环境。

本指南假设 GPU 0 是你获准使用且空闲的 GPU；否则改成实际分配的编号。
每条多行命令请整段复制，行尾反斜线后面不能有空格。不要复制终端提示符或 >。

## 1. 上传和解压

将交付的 uctp_cd_temporal_v1.zip 上传至：

    /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1.zip

在服务器执行：

    if [ -e /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1 ]; then
      printf '%s\n' '新目录已存在，请停止：不要覆盖已有版本或结果。'
    else
      /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e \
        /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1.zip \
        /home/wangxiao/QCCDM/top_sci_repro
    fi

如果提示目录已存在，先核实版本，不要继续执行本指南，也不要删除原目录。
压缩包自带 uctp_cd_temporal_v1 顶层目录，不能解压进同名目录里面再套一层。

## 2. 在 tmux 中运行

    tmux new -s temporal_v1_checks

进入会话后：

    cd /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1
    conda activate yydw
    export CUDA_DEVICE_ORDER=PCI_BUS_ID
    export CUDA_VISIBLE_DEVICES=0
    df -h /home/wangxiao/QCCDM/top_sci_repro
    nvidia-smi

暂时离开：先按 Ctrl+b，松开，再按 d。重新连接：

    tmux attach -t temporal_v1_checks

若提示同名会话已存在，使用 attach，别重复创建训练作业。
不要使用 Ctrl+c 来退出正在训练的会话；那会中断作业。

## 3. 环境、CPU 和 GPU 单元测试

依次执行，上一项通过再执行下一项：

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/check_environment.py \
      --device cuda \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_env_01

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/run_tests.py \
      --device cpu \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_tests_cpu_01

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/run_tests.py \
      --device cuda \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_tests_gpu_01

预期：环境 cuda_available 和 forward_backward_ok 为 true；
CPU、GPU 各 tests_run=68，success=true，failures/errors/skipped 全为空。
若 GPU 测试报错，保留完整输出并发给我，不先改容差或跳过测试。

## 4. 旧 checkpoint 与新 none 模式桥接

这里不训练、不改权重、不重新选模型。把旧 checkpoint 的相同权重分别交给冻结旧模型和新 none 模式，
只比较验证集输出。脚本会先核对旧源码指纹、冻结参考模型和数据指纹。

ASSIST：

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/check_baseline_equivalence.py \
      --checkpoint /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/outputs/server_assist_smoke_seed0/best_model.pt \
      --data-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_smoke \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_assist_bridge_01 \
      --view valid --batch-size 8 --chunk-size 100 --atol 1e-6 \
      --device cuda --ack-row-feedback

EDNet：

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/check_baseline_equivalence.py \
      --checkpoint /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/outputs/server_ednet_smoke_seed0/best_model.pt \
      --data-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/ednet_smoke \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_bridge_01 \
      --view valid --batch-size 8 --chunk-size 100 --atol 1e-6 \
      --device cuda --ack-row-feedback

预期：均 success=true；ASSIST n=338，EDNet n=601；probability、uncertainty、evidence 最大绝对差 ≤1e-6。
这里是 valid，因此不是此前 test 的 737/1243。
如果旧 checkpoint 不在上述位置，只提供其准确路径，不要用新模型覆盖旧文件。
若提示旧源码或数据指纹不同，请保留报错并停止；不要移除指纹检查。

## 5. 两套小样本矩阵：每套 6 个作业

两种写入规则 × 三种时间模式 × seed 0 × 1 epoch。逐个运行。
168 小时为固定工程测试值，不表示已经得到最佳遗忘时间。
none 自动使用零衰减；joint/mass 才使用该半衰期。

先 ASSIST：

    /home/wangxiao/miniconda3/envs/yydw/bin/python -u \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/run_temporal_matrix.py \
      --data-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_smoke \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_assist_smoke_01 \
      --variants dynamic_only unit_write \
      --time-modes none joint mass --seeds 0 \
      --epochs 1 --patience 5 --half-life-hours 168 \
      --batch-size 8 --chunk-size 50 --eval-chunk-size 100 \
      --device cuda --ack-row-feedback --ack-time-proxy

ASSIST 六项全部完成以后再 EDNet：

    /home/wangxiao/miniconda3/envs/yydw/bin/python -u \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/run_temporal_matrix.py \
      --data-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/ednet_smoke \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01 \
      --variants dynamic_only unit_write \
      --time-modes none joint mass --seeds 0 \
      --epochs 1 --patience 5 --half-life-hours 168 \
      --batch-size 8 --chunk-size 50 --eval-chunk-size 100 \
      --device cuda --ack-row-feedback --ack-time-proxy

时间模式含义：

- none：旧基线写入，无时间衰减。
- joint：历史正负证据衰减，动态掌握均值也随之向 0.5 回缩。
- mass：动态掌握均值暂时不变，只降低有效支持量，让后续证据更容易改变状态。

预期每个作业 status=complete，best_epoch=1，test_evaluated=false。
日志最后 test 为 null 是刻意设计，不是评测失败。
默认只生成 validation_metrics.json 等验证文件，没有 test_metrics.json。
这里同时承认逐行即时反馈假设和事件时间代理假设；并没有恢复 EDNet 的真实 bundle 反馈。

## 6. 随时查看进度

ASSIST：

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/show_progress.py \
      --run-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_assist_smoke_01

EDNet：

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/show_progress.py \
      --run-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01

预期每套 Completed: 6/6。running 是保存状态，不足以证明进程仍在运行。
需要确认进程时：

    pgrep -a -u wangxiao -f 'uctp_cd_temporal_v1/(train[.]py|scripts/run_temporal_matrix[.]py)'

例如看 EDNet mass 作业日志：

    tail -n 60 /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01/dynamic_only_mass_seed0.log

日志包含 phase=train、phase=validation、phase=best_checkpoint_validation。
验证阶段可能暂时没有逐 batch 输出。不要只因暂时没有输出就重复启动。

## 7. EDNet mass checkpoint 独立评测与 chunk-size=17 检查

必须先完成第 5 节 EDNet 六个作业。

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/evaluate.py \
      --checkpoint /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01/dynamic_only_mass_seed0/best_model.pt \
      --data-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/ednet_smoke \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_mass_chunk17 \
      --view valid --batch-size 8 --chunk-size 17 \
      --update-targets 1 --device cuda --ack-row-feedback --ack-time-proxy

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/compare_predictions.py \
      --left /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01/dynamic_only_mass_seed0/validation_predictions.csv \
      --right /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_mass_chunk17/predictions.csv \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_mass_chunk_check \
      --atol 1e-6

预期 n=601，success=true，三列最大绝对差 ≤1e-6。
本地已对两个数据集全部 12 个组合检查过，三列差值均为 0；服务器仍需独立确认。

## 8. 汇总验证结果

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/summarize_runs.py \
      --run-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_assist_smoke_01 \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_assist_summary_01 \
      --view valid --expected-seeds 1

    /home/wangxiao/miniconda3/envs/yydw/bin/python \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/scripts/summarize_runs.py \
      --run-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_smoke_01 \
      --output-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_summary_01 \
      --view valid --expected-seeds 1

查看 JSON 是读取文件，不是直接把文件路径当命令执行：

    cat /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1/outputs/server_ednet_summary_01/summary.json

每组只有一个 seed，sample_std=null 正常，不代表零方差。

## 9. 请发回哪些结果

优先发回：

1. server_env_01/environment.json。
2. server_tests_cpu_01/test_results.json 和 server_tests_gpu_01/test_results.json 的 success、tests_run、failures、errors、skipped。
3. 两个 bridge 的 comparison.json 中 success、n、max_absolute_difference。
4. 两套 show_progress 输出，两个 summary.json。
5. server_ednet_mass_chunk_check/comparison.json。
6. 如有失败，对应日志末尾完整 traceback；不要只发最后一句。

需要进一步核查时再提供各 run 的 run_config.json、history.json 和 validation_subgroup_metrics.json。
无需先上传大型 checkpoint 或完整预测 CSV。

到这里停止。通过验收后再冻结 full-data 小规模验证计划和预算。
不能凭 smoke AUC 宣称方法有效，也不要直接重跑此前 18 个正式基线或启动所有新组合。

## 10. 常见安全问题

- 输出目录已存在：这是防覆盖保护。保留旧目录，确认无同名活跃作业后，使用新编号；不要删旧结果。
- 某项失败：矩阵会停止并保留已成功作业。目前不提供断点续训；不要假设重复命令会自动跳过完成项。
- 需要重跑单个失败项：先发日志，确认原因，再用新的输出目录和明确的单作业命令。
- Permission denied：若是直接敲 summary.json 路径，改用 cat；不要 chmod 或 sudo。
- ModuleNotFoundError：核对是否用了本指南的 yydw 绝对 Python 路径，不要先在 base 装依赖。
- 评测提示源码指纹不同：不要绕过检查，先核实上传的版本和 checkpoint 所属项目。
- --ack-time-proxy 不等于反馈时间已验证。相同时间、跨 split 的相同时间组仍是研究协议限制。
- 固定 half-life=168h 仅用于实现检查；今后如调参，只按预先规定的验证集协议，不能用 test 选参。
