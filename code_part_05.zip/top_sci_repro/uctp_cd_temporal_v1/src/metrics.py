"""Binary metrics without a scikit-learn runtime dependency."""
import numpy as np


def compute_metrics(y, p):
    y, p = np.asarray(y, dtype=float), np.asarray(p, dtype=float)
    if y.shape != p.shape or not np.isin(y, [0, 1]).all() or not np.isfinite(p).all():
        raise ValueError("Invalid metric input")
    if ((p < 0) | (p > 1)).any():
        raise ValueError("Probabilities outside [0,1]")
    if not len(y):
        return {"n": 0, **{k: None for k in ("auc", "acc", "f1", "nll", "brier", "rmse", "ece")}}
    order = np.argsort(p, kind="stable")
    _, first, counts = np.unique(p[order], return_index=True, return_counts=True)
    ranks = np.repeat(first + (counts + 1) / 2, counts)
    positives = y.sum()
    negatives = len(y) - positives
    auc = float((ranks[y[order] == 1].sum() - positives*(positives+1)/2) / (positives*negatives)) if positives and negatives else None
    pred = p >= 0.5
    tp, fp, fn = ((pred & (y == 1)).sum(), (pred & (y == 0)).sum(), ((~pred) & (y == 1)).sum())
    clipped = p.clip(1e-7, 1-1e-7)
    brier = float(np.mean((p-y)**2))
    bin_id = np.minimum((p*15).astype(int), 14)
    ece = 0.0
    for i in range(15):
        mask = bin_id == i
        if mask.any():
            ece += float(mask.mean() * abs(p[mask].mean()-y[mask].mean()))
    return {"n": len(y), "auc": auc, "acc": float((pred == y).mean()),
            "f1": float(2*tp/(2*tp+fp+fn)) if 2*tp+fp+fn else 0.0,
            "nll": float(-np.mean(y*np.log(clipped)+(1-y)*np.log1p(-clipped))),
            "brier": brier, "rmse": brier**0.5, "ece": ece}
