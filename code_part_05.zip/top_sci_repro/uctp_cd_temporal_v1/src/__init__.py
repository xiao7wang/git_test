"""Clean dynamic cognitive diagnosis, baseline stage only."""
