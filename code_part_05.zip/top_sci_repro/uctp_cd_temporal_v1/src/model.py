"""Single P/N state extracted from early UCTP dynamic_only.

No time decay, response-time encoder, reliability, dual memory or extra loss.
Shared parameter names intentionally match the legacy reference for equivalence tests.
"""
from dataclasses import dataclass
import torch
from torch import Tensor, nn
import torch.nn.functional as F


class PositiveLinear(nn.Module):
    def __init__(self, in_features, out_features):
        super().__init__()
        raw = float(torch.log(torch.expm1(torch.tensor(0.02))))
        self.raw_weight = nn.Parameter(torch.empty(out_features, in_features).normal_(raw, 0.05))
        self.bias = nn.Parameter(torch.zeros(out_features))

    def forward(self, x):
        return F.linear(x, F.softplus(self.raw_weight), self.bias)


class EvidenceStrength(nn.Module):
    # Preserve the legacy four-input shape: only difficulty is active in this baseline.
    def __init__(self):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(4, 16), nn.GELU(), nn.Linear(16, 1))

    def forward(self, x):
        return F.softplus(self.net(x)).squeeze(-1) + 1e-6


@dataclass
class State:
    positive: Tensor
    negative: Tensor

    def detach(self):
        return State(self.positive.detach(), self.negative.detach())


class CleanCD(nn.Module):
    VARIANTS = ("static", "dynamic_only", "unit_write")

    def __init__(self, num_students, num_items, num_knowledges,
                 variant="dynamic_only", ncd_hidden_dim=128):
        super().__init__()
        if variant not in self.VARIANTS or min(num_students, num_items, num_knowledges) < 1:
            raise ValueError("Invalid variant or empty vocabulary")
        if ncd_hidden_dim < 2:
            raise ValueError("ncd_hidden_dim must be >=2")
        self.variant = variant
        self.num_knowledges = num_knowledges
        self.student_mastery_logit = nn.Embedding(num_students, num_knowledges)
        self.item_difficulty_logit = nn.Embedding(num_items, num_knowledges)
        self.item_discrimination_raw = nn.Embedding(num_items, 1)
        self.item_bias = nn.Embedding(num_items, 1)
        nn.init.normal_(self.student_mastery_logit.weight, 0.0, 0.1)
        nn.init.normal_(self.item_difficulty_logit.weight, 0.0, 0.1)
        nn.init.constant_(self.item_discrimination_raw.weight, 0.5)
        nn.init.zeros_(self.item_bias.weight)
        self.positive_strength = EvidenceStrength()
        self.negative_strength = EvidenceStrength()
        self.raw_dynamic_scale = nn.Parameter(torch.tensor(-1.0))
        self.raw_direct_scale = nn.Parameter(torch.tensor(0.5))
        self.ncd = nn.Sequential(
            PositiveLinear(num_knowledges, ncd_hidden_dim), nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim, ncd_hidden_dim // 2), nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim // 2, 1),
        )
        nn.init.constant_(self.ncd[-1].bias, -0.85)

    def init_state(self, batch_size, device):
        z = torch.zeros(batch_size, self.num_knowledges, device=device)
        return State(z, z.clone())

    def predict(self, state, student_idx, item_idx, q):
        """Before feedback: deliberately has no response/RT argument."""
        alpha = 1 + state.positive.clamp_min(0)
        beta = 1 + state.negative.clamp_min(0)
        return self.predict_from_beta(alpha, beta, student_idx, item_idx, q)

    def predict_from_beta(self, alpha, beta, student_idx, item_idx, q):
        """Shared, unchanged prediction head. Inputs may have alpha/beta < 1."""
        dynamic_mastery = alpha / (alpha + beta)
        base = self.student_mastery_logit(student_idx)
        if self.variant != "static":
            base = base + F.softplus(self.raw_dynamic_scale) * torch.logit(dynamic_mastery.clamp(1e-5, 1-1e-5))
        mastery = torch.sigmoid(base)
        difficulty = torch.sigmoid(self.item_difficulty_logit(item_idx))
        discrimination = F.softplus(self.item_discrimination_raw(item_idx)).squeeze(-1) + 1e-4
        interaction = discrimination.unsqueeze(-1) * (mastery - difficulty) * q
        q_sum = q.sum(-1).clamp_min(1)
        logit = (self.item_bias(item_idx).squeeze(-1)
                 + F.softplus(self.raw_direct_scale) * interaction.sum(-1) / q_sum
                 + self.ncd(interaction).squeeze(-1))
        return {"logit": logit, "probability": torch.sigmoid(logit),
                "uncertainty": (2 / (alpha + beta) * q).sum(-1) / q_sum,
                "evidence": ((alpha + beta - 2) * q).sum(-1) / q_sum,
                "difficulty_scalar": (difficulty * q).sum(-1) / q_sum}

    def observe(self, state, q, label, difficulty_scalar, update_mask):
        """After feedback: only selected observations write into state."""
        if self.variant == "static":
            return state
        increment = self.evidence_increment(q, label, difficulty_scalar, update_mask)
        return State(state.positive + increment.positive, state.negative + increment.negative)

    def evidence_increment(self, q, label, difficulty_scalar, update_mask):
        """Exactly the baseline writing rule; no time, RT, or reliability input."""
        # Inactive/padded labels need not be meaningful; never let NaN * 0 enter state.
        y = torch.where(update_mask, label, torch.zeros_like(label))
        if self.variant == "unit_write":
            positive, negative = y, 1-y
        else:
            zero = torch.zeros_like(difficulty_scalar)
            features = torch.stack([difficulty_scalar, zero, zero, zero], -1)
            positive = y * self.positive_strength(features)
            negative = (1-y) * self.negative_strength(features)
        active_q = q * update_mask.unsqueeze(-1)
        return State(active_q * positive.unsqueeze(-1), active_q * negative.unsqueeze(-1))

    def forward_chunk(self, state, student_idx, item_idx, q, label, active_mask, update_mask=None):
        if item_idx.shape[1] == 0:
            raise ValueError("Empty chunk")
        if update_mask is None:
            update_mask = active_mask
        outputs = {key: [] for key in ("probability", "logit", "uncertainty", "evidence")}
        for t in range(item_idx.shape[1]):
            prediction = self.predict(state, student_idx, item_idx[:, t], q[:, t])
            for key in outputs:
                outputs[key].append(prediction[key])
            state = self.observe(state, q[:, t], label[:, t], prediction["difficulty_scalar"],
                                 active_mask[:, t] & update_mask[:, t])
        return {key: torch.stack(values, 1) for key, values in outputs.items()}, state
