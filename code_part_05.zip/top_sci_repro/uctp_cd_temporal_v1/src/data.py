"""Read-only source ingestion, explicit units, immutable numeric prepared data.

The baseline stores RT/time for traceability but does not fit or consume RT features.
This prevents an unused RT filter or full-training student statistic changing its inputs.
"""
import ast
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd
from .common import ROOT, new_output_dir, read_json, write_json, sha256, source_hashes

SPLITS = ("train", "valid", "test")
RECORD_FIELDS = ("student_idx", "item_idx", "label", "timestamp", "response_time",
                 "rt_valid", "source_row", "split", "delta_t_hours", "delta_t_k_hours",
                 "kc_count_before", "student_count_before")


def timestamp_seconds(series, unit):
    if unit == "datetime":
        parsed = pd.to_datetime(series, errors="coerce", utc=True, format="mixed")
        # Timedelta arithmetic does not assume pandas' datetime resolution is ns.
        return (parsed - pd.Timestamp("1970-01-01", tz="UTC")).dt.total_seconds()
    factors = {"s": 1.0, "ms": 1e3, "us": 1e6, "ns": 1e9}
    if unit not in factors:
        raise ValueError("Explicit timestamp unit required: s/ms/us/ns/datetime")
    return pd.to_numeric(series, errors="coerce") / factors[unit]


@lru_cache(maxsize=100000)
def parse_kcs(text):
    value = str(text).strip()
    values = ast.literal_eval(value) if value.startswith("[") else value.split(",")
    if not isinstance(values, (list, tuple)):
        raise ValueError(f"Invalid knowledge list: {text}")
    result = tuple(sorted(set(str(k).strip() for k in values if str(k).strip())))
    if not result or any(k.lower() in ("nan", "none", "<na>") for k in result):
        raise ValueError("Missing knowledge IDs")
    return result


def load_item_kcs(mapping_path, q_path):
    mapping = read_json(mapping_path)
    q = np.load(q_path, allow_pickle=False)
    if q.ndim != 2 or not np.isin(q, [0, 1]).all() or not (q.sum(1) > 0).all():
        raise ValueError("Q must be finite, binary and have no empty item rows")
    if sorted(mapping.values()) != list(range(len(q))):
        raise ValueError("item_mapping must bijectively cover Q rows")
    return {str(raw): tuple(str(k) for k in np.flatnonzero(q[row])) for raw, row in mapping.items()}


def read_sources(config, split_dir, meta_dir=None):
    sources = []
    lookup = None
    if config["kind"] == "ednet":
        if meta_dir is None:
            raise ValueError("EDNet requires meta_dir containing item_mapping.json and q_matrix.npy")
        paths = [Path(meta_dir) / "item_mapping.json", Path(meta_dir) / "q_matrix.npy"]
        lookup = load_item_kcs(*paths)
        sources.extend(paths)
    parts = []
    for code, split in enumerate(SPLITS):
        path = Path(split_dir) / f"{split}.csv"
        sources.append(path)
        columns = {"student_id": config["student_col"], "item_id": config["item_col"],
                   "label": config["label_col"], "timestamp": config["timestamp_col"]}
        rt_col = config["response_time_col"]
        knowledge_col = config.get("knowledge_col")
        strings = {columns["student_id"]: "string", columns["item_id"]: "string"}
        if knowledge_col:
            strings[knowledge_col] = "string"
        raw = pd.read_csv(path, dtype=strings)
        missing = set(columns.values()) - set(raw.columns)
        if missing:
            raise ValueError(f"{path}: missing required fields {sorted(missing)}")
        frame = raw[list(columns.values())].rename(columns={v: k for k, v in columns.items()}).copy()
        for name in ("student_id", "item_id"):
            if frame[name].isna().any():
                raise ValueError(f"{path}: missing {name}")
            frame[name] = frame[name].astype(str).str.strip()
            if frame[name].isin(["", "nan", "None", "<NA>"]).any():
                raise ValueError(f"{path}: empty {name}")
        frame["label"] = pd.to_numeric(frame["label"], errors="coerce")
        frame["timestamp"] = timestamp_seconds(frame["timestamp"], config["timestamp_unit"])
        if not frame.label.isin([0, 1]).all() or not np.isfinite(frame.timestamp).all():
            raise ValueError(f"{path}: invalid label/timestamp (no silent row deletion)")
        if config["response_time_unit"] not in ("s", "ms"):
            raise ValueError("Explicit response_time_unit s/ms required")
        rt = (pd.to_numeric(raw[rt_col], errors="coerce") if rt_col in raw else pd.Series(np.nan, index=raw.index))
        frame["response_time"] = rt / (1000 if config["response_time_unit"] == "ms" else 1)
        frame["rt_valid"] = np.isfinite(frame.response_time) & (frame.response_time > 0)
        # Preserve the original value; rt_valid determines usability. Never impute or drop.
        if lookup is not None:
            frame["knowledge_ids"] = frame.item_id.map(lookup)
            if frame.knowledge_ids.isna().any():
                raise ValueError(f"{path}: unknown Q mapping")
        else:
            if knowledge_col not in raw or raw[knowledge_col].isna().any():
                raise ValueError(f"{path}: missing knowledge IDs")
            frame["knowledge_ids"] = raw[knowledge_col].map(parse_kcs)
        frame["source_row"] = np.arange(len(frame), dtype=np.int64)
        frame["split"] = code
        parts.append(frame)
    return pd.concat(parts, ignore_index=True), sources


def encode_frame(frame):
    f = frame.sort_values(["student_id", "timestamp", "split", "source_row"], kind="stable").reset_index(drop=True)
    if (f.groupby("student_id", sort=False)["split"].diff().fillna(0) < 0).any():
        raise ValueError("Splits interleave in student time; do not mix the two EDNet split versions")
    conflicts = f.groupby("item_id", sort=False).knowledge_ids.nunique()
    if (conflicts != 1).any():
        raise ValueError("One item maps to inconsistent knowledge sets")
    student_ids = sorted(f.student_id.unique().tolist())
    item_ids = sorted(f.item_id.unique().tolist())
    knowledge_ids = sorted({k for ks in f.knowledge_ids for k in ks})
    students = {key: i for i, key in enumerate(student_ids)}
    items = {key: i for i, key in enumerate(item_ids)}
    kcs = {key: i for i, key in enumerate(knowledge_ids)}
    f["student_idx"] = f.student_id.map(students)
    f["item_idx"] = f.item_id.map(items)
    item_q = np.zeros((len(items), len(kcs)), dtype=np.bool_)
    for row in f[["item_id", "knowledge_ids"]].drop_duplicates("item_id").itertuples(index=False):
        item_q[items[row.item_id], [kcs[k] for k in row.knowledge_ids]] = True
    f["student_count_before"] = f.groupby("student_idx", sort=False).cumcount()
    f["delta_t_hours"] = f.groupby("student_idx", sort=False).timestamp.diff().fillna(0) / 3600
    # Multi-KC metadata is retained; the scalar summaries are diagnostic only in this stage.
    events = f[["student_idx", "timestamp", "knowledge_ids"]].explode("knowledge_ids")
    grouped = events.groupby(["student_idx", "knowledge_ids"], sort=False)
    gaps = grouped.timestamp.diff() / 3600
    gaps = gaps.fillna(pd.Series(f.delta_t_hours.to_numpy()[events.index], index=events.index))
    f["delta_t_k_hours"] = gaps.groupby(level=0).mean()
    f["kc_count_before"] = grouped.cumcount().groupby(level=0).mean()
    arrays = {}
    for name in RECORD_FIELDS:
        dtype = np.float64 if name in ("timestamp", "response_time") else np.float32
        if name in ("student_idx", "item_idx", "split", "student_count_before"):
            dtype = np.int32
        elif name == "source_row":
            dtype = np.int64
        elif name == "rt_valid":
            dtype = np.bool_
        arrays[name] = f[name].to_numpy(dtype=dtype)
    arrays["item_q"] = item_q
    sizes = f.groupby("student_idx", sort=True).size().to_numpy(dtype=np.int64)
    arrays["user_offsets"] = np.r_[0, np.cumsum(sizes)]
    ties = f.groupby(["student_idx", "timestamp"], sort=False).agg(n=("split", "size"), splits=("split", "nunique"))
    summary = {"rows": len(f), "students": len(students), "items": len(items), "knowledges": len(kcs),
               "split_rows": {name: int((f.split == i).sum()) for i, name in enumerate(SPLITS)},
               "rt_unavailable": int((~f.rt_valid).sum()), "removed_rows": 0,
               "max_sequence_length": int(sizes.max()),
               "same_time_groups": int((ties.n > 1).sum()),
               "cross_split_same_time_groups": int((ties.splits > 1).sum()),
               "test_unseen_item_rows": int(((f.split == 2) & ~f.item_id.isin(f.loc[f.split == 0, "item_id"])).sum())}
    vocab = {"student_ids": student_ids, "item_ids": item_ids, "knowledge_ids": knowledge_ids}
    return arrays, vocab, summary


def prepare(config_path, output, split_dir=None, meta_dir=None, max_students=None, sample_seed=2026):
    config = read_json(config_path)
    split_dir = Path(split_dir) if split_dir else ROOT / config["split_dir"]
    meta_dir = Path(meta_dir) if meta_dir else (ROOT / config["meta_dir"] if config.get("meta_dir") else None)
    if Path(output).resolve().exists():
        raise FileExistsError(f"Refusing to overwrite prepared data: {output}")
    f, paths = read_sources(config, split_dir, meta_dir)
    full_rows = len(f)
    if max_students is not None:
        if max_students < 1:
            raise ValueError("max_students must be positive")
        ids = np.array(sorted(f.student_id.unique()))
        selected = np.random.default_rng(sample_seed).permutation(ids)[:max_students]
        f = f[f.student_id.isin(selected)].copy()
    arrays, vocab, summary = encode_frame(f)
    if any(count == 0 for count in summary["split_rows"].values()):
        raise ValueError("Each split must have at least one observation")
    output = new_output_dir(output)
    np.savez_compressed(output / "records.npz", **arrays)
    write_json(output / "vocabulary.json", vocab)
    manifest = {"schema_version": 1, "stage": "clean_baseline", "dataset": config["kind"],
                "config": config, "summary": summary, "full_source_rows": full_rows,
                "max_students": max_students, "sample_seed": sample_seed,
                "feedback_protocol": "row_immediate_assumption",
                "feedback_boundaries_verified": False,
                "vocabulary_policy": "label-free union of selected train/valid/test IDs",
                "rt_policy": "retain all responses; mark RT unavailable; baseline ignores RT",
                "rt_residual_fitted": False, "prior_cache_loaded": False,
                "sources": [{"path": str(p.resolve()), "sha256": sha256(p)} for p in paths],
                "records_sha256": sha256(output / "records.npz"),
                "vocabulary_sha256": sha256(output / "vocabulary.json"), "source_code": source_hashes()}
    write_json(output / "manifest.json", manifest)
    return manifest


class PreparedData:
    def __init__(self, path):
        self.path = Path(path)
        self.manifest = read_json(self.path / "manifest.json")
        if self.manifest["schema_version"] != 1:
            raise ValueError("Unsupported data schema")
        for name, key in (("records.npz", "records_sha256"), ("vocabulary.json", "vocabulary_sha256")):
            if sha256(self.path / name) != self.manifest[key]:
                raise ValueError(f"Prepared data changed: {name}")
        with np.load(self.path / "records.npz", allow_pickle=False) as archive:
            self.arrays = {key: archive[key] for key in archive.files}
        self.vocab = read_json(self.path / "vocabulary.json")
        self.fingerprint = sha256(self.path / "manifest.json")

    def batches(self, view, batch_size, shuffle_seed=None):
        if batch_size < 1 or view not in SPLITS:
            raise ValueError("Invalid batch size/view")
        code = SPLITS.index(view)
        offsets = self.arrays["user_offsets"]
        users = np.arange(len(offsets)-1)
        if shuffle_seed is not None:
            np.random.default_rng(shuffle_seed).shuffle(users)
        for start in range(0, len(users), batch_size):
            chosen = users[start:start+batch_size]
            sequences = []
            for u in chosen:
                idx = np.arange(offsets[u], offsets[u+1])
                sequences.append(idx[self.arrays["split"][idx] <= code])
            if any(len(x) for x in sequences):
                yield chosen, sequences

    def chunks(self, users, sequences, view, chunk_size, device):
        import torch
        if chunk_size < 1:
            raise ValueError("chunk_size must be positive")
        for start in range(0, max(map(len, sequences)), chunk_size):
            width = min(chunk_size, max(map(len, sequences))-start)
            indices = np.full((len(users), width), -1, dtype=np.int64)
            for b, seq in enumerate(sequences):
                segment = seq[start:start+width]
                indices[b, :len(segment)] = segment
            active = indices >= 0
            safe = np.maximum(indices, 0)
            item = self.arrays["item_idx"][safe]
            q = self.arrays["item_q"][item].astype(np.float32) * active[..., None]
            batch = {"student_idx": torch.as_tensor(users, dtype=torch.long, device=device),
                     "item_idx": torch.as_tensor(item, dtype=torch.long, device=device),
                     "q": torch.as_tensor(q, device=device),
                     "label": torch.as_tensor(self.arrays["label"][safe], device=device),
                     # Keep Unix seconds in float64: float32 erases short real gaps.
                     "timestamp": torch.as_tensor(self.arrays["timestamp"][safe], dtype=torch.float64, device=device),
                     "active_mask": torch.as_tensor(active, device=device),
                     "target_mask": torch.as_tensor(active & (self.arrays["split"][safe] == SPLITS.index(view)), device=device)}
            yield batch, indices
