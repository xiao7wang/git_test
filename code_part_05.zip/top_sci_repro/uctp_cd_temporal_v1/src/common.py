import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, value):
    # Strict JSON: callers represent unavailable metrics with None, not NaN.
    with open(path, "w", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)


def read_json(path):
    with open(path, encoding="utf-8") as stream:
        return json.load(stream)


def new_output_dir(path):
    """Only new directories inside this independent project; no --force mode."""
    target = Path(path).resolve()
    if not target.is_relative_to(ROOT) or target == ROOT:
        raise ValueError(f"Output must be a NEW subdirectory of {ROOT}")
    target.mkdir(parents=True, exist_ok=False)
    return target


def source_hashes():
    files = list((ROOT / "src").glob("*.py")) + list(ROOT.glob("*.py"))
    files += list((ROOT / "scripts").glob("*.py"))
    return {str(p.relative_to(ROOT)).replace("\\", "/"): sha256(p) for p in sorted(files)}
