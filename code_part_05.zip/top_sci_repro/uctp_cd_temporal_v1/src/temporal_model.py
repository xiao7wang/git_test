"""Three fixed-rate temporal interventions with identical learned parameters.

none: baseline P/N state; joint: decay P/N before prediction.
mass: scale alpha/beta to shrink their total toward 2, preserving their ratio.
Mass alpha/beta can be below 1. Never convert to nonnegative P/N or clip them.
Clocks are lazy per-KC, advance on queries even without feedback, and survive chunks.
"""
from dataclasses import dataclass
import math
from typing import Union
import torch
from torch import Tensor
from .model import CleanCD, State


@dataclass
class BetaEvidence:
    alpha: Tensor
    beta: Tensor

    def detach(self):
        return BetaEvidence(self.alpha.detach(), self.beta.detach())


@dataclass
class Clock:
    last_kc_seconds: Tensor
    seen_kc: Tensor
    last_event_seconds: Tensor
    seen_event: Tensor

    def detach(self):
        return Clock(*(x.detach() for x in (
            self.last_kc_seconds, self.seen_kc, self.last_event_seconds, self.seen_event)))


@dataclass
class TemporalState:
    evidence: Union[State, BetaEvidence]
    clock: Clock

    def detach(self):
        return TemporalState(self.evidence.detach(), self.clock.detach())


class TemporalCD(CleanCD):
    TIME_MODES = ("none", "joint", "mass")
    uses_timestamps = True

    def __init__(self, num_students, num_items, num_knowledges,
                 variant="dynamic_only", ncd_hidden_dim=128,
                 time_mode="none", decay_rate_per_hour=0.0):
        rate = float(decay_rate_per_hour)
        if time_mode not in self.TIME_MODES or not math.isfinite(rate) or rate < 0:
            raise ValueError("Invalid time mode or finite nonnegative decay rate")
        if time_mode == "none" and rate != 0:
            raise ValueError("none requires decay_rate_per_hour=0")
        if variant == "static" and time_mode != "none":
            raise ValueError("Temporal interventions require a dynamic writing rule")
        super().__init__(num_students, num_items, num_knowledges, variant, ncd_hidden_dim)
        self.time_mode, self.decay_rate_per_hour = time_mode, rate
        # Zero-rate paths deliberately retain exact baseline accumulation arithmetic.
        self.mass_representation = time_mode == "mass" and rate > 0

    def init_state(self, batch_size, device):
        evidence = super().init_state(batch_size, device)
        if self.mass_representation:
            evidence = BetaEvidence(torch.ones_like(evidence.positive),
                                    torch.ones_like(evidence.negative))
        clock = Clock(
            torch.zeros((batch_size, self.num_knowledges), dtype=torch.float64, device=device),
            torch.zeros((batch_size, self.num_knowledges), dtype=torch.bool, device=device),
            torch.zeros(batch_size, dtype=torch.float64, device=device),
            torch.zeros(batch_size, dtype=torch.bool, device=device))
        return TemporalState(evidence, clock)

    @staticmethod
    def components(state):
        """Return dynamic mean and effective total support (not calibrated confidence)."""
        if isinstance(state.evidence, BetaEvidence):
            alpha, beta = state.evidence.alpha, state.evidence.beta
        else:
            alpha = 1 + state.evidence.positive
            beta = 1 + state.evidence.negative
        return alpha / (alpha + beta), alpha + beta

    def predict(self, state, student_idx, item_idx, q):
        if isinstance(state.evidence, BetaEvidence):
            return self.predict_from_beta(state.evidence.alpha, state.evidence.beta,
                                          student_idx, item_idx, q)
        return super().predict(state.evidence, student_idx, item_idx, q)

    @staticmethod
    def _validate_times(clock, timestamps, active):
        if timestamps is None or timestamps.dtype != torch.float64:
            raise ValueError("timestamp must be float64 Unix seconds, not float32")
        if timestamps.shape != active.shape or timestamps.ndim != 2:
            raise ValueError("timestamp and active_mask must have the same [B,T] shape")
        if not bool(torch.isfinite(timestamps[active]).all()):
            raise ValueError("Active timestamp is missing or non-finite")
        masked = torch.where(active, timestamps, -torch.inf)
        prior = torch.where(clock.seen_event, clock.last_event_seconds, -torch.inf)
        running = torch.cummax(torch.cat((prior[:, None], masked), dim=1), dim=1).values
        if bool((active & (timestamps < running[:, :-1])).any()):
            raise ValueError("Student timestamps decreased, including across chunks")

    def advance_time(self, state, q, timestamp, active_mask):
        """Public single-step forecast. No label/RT argument and no evidence writing."""
        self._validate_times(state.clock, timestamp[:, None], active_mask[:, None])
        return self._advance_time_unchecked(state, q, timestamp, active_mask)

    def _advance_time_unchecked(self, state, q, timestamp, active_mask):
        clock, evidence = state.clock, state.evidence
        now = torch.where(active_mask, timestamp, clock.last_event_seconds)
        selected = active_mask[:, None] & (q > 0)
        elapsed = torch.where(selected & clock.seen_kc,
                              (now[:, None] - clock.last_kc_seconds) / 3600.0, 0.0)
        if self.decay_rate_per_hour > 0:
            decay = torch.exp(-self.decay_rate_per_hour * elapsed).to(q.dtype)
            changed = selected & clock.seen_kc & (elapsed > 0)
            if isinstance(evidence, BetaEvidence):
                total = evidence.alpha + evidence.beta
                next_total = 2.0 + (total - 2.0) * decay
                factor = next_total / total
                evidence = BetaEvidence(
                    torch.where(changed, evidence.alpha * factor, evidence.alpha),
                    torch.where(changed, evidence.beta * factor, evidence.beta))
            else:
                evidence = State(
                    torch.where(changed, evidence.positive * decay, evidence.positive),
                    torch.where(changed, evidence.negative * decay, evidence.negative))
        next_clock = Clock(
            torch.where(selected, now[:, None], clock.last_kc_seconds),
            clock.seen_kc | selected, now, clock.seen_event | active_mask)
        return TemporalState(evidence, next_clock)

    def observe(self, state, q, label, difficulty_scalar, update_mask):
        if isinstance(state.evidence, BetaEvidence):
            increment = self.evidence_increment(q, label, difficulty_scalar, update_mask)
            evidence = BetaEvidence(state.evidence.alpha + increment.positive,
                                    state.evidence.beta + increment.negative)
        else:
            evidence = super().observe(state.evidence, q, label, difficulty_scalar, update_mask)
        return TemporalState(evidence, state.clock)

    def forward_chunk(self, state, student_idx, item_idx, q, label, active_mask,
                      update_mask=None, timestamp=None):
        if item_idx.shape[1] == 0:
            raise ValueError("Empty chunk")
        self._validate_times(state.clock, timestamp, active_mask)
        if update_mask is None:
            update_mask = active_mask
        outputs = {key: [] for key in ("probability", "logit", "uncertainty", "evidence")}
        for t in range(item_idx.shape[1]):
            state = self._advance_time_unchecked(state, q[:, t], timestamp[:, t], active_mask[:, t])
            prediction = self.predict(state, student_idx, item_idx[:, t], q[:, t])
            for key in outputs:
                outputs[key].append(prediction[key])
            state = self.observe(state, q[:, t], label[:, t], prediction["difficulty_scalar"],
                                 active_mask[:, t] & update_mask[:, t])
        return {key: torch.stack(values, 1) for key, values in outputs.items()}, state
