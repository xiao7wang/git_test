import time
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from .metrics import compute_metrics


def forward(model, state, batch, update_targets=True):
    update = batch["active_mask"] & (~batch["target_mask"] | update_targets)
    temporal = {"timestamp": batch["timestamp"]} if getattr(model, "uses_timestamps", False) else {}
    return model.forward_chunk(state, batch["student_idx"], batch["item_idx"], batch["q"],
                               batch["label"], batch["active_mask"], update, **temporal)


def train_epoch(model, data, optimizer, device, batch_size, chunk_size, seed, grad_clip=5):
    model.train()
    loss_sum, observations, steps = 0.0, 0, 0
    started = time.perf_counter()
    for batch_no, (users, sequences) in enumerate(data.batches("train", batch_size, seed), 1):
        state = model.init_state(len(users), device)
        for batch, _ in data.chunks(users, sequences, "train", chunk_size, device):
            optimizer.zero_grad(set_to_none=True)
            outputs, state = forward(model, state, batch)
            mask = batch["target_mask"]
            count = int(mask.sum().item())
            if count:
                loss = F.binary_cross_entropy(outputs["probability"][mask].clamp(1e-6, 1-1e-6), batch["label"][mask])
                if not torch.isfinite(loss):
                    raise FloatingPointError("Non-finite training loss")
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip, error_if_nonfinite=True)
                optimizer.step()
                loss_sum += loss.item()*count
                observations += count
                steps += 1
            state = state.detach()
        if batch_no % 100 == 0:
            print(f"  batch={batch_no} seen={observations} mean_bce={loss_sum/max(observations,1):.6f}", flush=True)
    return {"bce": loss_sum/observations if observations else None, "n": observations,
            "optimizer_steps": steps, "seconds": time.perf_counter()-started}


@torch.no_grad()
def evaluate(model, data, device, view="test", batch_size=8, chunk_size=100, update_targets=True):
    model.eval()
    records = []
    started = time.perf_counter()
    for users, sequences in data.batches(view, batch_size):
        state = model.init_state(len(users), device)
        for batch, indices in data.chunks(users, sequences, view, chunk_size, device):
            outputs, state = forward(model, state, batch, update_targets)
            mask = batch["target_mask"].cpu().numpy()
            if not mask.any():
                continue
            record_idx = indices[mask]
            columns = {name: data.arrays[name][record_idx] for name in (
                "student_idx", "item_idx", "label", "source_row", "split", "timestamp",
                "response_time", "rt_valid", "delta_t_hours", "delta_t_k_hours", "kc_count_before", "student_count_before")}
            columns["record_idx"] = record_idx
            for key in ("probability", "uncertainty", "evidence"):
                columns[key] = outputs[key].cpu().numpy()[mask]
            records.append(pd.DataFrame(columns))
    if not records:
        raise ValueError(f"No target observations in {view}")
    frame = pd.concat(records, ignore_index=True).sort_values("record_idx").reset_index(drop=True)
    metrics = compute_metrics(frame.label.to_numpy(), frame.probability.to_numpy())
    metrics["seconds"] = time.perf_counter()-started
    metrics["update_targets"] = bool(update_targets)
    groups = {}
    for name, mask in {"same_kc_gap_gt7days": frame.delta_t_k_hours > 168,
                       "rt_unavailable": ~frame.rt_valid,
                       "first_10_events": frame.student_count_before < 10}.items():
        subset = frame.loc[mask]
        groups[name] = compute_metrics(subset.label.to_numpy(), subset.probability.to_numpy())
        groups[name]["students"] = int(subset.student_idx.nunique())
    return metrics, frame, groups
