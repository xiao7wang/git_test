import argparse
import json
from src.data import prepare


def main():
    p = argparse.ArgumentParser(description="Prepare immutable baseline data; never overwrite sources")
    p.add_argument("--config", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--split-dir")
    p.add_argument("--meta-dir")
    p.add_argument("--max-students", type=int)
    p.add_argument("--sample-seed", type=int, default=2026)
    args = p.parse_args()
    manifest = prepare(args.config, args.output_dir, args.split_dir, args.meta_dir,
                       args.max_students, args.sample_seed)
    print(json.dumps(manifest["summary"], indent=2))
    print("Prepared successfully. Feedback boundaries remain unverified; row-immediate assumption only.")


if __name__ == "__main__":
    main()
