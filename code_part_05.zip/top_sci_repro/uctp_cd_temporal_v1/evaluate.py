import argparse
import os
from pathlib import Path
import torch
from src.common import new_output_dir, write_json, source_hashes, sha256
from src.data import PreparedData
from src.temporal_model import TemporalCD
from src.engine import evaluate
from train import choose_device, set_seed


def main():
    p = argparse.ArgumentParser(description="Evaluate without refitting or overwriting data/checkpoint")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--view", choices=("valid", "test"), default="valid")
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=100)
    p.add_argument("--update-targets", type=int, choices=(0, 1), default=1)
    p.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--ack-row-feedback", action="store_true")
    p.add_argument("--ack-time-proxy", action="store_true")
    p.add_argument("--ack-test-evaluation", action="store_true")
    a = p.parse_args()
    if not a.ack_row_feedback:
        p.error("--ack-row-feedback required; feedback groups remain unverified")
    if min(a.batch_size, a.chunk_size, a.threads) < 1:
        p.error("batch/chunk/threads must be positive")
    if a.view == "test" and not a.ack_test_evaluation:
        p.error("Test evaluation requires --ack-test-evaluation; development uses valid")
    if Path(a.output_dir).resolve().exists():
        raise FileExistsError("Refusing to overwrite evaluation output")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(a.threads)
    set_seed(0)
    device = choose_device(a.device)
    data = PreparedData(a.data_dir)
    ckpt = torch.load(a.checkpoint, map_location=device, weights_only=True)
    if ckpt.get("model_family") != "temporal_v1":
        raise ValueError("Legacy checkpoint: use the frozen project or scripts/check_baseline_equivalence.py")
    if ckpt["model_config"]["time_mode"] != "none" and not a.ack_time_proxy:
        p.error("--ack-time-proxy required for temporal checkpoint")
    if ckpt["data_fingerprint"] != data.fingerprint:
        raise ValueError("Dataset/metadata do not match the checkpoint; do not rebuild preprocessing for evaluation")
    for name, digest in source_hashes().items():
        if name.startswith("src/") and ckpt["source_code"].get(name) != digest:
            raise ValueError(f"Evaluation code differs from training: {name}")
    model = TemporalCD(**ckpt["model_config"]).to(device)
    model.load_state_dict(ckpt["model_state"], strict=True)
    out = new_output_dir(a.output_dir)
    metrics, frame, groups = evaluate(model, data, device, a.view, a.batch_size, a.chunk_size, bool(a.update_targets))
    frame.to_csv(out / "predictions.csv", index=False)
    write_json(out / "metrics.json", metrics)
    write_json(out / "subgroup_metrics.json", groups)
    write_json(out / "evaluation.json", {"args": vars(a), "epoch": ckpt["epoch"], "data_fingerprint": data.fingerprint,
               "checkpoint_sha256": sha256(a.checkpoint), "source_code": source_hashes()})
    print(metrics)


if __name__ == "__main__":
    main()
