import unittest
from src.metrics import compute_metrics


class MetricTests(unittest.TestCase):
    def test_perfect_auc(self):
        self.assertEqual(compute_metrics([0, 1, 0, 1], [0.1, .8, .2, .9])["auc"], 1)

    def test_tied_auc(self):
        self.assertEqual(compute_metrics([0, 1, 1, 0], [.5]*4)["auc"], .5)

    def test_known_auc(self):
        self.assertEqual(compute_metrics([0, 0, 1, 1], [.1, .4, .35, .8])["auc"], .75)

    def test_single_class_and_empty(self):
        self.assertIsNone(compute_metrics([1, 1], [.5, .6])["auc"])
        self.assertEqual(compute_metrics([], [])["n"], 0)

    def test_invalid_probability_rejected(self):
        with self.assertRaises(ValueError):
            compute_metrics([1], [float("nan")])

    def test_brier(self):
        self.assertAlmostEqual(compute_metrics([0, 1], [.2, .7])["brier"], .065)
