import inspect
import math
import os
import unittest
import numpy as np
import torch
from src.model import CleanCD, State
from src.temporal_model import TemporalCD, BetaEvidence
from src.data import PreparedData, encode_frame
from src.engine import evaluate, forward
from tests.test_data import frame
from tests.test_model import example
from tests.fixtures.frozen_clean_model import CleanCD as FrozenCleanCD

DEVICE = torch.device(os.environ.get("UCTP_TEST_DEVICE", "cpu"))


def times():
    return torch.tensor([[1700000000., 1700000000.125, 1700003600., 1700007200., 1700010800.],
                         [1700000000., 1700000100., 1700007200., float("nan"), float("nan")]],
                        dtype=torch.float64, device=DEVICE)


class TemporalTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(19)
        self.x = example()

    def model(self, mode="mass", rate=math.log(2), variant="unit_write"):
        return TemporalCD(2, 3, 2, variant=variant, ncd_hidden_dim=16,
                          time_mode=mode, decay_rate_per_hour=rate).to(DEVICE)

    def run_model(self, model, x=None, timestamp=None, update=None):
        return model.forward_chunk(model.init_state(2, DEVICE), *(self.x if x is None else x),
                                   timestamp=times() if timestamp is None else timestamp,
                                   update_mask=update)

    def seeded(self, model):
        state = model.init_state(2, DEVICE)
        if isinstance(state.evidence, BetaEvidence):
            state.evidence.alpha.fill_(9)
            state.evidence.beta.fill_(1)
        else:
            state.evidence.positive.fill_(8)
        state.clock.seen_kc.fill_(True)
        state.clock.seen_event.fill_(True)
        return state

    def forecast(self, model, state, hours, q=None, active=None):
        return model.advance_time(
            state, torch.ones((2, 2), device=DEVICE) if q is None else q,
            torch.full((2,), hours*3600, dtype=torch.float64, device=DEVICE),
            torch.ones(2, dtype=torch.bool, device=DEVICE) if active is None else active)

    def test_none_exact_reference_predictions_states_gradients_all_writes(self):
        for variant in ("static", "unit_write", "dynamic_only"):
            with self.subTest(variant=variant):
                old = FrozenCleanCD(2, 3, 2, variant=variant, ncd_hidden_dim=16).to(DEVICE)
                new = self.model("none", 0, variant)
                new.load_state_dict(old.state_dict(), strict=True)
                before, end = old.forward_chunk(old.init_state(2, DEVICE), *self.x)
                after, state = self.run_model(new)
                for key in before:
                    torch.testing.assert_close(before[key], after[key], rtol=0, atol=0)
                torch.testing.assert_close(end.positive, state.evidence.positive, rtol=0, atol=0)
                torch.testing.assert_close(end.negative, state.evidence.negative, rtol=0, atol=0)
                before["probability"].sum().backward()
                after["probability"].sum().backward()
                for (name, p), (other_name, other) in zip(old.named_parameters(), new.named_parameters()):
                    self.assertEqual(name, other_name)
                    if p.grad is None:
                        self.assertIsNone(other.grad)
                    else:
                        torch.testing.assert_close(p.grad, other.grad, rtol=0, atol=0)

    def test_zero_rate_joint_and_mass_exact_none(self):
        base = self.model("none", 0, "dynamic_only")
        expected, _ = self.run_model(base)
        for mode in ("joint", "mass"):
            candidate = self.model(mode, 0, "dynamic_only")
            candidate.load_state_dict(base.state_dict())
            actual, _ = self.run_model(candidate)
            for key in expected:
                torch.testing.assert_close(expected[key], actual[key], rtol=0, atol=0)

    def test_no_added_learnable_parameters_or_rng_consumption(self):
        for mode, rate in (("none", 0), ("joint", 0.2), ("mass", 0.2)):
            torch.manual_seed(123)
            old = FrozenCleanCD(2, 3, 2, ncd_hidden_dim=16).to(DEVICE)
            torch.manual_seed(123)
            new = self.model(mode, rate, "dynamic_only")
            self.assertEqual(list(old.state_dict()), list(new.state_dict()))
            for key in old.state_dict():
                torch.testing.assert_close(old.state_dict()[key], new.state_dict()[key], rtol=0, atol=0)

    def test_known_joint_example(self):
        model = self.model("joint")
        state = self.forecast(model, self.seeded(model), 2)
        mean, support = model.components(state)
        torch.testing.assert_close(mean, torch.full_like(mean, .75))
        torch.testing.assert_close(support, torch.full_like(support, 4))
        state = model.observe(state, torch.ones((2, 2), device=DEVICE), torch.zeros(2, device=DEVICE),
                              torch.full((2,), .5, device=DEVICE), torch.ones(2, dtype=torch.bool, device=DEVICE))
        torch.testing.assert_close(model.components(state)[0], torch.full_like(mean, .6))

    def test_known_mass_example_and_wrong_feedback(self):
        model = self.model("mass")
        state = self.forecast(model, self.seeded(model), 2)
        mean, support = model.components(state)
        torch.testing.assert_close(mean, torch.full_like(mean, .9))
        torch.testing.assert_close(support, torch.full_like(support, 4))
        self.assertTrue(bool((state.evidence.beta < 1).all()))
        state = model.observe(state, torch.ones((2, 2), device=DEVICE), torch.zeros(2, device=DEVICE),
                              torch.full((2,), .5, device=DEVICE), torch.ones(2, dtype=torch.bool, device=DEVICE))
        torch.testing.assert_close(model.components(state)[0], torch.full_like(mean, .72))

    def test_mass_correct_feedback_moves_up_faster(self):
        model = self.model("mass")
        state = self.forecast(model, self.seeded(model), 2)
        state = model.observe(state, torch.ones((2, 2), device=DEVICE), torch.ones(2, device=DEVICE),
                              torch.full((2,), .5, device=DEVICE), torch.ones(2, dtype=torch.bool, device=DEVICE))
        mean, support = model.components(state)
        torch.testing.assert_close(mean, torch.full_like(mean, .92))
        torch.testing.assert_close(support, torch.full_like(support, 5))

    def test_large_gap_mass_floor_preserves_mean_not_clipped_pn(self):
        model = self.model("mass")
        state = self.forecast(model, self.seeded(model), 1e8)
        mean, support = model.components(state)
        torch.testing.assert_close(mean, torch.full_like(mean, .9))
        torch.testing.assert_close(support, torch.full_like(support, 2))
        self.assertTrue(bool((state.evidence.beta < 1).all()))

    def test_mass_gap_changes_support_not_current_prediction(self):
        model = self.model("mass")
        a = self.forecast(model, self.seeded(model), 0)
        b = self.forecast(model, self.seeded(model), 10)
        users, items, q, _, _ = self.x
        pa = model.predict(a, users, items[:, 0], q[:, 0])
        pb = model.predict(b, users, items[:, 0], q[:, 0])
        torch.testing.assert_close(pa["probability"], pb["probability"], rtol=1e-6, atol=1e-7)
        self.assertTrue(bool((model.components(b)[1] < model.components(a)[1]).all()))

    def test_joint_does_change_current_prediction(self):
        model = self.model("joint")
        a = self.forecast(model, self.seeded(model), 0)
        b = self.forecast(model, self.seeded(model), 10)
        users, items, q, _, _ = self.x
        pa = model.predict(a, users, items[:, 0], q[:, 0])["probability"]
        pb = model.predict(b, users, items[:, 0], q[:, 0])["probability"]
        self.assertGreater(float((pa-pb).abs().max().detach()), 0)

    def test_zero_gap_exact_noop(self):
        for mode in ("joint", "mass"):
            model = self.model(mode)
            original = self.seeded(model)
            after = self.forecast(model, original, 0)
            for a, b in zip(model.components(original), model.components(after)):
                torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_forecast_semigroup_and_no_double_decay(self):
        for mode in ("joint", "mass"):
            model = self.model(mode)
            state = self.seeded(model)
            direct = self.forecast(model, state, 3)
            twice = self.forecast(model, self.forecast(model, state, 1), 3)
            for a, b in zip(model.components(direct), model.components(twice)):
                torch.testing.assert_close(a, b)
            again = self.forecast(model, twice, 3)
            for a, b in zip(model.components(twice), model.components(again)):
                torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_multikc_has_separate_clocks_not_average_gap(self):
        model = self.model("joint")
        state = self.seeded(model)
        state.clock.last_kc_seconds[:, 1] = 3600
        state.clock.last_event_seconds.fill_(3600)
        state = self.forecast(model, state, 3)
        torch.testing.assert_close(state.evidence.positive[:, 0], torch.ones(2, device=DEVICE))
        torch.testing.assert_close(state.evidence.positive[:, 1], torch.full((2,), 2., device=DEVICE))

    def test_unqueried_kc_unchanged_then_lazy_decay_correct(self):
        model = self.model("joint")
        state = self.seeded(model)
        q = torch.tensor([[1., 0], [1, 0]], device=DEVICE)
        state = self.forecast(model, state, 1, q)
        torch.testing.assert_close(state.evidence.positive[:, 1], torch.full((2,), 8., device=DEVICE))
        self.assertEqual(float(state.clock.last_kc_seconds[0, 1]), 0)
        state = self.forecast(model, state, 2, 1-q)
        torch.testing.assert_close(state.evidence.positive[:, 1], torch.full((2,), 2., device=DEVICE))

    def test_first_visit_has_no_invented_gap(self):
        for mode in ("joint", "mass"):
            model = self.model(mode)
            before = model.init_state(2, DEVICE)
            after = self.forecast(model, before, 1e8)
            for a, b in zip(model.components(before), model.components(after)):
                torch.testing.assert_close(a, b, rtol=0, atol=0)

    def test_current_and_future_labels_cannot_change_current_or_past(self):
        for mode in ("none", "joint", "mass"):
            model = self.model(mode, 0 if mode == "none" else .1, "dynamic_only")
            original, _ = self.run_model(model)
            for position in (1, 3):
                x = list(self.x)
                x[3] = x[3].clone()
                x[3][0, position:] = 1-x[3][0, position:]
                changed, _ = self.run_model(model, tuple(x))
                torch.testing.assert_close(original["probability"][:, :position+1],
                                           changed["probability"][:, :position+1], rtol=0, atol=0)

    def test_future_timestamp_cannot_change_past(self):
        for mode in ("joint", "mass"):
            model = self.model(mode)
            original, _ = self.run_model(model)
            ts = times()
            ts[0, 4] += 999999
            changed, _ = self.run_model(model, timestamp=ts)
            torch.testing.assert_close(original["probability"][:, :4],
                                       changed["probability"][:, :4], rtol=0, atol=0)

    def test_whole_and_chunked_predictions_and_clocks_exact(self):
        for mode in ("none", "joint", "mass"):
            for variant in ("unit_write", "dynamic_only"):
                model = self.model(mode, 0 if mode == "none" else .1, variant)
                whole, end = self.run_model(model)
                state, outputs = model.init_state(2, DEVICE), []
                users, items, q, y, active = self.x
                for lo, hi in ((0, 1), (1, 3), (3, 5)):
                    out, state = model.forward_chunk(state, users, items[:, lo:hi], q[:, lo:hi],
                                                     y[:, lo:hi], active[:, lo:hi],
                                                     timestamp=times()[:, lo:hi])
                    outputs.append(out)
                    state = state.detach()
                for key in whole:
                    torch.testing.assert_close(whole[key], torch.cat([x[key] for x in outputs], 1), rtol=0, atol=0)
                for a, b in zip(model.components(end), model.components(state)):
                    torch.testing.assert_close(a, b, rtol=0, atol=0)
                torch.testing.assert_close(end.clock.last_kc_seconds, state.clock.last_kc_seconds)

    def test_frozen_writes_still_advance_time(self):
        model = self.model("mass")
        state = self.seeded(model)
        ts = torch.full((2, 1), 7200., dtype=torch.float64, device=DEVICE)
        users, items, q, y, active = self.x
        _, state = model.forward_chunk(state, users, items[:, :1], torch.ones((2, 1, 2), device=DEVICE),
                                       y[:, :1], active[:, :1], update_mask=torch.zeros((2, 1), dtype=torch.bool, device=DEVICE),
                                       timestamp=ts)
        mean, support = model.components(state)
        torch.testing.assert_close(mean, torch.full_like(mean, .9))
        torch.testing.assert_close(support, torch.full_like(support, 4))
        torch.testing.assert_close(state.clock.last_kc_seconds, torch.full_like(state.clock.last_kc_seconds, 7200))

    def test_padding_nan_time_and_label_do_not_touch_state(self):
        for mode in ("joint", "mass"):
            model = self.model(mode)
            state = self.seeded(model)
            users, items, q, y, active = self.x
            _, after = model.forward_chunk(state, users, items[:, :1], q[:, :1],
                                           torch.full((2, 1), float("nan"), device=DEVICE),
                                           torch.zeros((2, 1), dtype=torch.bool, device=DEVICE),
                                           timestamp=torch.full((2, 1), float("nan"), dtype=torch.float64, device=DEVICE))
            for a, b in zip(model.components(state), model.components(after)):
                torch.testing.assert_close(a, b, rtol=0, atol=0)
            torch.testing.assert_close(state.clock.last_event_seconds, after.clock.last_event_seconds)

    def test_timestamps_rejected_if_missing_nan_float32_or_backward(self):
        model = self.model()
        with self.assertRaises(ValueError):
            model.forward_chunk(model.init_state(2, DEVICE), *self.x)
        ts = times()
        ts[0, 1] = float("nan")
        with self.assertRaises(ValueError):
            self.run_model(model, timestamp=ts)
        with self.assertRaises(ValueError):
            self.run_model(model, timestamp=times().float())
        ts = times()
        ts[0, 1] = ts[0, 0]-1
        with self.assertRaises(ValueError):
            self.run_model(model, timestamp=ts)

    def test_backward_across_chunks_rejected(self):
        model = self.model()
        state = self.forecast(model, self.seeded(model), 10)
        with self.assertRaises(ValueError):
            self.forecast(model, state, 9)

    def test_subsecond_unix_timestamp_preserved(self):
        model = self.model()
        _, state = self.run_model(model)
        self.assertEqual(float(times()[0, 1] - times()[0, 0]), .125)
        self.assertEqual(state.clock.last_kc_seconds.dtype, torch.float64)

    def test_missing_student_steps_do_not_hide_backward_time(self):
        model = self.model()
        x = list(self.x)
        x[-1] = x[-1].clone()
        x[-1][0, 1] = False
        ts = times()
        ts[0, 1] = float("nan")
        ts[0, 2] = ts[0, 0]-1
        with self.assertRaises(ValueError):
            self.run_model(model, tuple(x), ts)

    def test_finite_backward_both_writes_and_modes(self):
        for mode in ("joint", "mass"):
            for variant in ("unit_write", "dynamic_only"):
                model = self.model(mode, .1, variant)
                out, state = self.run_model(model)
                loss = torch.nn.functional.binary_cross_entropy(out["probability"][self.x[-1]],
                                                                self.x[3][self.x[-1]])
                loss.backward()
                self.assertTrue(bool(torch.isfinite(loss)))
                for p in model.parameters():
                    if p.grad is not None:
                        self.assertTrue(bool(torch.isfinite(p.grad).all()))
                detached = state.detach()
                self.assertFalse(model.components(detached)[0].requires_grad)

    def test_no_feedback_fields_in_forecast_or_prediction(self):
        model = self.model()
        for method in (model.predict, model.advance_time):
            for key in ("label", "response_time", "rt_residual", "reliability"):
                self.assertNotIn(key, inspect.signature(method).parameters)

    def test_invalid_configuration_rejected(self):
        for mode, rate in (("bad", 0), ("joint", -1), ("mass", float("nan")),
                           ("joint", float("inf")), ("none", .1)):
            with self.assertRaises(ValueError):
                self.model(mode, rate)
        with self.assertRaises(ValueError):
            self.model("mass", 0, "static")


class TemporalEngineTests(unittest.TestCase):
    def setUp(self):
        arrays, vocab, _ = encode_frame(frame())
        self.data = PreparedData.__new__(PreparedData)
        self.data.arrays, self.data.vocab = arrays, vocab
        self.model = TemporalCD(1, 2, 1, variant="unit_write", ncd_hidden_dim=16,
                                time_mode="mass", decay_rate_per_hour=math.log(2)).to(DEVICE)

    def test_loader_emits_float64_raw_timestamps(self):
        users, seq = next(self.data.batches("test", 1))
        batch, idx = next(self.data.chunks(users, seq, "test", 5, DEVICE))
        self.assertEqual(batch["timestamp"].dtype, torch.float64)
        np.testing.assert_array_equal(batch["timestamp"].cpu().numpy().ravel(), self.data.arrays["timestamp"])

    def test_engine_chunk_invariance_with_and_without_target_writes(self):
        for write in (True, False):
            _, a, _ = evaluate(self.model, self.data, DEVICE, "test", 1, 1, write)
            _, b, _ = evaluate(self.model, self.data, DEVICE, "test", 1, 4, write)
            for key in ("probability", "uncertainty", "evidence"):
                np.testing.assert_array_equal(a[key], b[key])

    def test_rt_and_precomputed_gap_summaries_are_not_model_inputs(self):
        _, before, _ = evaluate(self.model, self.data, DEVICE, "test", 1, 2)
        for key in ("response_time", "delta_t_hours", "delta_t_k_hours", "kc_count_before"):
            self.data.arrays[key] = np.full_like(self.data.arrays[key], 99999)
        _, after, _ = evaluate(self.model, self.data, DEVICE, "test", 1, 2)
        np.testing.assert_array_equal(before.probability, after.probability)

    def test_engine_training_backward(self):
        from src.engine import train_epoch
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=.001)
        stats = train_epoch(self.model, self.data, optimizer, DEVICE, 1, 2, 0)
        self.assertEqual(stats["n"], 3)
        self.assertTrue(math.isfinite(stats["bce"]))
