import os
import unittest
import numpy as np
import torch
from src.data import PreparedData, encode_frame
from src.engine import evaluate, forward
from src.model import CleanCD
from tests.test_data import frame


class EngineTests(unittest.TestCase):
    def setUp(self):
        self.device = torch.device(os.environ.get("UCTP_TEST_DEVICE", "cpu"))
        arrays, vocab, _ = encode_frame(frame())
        self.data = PreparedData.__new__(PreparedData)
        self.data.arrays, self.data.vocab = arrays, vocab
        torch.manual_seed(4)
        self.model = CleanCD(1, 2, 1, variant="unit_write", ncd_hidden_dim=16).to(self.device)

    def test_streaming_evaluation_is_chunk_invariant(self):
        _, a, _ = evaluate(self.model, self.data, self.device, "test", 1, 1)
        _, b, _ = evaluate(self.model, self.data, self.device, "test", 1, 4)
        np.testing.assert_array_equal(a.probability, b.probability)

    def test_rt_changes_do_not_enter_baseline_prediction(self):
        _, a, _ = evaluate(self.model, self.data, self.device, "test", 1, 2)
        self.data.arrays["response_time"] = np.full_like(self.data.arrays["response_time"], 999999)
        self.data.arrays["rt_valid"] = np.ones_like(self.data.arrays["rt_valid"])
        _, b, _ = evaluate(self.model, self.data, self.device, "test", 1, 2)
        np.testing.assert_array_equal(a.probability, b.probability)

    def test_freeze_target_still_replays_train_and_valid(self):
        state = self.model.init_state(1, self.device)
        users, seq = next(self.data.batches("test", 1))
        for batch, _ in self.data.chunks(users, seq, "test", 2, self.device):
            _, state = forward(self.model, state, batch, update_targets=False)
        self.assertEqual(float(state.positive.sum()), 2)
        self.assertEqual(float(state.negative.sum()), 2)

    def test_no_dropped_or_duplicated_chunk_events(self):
        users, seq = next(self.data.batches("test", 1))
        observed = []
        for _, idx in self.data.chunks(users, seq, "test", 2, self.device):
            observed.extend(idx[idx >= 0].tolist())
        self.assertEqual(observed, list(range(5)))

    def test_views_do_not_include_later_splits(self):
        for view, expected in (("train", 3), ("valid", 4), ("test", 5)):
            _, seq = next(self.data.batches(view, 1))
            self.assertEqual(len(seq[0]), expected)

    def test_zero_size_chunk_is_rejected(self):
        users, seq = next(self.data.batches("test", 1))
        with self.assertRaises(ValueError):
            list(self.data.chunks(users, seq, "test", 0, self.device))
