from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class PositiveLinear(nn.Module):
    """Linear layer with non-negative effective weights for monotonic NCD."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        initial_effective_weight: float = 0.02,
    ) -> None:
        super().__init__()
        if initial_effective_weight <= 0:
            raise ValueError("initial_effective_weight must be positive")
        raw_init = float(torch.log(torch.expm1(torch.tensor(initial_effective_weight))))
        self.raw_weight = nn.Parameter(
            torch.empty(out_features, in_features).normal_(mean=raw_init, std=0.05)
        )
        self.bias = nn.Parameter(torch.zeros(out_features)) if bias else None

    def forward(self, x: Tensor) -> Tensor:
        weight = F.softplus(self.raw_weight)
        return F.linear(x, weight, self.bias)


@dataclass
class UCTPState:
    p_short: Tensor
    n_short: Tensor
    p_long: Tensor
    n_long: Tensor
    mix_gate: Tensor

    def detach(self) -> "UCTPState":
        return UCTPState(
            self.p_short.detach(),
            self.n_short.detach(),
            self.p_long.detach(),
            self.n_long.detach(),
            self.mix_gate.detach(),
        )


class ReliabilityEncoder(nn.Module):
    def __init__(self, hidden_dim: int = 32) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(10, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, features: Tensor) -> Tensor:
        return torch.sigmoid(self.net(features)).squeeze(-1)


class EvidenceStrength(nn.Module):
    def __init__(self, hidden_dim: int = 16) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, features: Tensor) -> Tensor:
        return F.softplus(self.net(features)).squeeze(-1) + 1e-6


class UCTPCDV1(nn.Module):
    """
    Working version for innovation 1 + innovation 3.

    Baseline path:
      static student mastery embedding -> monotonic NeuralCD head.

    Innovation 1:
      RT residual + real time gaps + reliability gate + dual-timescale evidence memory.

    Innovation 3:
      Beta evidence mastery + uncertainty output + uncertainty-gated dynamic residual.
    """

    def __init__(
        self,
        num_students: int,
        num_items: int,
        num_knowledges: int,
        hidden_dim: int = 64,
        ncd_hidden_dim: int = 128,
        use_dynamic: bool = True,
        use_time: bool = True,
        use_rt: bool = True,
        use_reliability: bool = True,
        use_dual_timescale: bool = True,
        use_uncertainty_gate: bool = True,
    ) -> None:
        super().__init__()
        self.num_students = num_students
        self.num_items = num_items
        self.num_knowledges = num_knowledges
        self.use_dynamic = use_dynamic
        self.use_time = use_time
        self.use_rt = use_rt
        self.use_reliability = use_reliability
        self.use_dual_timescale = use_dual_timescale
        self.use_uncertainty_gate = use_uncertainty_gate

        self.student_mastery_logit = nn.Embedding(num_students, num_knowledges)
        self.item_difficulty_logit = nn.Embedding(num_items, num_knowledges)
        self.item_discrimination_raw = nn.Embedding(num_items, 1)
        self.item_bias = nn.Embedding(num_items, 1)
        nn.init.normal_(self.student_mastery_logit.weight, mean=0.0, std=0.1)
        nn.init.normal_(self.item_difficulty_logit.weight, mean=0.0, std=0.1)
        nn.init.constant_(self.item_discrimination_raw.weight, 0.5)
        nn.init.zeros_(self.item_bias.weight)

        self.reliability_encoder = ReliabilityEncoder(hidden_dim=hidden_dim)
        self.positive_strength = EvidenceStrength()
        self.negative_strength = EvidenceStrength()

        # lambda_short = lambda_long + positive gap, guaranteeing short decay is faster.
        self.raw_lambda_long = nn.Parameter(torch.tensor(-4.0))
        self.raw_lambda_gap = nn.Parameter(torch.tensor(-2.5))

        self.timescale_gate = nn.Sequential(
            nn.Linear(4, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )
        self.raw_dynamic_scale = nn.Parameter(torch.tensor(-1.0))
        self.raw_direct_scale = nn.Parameter(torch.tensor(0.5))

        self.ncd = nn.Sequential(
            PositiveLinear(num_knowledges, ncd_hidden_dim, initial_effective_weight=0.02),
            nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim, ncd_hidden_dim // 2, initial_effective_weight=0.02),
            nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim // 2, 1, initial_effective_weight=0.02),
        )
        # Centre the initial prediction near 0.5 instead of saturating at 1.0.
        if self.ncd[-1].bias is not None:
            nn.init.constant_(self.ncd[-1].bias, -0.85)

    @property
    def lambda_long(self) -> Tensor:
        return F.softplus(self.raw_lambda_long) + 1e-8

    @property
    def lambda_short(self) -> Tensor:
        return self.lambda_long + F.softplus(self.raw_lambda_gap) + 1e-8

    @property
    def dynamic_scale(self) -> Tensor:
        return F.softplus(self.raw_dynamic_scale)

    @property
    def direct_scale(self) -> Tensor:
        return F.softplus(self.raw_direct_scale)

    def init_state(self, batch_size: int, device: torch.device) -> UCTPState:
        zeros = torch.zeros(batch_size, self.num_knowledges, device=device)
        return UCTPState(
            p_short=zeros.clone(),
            n_short=zeros.clone(),
            p_long=zeros.clone(),
            n_long=zeros.clone(),
            mix_gate=torch.full_like(zeros, 0.5),
        )

    @staticmethod
    def _beta_from_state(state: UCTPState) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
        p = state.mix_gate * state.p_short + (1.0 - state.mix_gate) * state.p_long
        n = state.mix_gate * state.n_short + (1.0 - state.mix_gate) * state.n_long
        alpha = 1.0 + p.clamp_min(0.0)
        beta = 1.0 + n.clamp_min(0.0)
        mastery = alpha / (alpha + beta)
        uncertainty = 2.0 / (alpha + beta)
        return alpha, beta, mastery, uncertainty

    def _current_mastery(
        self,
        state: UCTPState,
        student_idx: Tensor,
    ) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
        alpha, beta, dynamic_mastery, uncertainty = self._beta_from_state(state)
        base_logit = self.student_mastery_logit(student_idx)
        if not self.use_dynamic:
            return torch.sigmoid(base_logit), uncertainty, alpha, beta

        eps = 1e-5
        dynamic_logit = torch.logit(dynamic_mastery.clamp(eps, 1.0 - eps))
        if self.use_uncertainty_gate:
            dynamic_logit = dynamic_logit * (1.0 - uncertainty).clamp(0.0, 1.0)
        mastery = torch.sigmoid(base_logit + self.dynamic_scale * dynamic_logit)
        return mastery, uncertainty, alpha, beta

    def _predict_step(
        self,
        state: UCTPState,
        student_idx: Tensor,
        item_idx: Tensor,
        q: Tensor,
    ) -> Dict[str, Tensor]:
        mastery, uncertainty, alpha, beta = self._current_mastery(state, student_idx)
        difficulty = torch.sigmoid(self.item_difficulty_logit(item_idx))
        discrimination = F.softplus(self.item_discrimination_raw(item_idx)).squeeze(-1) + 1e-4
        interaction = discrimination.unsqueeze(-1) * (mastery - difficulty) * q
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        # A direct monotonic path prevents the positive MLP from becoming nearly constant
        # during the first epochs; the positive MLP remains as a nonlinear residual.
        direct_logit = self.direct_scale * interaction.sum(dim=-1) / q_sum
        nonlinear_logit = self.ncd(interaction).squeeze(-1)
        logit = self.item_bias(item_idx).squeeze(-1) + direct_logit + nonlinear_logit
        probability = torch.sigmoid(logit)
        relevant_uncertainty = (uncertainty * q).sum(dim=-1) / q_sum
        relevant_evidence = ((alpha + beta - 2.0) * q).sum(dim=-1) / q_sum
        return {
            "probability": probability,
            "uncertainty": relevant_uncertainty,
            "evidence": relevant_evidence,
            "difficulty_scalar": (difficulty * q).sum(dim=-1) / q_sum,
        }

    def _update_step(
        self,
        state: UCTPState,
        active: Tensor,
        q: Tensor,
        y: Tensor,
        rt_residual: Tensor,
        delta_t_hours: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
        difficulty_scalar: Tensor,
    ) -> Tuple[UCTPState, Tensor, Tensor, Tensor, Tensor]:
        _, _, _, prev_uncertainty = self._beta_from_state(state)
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        prev_u = (prev_uncertainty * q).sum(dim=-1) / q_sum
        short_rate = ((1.0 + state.p_short) / (2.0 + state.p_short + state.n_short) * q).sum(dim=-1) / q_sum
        long_rate = ((1.0 + state.p_long) / (2.0 + state.p_long + state.n_long) * q).sum(dim=-1) / q_sum

        used_rt = rt_residual if self.use_rt else torch.zeros_like(rt_residual)
        used_dt = delta_t_hours if self.use_time else torch.zeros_like(delta_t_hours)
        used_dt_k = delta_t_k_hours if self.use_time else torch.zeros_like(delta_t_k_hours)

        reliability_features = torch.stack(
            [
                y,
                used_rt,
                used_rt.abs(),
                torch.log1p(used_dt.clamp_min(0.0)),
                torch.log1p(used_dt_k.clamp_min(0.0)),
                difficulty_scalar,
                torch.log1p(kc_count_before.clamp_min(0.0)),
                short_rate,
                long_rate,
                prev_u,
            ],
            dim=-1,
        )
        if self.use_reliability:
            reliability = self.reliability_encoder(reliability_features)
        else:
            reliability = torch.ones_like(y)

        strength_features = torch.stack(
            [
                difficulty_scalar,
                used_rt,
                used_rt.abs(),
                torch.log1p(used_dt_k.clamp_min(0.0)),
            ],
            dim=-1,
        )
        positive_evidence = reliability * y * self.positive_strength(strength_features)
        negative_evidence = reliability * (1.0 - y) * self.negative_strength(strength_features)

        if self.use_time:
            d_short = torch.exp(-self.lambda_short * used_dt_k.clamp_min(0.0))
            d_long = torch.exp(-self.lambda_long * used_dt_k.clamp_min(0.0))
        else:
            d_short = torch.ones_like(y)
            d_long = torch.ones_like(y)
        if not self.use_dual_timescale:
            d_short = d_long

        active_f = active.float().unsqueeze(-1)
        q_active = q * active_f
        keep_short = 1.0 - q_active + q_active * d_short.unsqueeze(-1)
        keep_long = 1.0 - q_active + q_active * d_long.unsqueeze(-1)

        p_short = state.p_short * keep_short + q_active * positive_evidence.unsqueeze(-1)
        n_short = state.n_short * keep_short + q_active * negative_evidence.unsqueeze(-1)
        p_long = state.p_long * keep_long + q_active * positive_evidence.unsqueeze(-1)
        n_long = state.n_long * keep_long + q_active * negative_evidence.unsqueeze(-1)

        if self.use_dual_timescale:
            gate_features = torch.stack(
                [
                    torch.log1p(used_dt_k.clamp_min(0.0)),
                    torch.log1p(kc_count_before.clamp_min(0.0)),
                    reliability,
                    prev_u,
                ],
                dim=-1,
            )
            gate_scalar = torch.sigmoid(self.timescale_gate(gate_features)).squeeze(-1)
        else:
            gate_scalar = torch.zeros_like(y)

        new_gate = state.mix_gate * (1.0 - q_active) + q_active * gate_scalar.unsqueeze(-1)
        # Preserve all states for padded rows.
        preserve = 1.0 - active_f
        new_state = UCTPState(
            p_short=p_short * active_f + state.p_short * preserve,
            n_short=n_short * active_f + state.n_short * preserve,
            p_long=p_long * active_f + state.p_long * preserve,
            n_long=n_long * active_f + state.n_long * preserve,
            mix_gate=new_gate * active_f + state.mix_gate * preserve,
        )
        return new_state, reliability, positive_evidence, negative_evidence, gate_scalar

    def forward_chunk(
        self,
        state: UCTPState,
        student_idx: Tensor,
        item_idx: Tensor,
        q: Tensor,
        label: Tensor,
        rt_residual: Tensor,
        delta_t_hours: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
        active_mask: Tensor,
        update_mask: Optional[Tensor] = None,
    ) -> Tuple[Dict[str, Tensor], UCTPState]:
        """Process [B,T] chunk. Prediction is always made before observing current label."""
        batch_size, steps = item_idx.shape
        if update_mask is None:
            update_mask = active_mask

        outputs: Dict[str, list[Tensor]] = {
            "probability": [],
            "uncertainty": [],
            "evidence": [],
            "reliability": [],
            "positive_evidence": [],
            "negative_evidence": [],
            "timescale_gate": [],
        }

        current = state
        for t in range(steps):
            active_t = active_mask[:, t]
            pred = self._predict_step(current, student_idx, item_idx[:, t], q[:, t])
            should_update = active_t & update_mask[:, t]
            if self.use_dynamic:
                current, rho, pos, neg, gate = self._update_step(
                    current,
                    should_update,
                    q[:, t],
                    label[:, t],
                    rt_residual[:, t],
                    delta_t_hours[:, t],
                    delta_t_k_hours[:, t],
                    kc_count_before[:, t],
                    pred["difficulty_scalar"],
                )
            else:
                rho = torch.ones(batch_size, device=item_idx.device)
                pos = torch.zeros_like(rho)
                neg = torch.zeros_like(rho)
                gate = torch.zeros_like(rho)

            outputs["probability"].append(pred["probability"])
            outputs["uncertainty"].append(pred["uncertainty"])
            outputs["evidence"].append(pred["evidence"])
            outputs["reliability"].append(rho)
            outputs["positive_evidence"].append(pos)
            outputs["negative_evidence"].append(neg)
            outputs["timescale_gate"].append(gate)

        stacked = {key: torch.stack(values, dim=1) for key, values in outputs.items()}
        return stacked, current

