import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
from src.common import ROOT, new_output_dir, write_json
from src.data import encode_frame, timestamp_seconds, load_item_kcs, read_sources


def frame():
    return pd.DataFrame({"student_id": ["1"]*5, "item_id": ["2", "1", "2", "1", "2"],
                         "knowledge_ids": [("k",)]*5, "label": [1, 0, 1, 0, 1],
                         "timestamp": [0, 3600, 7200, 10800, 14400],
                         "response_time": [20., 0, np.nan, 10, 12], "rt_valid": [True, False, False, True, True],
                         "source_row": [0, 1, 2, 0, 0], "split": [0, 0, 0, 1, 2]})


class DataTests(unittest.TestCase):
    def test_datetime_units_and_missing(self):
        result = timestamp_seconds(pd.Series(["2020-01-01", None, "bad-date"]), "datetime")
        self.assertEqual(result.iloc[0], 1577836800)
        self.assertTrue(result.iloc[1:].isna().all())

    def test_numeric_units(self):
        for unit, factor in (("s", 1), ("ms", 1000), ("us", 1e6), ("ns", 1e9)):
            result = timestamp_seconds(pd.Series([1577836800*factor]), unit)
            self.assertEqual(result.iloc[0], 1577836800)

    def test_auto_unit_rejected(self):
        with self.assertRaises(ValueError):
            timestamp_seconds(pd.Series([1]), "auto")

    def test_missing_rt_rows_retained(self):
        arrays, _, summary = encode_frame(frame())
        self.assertEqual(summary["rows"], 5)
        self.assertEqual(summary["rt_unavailable"], 2)
        self.assertEqual(summary["removed_rows"], 0)
        self.assertTrue(np.isnan(arrays["response_time"][2]))

    def test_prefix_counts_and_gaps(self):
        a, _, _ = encode_frame(frame())
        np.testing.assert_array_equal(a["kc_count_before"], [0, 1, 2, 3, 4])
        np.testing.assert_array_equal(a["delta_t_k_hours"], [0, 1, 1, 1, 1])

    def test_future_response_and_rt_dont_change_past_features(self):
        f = frame()
        old, _, _ = encode_frame(f)
        f.loc[4, ["label", "response_time", "timestamp"]] = [0, 999999, 9999999]
        new, _, _ = encode_frame(f)
        for key in ("delta_t_hours", "delta_t_k_hours", "kc_count_before", "student_count_before"):
            np.testing.assert_array_equal(old[key][:4], new[key][:4])

    def test_q_conflict_is_rejected(self):
        f = frame()
        f.at[4, "knowledge_ids"] = ("different",)
        with self.assertRaises(ValueError):
            encode_frame(f)

    def test_interleaved_splits_rejected(self):
        f = frame()
        f.loc[1, "split"] = 2
        with self.assertRaises(ValueError):
            encode_frame(f)

    def test_vocab_independent_of_input_file_order(self):
        a, vocab, _ = encode_frame(frame())
        b, changed, _ = encode_frame(frame().iloc[::-1])
        self.assertEqual(vocab, changed)
        np.testing.assert_array_equal(a["item_idx"], b["item_idx"])

    def test_multikc_q_and_prefix(self):
        f = frame()
        f["knowledge_ids"] = [("k", "z")]*5
        arrays, vocab, _ = encode_frame(f)
        self.assertEqual(vocab["knowledge_ids"], ["k", "z"])
        self.assertTrue(arrays["item_q"].all())
        np.testing.assert_array_equal(arrays["kc_count_before"], np.arange(5))

    def test_tied_cross_split_events_reported_not_hidden(self):
        f = frame()
        f.loc[3, "timestamp"] = 7200
        _, _, summary = encode_frame(f)
        self.assertEqual(summary["cross_split_same_time_groups"], 1)

    def test_output_protection(self):
        with self.assertRaises(FileExistsError):
            new_output_dir(ROOT / "src")
        with self.assertRaises(ValueError):
            new_output_dir(ROOT.parent / "uctp_cd_v1_working" / "outputs" / "not_allowed")

    def test_q_mapping_validated(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            write_json(root / "item_mapping.json", {"17": 0, "28": 1})
            np.save(root / "q.npy", [[0, 1, 0], [0, 0, 1]])
            self.assertEqual(load_item_kcs(root / "item_mapping.json", root / "q.npy"), {"17": ("1",), "28": ("2",)})
            write_json(root / "item_mapping.json", {"17": 1, "28": 1})
            with self.assertRaises(ValueError):
                load_item_kcs(root / "item_mapping.json", root / "q.npy")

    def test_reader_rejects_bad_label_keeps_absent_rt(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            cfg = {"kind": "assist", "student_col": "student_id", "item_col": "item_id", "knowledge_col": "knowledge_ids",
                   "label_col": "correct", "timestamp_col": "timestamp", "response_time_col": "rt",
                   "timestamp_unit": "s", "response_time_unit": "s"}
            for name in ("train", "valid", "test"):
                pd.DataFrame({"student_id": [1], "item_id": [2], "knowledge_ids": ["3"], "correct": [1], "timestamp": [100]}).to_csv(root/f"{name}.csv", index=False)
            f, _ = read_sources(cfg, root)
            self.assertEqual(len(f), 3)
            self.assertFalse(f.rt_valid.any())
            bad = pd.read_csv(root/"train.csv")
            bad.loc[0, "correct"] = 2
            bad.to_csv(root/"train.csv", index=False)
            with self.assertRaises(ValueError):
                read_sources(cfg, root)
