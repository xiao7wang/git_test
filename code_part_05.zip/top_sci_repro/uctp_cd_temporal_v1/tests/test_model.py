import os
import unittest
import torch
from src.model import CleanCD
from tests.fixtures.legacy_model import UCTPCDV1

DEVICE = torch.device(os.environ.get("UCTP_TEST_DEVICE", "cpu"))


def example():
    users = torch.tensor([0, 1], device=DEVICE)
    items = torch.tensor([[0, 1, 2, 0, 2], [1, 0, 2, 1, 0]], device=DEVICE)
    q = torch.tensor([[[1., 0], [1, 1], [0, 1], [1, 0], [0, 1]],
                      [[1., 1], [1, 0], [0, 1], [0, 0], [0, 0]]], device=DEVICE)
    y = torch.tensor([[1., 0, 1, 0, 1], [0., 1, 1, 0, 0]], device=DEVICE)
    active = torch.tensor([[True]*5, [True, True, True, False, False]], device=DEVICE)
    return users, items, q, y, active


class ModelTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.model = CleanCD(2, 3, 2, ncd_hidden_dim=16).to(DEVICE)
        self.x = example()

    def run_model(self, x=None, update=None):
        x = self.x if x is None else x
        return self.model.forward_chunk(self.model.init_state(2, DEVICE), *x, update_mask=update)

    def test_legacy_equivalence_outputs_states_and_gradients(self):
        legacy = UCTPCDV1(2, 3, 2, ncd_hidden_dim=16, use_dynamic=True, use_time=False,
                         use_rt=False, use_reliability=False, use_dual_timescale=False,
                         use_uncertainty_gate=False).to(DEVICE)
        common = {key: legacy.state_dict()[key] for key in self.model.state_dict()}
        self.model.load_state_dict(common, strict=True)
        users, items, q, y, active = self.x
        zero = torch.zeros_like(y)
        old, old_state = legacy.forward_chunk(legacy.init_state(2, DEVICE), users, items, q, y,
                                              zero, zero, zero, zero, active)
        new, new_state = self.run_model()
        for key in ("probability", "uncertainty", "evidence"):
            torch.testing.assert_close(new[key], old[key], rtol=1e-6, atol=1e-7)
        torch.testing.assert_close(new_state.positive, old_state.p_long)
        torch.testing.assert_close(new_state.negative, old_state.n_short)
        old["probability"][active].sum().backward()
        new["probability"][active].sum().backward()
        old_params = dict(legacy.named_parameters())
        for name, parameter in self.model.named_parameters():
            reference = old_params[name].grad
            if reference is None:
                self.assertIsNone(parameter.grad, name)
            else:
                torch.testing.assert_close(parameter.grad, reference, rtol=3e-5, atol=2e-6, msg=name)

    def test_current_label_does_not_change_current_prediction(self):
        before, _ = self.run_model()
        x = list(self.x)
        x[3] = x[3].clone()
        x[3][0, 1] = 1-x[3][0, 1]
        after, _ = self.run_model(tuple(x))
        torch.testing.assert_close(before["probability"][:, :2], after["probability"][:, :2], rtol=0, atol=0)
        self.assertGreater(float((before["probability"][0, 2:]-after["probability"][0, 2:]).abs().max().detach()), 0)

    def test_future_labels_do_not_change_past(self):
        before, _ = self.run_model()
        x = list(self.x)
        x[3] = x[3].clone()
        x[3][:, 3:] = 1-x[3][:, 3:]
        after, _ = self.run_model(tuple(x))
        torch.testing.assert_close(before["probability"][:, :4], after["probability"][:, :4], rtol=0, atol=0)

    def test_chunked_equals_whole(self):
        whole, end = self.run_model()
        users, items, q, y, active = self.x
        state, values = self.model.init_state(2, DEVICE), []
        for lo, hi in ((0, 2), (2, 3), (3, 5)):
            out, state = self.model.forward_chunk(state, users, items[:, lo:hi], q[:, lo:hi], y[:, lo:hi], active[:, lo:hi])
            values.append(out["probability"])
            state = state.detach()
        torch.testing.assert_close(torch.cat(values, 1), whole["probability"], rtol=0, atol=0)
        torch.testing.assert_close(state.positive, end.positive, rtol=0, atol=0)

    def test_no_writes_preserves_state(self):
        _, state = self.run_model(update=torch.zeros_like(self.x[-1]))
        self.assertEqual(float((state.positive.sum()+state.negative.sum()).detach()), 0)

    def test_padding_nan_label_preserves_finite_state(self):
        _, original = self.run_model()
        x = list(self.x)
        x[3] = x[3].clone()
        x[3][~x[-1]] = float("nan")
        _, changed = self.run_model(tuple(x))
        torch.testing.assert_close(changed.positive, original.positive)
        torch.testing.assert_close(changed.negative, original.negative)

    def test_unit_writes_are_counts(self):
        self.model.variant = "unit_write"
        _, state = self.run_model()
        _, _, q, y, active = self.x
        torch.testing.assert_close(state.positive, (q*y[..., None]*active[..., None]).sum(1))
        torch.testing.assert_close(state.negative, (q*(1-y[..., None])*active[..., None]).sum(1))

    def test_static_never_updates(self):
        self.model.variant = "static"
        before, state = self.run_model()
        x = list(self.x)
        x[3] = 1-x[3]
        after, _ = self.run_model(tuple(x))
        torch.testing.assert_close(before["probability"], after["probability"], rtol=0, atol=0)
        self.assertEqual(float(state.positive.sum()), 0)

    def test_predict_interface_excludes_feedback(self):
        import inspect
        parameters = inspect.signature(self.model.predict).parameters
        for forbidden in ("label", "y", "response_time", "rt_residual"):
            self.assertNotIn(forbidden, parameters)

    def test_only_selected_kcs_change(self):
        state = self.model.init_state(2, DEVICE)
        q = torch.tensor([[1., 0], [0, 1]], device=DEVICE)
        updated = self.model.observe(state, q, torch.ones(2, device=DEVICE),
                                     torch.full((2,), 0.5, device=DEVICE), torch.ones(2, dtype=torch.bool, device=DEVICE))
        self.assertEqual(float(updated.positive[0, 1].detach()), 0)
        self.assertEqual(float(updated.positive[1, 0].detach()), 0)

    def test_detach_removes_graph(self):
        _, state = self.run_model()
        self.assertTrue(state.positive.requires_grad)
        self.assertFalse(state.detach().positive.requires_grad)

    def test_invalid_variant_is_rejected(self):
        with self.assertRaises(ValueError):
            CleanCD(2, 3, 2, variant="v7")
