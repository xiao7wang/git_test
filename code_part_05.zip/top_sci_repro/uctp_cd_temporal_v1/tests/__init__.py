"""Executable regression tests for the clean baseline."""
