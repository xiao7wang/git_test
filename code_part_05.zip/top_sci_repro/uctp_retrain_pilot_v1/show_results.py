import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser()
p.add_argument('--output-dir',required=True)
a=p.parse_args()
root=Path(a.output_dir)
if not (root/'status.json').exists():
    print('Not started or tests still running; check launch log.')
else:
    status=read(root/'status.json')
    print('status:',status.get('status'),'phase:',status.get('phase'),'error:',status.get('error','-'))
    print('Saved running status does not itself prove a live process.')
    if (root/'pilot_summary.json').exists():
        for r in read(root/'pilot_summary.json')['runs']:
            print(r['rule'],'train_seconds=',round(r['train']['seconds'],1),
                  'dev_seconds=',round(r['dev_seconds'],1),'dev_nll=',r['dev_nll'])
        print('One epoch only: timing and feasibility, not a performance comparison.')
        if (root/'retrain_pilot_results.zip').exists():
            print('Results archive:',root/'retrain_pilot_results.zip')
