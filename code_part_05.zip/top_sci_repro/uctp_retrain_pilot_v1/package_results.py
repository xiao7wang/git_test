import argparse
import hashlib
import json
import zipfile
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--output-dir',required=True)
root=Path(p.parse_args().output_dir).resolve()
assert json.loads((root/'status.json').read_text(encoding='utf8'))['status']=='complete'
names=['status.json','config.json','partial_results.json','pilot_summary.json']
manifest={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
archive=root/'retrain_pilot_results.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for name in names: z.write(root/name,name)
    z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None or any(hashlib.sha256(z.read(k)).hexdigest()!=v for k,v in manifest.items()):
        raise ValueError('Archive failed verification')
print('RESULTS READY:',archive,flush=True)
