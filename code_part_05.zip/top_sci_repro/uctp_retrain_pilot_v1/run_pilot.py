"""Train A/B/C for one epoch each, on ASSIST, to validate and time training."""
import argparse
import importlib
import json
import os
import platform
import sys
import time
from pathlib import Path

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch
from cross_core import import_project, read, sha, write
from pilot_core import DevelopmentData, RULES, SALT, development_users, run_one

ROOT = Path(__file__).resolve().parent

def main():
    p = argparse.ArgumentParser()
    for name in ('project-dir','data-dir','output-dir'):
        p.add_argument('--'+name, required=True)
    p.add_argument('--device', choices=('cpu','cuda'), default='cuda')
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Both feedback and time-proxy acknowledgements required')
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA is unavailable')
    out=Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=False)
    status={'status':'running','phase':'audit','trained':True,'test_evaluated':False,'holdout_evaluated':False}
    write(out/'status.json',status)
    start=time.monotonic()
    try:
        spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
        Data,Base,_=import_project(args.project_dir,spec['source'])
        if sha(Path(args.data_dir)/'manifest.json') != spec['data_fingerprint']:
            raise ValueError('ASSIST data manifest fingerprint mismatch')
        data=Data(args.data_dir)
        if not (data.arrays['item_q'].sum(1)==1).all():
            raise ValueError('Pilot requires single-KC data')
        users=development_users(data.arrays['student_idx'][data.arrays['split']==1])
        if not users:
            raise ValueError('No development students')
        dev=DevelopmentData(data,users)
        device=torch.device(args.device)
        torch.set_num_threads(4)
        torch.backends.cudnn.benchmark=False
        torch.backends.cudnn.deterministic=True
        torch.use_deterministic_algorithms(True)
        engine=importlib.import_module('src.engine')
        config={'dataset':'ASSIST','data_fingerprint':data.fingerprint,'project_source':spec['source'],
                'pilot_source':{name:sha(ROOT/name) for name in ('pilot_core.py','run_pilot.py','decision_core.py','cross_core.py')},
                'rules':RULES,'seed':0,'epochs_per_rule':1,'lr':1e-3,'weight_decay':1e-5,
                'batch_size':8,'train_chunk':50,'eval_chunk':100,'student_split_salt':SALT,
                'development_students':len(users),'selection_metric':'development NLL',
                'test_evaluated':False,'holdout_evaluated':False,'checkpoint_saved':False,
                'note':'One-epoch feasibility and timing only; do not rank methods or claim performance.',
                'python':platform.python_version(),'torch':str(torch.__version__),'device':str(device),
                'gpu':torch.cuda.get_device_name(device) if device.type=='cuda' else None}
        write(out/'config.json',config)
        results=[]
        for rule,value in RULES:
            status['phase']='train_'+rule
            write(out/'status.json',status)
            print(json.dumps({'phase':'starting','rule':rule,'value':value}),flush=True)
            result=run_one(dev,Base,engine,rule,value,0,device)
            results.append(result)
            write(out/'partial_results.json',{'runs':results})
            print(json.dumps({'phase':'completed',**result}),flush=True)
        if len({r['initial_state_sha256'] for r in results}) != 1:
            raise AssertionError('Model initialization differs across rules')
        elapsed=time.monotonic()-start
        summary={'status':'complete','runs':results,'seconds':elapsed,'test_evaluated':False,
                 'holdout_evaluated':False,'interpretation':'Training and time feasibility only; one epoch is not a performance comparison.'}
        write(out/'pilot_summary.json',summary)
        status.update(status='complete',phase=None,seconds=elapsed)
        write(out/'status.json',status)
        print('PILOT COMPLETE',flush=True)
    except BaseException as exc:
        status.update(status='failed',error=repr(exc),seconds=time.monotonic()-start)
        write(out/'status.json',status)
        raise

if __name__=='__main__':
    main()
