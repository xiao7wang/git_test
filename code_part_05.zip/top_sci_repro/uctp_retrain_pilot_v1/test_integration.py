"""Isolated synthetic command-line end-to-end validation."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import test_step
from cross_core import read, write

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
test_step.PROJECT=str(PROJECT)
test_step.StepTests.setUpClass()
fixture=test_step.StepTests()
fixture.setUp()
try:
    with tempfile.TemporaryDirectory(prefix='retrain_pilot_e2e_') as tmp:
        base=Path(tmp)
        pkg=base/'pkg'
        pkg.mkdir()
        for name in ('run_pilot.py','pilot_core.py','decision_core.py','cross_core.py'):
            shutil.copy2(ROOT/name,pkg/name)
        write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{
              'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
        cmd=[sys.executable,'-B',str(pkg/'run_pilot.py'),'--project-dir',str(PROJECT),
             '--data-dir',str(fixture.path),'--output-dir',str(base/'result'),
             '--device','cpu','--ack-row-feedback','--ack-time-proxy']
        env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
        first=subprocess.run(cmd,env=env,text=True,encoding='utf-8',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if first.returncode:
            raise RuntimeError(first.stdout)
        summary=read(base/'result/pilot_summary.json')
        assert summary['status']=='complete' and len(summary['runs'])==3
        assert not summary['test_evaluated'] and not summary['holdout_evaluated']
        assert len({x['initial_state_sha256'] for x in summary['runs']})==1
        assert all(x['train']['optimizer_steps']>0 for x in summary['runs'])
        second=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        assert second.returncode != 0
        print(json.dumps({'synthetic_cli_complete':True,'nonoverwrite':True,'real_gpu_or_server_not_tested':True}))
finally:
    fixture.tearDown()
