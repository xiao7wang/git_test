import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parent
for name, expected in json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
    path=root/name
    if path.parent != root or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('Missing or changed package member: '+name)
print('Package integrity verified',flush=True)
