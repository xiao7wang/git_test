import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();root=Path(a.output_dir)
if not (root/'status.json').exists():print('Not started or tests still running; check launch log.')
else:
 s=read(root/'status.json');print('Suite:',s.get('status'),'active:',s.get('active'),'error:',s.get('error','-'))
 print('Saved running status does not prove a live process.')
 for name in ('A_seed1','B_seed1','C_seed1','A_seed2','B_seed2','C_seed2'):
  path=root/name/'status.json'
  if not path.exists():print(name,'not_started');continue
  st=read(path);print(name,st.get('status'),'epoch=',st.get('epoch',st.get('epochs')),'phase=',st.get('phase'), 'best_nll=',st.get('best_dev_nll'))
 if (root/'summary.json').exists():print('Locked from seed0:',read(root/'summary.json')['locked_values'])
 if (root/'screen_results.zip').exists():print('Results archive:',root/'screen_results.zip')
