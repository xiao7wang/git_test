"""One-epoch development-only training benchmark, never a method evaluation."""
import hashlib
import random
import numpy as np
import torch
from decision_core import decision_class
from cross_core import model_digest

SALT = 'decision-v1-20261105:'
RULES = [('A', None), ('B', 0.8), ('C', 672)]

def development_users(values):
    return {int(u) for u in np.unique(values)
            if hashlib.sha256((SALT+str(int(u))).encode()).digest()[-1] % 2 == 0}

class DevelopmentData:
    """Training sees training records; validation visits development students only."""
    def __init__(self, data, users):
        self.data, self.users = data, set(users)
    def __getattr__(self, name):
        return getattr(self.data, name)
    def batches(self, view, batch_size, shuffle_seed=None):
        if view not in ('train','valid'):
            raise ValueError('Pilot never accesses test data')
        for users, sequences in self.data.batches(view, batch_size, shuffle_seed):
            if view == 'train':
                yield users, sequences
            else:
                indices = [i for i,u in enumerate(users) if int(u) in self.users]
                if indices:
                    yield users[indices], [sequences[i] for i in indices]

def fresh_model(Base, summary, rule, value, seed, device, hidden=128):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if device.type == 'cuda':
        torch.cuda.manual_seed_all(seed)
    kwargs = dict(num_students=summary['students'], num_items=summary['items'],
                  num_knowledges=summary['knowledges'], variant='unit_write', ncd_hidden_dim=hidden,
                  time_mode='none', decay_rate_per_hour=0.0)
    if rule == 'A':
        model = Base(**kwargs)
    elif rule in ('B','C'):
        model = decision_class(Base)(decision_rule='fixed_all' if rule=='B' else 'real_time',
                                     value=value, **kwargs)
    else:
        raise ValueError('Invalid pilot rule')
    model = model.to(device)
    return model, model_digest(model.state_dict())

def run_one(data, Base, engine, rule, value, seed, device, batch_size=8, chunk_size=50,
            eval_chunk=100, hidden=128):
    model, initial_digest = fresh_model(Base, data.manifest['summary'], rule, value, seed, device, hidden)
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)
    train = engine.train_epoch(model, data, optimizer, device, batch_size, chunk_size, seed+1)
    after_digest = model_digest(model.state_dict())
    if not train['n'] or not train['optimizer_steps'] or after_digest == initial_digest:
        raise RuntimeError('Training did not update model parameters')
    if any(not bool(torch.isfinite(p).all()) for p in model.parameters()):
        raise FloatingPointError('Non-finite model parameters')
    valid, frame, _ = engine.evaluate(model, data, device, 'valid', batch_size, eval_chunk, True)
    if not set(frame.student_idx.astype(int)).issubset(data.users):
        raise AssertionError('Validation includes non-development students')
    if not np.isfinite(valid['nll']):
        raise FloatingPointError('Non-finite development NLL')
    return {'rule':rule, 'value':value, 'train':train, 'dev_nll':valid['nll'],
            'dev_n':valid['n'], 'dev_seconds':valid['seconds'],
            'dev_students':int(frame.student_idx.nunique()), 'initial_state_sha256':initial_digest,
            'final_state_sha256':after_digest}
