"""Paired, three-seed validation statistics; no metric-driven selection."""
import numpy as np
from review_stats import losses, metrics, groups, cluster_intervals

BRANCHES = ('NN', 'NS', 'NF')
CONTRASTS = {'real_time_minus_fixed_step': (1, 2),
             'fixed_step_minus_none': (2, 0), 'real_time_minus_none': (1, 0)}


def summarize_group(frame, arrays, mask, reps=2000):
    ids = np.flatnonzero(mask)
    if not len(ids):
        return {'n': 0, 'students': 0, 'means': {}, 'paired': {}}
    if arrays.shape != (3, 3, len(frame)):
        raise ValueError('Require seeds 0,1,2 and NN,NS,NF in order')
    y, student = frame.label.to_numpy()[ids], frame.student_idx.to_numpy()[ids]
    users, inverse = np.unique(student, return_inverse=True)
    counts = np.bincount(inverse)
    values = np.empty((3, 3, len(ids), 2))
    rows, means = {}, {}
    for s in range(3):
        for b, branch in enumerate(BRANCHES):
            values[s, b] = losses(y, arrays[s, b, ids])
            row = metrics(y, arrays[s, b, ids])
            for li, name in enumerate(('nll', 'brier')):
                row['student_macro_' + name] = float(np.mean(np.bincount(inverse, weights=values[s, b, :, li]) / counts))
            rows[f'{branch}_seed{s}'] = row
    for b in BRANCHES:
        means[b] = {}
        for name in ('auc', 'nll', 'brier', 'student_macro_nll', 'student_macro_brier'):
            v = [rows[f'{b}_seed{s}'][name] for s in range(3)]
            means[b][name] = {'mean': None if None in v else float(np.mean(v)),
                              'sample_sd': None if None in v else float(np.std(v, ddof=1))}
    names, columns, auc = [], [], {}
    for label, value in [(f'seed{s}', values[s]) for s in range(3)] + [('seed_mean', values.mean(0))]:
        for contrast, (a, b) in CONTRASTS.items():
            for li, loss in enumerate(('nll', 'brier')):
                names.append(f'{label}/{contrast}/{loss}')
                columns.append(value[a, :, li] - value[b, :, li])
    for contrast, (a, b) in CONTRASTS.items():
        pairs = [(rows[f'{BRANCHES[a]}_seed{s}']['auc'], rows[f'{BRANCHES[b]}_seed{s}']['auc']) for s in range(3)]
        auc[contrast] = [None if None in pair else pair[0]-pair[1] for pair in pairs]
    intervals = cluster_intervals(student, np.column_stack(columns), reps, 20261027)
    return {'n': len(ids), 'students': len(users), 'metrics': rows, 'means': means,
            'auc_differences_descriptive_only': auc, 'paired': dict(zip(names, intervals['comparisons']))}


def all_groups(frame, pairs):
    out = groups(frame)
    out['long_gap_matched_current'] = np.isin(frame.record_idx.to_numpy(), pairs[:, 0])
    out['long_gap_next_event'] = np.isin(frame.record_idx.to_numpy(), pairs[:, 1])
    return out


def pair_window(frame, arrays, pairs, reps=2000):
    if not len(pairs):
        return {'n_pairs': 0}
    index = {v: i for i, v in enumerate(frame.record_idx.to_numpy())}
    ai, ti = [np.asarray([index[v] for v in pairs[:, k]]) for k in (0, 1)]
    students = frame.student_idx.to_numpy()
    if not np.array_equal(students[ai], students[ti]):
        raise ValueError('Paired events must share student')
    y = frame.label.to_numpy()
    value = np.stack([[losses(y, arrays[s, b])[:, 0] for b in range(3)] for s in range(3)]).mean(0)
    columns = np.column_stack([((value[a, ai]-value[b, ai]) + (value[a, ti]-value[b, ti])) / 2
                               for a, b in CONTRASTS.values()])
    boot = cluster_intervals(students[ai], columns, reps, 20261027)
    return {'n_pairs': len(pairs), 'overlapping_event_roles': len(np.intersect1d(pairs[:, 0], pairs[:, 1])),
            'interpretation': 'Matched two-event average; overlapping event roles retained and clustered by student. Not whole-stream utility.',
            'comparisons': dict(zip(CONTRASTS, boot['comparisons']))}
