"""Synthetic six-run integration, fixed choices, hash guard and archive."""
import json,os,shutil,subprocess,sys,tempfile,hashlib,zipfile
from pathlib import Path
import test_step
from cross_core import read,write,sha

ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass()
fixture=test_step.StepTests();fixture.setUp()
try:
    with tempfile.TemporaryDirectory(prefix='seed_replication_test_') as tmp:
        root=Path(tmp);pkg=root/'pkg';prior=root/'prior';pkg.mkdir();prior.mkdir()
        for n in ('run_suite.py','run_candidate.py','screen_core.py','pilot_core.py','decision_core.py','cross_core.py','package_results.py'):
            shutil.copy2(ROOT/n,pkg/n)
        write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
        selected={};lock={}
        for rule,value,directory in [('A',None,'A_none'),('B',0.8,'B_0.8'),('C',168,'C_168')]:
            folder=prior/directory;folder.mkdir();(folder/'best_model.pt').write_bytes(b'fixture-'+rule.encode())
            digest=sha(folder/'best_model.pt');selected[rule]={'value':value,'checkpoint_sha256':digest}
            lock[rule]={'value':value,'directory':directory,'checkpoint_sha256':digest}
        write(prior/'summary.json',{'selected':selected,'test_evaluated':False,'holdout_evaluated':False})
        write(prior/'status.json',{'status':'complete'});write(prior/'suite_config.json',{'synthetic':True})
        write(pkg/'locked_selection.json',{'seed0_summary_sha256':sha(prior/'summary.json'),
              'seed0_config_sha256':sha(prior/'suite_config.json'),'selected':lock})
        cmd=[sys.executable,'-B',str(pkg/'run_suite.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),
             '--prior-dir',str(prior),'--output-dir',str(root/'out'),'--device','cpu','--epochs','2','--patience','1',
             '--ack-row-feedback','--ack-time-proxy']
        env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
        r=subprocess.run(cmd,env=env,text=True,encoding='utf8',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError(r.stdout)
        summary=read(root/'out/summary.json');assert len(summary['candidates'])==6
        assert summary['locked_values']=={'A':None,'B':0.8,'C':168}
        assert not summary['test_evaluated'] and not summary['holdout_evaluated']
        for seed in (1,2):
            rows=[r for r in summary['candidates'] if r['seed']==seed];assert len(rows)==3
            assert len({r['initial_state_sha256'] for r in rows})==1
            for row in rows:
                path=root/'out'/f"{row['rule']}_seed{seed}"
                history=read(path/'history.json')
                assert abs(row['best_dev_nll']-min(h['dev']['nll'] for h in history))<1e-12
                assert (path/'best_model.pt').is_file()
        assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
        packaged=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        assert packaged.returncode==0,packaged.stdout
        with zipfile.ZipFile(root/'out/screen_results.zip') as z:
            assert z.testzip() is None
            manifest=json.loads(z.read('manifest.json'));assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
        (prior/'B_0.8'/'best_model.pt').write_bytes(b'tampered')
        bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
        assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
        assert read(root/'bad/status.json')['status']=='failed'
        print(json.dumps({'synthetic_six_runs':True,'fixed_choices':True,'per_seed_initialization':True,'nll_early_stop':True,'archive_and_tamper_guard':True,'real_gpu_tested':False}))
finally:fixture.tearDown()
