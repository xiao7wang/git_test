"""Behavioral checks for same-head recency alternatives."""
import argparse
import contextlib
import io
import unittest

import numpy as np
import torch
import test_step
from cross_core import compare, model_digest
from decision_core import make_decision


class DecisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_step.StepTests.setUpClass()

    def setUp(self):
        self.f = test_step.StepTests()
        self.f.setUp()
        self.device = torch.device(test_step.DEVICE)

    def tearDown(self):
        self.f.tearDown()

    def model(self, rule, value):
        return make_decision(self.f.Base, self.f.ckpt, self.device,
                             self.f.data.fingerprint, self.f.sources, rule, value)

    def replay(self, model, batch=8, chunk=100):
        with contextlib.redirect_stdout(io.StringIO()):
            return self.f.run_replay(model, batch=batch, chunk=chunk)

    def test_real_time_168_reproduces_existing_support(self):
        a = self.replay(self.model('real_time', 168))
        b = self.replay(self.f.original('support_only'))
        self.assertTrue(compare(a, b)['success'])

    def test_positive_fixed_reproduces_existing_rule(self):
        a = self.replay(self.model('fixed_positive', .7))
        b = self.replay(self.f.model(.7))
        self.assertTrue(compare(a, b)['success'])

    def test_all_event_folds_equal_time_but_positive_does_not(self):
        for rule, expected in [('fixed_all', 2.5), ('fixed_positive', 3.0)]:
            m = self.model(rule, .5)
            state = self.f.step(m, m.init_state(1, self.device), 0, label=1.)
            state = self.f.step(m, state, 0)
            self.assertAlmostEqual(m.components(state)[1][0, 0].item(), expected)

    def test_fixed_gain_updates_only_feedback_kc(self):
        model = self.model('fixed_gain', .1)
        state = model.init_state(1, self.device)
        state = self.f.step(model, state, 0, label=1.)
        mean, support = model.components(state)
        np.testing.assert_allclose(mean.detach().cpu().numpy(), [[.55, .5]], atol=1e-6)
        np.testing.assert_allclose(support.detach().cpu().numpy(), [[2, 2]], atol=1e-6)
        state = self.f.step(model, state, 1, label=0.)
        self.assertAlmostEqual(model.components(state)[0][0, 0].item(), .495, places=6)

    def test_fixed_gain_without_feedback_no_change(self):
        model = self.model('fixed_gain', .1)
        state = model.init_state(1, self.device)
        after = self.f.step(model, state, 1, label=None)
        self.assertTrue(torch.equal(state.evidence.alpha, after.evidence.alpha))
        self.assertTrue(torch.equal(state.evidence.beta, after.evidence.beta))

    def test_all_rules_are_invariant_to_batch_and_chunk(self):
        for rule, value in [('fixed_all', .9), ('fixed_positive', .9),
                            ('real_time', 48), ('fixed_gain', .1)]:
            model = self.model(rule, value)
            self.assertTrue(compare(self.replay(model), self.replay(model, batch=3, chunk=2))['success'], rule)

    def test_current_prediction_does_not_depend_on_current_or_future_answer(self):
        ids = np.flatnonzero(self.f.data.arrays['split'] == 1)
        target = ids[2]
        for rule, value in [('fixed_all', .9), ('fixed_positive', .9),
                            ('real_time', 48), ('fixed_gain', .1)]:
            before = self.replay(self.model(rule, value))
            old = self.f.data.arrays['label'][target].copy()
            self.f.data.arrays['label'][target] = 1 - old
            after = self.replay(self.model(rule, value))
            self.f.data.arrays['label'][target] = old
            pos = np.flatnonzero(before['record_idx'] == target)[0]
            self.assertEqual(before['probability'][pos], after['probability'][pos], rule)

    def test_fixed_all_ignores_elapsed_duration_and_zero_vs_positive(self):
        model = self.model('fixed_all', .9)
        initial = self.f.step(model, model.init_state(1, self.device), 0, label=1.)
        same = self.f.step(model, initial, 0)
        later = self.f.step(model, initial, 1000)
        self.assertTrue(torch.equal(same.evidence.alpha, later.evidence.alpha))
        self.assertTrue(torch.equal(same.evidence.beta, later.evidence.beta))

    def test_weights_are_unchanged(self):
        for rule, value in [('fixed_all', .9), ('fixed_positive', .9),
                            ('real_time', 48), ('fixed_gain', .1)]:
            model = self.model(rule, value)
            before = model_digest(model.state_dict())
            self.replay(model)
            self.assertEqual(before, model_digest(model.state_dict()))

    def test_unknown_rule_and_invalid_values_fail(self):
        for rule, value in [('unknown', .5), ('fixed_gain', 1), ('fixed_gain', 0),
                            ('real_time', 0), ('fixed_all', 1.1)]:
            with self.assertRaises(ValueError):
                self.model(rule, value)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-dir', required=True)
    parser.add_argument('--device', choices=('cpu', 'cuda'), default='cpu')
    args = parser.parse_args()
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; not skipping')
    test_step.PROJECT, test_step.DEVICE = args.project_dir, args.device
    unittest.main(argv=[__file__], verbosity=2)
