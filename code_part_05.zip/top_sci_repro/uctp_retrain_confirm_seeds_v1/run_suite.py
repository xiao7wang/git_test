"""Run 2 independent training seeds for the seed-0 selected candidate values."""
import argparse
import json
import platform
import subprocess
import sys
import time
from pathlib import Path
import torch
from cross_core import read,sha,write

ROOT=Path(__file__).resolve().parent
PLAN=[(seed,rule,index,f'{rule}_seed{seed}') for seed in (1,2) for rule,index in (('A',0),('B',1),('C',0))]

def check_selection(prior):
    lock=read(ROOT/'locked_selection.json')
    if sha(prior/'summary.json')!=lock['seed0_summary_sha256'] or sha(prior/'suite_config.json')!=lock['seed0_config_sha256']:
        raise ValueError('Seed 0 selection files do not match the reviewed archive')
    summary=read(prior/'summary.json')
    status=read(prior/'status.json')
    if status['status']!='complete' or summary['test_evaluated'] or summary['holdout_evaluated']:
        raise ValueError('Seed 0 suite status or protocol does not match')
    for rule,entry in lock['selected'].items():
        selected=summary['selected'][rule]
        if selected['value']!=entry['value'] or selected['checkpoint_sha256']!=entry['checkpoint_sha256']:
            raise ValueError('Seed 0 selected candidate changed: '+rule)
        if sha(prior/entry['directory']/'best_model.pt')!=entry['checkpoint_sha256']:
            raise ValueError('Seed 0 selected checkpoint missing or changed: '+rule)
    return lock

def main():
    p=argparse.ArgumentParser()
    for name in ('project-dir','data-dir','output-dir','prior-dir'):p.add_argument('--'+name,required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5)
    p.add_argument('--ack-row-feedback',action='store_true');p.add_argument('--ack-time-proxy',action='store_true')
    a=p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy:p.error('Both acknowledgements required')
    if min(a.epochs,a.patience)<1:p.error('Invalid settings')
    out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    start=time.monotonic();status={'status':'running','active':None,'test_evaluated':False,'holdout_evaluated':False}
    write(out/'status.json',status)
    try:
        lock=check_selection(Path(a.prior_dir))
        config={'plan':PLAN,'locked_from_seed0':lock,'epochs':a.epochs,'patience':a.patience,
                'selection':'fixed hyperparameters; per-run best epoch by development event NLL',
                'test_evaluated':False,'holdout_evaluated':False,
                'data_manifest_sha256':sha(Path(a.data_dir)/'manifest.json'),
                'code_sha256':{name:sha(ROOT/name) for name in ('run_suite.py','run_candidate.py','screen_core.py','pilot_core.py','decision_core.py','cross_core.py','locked_selection.json')},
                'feedback':'row immediate assumption','time':'event-time proxy','optimizer':'AdamW','lr':0.001,
                'weight_decay':0.00001,'batch_size':8,'chunk_size':50,'eval_chunk_size':100,
                'python':platform.python_version(),'torch':str(torch.__version__),'device':a.device,
                'gpu':torch.cuda.get_device_name(0) if a.device=='cuda' and torch.cuda.is_available() else None,
                'checkpoint_policy':'best model retained on server; no automatic resume'}
        write(out/'suite_config.json',config)
        rows=[]
        for seed,rule,index,name in PLAN:
            status['active']=name;write(out/'status.json',status)
            cmd=[sys.executable,'-B','-u',str(ROOT/'run_candidate.py'),'--project-dir',a.project_dir,
                 '--data-dir',a.data_dir,'--output-dir',str(out/name),'--rule',rule,'--index',str(index),'--seed',str(seed),
                 '--device',a.device,'--epochs',str(a.epochs),'--patience',str(a.patience),'--ack-row-feedback','--ack-time-proxy']
            log=out/(name+'.log');print('START',name,'log:',log,flush=True)
            with log.open('x',encoding='utf8') as stream:code=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT).returncode
            if code:raise RuntimeError(f'{name} failed, returncode={code}, log={log}')
            row=read(out/name/'status.json')
            if row['status']!='complete' or row['seed']!=seed or row['value']!=lock['selected'][rule]['value']:
                raise ValueError('Candidate status does not match fixed protocol')
            rows.append(row);print('COMPLETED',name,'best_epoch',row['best_epoch'],'dev_nll',row['best_dev_nll'],flush=True)
        for seed in (1,2):
            if len({r['initial_state_sha256'] for r in rows if r['seed']==seed})!=1:
                raise AssertionError('Rule initialization differs within seed')
        write(out/'summary.json',{'scope':'ASSIST seeds 1 and 2, fixed seed0 choices, development data only; not independent confirmation',
              'candidates':rows,'locked_values':{k:v['value'] for k,v in lock['selected'].items()},
              'holdout_evaluated':False,'test_evaluated':False})
        status.update(status='complete',active=None,seconds=time.monotonic()-start);write(out/'status.json',status)
        print('SUITE COMPLETE',flush=True)
    except BaseException as exc:
        status.update(status='failed',error=repr(exc),seconds=time.monotonic()-start);write(out/'status.json',status);raise

if __name__=='__main__':main()
