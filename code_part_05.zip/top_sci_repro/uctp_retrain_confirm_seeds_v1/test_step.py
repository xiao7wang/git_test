"""Synthetic protocol, numerical, and statistics tests; CPU/CUDA selectable."""
import argparse
import contextlib
import io
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from cross_core import read, write, sha, import_project, frozen_model, replay, compare, model_digest, validation_frame, KEYS
from step_core import ROOT, calibrate, calibrate_data, fixed_class, make_fixed, cached_arrays, cold_compare
from step_stats import summarize_group, pair_window

PROJECT, DEVICE = None, 'cpu'


class StepTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sources = read(ROOT / 'expected_inputs.json')['datasets']['assist']['shared_protocol']['source']
        cls.Data, cls.Base, cls.forward_fn = import_project(PROJECT, cls.sources)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='fixed_step_test_')
        self.path = Path(self.temp.name)
        from src.data import encode_frame
        rows = []
        for u in range(4):
            for i, hours in enumerate((0, 0, 12, 180, 200, 400, 401, 800, 900, 901, 1000)):
                kc = 'cold' if i == 8 else 'normal'
                rows.append(dict(student_id=str(u), item_id=kc, knowledge_ids=(kc,), timestamp=1_700_000_000.125+hours*3600,
                    response_time=1., rt_valid=True, source_row=i, label=float((i+u)%3>0), split=0 if i<4 else (1 if i<10 else 2)))
        arrays, vocab, summary = encode_frame(pd.DataFrame(rows))
        np.savez_compressed(self.path/'records.npz', **arrays)
        write(self.path/'vocabulary.json', vocab)
        write(self.path/'manifest.json', {'schema_version':1,'summary':summary,'records_sha256':sha(self.path/'records.npz'),
                                         'vocabulary_sha256':sha(self.path/'vocabulary.json')})
        self.data = self.Data(self.path)
        torch.manual_seed(7)
        cfg = dict(num_students=4,num_items=2,num_knowledges=2,variant='unit_write',ncd_hidden_dim=8,time_mode='none',decay_rate_per_hour=0.)
        model = self.Base(**cfg)
        self.ckpt = {'model_family':'time_factorial_v1','model_config':cfg,'model_state':model.state_dict(),
                     'data_fingerprint':self.data.fingerprint,'source_code':self.sources,'epoch':2}

    def tearDown(self):
        self.temp.cleanup()

    def model(self, retention=.7):
        return make_fixed(self.Base,self.ckpt,torch.device(DEVICE),self.data.fingerprint,self.sources,retention)

    def original(self, mode='none'):
        return frozen_model(self.Base,self.ckpt,mode,torch.device(DEVICE),self.data.fingerprint,self.sources)

    def run_replay(self, model=None, chunk=100, batch=8):
        with contextlib.redirect_stdout(io.StringIO()):
            return replay(model or self.model(),self.data,type(self).forward_fn,torch.device(DEVICE),'test',chunk_size=chunk,batch_size=batch)

    def step(self, model, state, hour, q=None, active=True, label=None):
        q = torch.tensor([[1.,0.]],device=DEVICE) if q is None else q
        now = torch.tensor([hour*3600],dtype=torch.float64,device=DEVICE)
        mask = torch.tensor([active],device=DEVICE)
        state = model.advance_time(state,q,now,mask)
        if label is not None:
            state = model.observe(state,q,torch.tensor([label],device=DEVICE),torch.zeros(1,device=DEVICE),mask)
        return state

    def test_calibration_mean_and_zero_exclusion(self):
        c=calibrate_data(self.data)
        expected=float(np.mean(np.array([2**(-12/168),.5],dtype=np.float32).astype(float)))
        self.assertEqual(c['eligible_positive_train_gaps'],8)
        self.assertEqual(c['zero_train_gaps_excluded'],4)
        self.assertEqual(c['mean_retention_float64'],expected)

    def test_calibration_ignores_valid_test_times(self):
        c=calibrate_data(self.data)
        self.data.arrays['timestamp'][self.data.arrays['split']>0]=np.nan
        self.assertEqual(c,calibrate_data(self.data))

    def test_calibration_ignores_all_labels(self):
        c=calibrate_data(self.data)
        self.data.arrays['label'][:]=np.nan
        self.assertEqual(c,calibrate_data(self.data))

    def test_calibration_no_train_rejected(self):
        self.data.arrays['split'][:]=1
        with self.assertRaises(ValueError): calibrate_data(self.data)

    def test_calibration_no_positive_gap_rejected(self):
        self.data.arrays['timestamp'][:]=1.
        with self.assertRaises(ValueError): calibrate_data(self.data)

    def test_calibration_float32_timestamp_rejected(self):
        self.data.arrays['timestamp']=self.data.arrays['timestamp'].astype(np.float32)
        with self.assertRaises(ValueError): calibrate_data(self.data)

    def test_calibration_multikc_rejected(self):
        self.data.arrays['item_q'][:]=True
        with self.assertRaises(ValueError): calibrate_data(self.data)

    def test_calibration_backwards_rejected(self):
        self.data.arrays['timestamp'][2]=0
        with self.assertRaises(ValueError): calibrate_data(self.data)

    def test_fixed_d_has_no_trainable_parameter(self):
        m=self.model()
        self.assertEqual(set(m.state_dict()),set(self.ckpt['model_state']))
        self.assertFalse(any(p.requires_grad for p in m.parameters()))
        self.assertEqual(model_digest(m.state_dict()),model_digest(self.ckpt['model_state']))

    def test_invalid_fixed_values(self):
        for value in (-.1,1.1,float('nan'),float('inf')):
            with self.assertRaises(ValueError): self.model(value)

    def test_half_retention_support_mean(self):
        m=self.model(.5);s=m.init_state(1,torch.device(DEVICE))
        s=self.step(m,s,0,label=1.)
        before_m,before_s=m.components(s)
        out=self.step(m,s,100)
        mean,support=m.components(out)
        self.assertTrue(torch.allclose(mean,before_m,atol=1e-7,rtol=0))
        self.assertAlmostEqual(support[0,0].item(),2.5)

    def test_fixed_retention_not_elapsed_magnitude(self):
        m=self.model();s=self.step(m,m.init_state(1,torch.device(DEVICE)),0,label=1.)
        a,b=self.step(m,s,.01),self.step(m,s,10000)
        self.assertTrue(torch.equal(a.evidence.alpha,b.evidence.alpha))
        self.assertTrue(torch.equal(a.evidence.beta,b.evidence.beta))

    def test_zero_gap_noop(self):
        m=self.model();s=self.step(m,m.init_state(1,torch.device(DEVICE)),0,label=1.)
        a=self.step(m,s,0)
        self.assertTrue(torch.equal(s.evidence.alpha,a.evidence.alpha))

    def test_first_and_prior_only_no_decay(self):
        m=self.model();s=m.init_state(1,torch.device(DEVICE))
        a=self.step(m,s,10000);b=self.step(m,a,20000)
        self.assertTrue(torch.equal(s.evidence.alpha,b.evidence.alpha))
        self.assertTrue(torch.equal(s.evidence.beta,b.evidence.beta))

    def test_inactive_noop(self):
        m=self.model();s=self.step(m,m.init_state(1,torch.device(DEVICE)),0,label=1.)
        a=self.step(m,s,100,active=False)
        self.assertTrue(torch.equal(s.evidence.alpha,a.evidence.alpha))
        self.assertTrue(torch.equal(s.clock.last_event_seconds,a.clock.last_event_seconds))

    def test_nonqueried_kc_unchanged(self):
        m=self.model();s=self.step(m,m.init_state(1,torch.device(DEVICE)),0,label=1.)
        a=self.step(m,s,100,q=torch.tensor([[0.,1.]],device=DEVICE))
        self.assertTrue(torch.equal(s.evidence.alpha[:,0],a.evidence.alpha[:,0]))

    def test_backward_clock_rejected(self):
        m=self.model();s=self.step(m,m.init_state(1,torch.device(DEVICE)),10)
        with self.assertRaises(ValueError): self.step(m,s,9)

    def test_support_floor_zero_retention(self):
        m=self.model(0);s=self.step(m,m.init_state(1,torch.device(DEVICE)),0,label=1.)
        a=self.step(m,s,100)
        self.assertAlmostEqual(m.components(a)[1][0,0].item(),2.)

    def test_one_retention_matches_none(self):
        self.assertTrue(compare(self.run_replay(self.model(1)),self.run_replay(self.original()))['success'])

    def test_equal_constant_gaps_match_real_time(self):
        m=self.model(.5);t=self.original('support_only')
        a,b=m.init_state(1,torch.device(DEVICE)),t.init_state(1,torch.device(DEVICE))
        for i in range(6):
            a=self.step(m,a,i*168,label=float(i%2))
            b=self.step(t,b,i*168,label=float(i%2))
            self.assertTrue(torch.equal(a.evidence.alpha,b.evidence.alpha))
            self.assertTrue(torch.equal(a.evidence.beta,b.evidence.beta))

    def test_chunk_and_batch_equivalence(self):
        self.assertTrue(compare(self.run_replay(),self.run_replay(chunk=3,batch=3))['success'])

    def test_reset_each_replay(self):
        m=self.model();a=self.run_replay(m);b=self.run_replay(m)
        self.assertTrue(compare(a,b)['success'])

    def test_labels_after_prediction(self):
        a=self.run_replay();row=a['record_idx'][1]
        self.data.arrays['label'][row]=1-self.data.arrays['label'][row]
        b=self.run_replay();upto=a['record_idx']<=row
        self.assertTrue(np.array_equal(a['probability'][upto],b['probability'][upto]))
        self.assertTrue((a['probability'][~upto]!=b['probability'][~upto]).any())

    def test_test_labels_never_consumed(self):
        a=self.run_replay();self.data.arrays['label'][self.data.arrays['split']==2]=np.nan
        self.assertTrue(compare(a,self.run_replay())['success'])

    def test_retiming_preserves_fixed_replay(self):
        a=self.run_replay();self.data.arrays['timestamp'][:]*=3
        self.assertTrue(compare(a,self.run_replay())['success'])

    def test_retiming_changes_real_time(self):
        a=self.run_replay(self.original('support_only'));self.data.arrays['timestamp'][:]*=3
        b=self.run_replay(self.original('support_only'))
        self.assertGreater(float(np.max(np.abs(a['probability']-b['probability']))),1e-6)

    def test_cold_guard(self):
        self.assertTrue(cold_compare({'NN':self.run_replay(self.original()),'NF':self.run_replay()},self.data)['success'])

    def test_cache_alignment_and_corruption(self):
        r=self.run_replay(self.original());f=validation_frame(self.data,r['record_idx'])
        f.to_csv(self.path/'events.csv.gz',index=False,compression='gzip')
        np.savez_compressed(self.path/'predictions.npz',record_idx=r['record_idx'],**{b+'_'+k:r[k] for b in ('NN','NS') for k in KEYS})
        _,v=cached_arrays(self.path,self.data)
        self.assertTrue(compare(r,v['NN'])['success'])
        f.loc[0,'label']=1-f.loc[0,'label'];f.to_csv(self.path/'events.csv.gz',index=False,compression='gzip')
        with self.assertRaises(AssertionError): cached_arrays(self.path,self.data)

    def test_cache_gap_roundtrip_is_compared_at_original_float32_precision(self):
        ids = np.flatnonzero(self.data.arrays['split'] == 1)
        self.data.arrays['delta_t_k_hours'][ids[0]] = np.float32(384.7025)
        r = self.run_replay(self.original())
        f = validation_frame(self.data, r['record_idx'])
        f.to_csv(self.path/'events.csv.gz', index=False, compression='gzip')
        np.savez_compressed(self.path/'predictions.npz', record_idx=r['record_idx'],
                            **{b+'_'+k:r[k] for b in ('NN','NS') for k in KEYS})
        parsed = pd.read_csv(self.path/'events.csv.gz', compression='gzip', float_precision='round_trip')
        self.assertNotEqual(float(parsed.loc[0, 'delta_t_k_hours']), float(np.float32(384.7025)))
        cached_arrays(self.path, self.data)
        parsed.loc[0, 'delta_t_k_hours'] += 0.01
        parsed.to_csv(self.path/'events.csv.gz', index=False, compression='gzip')
        with self.assertRaisesRegex(AssertionError, 'delta_t_k_hours'):
            cached_arrays(self.path, self.data)

    def test_cache_timestamp_does_not_get_float32_tolerance(self):
        r = self.run_replay(self.original())
        f = validation_frame(self.data, r['record_idx'])
        f.to_csv(self.path/'events.csv.gz', index=False, compression='gzip')
        np.savez_compressed(self.path/'predictions.npz', record_idx=r['record_idx'],
                            **{b+'_'+k:r[k] for b in ('NN','NS') for k in KEYS})
        f.loc[0, 'timestamp'] += 0.125
        f.to_csv(self.path/'events.csv.gz', index=False, compression='gzip')
        with self.assertRaisesRegex(AssertionError, 'timestamp'):
            cached_arrays(self.path, self.data)

    def test_stats_identical_models_zero(self):
        r=self.run_replay();f=validation_frame(self.data,r['record_idx'])
        arrays=np.broadcast_to(r['probability'],(3,3,len(f))).copy()
        s=summarize_group(f,arrays,np.ones(len(f),bool),reps=20)
        for row in s['paired'].values():
            self.assertEqual(row['delta'],0);self.assertEqual(row['ci95'],[0,0])

    def test_stats_average_losses_not_ensemble(self):
        r=self.run_replay();f=validation_frame(self.data,r['record_idx'])
        arrays=np.full((3,3,len(f)),.5);arrays[0,1]=.1;arrays[1,1]=.9
        s=summarize_group(f,arrays,np.ones(len(f),bool),reps=20)
        self.assertGreater(s['paired']['seed_mean/real_time_minus_none/nll']['delta'],.1)

    def test_parameter_hash_after_replay(self):
        m=self.model();before=model_digest(m.state_dict());self.run_replay(m)
        self.assertEqual(before,model_digest(m.state_dict()))

    def test_pair_window_zero_and_coverage(self):
        r=self.run_replay();f=validation_frame(self.data,r['record_idx'])
        arrays=np.broadcast_to(r['probability'],(3,3,len(f))).copy()
        pairs=np.array([[r['record_idx'][0],r['record_idx'][1]]])
        v=pair_window(f,arrays,pairs,reps=20)
        self.assertEqual(v['comparisons']['real_time_minus_fixed_step']['delta'],0)


def main():
    global PROJECT,DEVICE
    p=argparse.ArgumentParser();p.add_argument('--project-dir',required=True);p.add_argument('--device',choices=('cpu','cuda'),required=True);p.add_argument('--report',required=True)
    args=p.parse_args();PROJECT,DEVICE=args.project_dir,args.device
    if DEVICE=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA required; no skip/fallback')
    torch.set_num_threads(2)
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(StepTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    write(args.report,{'success':result.wasSuccessful() and not result.skipped,'tests_run':result.testsRun,'device':DEVICE,
          'torch':str(torch.__version__),'failures':[(str(t),e) for t,e in result.failures],
          'errors':[(str(t),e) for t,e in result.errors],'skipped':result.skipped,'synthetic_only':True})
    if not result.wasSuccessful() or result.skipped: raise SystemExit(1)


if __name__=='__main__': main()
