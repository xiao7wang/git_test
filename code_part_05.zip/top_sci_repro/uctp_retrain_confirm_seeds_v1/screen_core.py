"""Train one candidate, select strictly by development NLL, and preserve best weights."""
import math
import time
from pathlib import Path
import numpy as np
import torch
from cross_core import model_digest, sha, write
from pilot_core import fresh_model

def fit_candidate(data, Base, engine, rule, value, seed, device, output, epochs=20, patience=5, hidden=128):
    out=Path(output)
    out.mkdir(parents=True,exist_ok=False)
    model,initial=fresh_model(Base,data.manifest['summary'],rule,value,seed,device,hidden)
    optimizer=torch.optim.AdamW(model.parameters(),lr=1e-3,weight_decay=1e-5)
    status={'status':'running','rule':rule,'value':value,'seed':seed,'epoch':0,'test_evaluated':False,'holdout_evaluated':False}
    write(out/'status.json',status)
    history=[]
    best=float('inf')
    best_epoch=None
    stale=0
    start=time.monotonic()
    try:
        for epoch in range(1,epochs+1):
            status.update(epoch=epoch,phase='train')
            write(out/'status.json',status)
            print(f'epoch={epoch} rule={rule} value={value} phase=train',flush=True)
            train=engine.train_epoch(model,data,optimizer,device,8,50,seed+epoch)
            if any(not bool(torch.isfinite(p).all()) for p in model.parameters()):
                raise FloatingPointError('Non-finite model parameter')
            status['phase']='development_validation'
            write(out/'status.json',status)
            valid,frame,_=engine.evaluate(model,data,device,'valid',8,100,True)
            if not set(frame.student_idx.astype(int)).issubset(data.users):
                raise AssertionError('Unexpected validation student')
            nll=float(valid['nll'])
            if not math.isfinite(nll):
                raise ValueError('Nonfinite development NLL')
            history.append({'epoch':epoch,'train':train,'dev':valid})
            write(out/'history.json',history)
            print(f'epoch={epoch} dev_nll={nll:.9f} dev_auc={valid["auc"]}',flush=True)
            if nll<best:
                best,best_epoch,stale=nll,epoch,0
                checkpoint={'model_state':model.state_dict(),'rule':rule,'value':value,'seed':seed,
                            'best_epoch':epoch,'dev_nll':nll,'initial_state_sha256':initial,
                            'data_fingerprint':data.fingerprint,'model_family':'retrain_screen_v1',
                            'selection_metric':'development_nll'}
                pending=out/'best_model.pending.pt'
                torch.save(checkpoint,pending)
                pending.replace(out/'best_model.pt')
            else:
                stale+=1
            if stale>=patience:
                print(f'early_stopping epoch={epoch} patience={patience}',flush=True)
                break
        if best_epoch is None: raise RuntimeError('No best model')
        status.update(phase='best_development_recheck')
        write(out/'status.json',status)
        ckpt=torch.load(out/'best_model.pt',map_location=device,weights_only=True)
        model.load_state_dict(ckpt['model_state'],strict=True)
        valid,frame,_=engine.evaluate(model,data,device,'valid',8,100,True)
        if abs(float(valid['nll'])-best)>1e-7:
            raise AssertionError('Best checkpoint does not reproduce its NLL')
        frame[['record_idx','student_idx','label','probability']].to_csv(out/'dev_predictions.csv.gz',index=False,compression='gzip')
        result={'status':'complete','rule':rule,'value':value,'seed':seed,'epochs':len(history),
                'best_epoch':best_epoch,'best_dev_nll':best,'dev_auc':valid['auc'],
                'dev_n':valid['n'],'initial_state_sha256':initial,'checkpoint_sha256':sha(out/'best_model.pt'),
                'checkpoint_model_state_sha256':model_digest(model.state_dict()),
                'seconds':time.monotonic()-start,'test_evaluated':False,'holdout_evaluated':False}
        write(out/'status.json',result)
        return result
    except BaseException as exc:
        status.update(status='failed',error=repr(exc),seconds=time.monotonic()-start)
        write(out/'status.json',status)
        raise
