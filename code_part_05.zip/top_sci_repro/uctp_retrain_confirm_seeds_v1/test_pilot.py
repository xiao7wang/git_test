"""Train on synthetic data and check strict development/test boundaries."""
import argparse
import io
import contextlib
import math
import unittest
import numpy as np
import torch
import test_step
from pilot_core import DevelopmentData, RULES, development_users, run_one

PROJECT, DEVICE = None, 'cpu'

class TrainingPilotTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        test_step.PROJECT, test_step.DEVICE = PROJECT, DEVICE
        test_step.StepTests.setUpClass()
        from src import engine
        cls.engine = engine
        cls.Base = test_step.StepTests.Base

    def setUp(self):
        self.fixture = test_step.StepTests()
        self.fixture.setUp()

    def tearDown(self):
        self.fixture.tearDown()

    def test_one_epoch_training_all_rules_without_holdout_or_test_labels(self):
        d = self.fixture.data
        valid_students = d.arrays['student_idx'][d.arrays['split']==1]
        dev_users = development_users(valid_students)
        self.assertTrue(dev_users)
        self.assertTrue(set(valid_students)-dev_users)
        poison = (d.arrays['split']==2) | ((d.arrays['split']==1) & ~np.isin(d.arrays['student_idx'],list(dev_users)))
        d.arrays['label'][poison] = np.nan
        dev = DevelopmentData(d, dev_users)
        results = []
        for rule, value in RULES:
            with contextlib.redirect_stdout(io.StringIO()):
                row = run_one(dev, self.Base, self.engine, rule, value, 0,
                              torch.device(DEVICE), batch_size=2,chunk_size=3,eval_chunk=4,hidden=8)
            self.assertGreater(row['train']['optimizer_steps'],0)
            self.assertTrue(math.isfinite(row['dev_nll']))
            self.assertNotEqual(row['initial_state_sha256'],row['final_state_sha256'])
            results.append(row)
        self.assertEqual(len({r['initial_state_sha256'] for r in results}),1)

    def test_test_batches_are_rejected(self):
        dev=DevelopmentData(self.fixture.data,{0})
        with self.assertRaises(ValueError):
            list(dev.batches('test',2))

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--project-dir',required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cpu')
    a=p.parse_args()
    PROJECT,DEVICE=a.project_dir,a.device
    if DEVICE=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable')
    torch.set_num_threads(2)
    unittest.main(argv=['test_pilot'],verbosity=2)
