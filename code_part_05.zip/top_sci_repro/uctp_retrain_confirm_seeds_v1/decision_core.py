"""Frozen same-head state rules for the recency decision experiment."""
import math

from cross_core import RATE, frozen_model


def decision_class(Base):
    import torch
    from src.temporal_model import BetaEvidence, Clock, TemporalState

    class DecisionCD(Base):
        def __init__(self, *args, decision_rule, value, **kwargs):
            self.decision_rule = decision_rule
            self.decision_value = float(value)
            if decision_rule not in ('fixed_all', 'fixed_positive', 'real_time', 'fixed_gain'):
                raise ValueError('Unknown decision rule')
            if not math.isfinite(self.decision_value):
                raise ValueError('Parameter must be finite')
            if decision_rule in ('fixed_all', 'fixed_positive') and not 0 <= self.decision_value <= 1:
                raise ValueError('Retention must be in [0,1]')
            if decision_rule == 'fixed_gain' and not 0 < self.decision_value < 1:
                raise ValueError('Fixed gain must be in (0,1)')
            if decision_rule == 'real_time' and self.decision_value <= 0:
                raise ValueError('Half-life must be positive')
            kwargs.update(time_mode='support_only', decay_rate_per_hour=(
                math.log(2) / self.decision_value if decision_rule == 'real_time' else RATE))
            super().__init__(*args, **kwargs)
            if self.variant != 'unit_write':
                raise ValueError('Only unit_write checkpoints are supported')

        def _advance_time_unchecked(self, state, q, timestamp, active_mask):
            if self.decision_rule == 'real_time':
                return super()._advance_time_unchecked(state, q, timestamp, active_mask)
            clock, evidence = state.clock, state.evidence
            if not isinstance(evidence, BetaEvidence):
                raise TypeError('Expected BetaEvidence')
            now = torch.where(active_mask, timestamp, clock.last_event_seconds)
            selected = active_mask[:, None] & (q > 0)
            support = evidence.alpha + evidence.beta
            changed = selected & clock.seen_kc & (support > 2)
            if self.decision_rule == 'fixed_positive':
                changed = changed & (now[:, None] > clock.last_kc_seconds)
            if self.decision_rule in ('fixed_all', 'fixed_positive'):
                next_support = 2 + (support - 2) * self.decision_value
                factor = next_support / support
                evidence = BetaEvidence(torch.where(changed, evidence.alpha * factor, evidence.alpha),
                                        torch.where(changed, evidence.beta * factor, evidence.beta))
            clock = Clock(torch.where(selected, now[:, None], clock.last_kc_seconds),
                          clock.seen_kc | selected, now, clock.seen_event | active_mask)
            return TemporalState(evidence, clock)

        def observe(self, state, q, label, difficulty_scalar, update_mask):
            if self.decision_rule != 'fixed_gain':
                return super().observe(state, q, label, difficulty_scalar, update_mask)
            evidence = state.evidence
            support = evidence.alpha + evidence.beta
            mean = evidence.alpha / support
            mask = update_mask[:, None] & (q > 0)
            outcome = torch.where(update_mask, label, torch.zeros_like(label))[:, None]
            next_mean = mean + self.decision_value * (outcome - mean)
            # S=2 is only a representation for the shared mean-based head;
            # its uncertainty/evidence outputs are not calibrated confidence.
            return TemporalState(BetaEvidence(torch.where(mask, 2 * next_mean, evidence.alpha),
                                              torch.where(mask, 2 * (1-next_mean), evidence.beta)),
                                 state.clock)

    return DecisionCD


def make_decision(Base, checkpoint, device, fingerprint, sources, rule, value):
    def factory(**kwargs):
        return decision_class(Base)(decision_rule=rule, value=value, **kwargs)
    return frozen_model(factory, checkpoint, 'support_only', device, fingerprint, sources)
