# Patched for ORCDF-only reproduction.
# Some baselines such as RCD/LightGCN require dgl. We make them optional.

try:
    from .orcdf import ORCDF
except Exception as e:
    raise e

try:
    from .ulcdf import ULCDF
except Exception as e:
    ULCDF = None
    print("[optional import skipped] ULCDF:", repr(e))

try:
    from .lightgcn import LIGHTGCN
except Exception as e:
    LIGHTGCN = None
    print("[optional import skipped] LIGHTGCN:", repr(e))

try:
    from .rcd import RCD
except Exception as e:
    RCD = None
    print("[optional import skipped] RCD:", repr(e))
