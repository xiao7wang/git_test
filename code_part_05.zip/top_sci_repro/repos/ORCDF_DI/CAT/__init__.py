# Patched for ORCDF-only reproduction.
# Avoid importing optional CAT modules that require extra dependencies.
