# Patched for ORCDF-only reproduction.
# ORCDF only needs AbstractModel from CAT.model.abstract_model.
try:
    from .abstract_model import AbstractModel
except Exception as e:
    raise e
