import json
import shutil
from pathlib import Path
import numpy as np
import csv

ORCDF_ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/ORCDF")
HYPER_ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM")

def read_csv_rows(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for r in reader:
            if not r:
                continue
            # skip possible header
            try:
                float(r[0]); float(r[1]); float(r[2])
            except Exception:
                continue
            rows.append([int(float(r[0])), int(float(r[1])), int(float(r[2]))])
    return np.asarray(rows, dtype=np.int64)

def convert(hyper_data_dir, dataset_name):
    hyper_data_dir = Path(hyper_data_dir)
    cfg = json.load(open(hyper_data_dir / "config.json", "r", encoding="utf-8"))

    data_file = hyper_data_dir / cfg["data"]
    q_file = hyper_data_dir / cfg["q_file"]

    out_dir = ORCDF_ROOT / "datasets" / dataset_name
    out_dir.mkdir(parents=True, exist_ok=True)

    response = read_csv_rows(data_file)
    q = np.loadtxt(q_file, delimiter=",")
    if q.ndim == 1:
        q = q.reshape(1, -1)

    # ORCDF uses response.csv: student_id, exercise_id, score
    np.savetxt(out_dir / "response.csv", response, fmt="%d", delimiter=",")
    np.savetxt(out_dir / "q_matrix.csv", q.astype(int), fmt="%d", delimiter=",")

    # copy original config structure if possible, then update dataset/files/info
    base_config_path = ORCDF_ROOT / "datasets" / "Assist17" / "config.json"
    if base_config_path.exists():
        out_cfg = json.load(open(base_config_path, "r", encoding="utf-8"))
    else:
        out_cfg = {}

    out_cfg["dataset"] = dataset_name
    out_cfg["files"] = {
        "q_matrix": "q_matrix.csv",
        "response": "response.csv"
    }

    # add both common styles to be safe
    out_cfg["student_num"] = int(cfg["student_num"])
    out_cfg["exercise_num"] = int(cfg["exercise_num"])
    out_cfg["knowledge_num"] = int(cfg["knowledge_num"])
    out_cfg["info"] = {
        "student_num": int(cfg["student_num"]),
        "exercise_num": int(cfg["exercise_num"]),
        "knowledge_num": int(cfg["knowledge_num"])
    }

    json.dump(out_cfg, open(out_dir / "config.json", "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print("saved:", out_dir)
    print("response:", response.shape, "min/max stu:", response[:,0].min(), response[:,0].max(),
          "min/max exer:", response[:,1].min(), response[:,1].max())
    print("q:", q.shape)

convert(
    HYPER_ROOT / "data" / "assistments_time_sample5000_item12000",
    "assist_sample5000_item12000"
)

convert(
    HYPER_ROOT / "data" / "ednet_time_ours",
    "ednet_time_ours"
)
