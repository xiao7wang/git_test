from pathlib import Path
import re

root = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/ORCDF_DI")

# ===== 1. Patch extractor: add item-prior adapter into exercise representation =====
p = root / "inscd/extractor/orcdf.py"
s = p.read_text(encoding="utf-8")

if "enable_item_prior" not in s:
    target = "        self.__knowledge_impact_emb = nn.Embedding(self.exercise_num, self.latent_dim, dtype=self.dtype).to(self.device)\n"
    insert = target + r'''
        # ===== Item-Prior Adapter: training-only difficulty/reliability prior =====
        # Disabled by default. It will be enabled after build() and before train().
        self.item_prior_dim = 0
        self.item_prior = None
        self.item_prior_adapter = None
'''
    if target not in s:
        raise RuntimeError("Cannot find __knowledge_impact_emb line in extractor.")
    s = s.replace(target, insert, 1)

    marker = "    def get_all_emb(self):\n"
    methods = r'''
    def enable_item_prior(self, item_prior_dim: int):
        """Create a learnable adapter for item prior features.

        The adapter maps item prior features, e.g. [difficulty] or
        [difficulty, reliability], into the same latent space as exercise
        representations. The last linear layer is zero-initialized so that
        the model starts from the original ORCDF behavior.
        """
        self.item_prior_dim = int(item_prior_dim)
        self.register_buffer(
            "item_prior",
            torch.zeros(self.exercise_num, self.item_prior_dim, dtype=self.dtype, device=self.device)
        )
        self.item_prior_adapter = nn.Sequential(
            nn.Linear(self.item_prior_dim, self.latent_dim, dtype=self.dtype),
            nn.Tanh(),
            nn.Linear(self.latent_dim, self.latent_dim, dtype=self.dtype)
        ).to(self.device)

        # Zero initialization: start exactly from original ORCDF exercise representation.
        nn.init.zeros_(self.item_prior_adapter[-1].weight)
        nn.init.zeros_(self.item_prior_adapter[-1].bias)

    def set_item_prior(self, item_prior):
        if self.item_prior_adapter is None or self.item_prior is None:
            raise RuntimeError("Call enable_item_prior(item_prior_dim) before set_item_prior().")
        item_prior = torch.as_tensor(item_prior, dtype=self.dtype, device=self.device)
        if item_prior.shape != self.item_prior.shape:
            raise ValueError(f"item_prior shape mismatch: got {tuple(item_prior.shape)}, expected {tuple(self.item_prior.shape)}")
        self.item_prior.data.copy_(item_prior)

    def _apply_item_prior(self, exercise_id, exer_repr):
        """Inject item-prior adapter into batch exercise representations."""
        if self.item_prior_adapter is None or self.item_prior is None:
            return exer_repr
        prior_batch = F.embedding(exercise_id, self.item_prior)
        return exer_repr + self.item_prior_adapter(prior_batch)

    def _apply_item_prior_all(self, exer_repr_all):
        """Inject item-prior adapter into all exercise representations."""
        if self.item_prior_adapter is None or self.item_prior is None:
            return exer_repr_all
        return exer_repr_all + self.item_prior_adapter(self.item_prior)

'''
    if marker not in s:
        raise RuntimeError("Cannot find def get_all_emb marker.")
    s = s.replace(marker, methods + marker, 1)

    old = """        diff_ts = self.transfer_exercise_layer(
            F.embedding(exercise_id, exer_forward)) if 'tf' not in self.mode else F.embedding(exercise_id, exer_forward)
"""
    new = """        exer_repr = F.embedding(exercise_id, exer_forward)
        exer_repr = self._apply_item_prior(exercise_id, exer_repr)
        diff_ts = self.transfer_exercise_layer(exer_repr) if 'tf' not in self.mode else exer_repr
"""
    if old not in s:
        raise RuntimeError("Cannot find batch diff_ts construction.")
    s = s.replace(old, new, 1)

    old = "        diff_ts = self.transfer_exercise_layer(exer_forward) if 'tf' not in self.mode else exer_forward\n"
    new = """        exer_forward = self._apply_item_prior_all(exer_forward)
        diff_ts = self.transfer_exercise_layer(exer_forward) if 'tf' not in self.mode else exer_forward
"""
    if old not in s:
        raise RuntimeError("Cannot find all-item diff_ts construction.")
    s = s.replace(old, new, 1)

    p.write_text(s, encoding="utf-8")
    print("[OK] patched extractor:", p)
else:
    print("[SKIP] extractor already patched:", p)


# ===== 2. Patch exp script: add --item_prior_type and compute prior from train split =====
p = root / "exp_orcdf_nowandb.py"
s = p.read_text(encoding="utf-8")

if "--item_prior_type" not in s:
    target = "parser.add_argument('--mode', type=str, default='')\n"
    insert = target + "parser.add_argument('--item_prior_type', type=str, default='none', choices=['none', 'd', 'i', 'di'], help='training-only item prior adapter type')\n"
    if target not in s:
        raise RuntimeError("Cannot find parser mode argument.")
    s = s.replace(target, insert, 1)

    helper = r'''

def _zscore(x):
    x = np.asarray(x, dtype=np.float64)
    std = float(np.std(x))
    if std < 1e-12:
        return np.zeros_like(x, dtype=np.float64)
    return (x - float(np.mean(x))) / std


def build_item_prior_from_train(datahub, item_prior_type: str):
    """Build training-only item prior.

    d: smoothed item correctness logit, standardized.
    i: log item exposure count, standardized.

    Only datahub['train'] is used, so validation/test labels are not leaked.
    """
    if item_prior_type == 'none':
        return None

    train = np.asarray(datahub['train'])
    exer = train[:, 1].astype(np.int64)
    score = train[:, 2].astype(np.float64)

    exercise_num = int(datahub.exercise_num)
    cnt = np.bincount(exer, minlength=exercise_num).astype(np.float64)
    cor = np.bincount(exer, weights=score, minlength=exercise_num).astype(np.float64)

    p = (cor + 1.0) / (cnt + 2.0)
    p = np.clip(p, 1e-6, 1 - 1e-6)
    d = _zscore(np.log(p / (1.0 - p)))
    i = _zscore(np.log1p(cnt))

    feats = []
    if 'd' in item_prior_type:
        feats.append(d)
    if 'i' in item_prior_type:
        feats.append(i)

    prior = np.stack(feats, axis=1).astype(np.float64)
    print(f"[item_prior] type={item_prior_type}, shape={prior.shape}, "
          f"range=({prior.min():.4f}, {prior.max():.4f})")
    return prior

'''
    marker = "\ndef main(config):\n"
    if marker not in s:
        raise RuntimeError("Cannot find def main marker.")
    s = s.replace(marker, helper + marker, 1)

    old = '    print("Number of response logs {}".format(len(datahub)))\n'
    new = '''    print("Number of response logs {}".format(len(datahub)))

    item_prior = build_item_prior_from_train(datahub, config.get('item_prior_type', 'none'))
'''
    if old not in s:
        raise RuntimeError("Cannot find Number of response logs line.")
    s = s.replace(old, new, 1)

    old = """        orcdf.build(latent_dim=config['latent_dim'], device=config['device'], if_type=config['if_type'],
                    gcn_layers=config['gcn_layers'], keep_prob=config['keep_prob'],
                    dtype=config['dtype'], ssl_weight=config['ssl_weight'], ssl_temp=config['ssl_temp'],
                    flip_ratio=config['flip_ratio'], mode=config['mode'])
"""
    new = old + """
        if item_prior is not None:
            orcdf.extractor.enable_item_prior(item_prior.shape[1])
            orcdf.extractor.set_item_prior(item_prior)
            print(f"[item_prior] enabled adapter with dim={item_prior.shape[1]}")

"""
    if old not in s:
        raise RuntimeError("Cannot find orcdf.build block.")
    s = s.replace(old, new, 1)

    p.write_text(s, encoding="utf-8")
    print("[OK] patched exp:", p)
else:
    print("[SKIP] exp already patched:", p)

