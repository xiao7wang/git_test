import os
import sys
import csv
import torch
import numpy as np
from sklearn.metrics import (
    roc_auc_score,
    precision_score,
    recall_score,
    f1_score,
)
from data_loader import ValTestDataLoader
from model import Net


def test(epoch, seed, out_csv=None):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    config_path = os.environ.get("NEURALCD_CONFIG", "config.txt")
    model_dir = os.environ.get("NEURALCD_MODEL_DIR", "model")
    data_dir = os.environ.get("NEURALCD_DATA_DIR", "")

    with open(config_path) as f:
        f.readline()
        student_n, exer_n, knowledge_n = list(map(int, f.readline().split(",")))

    data_loader = ValTestDataLoader("test")
    net = Net(student_n, exer_n, knowledge_n)

    model_path = os.path.join(model_dir, f"model_original_seed{seed}_epoch{epoch}")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"Checkpoint not found: {model_path}")

    net.load_state_dict(torch.load(model_path, map_location=device))
    net = net.to(device)
    net.eval()

    correct_count, exer_count = 0, 0
    pred_all, label_all = [], []

    with torch.no_grad():
        while not data_loader.is_end():
            stu, exer, kn, labels = data_loader.next_batch()

            stu = stu.to(device)
            exer = exer.to(device)
            kn = kn.to(device)
            labels = labels.to(device)

            output = net(stu, exer, kn).view(-1)
            output = torch.clamp(output, 1e-6, 1 - 1e-6)

            pred_all += output.detach().cpu().tolist()
            label_all += labels.detach().cpu().tolist()

            pred_label_batch = (output >= 0.5).long()
            correct_count += (pred_label_batch == labels.long()).sum().item()
            exer_count += len(labels)

    pred_all = np.array(pred_all, dtype=np.float64)
    label_all = np.array(label_all, dtype=np.int64)
    pred_label = (pred_all >= 0.5).astype(np.int64)

    acc = correct_count / exer_count
    rmse = np.sqrt(np.mean((label_all - pred_all) ** 2))
    auc = roc_auc_score(label_all, pred_all)
    precision = precision_score(label_all, pred_label, zero_division=0)
    recall = recall_score(label_all, pred_label, zero_division=0)
    f1 = f1_score(label_all, pred_label, zero_division=0)

    print(
        "epoch= %d, seed= %d, accuracy= %.6f, rmse= %.6f, auc= %.6f, "
        "precision= %.6f, recall= %.6f, f1= %.6f"
        % (epoch, seed, acc, rmse, auc, precision, recall, f1)
    )

    if out_csv:
        exists = os.path.exists(out_csv)
        with open(out_csv, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            if not exists:
                writer.writerow([
                    "dataset", "seed", "epoch",
                    "ACC", "RMSE", "AUC", "Precision", "Recall", "F1",
                    "config_path", "data_dir", "model_dir",
                ])
            dataset = os.environ.get("NEURALCD_DATASET", "unknown")
            writer.writerow([
                dataset, seed, epoch,
                f"{acc:.6f}", f"{rmse:.6f}", f"{auc:.6f}",
                f"{precision:.6f}", f"{recall:.6f}", f"{f1:.6f}",
                config_path, data_dir, model_dir,
            ])

    return acc, rmse, auc, precision, recall, f1


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("python predict_original_seed_extra_metrics.py {epoch} {seed} [out_csv]")
        sys.exit(1)

    epoch = int(sys.argv[1])
    seed = int(sys.argv[2])
    out_csv = sys.argv[3] if len(sys.argv) >= 4 else None
    test(epoch, seed, out_csv)
