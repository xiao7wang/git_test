import os
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import sys
import random
from sklearn.metrics import roc_auc_score
from data_loader import TrainDataLoader, ValTestDataLoader
from model import Net


def set_seed(seed):
    seed = int(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def evaluate(model, d_type, device):
    data_loader = ValTestDataLoader(d_type)
    model.eval()

    correct_count, exer_count = 0, 0
    pred_all, label_all = [], []

    with torch.no_grad():
        while not data_loader.is_end():
            stu, exer, kn, labels = data_loader.next_batch()

            stu = stu.to(device)
            exer = exer.to(device)
            kn = kn.to(device)
            labels = labels.to(device)

            output = model(stu, exer, kn).view(-1)
            output = torch.clamp(output, 1e-6, 1 - 1e-6)

            correct_count += (((labels == 1) & (output > 0.5)) | ((labels == 0) & (output < 0.5))).sum().item()
            exer_count += len(labels)

            pred_all += output.detach().cpu().tolist()
            label_all += labels.detach().cpu().tolist()

    pred_all = np.array(pred_all)
    label_all = np.array(label_all)

    acc = correct_count / exer_count
    rmse = np.sqrt(np.mean((label_all - pred_all) ** 2))
    auc = roc_auc_score(label_all, pred_all)

    return acc, rmse, auc


def train(device_name, epoch_n, seed):
    set_seed(seed)
    device = torch.device(device_name)

    with open(os.environ.get("NEURALCD_CONFIG", "config.txt")) as f:
        f.readline()
        student_n, exer_n, knowledge_n = list(map(int, f.readline().split(",")))

    train_loader = TrainDataLoader()
    net = Net(student_n, exer_n, knowledge_n).to(device)

    optimizer = optim.Adam(net.parameters(), lr=0.002)
    loss_function = nn.NLLLoss()

    val_path = f"result/model_val_original_seed{seed}.txt"
    open(val_path, "w", encoding="utf8").close()

    print(f"training NeuralCD original seed model... seed={seed}")

    for epoch in range(epoch_n):
        train_loader.reset()
        running_loss = 0.0
        batch_count = 0

        while not train_loader.is_end():
            batch_count += 1
            stu, exer, kn, labels = train_loader.next_batch()

            stu = stu.to(device)
            exer = exer.to(device)
            kn = kn.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()

            output_1 = net(stu, exer, kn)
            output_1 = torch.clamp(output_1, 1e-6, 1 - 1e-6)
            output_0 = torch.ones(output_1.size()).to(device) - output_1
            output = torch.cat((output_0, output_1), 1)

            loss = loss_function(torch.log(output), labels)
            loss.backward()
            optimizer.step()
            net.apply_clipper()

            running_loss += loss.item()

            if batch_count % 200 == 199:
                print("[%d, %5d] loss: %.3f" % (epoch + 1, batch_count + 1, running_loss / 200))
                running_loss = 0.0

        acc, rmse, auc = evaluate(net, "validation", device)
        print("epoch= %d, accuracy= %f, rmse= %f, auc= %f" % (epoch + 1, acc, rmse, auc))

        with open(val_path, "a", encoding="utf8") as f:
            f.write("epoch= %d, accuracy= %f, rmse= %f, auc= %f\n" % (epoch + 1, acc, rmse, auc))

        os.makedirs(os.environ.get("NEURALCD_MODEL_DIR", "model"), exist_ok=True)
        torch.save(net.state_dict(), os.path.join(os.environ.get("NEURALCD_MODEL_DIR", "model"), f"model_original_seed{seed}_epoch{epoch + 1}"))


if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("python train_original_seed.py {device} {epoch} {seed}")
        exit(1)

    train(
        device_name=sys.argv[1],
        epoch_n=int(sys.argv[2]),
        seed=int(sys.argv[3])
    )
