#!/bin/bash
source ~/miniconda3/etc/profile.d/conda.sh
conda activate cd5090
cd /home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD

echo "===== START Assistments NeuralCD original seeds ====="
date
cat config.txt

for s in 0 1 2
do
  echo "===== train original seed $s ====="
  date

  python -u train_original_seed.py cuda:0 5 $s \
    > /home/wangxiao/QCCDM/top_sci_repro/logs/seed_assist_original/train_seed${s}.log 2>&1

  cp result/model_val_original_seed${s}.txt \
    /home/wangxiao/QCCDM/top_sci_repro/results/seed_assist_original/assist_original_seed${s}_val.txt

  echo "===== predict original seed $s ====="
  for e in 1 2 3 4 5
  do
    python predict_original_seed.py $e $s \
      > /home/wangxiao/QCCDM/top_sci_repro/logs/seed_assist_original/predict/seed${s}_epoch${e}.log 2>&1
  done

  echo "===== finished original seed $s ====="
  date
done

echo "===== ALL DONE ====="
date

touch /home/wangxiao/QCCDM/top_sci_repro/logs/seed_assist_original/DONE
