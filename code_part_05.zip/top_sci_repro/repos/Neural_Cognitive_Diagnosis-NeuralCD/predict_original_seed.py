import os
import torch
import numpy as np
import sys
from sklearn.metrics import roc_auc_score
from data_loader import ValTestDataLoader
from model import Net


def test(epoch, seed):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    with open(os.environ.get("NEURALCD_CONFIG", "config.txt")) as f:
        f.readline()
        student_n, exer_n, knowledge_n = list(map(int, f.readline().split(",")))

    data_loader = ValTestDataLoader("test")
    net = Net(student_n, exer_n, knowledge_n)

    model_path = os.path.join(os.environ.get("NEURALCD_MODEL_DIR", "model"), f"model_original_seed{seed}_epoch{epoch}")
    net.load_state_dict(torch.load(model_path, map_location=device))
    net = net.to(device)
    net.eval()

    print(f"testing NeuralCD original seed model... epoch={epoch}, seed={seed}")

    correct_count, exer_count = 0, 0
    pred_all, label_all = [], []

    with torch.no_grad():
        while not data_loader.is_end():
            stu, exer, kn, labels = data_loader.next_batch()

            stu = stu.to(device)
            exer = exer.to(device)
            kn = kn.to(device)
            labels = labels.to(device)

            output = net(stu, exer, kn).view(-1)
            output = torch.clamp(output, 1e-6, 1 - 1e-6)

            correct_count += (((labels == 1) & (output > 0.5)) | ((labels == 0) & (output < 0.5))).sum().item()
            exer_count += len(labels)

            pred_all += output.detach().cpu().tolist()
            label_all += labels.detach().cpu().tolist()

    pred_all = np.array(pred_all)
    label_all = np.array(label_all)

    acc = correct_count / exer_count
    rmse = np.sqrt(np.mean((label_all - pred_all) ** 2))
    auc = roc_auc_score(label_all, pred_all)

    print("epoch= %d, accuracy= %f, rmse= %f, auc= %f" % (epoch, acc, rmse, auc))


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("python predict_original_seed.py {epoch} {seed}")
        exit(1)

    test(
        epoch=int(sys.argv[1]),
        seed=int(sys.argv[2])
    )
