from __future__ import annotations

import csv
from pathlib import Path

import torch
from torch import Tensor
from torch.utils.data import Dataset


class CognitiveDiagnosisDataset(Dataset):
    """CSV dataset for cognitive diagnosis interactions."""

    required_columns = {"user_id", "item_id", "score"}

    def __init__(self, csv_path: str | Path) -> None:
        self.csv_path = Path(csv_path)
        if not self.csv_path.exists():
            raise FileNotFoundError(f"CSV file not found: {self.csv_path}")

        self.user_ids: list[int] = []
        self.item_ids: list[int] = []
        self.scores: list[float] = []
        self.response_times: list[float | None] | None = None
        self._load_csv()

    def _load_csv(self) -> None:
        with self.csv_path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if reader.fieldnames is None:
                raise ValueError(f"CSV file is empty or missing header: {self.csv_path}")

            columns = set(reader.fieldnames)
            missing = self.required_columns - columns
            if missing:
                missing_text = ", ".join(sorted(missing))
                raise ValueError(f"{self.csv_path} is missing required columns: {missing_text}")

            has_response_time = "response_time" in columns
            response_times: list[float | None] = []

            for row_index, row in enumerate(reader, start=2):
                try:
                    self.user_ids.append(int(row["user_id"]))
                    self.item_ids.append(int(row["item_id"]))
                    self.scores.append(float(row["score"]))
                    if has_response_time:
                        raw_time = row.get("response_time", "")
                        response_times.append(float(raw_time) if raw_time not in ("", None) else None)
                except (TypeError, ValueError) as exc:
                    raise ValueError(f"Invalid value in {self.csv_path} at row {row_index}: {row}") from exc

        if has_response_time:
            self.response_times = response_times

    def __len__(self) -> int:
        return len(self.scores)

    def __getitem__(self, index: int) -> dict[str, Tensor]:
        sample = {
            "user_id": torch.tensor(self.user_ids[index], dtype=torch.long),
            "item_id": torch.tensor(self.item_ids[index], dtype=torch.long),
            "score": torch.tensor(self.scores[index], dtype=torch.float32),
        }
        if self.response_times is not None:
            response_time = self.response_times[index]
            sample["response_time"] = torch.tensor(
                -1.0 if response_time is None else response_time,
                dtype=torch.float32,
            )
        return sample
