from __future__ import annotations

from typing import Iterable

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    mean_squared_error,
    precision_score,
    recall_score,
    roc_auc_score,
)


def compute_metrics(y_true: Iterable[float], y_pred: Iterable[float], threshold: float = 0.5) -> dict[str, float]:
    """Compute binary cognitive diagnosis metrics from labels and probabilities."""
    true = np.asarray(list(y_true), dtype=np.float32)
    pred = np.asarray(list(y_pred), dtype=np.float32)
    if true.shape[0] != pred.shape[0]:
        raise ValueError(f"y_true and y_pred must have the same length, got {true.shape[0]} and {pred.shape[0]}.")
    if true.shape[0] == 0:
        raise ValueError("Cannot compute metrics on an empty input.")

    pred_label = (pred >= threshold).astype(np.int64)
    true_label = true.astype(np.int64)

    try:
        auc = float(roc_auc_score(true, pred))
    except ValueError:
        auc = 0.0

    mse = mean_squared_error(true, pred)
    return {
        "auc": auc,
        "acc": float(accuracy_score(true_label, pred_label)),
        "rmse": float(np.sqrt(mse)),
        "f1": float(f1_score(true_label, pred_label, zero_division=0)),
        "precision": float(precision_score(true_label, pred_label, zero_division=0)),
        "recall": float(recall_score(true_label, pred_label, zero_division=0)),
    }
