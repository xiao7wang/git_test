from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from torch import Tensor, nn
import torch.nn.functional as F

from .metrics import compute_metrics


class TraceCDTrainer:
    """Training helper for TRACE-CD-v0."""

    def __init__(
        self,
        model: nn.Module,
        optimizer: torch.optim.Optimizer,
        device: str | torch.device,
        save_dir: str | Path,
        dataset: str,
        seed: int,
        patience: int = 10,
    ) -> None:
        self.model = model.to(device)
        self.optimizer = optimizer
        self.device = torch.device(device)
        self.save_dir = Path(save_dir)
        self.dataset = dataset
        self.seed = seed
        self.patience = patience
        self.best_checkpoint_path = self.save_dir / f"trace_cd_v0_{dataset}_seed{seed}.pt"
        self.save_dir.mkdir(parents=True, exist_ok=True)

    def _move_batch(self, batch: dict[str, Tensor]) -> tuple[Tensor, Tensor, Tensor]:
        user_ids = batch["user_id"].to(self.device).long().view(-1)
        item_ids = batch["item_id"].to(self.device).long().view(-1)
        scores = batch["score"].to(self.device).float().view(-1)
        return user_ids, item_ids, scores

    def train_one_epoch(self, train_loader: torch.utils.data.DataLoader) -> float:
        self.model.train()
        total_loss = 0.0
        total_count = 0

        for batch in train_loader:
            user_ids, item_ids, scores = self._move_batch(batch)
            logits, _, _ = self.model(user_ids, item_ids)
            loss = F.binary_cross_entropy_with_logits(logits, scores)

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

            batch_size = scores.size(0)
            total_loss += float(loss.item()) * batch_size
            total_count += batch_size

        return total_loss / max(total_count, 1)

    @torch.no_grad()
    def evaluate(self, data_loader: torch.utils.data.DataLoader) -> dict[str, float]:
        self.model.eval()
        labels: list[float] = []
        preds: list[float] = []

        for batch in data_loader:
            user_ids, item_ids, scores = self._move_batch(batch)
            _, pred, _ = self.model(user_ids, item_ids)
            labels.extend(scores.detach().cpu().tolist())
            preds.extend(pred.detach().cpu().tolist())

        return compute_metrics(labels, preds)

    def fit(
        self,
        train_loader: torch.utils.data.DataLoader,
        valid_loader: torch.utils.data.DataLoader,
        test_loader: torch.utils.data.DataLoader | None = None,
        epochs: int = 50,
    ) -> dict[str, Any]:
        best_auc = float("-inf")
        best_epoch = 0
        bad_epochs = 0
        history: list[dict[str, Any]] = []

        for epoch in range(1, epochs + 1):
            train_loss = self.train_one_epoch(train_loader)
            valid_metrics = self.evaluate(valid_loader)
            history.append(
                {
                    "epoch": epoch,
                    "train_loss": train_loss,
                    "valid_metrics": valid_metrics,
                }
            )

            print(
                f"Epoch {epoch:03d} | train_loss={train_loss:.6f} "
                f"| valid_auc={valid_metrics['auc']:.6f} "
                f"| valid_acc={valid_metrics['acc']:.6f} "
                f"| valid_rmse={valid_metrics['rmse']:.6f}"
            )

            if valid_metrics["auc"] > best_auc:
                best_auc = valid_metrics["auc"]
                best_epoch = epoch
                bad_epochs = 0
                self._save_checkpoint(epoch, train_loss, valid_metrics)
            else:
                bad_epochs += 1
                if bad_epochs >= self.patience:
                    print(f"Early stopping at epoch {epoch}. Best epoch: {best_epoch}.")
                    break

        best_checkpoint = self._load_best_checkpoint()
        test_metrics = self.evaluate(test_loader) if test_loader is not None else None
        return {
            "best_epoch": best_checkpoint["epoch"],
            "best_valid_auc": best_checkpoint["valid_metrics"]["auc"],
            "best_valid_metrics": best_checkpoint["valid_metrics"],
            "test_metrics": test_metrics,
            "history": history,
            "best_checkpoint": str(self.best_checkpoint_path),
        }

    def _save_checkpoint(self, epoch: int, train_loss: float, valid_metrics: dict[str, float]) -> None:
        torch.save(
            {
                "epoch": epoch,
                "model_state_dict": self.model.state_dict(),
                "optimizer_state_dict": self.optimizer.state_dict(),
                "train_loss": train_loss,
                "valid_metrics": valid_metrics,
            },
            self.best_checkpoint_path,
        )

    def _load_best_checkpoint(self) -> dict[str, Any]:
        checkpoint = torch.load(self.best_checkpoint_path, map_location=self.device)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        return checkpoint
