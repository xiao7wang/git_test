from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch.utils.data import DataLoader

from data_utils import CognitiveDiagnosisDataset
from models import TraceCD
from trainers import TraceCDTrainer


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train TRACE-CD-v0.")
    parser.add_argument("--data_dir", type=str, required=True)
    parser.add_argument("--dataset", type=str, required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight_decay", type=float, default=0.0)
    parser.add_argument("--dropout", type=float, default=0.0)
    parser.add_argument("--patience", type=int, default=10)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--save_dir", type=str, default="checkpoints")
    parser.add_argument("--result_dir", type=str, default="results")
    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def load_config(config_path: Path) -> dict[str, int]:
    with config_path.open("r", encoding="utf-8") as f:
        raw_config: dict[str, Any] = json.load(f)

    required_keys = ("num_students", "num_items", "num_concepts")
    missing = [key for key in required_keys if key not in raw_config]
    if missing:
        raise ValueError(f"config.json is missing required keys: {', '.join(missing)}")

    return {key: int(raw_config[key]) for key in required_keys}


def resolve_device(device_arg: str) -> torch.device:
    if device_arg.startswith("cuda") and not torch.cuda.is_available():
        print("CUDA is not available, falling back to CPU.")
        return torch.device("cpu")
    return torch.device(device_arg)


def main() -> None:
    args = parse_args()
    set_seed(args.seed)

    dataset_dir = Path(args.data_dir) / args.dataset
    config = load_config(dataset_dir / "config.json")
    q_matrix = np.load(dataset_dir / "q_matrix.npy").astype(np.float32)
    expected_shape = (config["num_items"], config["num_concepts"])
    if tuple(q_matrix.shape) != expected_shape:
        raise ValueError(f"q_matrix.shape must be {expected_shape}, got {tuple(q_matrix.shape)}.")

    train_dataset = CognitiveDiagnosisDataset(dataset_dir / "train.csv")
    valid_dataset = CognitiveDiagnosisDataset(dataset_dir / "valid.csv")
    test_dataset = CognitiveDiagnosisDataset(dataset_dir / "test.csv")

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
    )
    valid_loader = DataLoader(
        valid_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
    )

    device = resolve_device(args.device)
    model = TraceCD(
        num_students=config["num_students"],
        num_items=config["num_items"],
        num_concepts=config["num_concepts"],
        q_matrix=q_matrix,
        dropout=args.dropout,
    )
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

    trainer = TraceCDTrainer(
        model=model,
        optimizer=optimizer,
        device=device,
        save_dir=args.save_dir,
        dataset=args.dataset,
        seed=args.seed,
        patience=args.patience,
    )
    run_summary = trainer.fit(
        train_loader=train_loader,
        valid_loader=valid_loader,
        test_loader=test_loader,
        epochs=args.epochs,
    )

    result_dir = Path(args.result_dir)
    result_dir.mkdir(parents=True, exist_ok=True)
    result_path = result_dir / f"trace_cd_v0_{args.dataset}_seed{args.seed}.json"
    result = {
        "dataset": args.dataset,
        "seed": args.seed,
        "config": config,
        "args": vars(args),
        **run_summary,
    }
    with result_path.open("w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    print(f"Saved result to {result_path}")


if __name__ == "__main__":
    main()
