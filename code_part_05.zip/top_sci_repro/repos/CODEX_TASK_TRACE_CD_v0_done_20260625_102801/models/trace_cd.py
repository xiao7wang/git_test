from __future__ import annotations

from typing import Any

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class TraceCD(nn.Module):
    """TRACE-CD-v0 cognitive diagnosis model.

    The model keeps the v0 structure intentionally compact:
    student mastery, item difficulty, item discrimination, and a fixed Q-matrix.
    """

    def __init__(
        self,
        num_students: int,
        num_items: int,
        num_concepts: int,
        q_matrix: Tensor | Any,
        dropout: float = 0.0,
        eps: float = 1e-8,
    ) -> None:
        super().__init__()
        if num_students <= 0 or num_items <= 0 or num_concepts <= 0:
            raise ValueError("num_students, num_items, and num_concepts must be positive.")
        if not 0.0 <= dropout < 1.0:
            raise ValueError("dropout must be in [0.0, 1.0).")

        q_tensor = torch.as_tensor(q_matrix, dtype=torch.float32)
        expected_shape = (num_items, num_concepts)
        if tuple(q_tensor.shape) != expected_shape:
            raise ValueError(f"q_matrix shape must be {expected_shape}, got {tuple(q_tensor.shape)}.")

        self.num_students = num_students
        self.num_items = num_items
        self.num_concepts = num_concepts
        self.eps = eps

        self.student_emb = nn.Embedding(num_students, num_concepts)
        self.item_diff_emb = nn.Embedding(num_items, num_concepts)
        self.item_disc_emb = nn.Embedding(num_items, num_concepts)
        self.item_bias = nn.Embedding(num_items, 1)
        self.dropout = nn.Dropout(dropout)

        self.register_buffer("q_matrix", q_tensor)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        """Use small initial values so sigmoid/softplus start in a stable range."""
        nn.init.normal_(self.student_emb.weight, mean=0.0, std=0.01)
        nn.init.normal_(self.item_diff_emb.weight, mean=0.0, std=0.01)
        nn.init.normal_(self.item_disc_emb.weight, mean=0.0, std=0.01)
        nn.init.zeros_(self.item_bias.weight)

    def forward(self, student_ids: Tensor, item_ids: Tensor) -> tuple[Tensor, Tensor, dict[str, Tensor]]:
        student_ids = student_ids.long().view(-1)
        item_ids = item_ids.long().view(-1)

        alpha = torch.sigmoid(self.student_emb(student_ids))
        beta = torch.sigmoid(self.item_diff_emb(item_ids))
        disc = F.softplus(self.item_disc_emb(item_ids)) + self.eps
        q = self.q_matrix[item_ids]

        h = q * disc * (alpha - beta)
        h = self.dropout(h)
        logits = torch.sum(h, dim=1) + self.item_bias(item_ids).squeeze(-1)
        pred = torch.sigmoid(logits)

        aux = {
            "alpha": alpha,
            "beta": beta,
            "disc": disc,
            "q": q,
            "h": h,
        }
        return logits, pred, aux
