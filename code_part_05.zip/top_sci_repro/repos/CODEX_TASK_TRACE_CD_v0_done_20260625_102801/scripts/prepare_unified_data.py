from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path
from typing import Iterable

import numpy as np


USER_COLUMN_CANDIDATES = ("user_id", "student_id", "user", "stu_id", "sid", "student")
ITEM_COLUMN_CANDIDATES = ("item_id", "exercise_id", "item", "exer_id", "problem_id", "exercise")
SCORE_COLUMN_CANDIDATES = ("score", "correct", "label", "answer", "is_correct", "response")
CONCEPT_COLUMN_CANDIDATES = (
    "knowledge_id",
    "knowledge_code",
    "concept_id",
    "concept",
    "skill_id",
    "skill",
    "kc_id",
    "kc",
)
Q_VALUE_COLUMN_CANDIDATES = ("value", "q", "score", "label", "relation")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Prepare unified TRACE-CD-v0 data files.")
    parser.add_argument("--src_dir", type=str, required=True, help="Directory with original config.json, q.csv, and data CSV.")
    parser.add_argument("--out_dir", type=str, required=True, help="Output directory for TRACE-CD train/valid/test files.")
    parser.add_argument("--seed", type=int, default=0, help="Random seed for the 8:1:1 split.")
    return parser.parse_args()


def normalize_column(name: str) -> str:
    return name.strip().lower()


def resolve_relative_path(base_dir: Path, value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base_dir / path


def read_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def pick_column(fieldnames: list[str], candidates: Iterable[str], role: str, csv_path: Path) -> str:
    lookup = {normalize_column(name): name for name in fieldnames}
    for candidate in candidates:
        if candidate in lookup:
            return lookup[candidate]

    print(f"Available columns in {csv_path}:")
    for name in fieldnames:
        print(f"  - {name}")
    candidate_text = ", ".join(candidates)
    raise ValueError(f"Cannot identify {role} column in {csv_path}. Expected one of: {candidate_text}")


def parse_int_id(value: object, column: str, row_number: int) -> int:
    text = str(value).strip()
    try:
        parsed = float(text)
    except ValueError as exc:
        raise ValueError(f"Invalid integer id in column '{column}' at row {row_number}: {value!r}") from exc
    if not parsed.is_integer():
        raise ValueError(f"ID in column '{column}' at row {row_number} is not an integer: {value!r}")
    return int(parsed)


def parse_score(value: object, column: str, row_number: int) -> float:
    text = str(value).strip()
    lowered = text.lower()
    if lowered in {"true", "correct", "yes"}:
        return 1.0
    if lowered in {"false", "incorrect", "no"}:
        return 0.0
    try:
        return float(text)
    except ValueError as exc:
        raise ValueError(f"Invalid score in column '{column}' at row {row_number}: {value!r}") from exc


def load_interactions(data_path: Path) -> list[tuple[int, int, float]]:
    with data_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"Data CSV is empty or missing a header: {data_path}")

        fieldnames = list(reader.fieldnames)
        user_col = pick_column(fieldnames, USER_COLUMN_CANDIDATES, "user", data_path)
        item_col = pick_column(fieldnames, ITEM_COLUMN_CANDIDATES, "item", data_path)
        score_col = pick_column(fieldnames, SCORE_COLUMN_CANDIDATES, "score", data_path)

        rows: list[tuple[int, int, float]] = []
        for row_number, row in enumerate(reader, start=2):
            user_id = parse_int_id(row[user_col], user_col, row_number)
            item_id = parse_int_id(row[item_col], item_col, row_number)
            score = parse_score(row[score_col], score_col, row_number)
            rows.append((user_id, item_id, score))

    if not rows:
        raise ValueError(f"No interaction rows found in {data_path}")
    return rows


def build_id_mapping(values: Iterable[int]) -> dict[int, int]:
    unique_values = sorted(set(values))
    if unique_values == list(range(len(unique_values))):
        return {value: value for value in unique_values}
    return {value: index for index, value in enumerate(unique_values)}


def save_mapping(mapping: dict[int, int], path: Path) -> None:
    serializable = {str(old_id): new_id for old_id, new_id in sorted(mapping.items(), key=lambda item: item[1])}
    with path.open("w", encoding="utf-8") as f:
        json.dump(serializable, f, ensure_ascii=False, indent=2)


def matrix_is_binary(matrix: np.ndarray) -> bool:
    return bool(np.isfinite(matrix).all() and matrix.size > 0 and np.min(matrix) >= 0 and np.max(matrix) <= 1)


def load_numeric_q_matrix(q_path: Path, knowledge_num: int) -> np.ndarray | dict[int, np.ndarray] | None:
    for skip_header in (0, 1):
        try:
            matrix = np.genfromtxt(
                q_path,
                delimiter=",",
                dtype=np.float32,
                encoding="utf-8-sig",
                skip_header=skip_header,
            )
        except ValueError:
            continue

        if matrix.size == 0:
            continue
        if matrix.ndim == 1:
            matrix = matrix.reshape(1, -1)
        if not np.isfinite(matrix).all():
            continue

        if matrix.shape[1] == knowledge_num and matrix_is_binary(matrix):
            return matrix.astype(np.float32)

        if matrix.shape[1] == knowledge_num + 1 and matrix_is_binary(matrix[:, 1:]):
            item_ids = matrix[:, 0]
            if np.all(np.equal(item_ids, np.floor(item_ids))) and len(set(item_ids.astype(int).tolist())) == len(item_ids):
                return {int(item_id): row.astype(np.float32) for item_id, row in zip(item_ids, matrix[:, 1:])}

    return None


def parse_concepts(value: object, column: str, row_number: int, knowledge_num: int) -> list[int]:
    text = str(value).strip()
    if not text:
        raise ValueError(f"Empty concept value in column '{column}' at row {row_number}")

    concepts: list[int] = []
    for token in re.split(r"[|;,_\s]+", text):
        if not token:
            continue
        concept_id = parse_int_id(token, column, row_number)
        if 0 <= concept_id < knowledge_num:
            concepts.append(concept_id)
        elif 1 <= concept_id <= knowledge_num:
            concepts.append(concept_id - 1)
        else:
            raise ValueError(
                f"Concept id {concept_id} in column '{column}' at row {row_number} "
                f"is outside [0, {knowledge_num - 1}] or [1, {knowledge_num}]."
            )
    if not concepts:
        raise ValueError(f"No concept ids found in column '{column}' at row {row_number}")
    return concepts


def load_long_q_matrix(q_path: Path, knowledge_num: int) -> dict[int, np.ndarray]:
    with q_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"Q CSV is empty or missing a header: {q_path}")

        fieldnames = list(reader.fieldnames)
        item_col = pick_column(fieldnames, ITEM_COLUMN_CANDIDATES, "Q item", q_path)
        concept_col = pick_column(fieldnames, CONCEPT_COLUMN_CANDIDATES, "Q concept", q_path)
        value_col = next((name for name in fieldnames if normalize_column(name) in Q_VALUE_COLUMN_CANDIDATES), None)

        q_by_item: dict[int, np.ndarray] = {}
        for row_number, row in enumerate(reader, start=2):
            item_id = parse_int_id(row[item_col], item_col, row_number)
            value = 1.0 if value_col is None else parse_score(row[value_col], value_col, row_number)
            if item_id not in q_by_item:
                q_by_item[item_id] = np.zeros(knowledge_num, dtype=np.float32)
            for concept_id in parse_concepts(row[concept_col], concept_col, row_number, knowledge_num):
                q_by_item[item_id][concept_id] = value

    if not q_by_item:
        raise ValueError(f"No Q entries found in {q_path}")
    return q_by_item


def load_q_source(q_path: Path, knowledge_num: int) -> np.ndarray | dict[int, np.ndarray]:
    numeric_q = load_numeric_q_matrix(q_path, knowledge_num)
    if numeric_q is not None:
        return numeric_q
    return load_long_q_matrix(q_path, knowledge_num)


def q_row_from_matrix(matrix: np.ndarray, old_item_id: int) -> np.ndarray:
    if 0 <= old_item_id < matrix.shape[0]:
        return matrix[old_item_id]
    if 1 <= old_item_id <= matrix.shape[0]:
        return matrix[old_item_id - 1]
    raise KeyError(old_item_id)


def q_row_from_mapping(q_by_item: dict[int, np.ndarray], old_item_id: int) -> np.ndarray:
    for candidate in (old_item_id, old_item_id - 1, old_item_id + 1):
        if candidate in q_by_item:
            return q_by_item[candidate]
    raise KeyError(old_item_id)


def build_output_q_matrix(
    q_source: np.ndarray | dict[int, np.ndarray],
    item_mapping: dict[int, int],
    knowledge_num: int,
) -> np.ndarray:
    q_matrix = np.zeros((len(item_mapping), knowledge_num), dtype=np.float32)
    missing_items: list[int] = []

    for old_item_id, new_item_id in item_mapping.items():
        try:
            if isinstance(q_source, np.ndarray):
                q_matrix[new_item_id] = q_row_from_matrix(q_source, old_item_id)
            else:
                q_matrix[new_item_id] = q_row_from_mapping(q_source, old_item_id)
        except KeyError:
            missing_items.append(old_item_id)

    if missing_items:
        preview = ", ".join(str(item_id) for item_id in missing_items[:10])
        suffix = " ..." if len(missing_items) > 10 else ""
        raise ValueError(f"Q matrix is missing {len(missing_items)} item(s): {preview}{suffix}")
    return q_matrix


def write_interaction_split(
    out_path: Path,
    rows: list[tuple[int, int, float]],
    indices: np.ndarray,
    user_mapping: dict[int, int],
    item_mapping: dict[int, int],
) -> None:
    with out_path.open("w", encoding="utf-8", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(("user_id", "item_id", "score"))
        for index in indices:
            old_user_id, old_item_id, score = rows[int(index)]
            writer.writerow((user_mapping[old_user_id], item_mapping[old_item_id], score))


def write_splits(
    rows: list[tuple[int, int, float]],
    out_dir: Path,
    seed: int,
    user_mapping: dict[int, int],
    item_mapping: dict[int, int],
) -> None:
    rng = np.random.default_rng(seed)
    indices = np.arange(len(rows))
    rng.shuffle(indices)

    train_end = int(len(indices) * 0.8)
    valid_end = int(len(indices) * 0.9)
    splits = {
        "train.csv": indices[:train_end],
        "valid.csv": indices[train_end:valid_end],
        "test.csv": indices[valid_end:],
    }
    for filename, split_indices in splits.items():
        write_interaction_split(out_dir / filename, rows, split_indices, user_mapping, item_mapping)


def main() -> None:
    args = parse_args()
    src_dir = Path(args.src_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    source_config = read_json(src_dir / "config.json")
    q_path = resolve_relative_path(src_dir, source_config["q_file"])
    data_path = resolve_relative_path(src_dir, source_config["data"])
    knowledge_num = int(source_config["knowledge_num"])

    rows = load_interactions(data_path)
    user_mapping = build_id_mapping(user_id for user_id, _, _ in rows)
    item_mapping = build_id_mapping(item_id for _, item_id, _ in rows)

    q_source = load_q_source(q_path, knowledge_num)
    q_matrix = build_output_q_matrix(q_source, item_mapping, knowledge_num)

    write_splits(rows, out_dir, args.seed, user_mapping, item_mapping)
    np.save(out_dir / "q_matrix.npy", q_matrix.astype(np.float32))
    save_mapping(user_mapping, out_dir / "user_mapping.json")
    save_mapping(item_mapping, out_dir / "item_mapping.json")

    target_config = {
        "num_students": len(user_mapping),
        "num_items": len(item_mapping),
        "num_concepts": knowledge_num,
    }
    with (out_dir / "config.json").open("w", encoding="utf-8") as f:
        json.dump(target_config, f, ensure_ascii=False, indent=2)

    print(f"Prepared TRACE-CD data at {out_dir}")
    print(f"num_students={target_config['num_students']}")
    print(f"num_items={target_config['num_items']}")
    print(f"num_concepts={target_config['num_concepts']}")


if __name__ == "__main__":
    main()
