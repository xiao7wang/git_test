#!/usr/bin/env bash
set -euo pipefail

python scripts/prepare_unified_data.py \
  --src_dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/assistments_time \
  --out_dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data/assistments_time \
  --seed 0

python scripts/prepare_unified_data.py \
  --src_dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/ednet \
  --out_dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data/ednet \
  --seed 0
