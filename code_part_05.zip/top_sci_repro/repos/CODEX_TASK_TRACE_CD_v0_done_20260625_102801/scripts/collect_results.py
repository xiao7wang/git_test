from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


METRIC_KEYS = ("auc", "acc", "rmse", "f1", "precision", "recall")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Collect TRACE-CD-v0 5-seed results.")
    parser.add_argument("--result_dir", type=str, default="results")
    parser.add_argument("--dataset", type=str, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    return parser.parse_args()


def load_test_metrics(result_path: Path) -> dict[str, float]:
    with result_path.open("r", encoding="utf-8") as f:
        result = json.load(f)

    metrics = result.get("test_metrics")
    if metrics is None:
        raise ValueError(f"{result_path} does not contain test_metrics.")
    missing = [key for key in METRIC_KEYS if key not in metrics]
    if missing:
        raise ValueError(f"{result_path} missing metrics: {', '.join(missing)}")
    return {key: float(metrics[key]) for key in METRIC_KEYS}


def main() -> None:
    args = parse_args()
    result_dir = Path(args.result_dir)

    rows = []
    for seed in args.seeds:
        result_path = result_dir / f"trace_cd_v0_{args.dataset}_seed{seed}.json"
        if not result_path.exists():
            raise FileNotFoundError(f"Missing result file: {result_path}")
        metrics = load_test_metrics(result_path)
        rows.append(metrics)

    print(f"TRACE-CD-v0 results for dataset={args.dataset}, seeds={args.seeds}")
    for key in METRIC_KEYS:
        values = np.asarray([row[key] for row in rows], dtype=np.float64)
        print(f"{key}: {values.mean():.6f}±{values.std(ddof=0):.6f}")


if __name__ == "__main__":
    main()
