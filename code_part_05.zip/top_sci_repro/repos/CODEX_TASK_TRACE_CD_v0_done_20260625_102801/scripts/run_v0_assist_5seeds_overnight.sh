#!/bin/bash
set -e

source ~/miniconda3/etc/profile.d/conda.sh
conda activate qccdm

cd /home/wangxiao/QCCDM/top_sci_repro/repos/CODEX_TASK_TRACE_CD
mkdir -p logs results checkpoints

echo "===== TRACE-CD-v0 ASSISTments_time 5 seeds started at $(date) ====="

for SEED in 0 1 2 3 4
do
  GPU=$((SEED % 4))
  echo "===== ASSISTments_time seed ${SEED} on GPU ${GPU} started at $(date) ====="

  CUDA_VISIBLE_DEVICES=${GPU} python -u train_trace_cd.py \
    --data_dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data \
    --dataset assistments_time \
    --seed ${SEED} \
    --batch_size 4096 \
    --epochs 50 \
    --lr 0.001 \
    --dropout 0.0 \
    --patience 10 \
    2>&1 | tee logs/trace_cd_v0_assist_seed${SEED}_full.log

  echo "===== ASSISTments_time seed ${SEED} finished at $(date) ====="
done

python - <<'PY' | tee results/trace_cd_v0_assistments_time_5seeds_summary.txt
import json
import numpy as np
from pathlib import Path

base = Path("results")
dataset = "assistments_time"
keys = ["auc", "acc", "rmse", "f1", "precision", "recall"]
rows = []

for seed in range(5):
    path = base / f"trace_cd_v0_{dataset}_seed{seed}.json"
    if not path.exists():
        print("MISSING", path)
        continue
    obj = json.load(open(path, "r", encoding="utf-8"))
    m = obj["test_metrics"]
    m["seed"] = seed
    m["best_epoch"] = obj.get("best_epoch")
    m["best_valid_auc"] = obj.get("best_valid_auc")
    rows.append(m)

print("=" * 80)
print("TRACE-CD-v0 ASSISTments_time 5 seeds summary")
print("=" * 80)

for r in rows:
    print(
        f"seed={r['seed']} best_epoch={r['best_epoch']} "
        f"best_valid_auc={r['best_valid_auc']:.6f} "
        + " ".join([f"test_{k}={r[k]:.6f}" for k in keys])
    )

print("-" * 80)
for k in keys:
    vals = np.array([r[k] for r in rows], dtype=float)
    print(f"{k}: {vals.mean():.6f} ± {vals.std():.6f}")
PY

echo "===== TRACE-CD-v0 ASSISTments_time 5 seeds finished at $(date) ====="
