#!/usr/bin/env bash
set -euo pipefail

DATA_DIR="${DATA_DIR:-/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data}"
DEVICE="${DEVICE:-cuda}"
BATCH_SIZE="${BATCH_SIZE:-256}"
EPOCHS="${EPOCHS:-50}"
LR="${LR:-0.001}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.0}"
DROPOUT="${DROPOUT:-0.0}"
PATIENCE="${PATIENCE:-10}"
NUM_WORKERS="${NUM_WORKERS:-0}"
SAVE_DIR="${SAVE_DIR:-checkpoints}"
RESULT_DIR="${RESULT_DIR:-results}"

for SEED in 0 1 2 3 4; do
  python train_trace_cd.py \
    --data_dir "${DATA_DIR}" \
    --dataset assistments_time \
    --seed "${SEED}" \
    --batch_size "${BATCH_SIZE}" \
    --epochs "${EPOCHS}" \
    --lr "${LR}" \
    --weight_decay "${WEIGHT_DECAY}" \
    --dropout "${DROPOUT}" \
    --patience "${PATIENCE}" \
    --device "${DEVICE}" \
    --num_workers "${NUM_WORKERS}" \
    --save_dir "${SAVE_DIR}" \
    --result_dir "${RESULT_DIR}"
done

python scripts/collect_results.py --result_dir "${RESULT_DIR}" --dataset assistments_time --seeds 0 1 2 3 4
