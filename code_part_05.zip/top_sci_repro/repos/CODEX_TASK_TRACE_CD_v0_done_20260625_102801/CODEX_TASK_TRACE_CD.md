你现在在 VS Code 远程服务器环境中工作，当前项目目录是：
/home/wangxiao/QCCDM/top_sci_repro/repos/TRACE-CD

请只负责生成代码文件，不要运行训练，不要跑实验，不要启动大规模测试。测试和运行部分我自己来。

请在当前 TRACE-CD 目录下实现 TRACE-CD-v0，一个 PyTorch 认知诊断模型。

一、总体要求
1. 不要修改 /home/wangxiao/QCCDM/top_sci_repro/repos 下已有的其他仓库。
2. 只在 /home/wangxiao/QCCDM/top_sci_repro/repos/TRACE-CD 内创建和修改文件。
3. 项目结构包括：models/、data_utils/、trainers/、scripts/、logs/、checkpoints/、results/。
4. 当前阶段只实现 TRACE-CD-v0，不要实现响应时间模块 REC，不要实现未交互题目模块 CUEC，不要实现知识图模块 KEPG。
5. 完成后告诉我创建了哪些文件，以及后续我应该用什么命令自己检查和运行。

二、模型定义
请实现 models/trace_cd.py，包含 TraceCD 类。

TRACE-CD-v0 的核心结构如下：
1. 学生知识掌握向量 alpha_u：student_emb shape=[num_students, num_concepts]，alpha = sigmoid(student_emb(student_ids))。
2. 题目知识点难度 beta_i：item_diff_emb shape=[num_items, num_concepts]，beta = sigmoid(item_diff_emb(item_ids))。
3. 题目多维区分度 a_i：item_disc_emb shape=[num_items, num_concepts]，disc = softplus(item_disc_emb(item_ids)) + eps，保证区分度非负，满足单调性。
4. q_matrix 形状为 [num_items, num_concepts]，用 register_buffer 保存。
5. forward 输入 student_ids、item_ids。
6. forward 中：q = q_matrix[item_ids]；h = q * disc * (alpha - beta)；logits = sum(h, dim=1) + item_bias；pred = sigmoid(logits)。
7. forward 返回 logits、pred、aux。
8. aux 至少包含 alpha、beta、disc、q、h，方便后续解释性分析。

三、数据读取
请实现 data_utils/dataset.py。
1. 实现 CognitiveDiagnosisDataset。
2. 读取 train.csv / valid.csv / test.csv。
3. CSV 必须包含 user_id,item_id,score。
4. __getitem__ 返回 dict：user_id: LongTensor；item_id: LongTensor；score: FloatTensor。
5. 可以兼容 response_time 字段，但 v0 暂时不用。

四、指标
请实现 trainers/metrics.py。
1. 实现 compute_metrics(y_true, y_pred, threshold=0.5)。
2. 输出 auc、acc、rmse、f1、precision、recall。
3. 使用 sklearn.metrics。
4. 如果 roc_auc_score 报错，auc 返回 0.0，避免程序中断。

五、训练器
请实现 trainers/trainer.py。
1. 实现 TraceCDTrainer。
2. train_one_epoch 使用 torch.nn.functional.binary_cross_entropy_with_logits。
3. evaluate 收集 labels 和 pred，调用 compute_metrics。
4. fit 支持 early stopping。
5. 根据 valid AUC 保存 best model。
6. 训练完成后加载 best checkpoint，在 test set 上评估。
7. 日志打印每个 epoch 的 train_loss、valid_auc、valid_acc、valid_rmse。

六、主入口
请实现 train_trace_cd.py。支持参数：--data_dir、--dataset、--seed、--batch_size、--epochs、--lr、--weight_decay、--dropout、--patience、--device、--num_workers、--save_dir、--result_dir。

数据路径格式如下：
data_dir/dataset/train.csv
data_dir/dataset/valid.csv
data_dir/dataset/test.csv
data_dir/dataset/q_matrix.npy
data_dir/dataset/config.json

config.json 包含：
{
  "num_students": ...,
  "num_items": ...,
  "num_concepts": ...
}

程序需要检查 q_matrix.shape 是否等于 [num_items, num_concepts]。

七、脚本
请生成：
1. scripts/run_5seeds_assist.sh
2. scripts/run_5seeds_ednet.sh
3. scripts/collect_results.py

run_5seeds 脚本中只写命令，不要自动帮我执行。collect_results.py 用于读取 results/trace_cd_v0_{dataset}_seed{seed}.json，并输出 5 seeds 的 mean±std。

八、代码质量
1. 所有 Python 文件必须结构清楚、可读性强。
2. 所有 import 应该正确。
3. 给关键函数加必要注释。
4. 不要把路径硬编码死，除非是 shell 脚本中的默认示例路径。
5. 不要运行训练。
6. 完成后只告诉我文件清单和我下一步应该执行的检查命令。
