"""Paired validation statistics. No fitting, model loading, or test-set access."""
import numpy as np

MODES = ("none", "mean_only", "support_only", "joint")
SEEDS = (0, 1, 2)
# All contrasts use RAW metrics: positive AUC is better; negative NLL/Brier is better.
CONTRASTS = {
    "support_only_minus_none": [-1, 0, 1, 0],
    "mean_only_minus_none": [-1, 1, 0, 0],
    "joint_minus_none": [-1, 0, 0, 1],
    "support_main": [-.5, -.5, .5, .5],
    "mean_main": [-.5, .5, -.5, .5],
    "interaction": [1, -1, -1, 1],
}


def losses(y, p):
    y, p = np.asarray(y, float), np.asarray(p, float)
    if y.shape != p.shape or not np.isin(y, [0, 1]).all() or not np.isfinite(p).all():
        raise ValueError("Invalid labels/probabilities")
    if ((p < 0) | (p > 1)).any():
        raise ValueError("Probability outside [0,1]")
    c = p.clip(1e-7, 1 - 1e-7)  # Matches the existing project's metrics.py.
    return np.stack((-(y * np.log(c) + (1-y) * np.log1p(-c)), (p-y)**2), axis=-1)


def metrics(y, p):
    if not len(y):
        return dict(n=0, auc=None, nll=None, brier=None)
    ls = losses(y, p)
    y, p = np.asarray(y), np.asarray(p)
    order = np.argsort(p, kind="stable")
    _, first, count = np.unique(p[order], return_index=True, return_counts=True)
    ranks = np.repeat(first + (count + 1) / 2, count)
    pos, neg = int(y.sum()), int(len(y)-y.sum())
    auc = float((ranks[y[order] == 1].sum()-pos*(pos+1)/2)/(pos*neg)) if pos and neg else None
    return dict(n=len(y), auc=auc, nll=float(ls[:, 0].mean()), brier=float(ls[:, 1].mean()))


def groups(frame):
    """Existing per-event KC columns are averages for multi-KC items, not exact KC windows."""
    gap = frame.delta_t_k_hours.to_numpy(float)
    repeated = frame.kc_count_before.to_numpy(float) > 0
    return {
        "all": np.ones(len(frame), dtype=bool),
        "repeated_kc_proxy": repeated,
        "repeat_gap_zero": repeated & (gap == 0),
        "repeat_gap_0_to_24h": repeated & (gap > 0) & (gap <= 24),
        "repeat_gap_24_to_168h": repeated & (gap > 24) & (gap <= 168),
        "repeat_gap_gt168h": repeated & (gap > 168),
        "no_previous_kc": ~repeated,
    }


def cluster_intervals(student, deltas, reps=2000, seed=20261022):
    """Resample STUDENTS, preserving all their events and all paired model/seed columns.

    deltas: records x comparisons. Event estimate = pooled loss over sampled events;
    macro estimate = equal-weight mean of within-student mean loss differences.
    Seeds are fixed models, not extra observations or separately resampled clusters.
    """
    deltas = np.asarray(deltas, dtype=np.float64)
    if deltas.ndim != 2 or len(student) != len(deltas) or not np.isfinite(deltas).all():
        raise ValueError("Invalid paired cluster input")
    if reps < 1:
        raise ValueError("Bootstrap repetitions must be positive")
    if not len(student):
        return {"students": 0, "n": 0, "comparisons": []}
    users, inverse = np.unique(student, return_inverse=True)
    counts = np.bincount(inverse).astype(float)
    sums = np.stack([np.bincount(inverse, weights=deltas[:, j])
                     for j in range(deltas.shape[1])], axis=1)
    per_student = sums / counts[:, None]
    point = sums.sum(0) / counts.sum()
    macro = per_student.mean(0)
    result = []
    if len(users) < 2:
        for j in range(deltas.shape[1]):
            result.append({"delta": float(point[j]), "ci95": None,
                           "student_macro_delta": float(macro[j]), "student_macro_ci95": None})
        return {"students": len(users), "n": len(student), "comparisons": result}
    rng = np.random.default_rng(seed)
    boot, macro_boot = np.empty((reps, deltas.shape[1])), np.empty((reps, deltas.shape[1]))
    # Bounded temporary memory; every comparison uses identical student draws.
    for start in range(0, reps, 8):
        count = min(8, reps-start)
        idx = rng.integers(0, len(users), size=(count, len(users)))
        boot[start:start+count] = sums[idx].sum(1) / counts[idx].sum(1)[:, None]
        macro_boot[start:start+count] = per_student[idx].mean(1)
    ci, macro_ci = np.quantile(boot, [.025, .975], axis=0), np.quantile(macro_boot, [.025, .975], axis=0)
    for j in range(deltas.shape[1]):
        result.append({"delta": float(point[j]), "ci95": ci[:, j].tolist(),
                       "student_macro_delta": float(macro[j]), "student_macro_ci95": macro_ci[:, j].tolist()})
    return {"students": len(users), "n": len(student), "comparisons": result}


def analyze_group(frame, predictions, mask, reps, seed):
    # predictions: seeds x modes x records. Average losses, never average probabilities.
    ids = np.flatnonzero(mask)
    if not len(ids):
        return {"n": 0, "students": 0, "metrics": {}, "paired": {}}
    y = frame.label.to_numpy(float)[ids]
    p = predictions[:, :, ids]
    values = np.empty((len(SEEDS), len(MODES), len(ids), 2), dtype=np.float64)
    rows = {}
    for si, s in enumerate(SEEDS):
        for mi, mode in enumerate(MODES):
            values[si, mi] = losses(y, p[si, mi])
            rows[f"{mode}_seed{s}"] = metrics(y, p[si, mi])
    columns, names = [], []
    for si, s in enumerate(SEEDS):
        for li, loss_name in enumerate(("nll", "brier")):
            columns.append(values[si, 2, :, li] - values[si, 0, :, li])
            names.append(f"seed{s}/support_only_minus_none/{loss_name}")
    mean_losses = values.mean(0)
    for name, weights in CONTRASTS.items():
        for li, loss_name in enumerate(("nll", "brier")):
            columns.append(np.einsum("m,mn->n", weights, mean_losses[:, :, li]))
            names.append(f"seed_mean/{name}/{loss_name}")
    boot = cluster_intervals(frame.student_idx.to_numpy()[ids], np.stack(columns, axis=1), reps, seed)
    summaries = {}
    for mode in MODES:
        summaries[mode] = {}
        for metric in ("auc", "nll", "brier"):
            v = [rows[f"{mode}_seed{s}"][metric] for s in SEEDS]
            summaries[mode][metric] = {"mean": None if any(x is None for x in v) else float(np.mean(v)),
                                     "sample_sd": None if any(x is None for x in v) else float(np.std(v, ddof=1))}
    auc_contrasts = {}
    for name, weights in CONTRASTS.items():
        v = []
        for s in SEEDS:
            a = [rows[f"{mode}_seed{s}"]["auc"] for mode in MODES]
            v.append(None if any(x is None for x in a) else float(np.dot(weights, a)))
        auc_contrasts[name] = {"per_seed": v, "mean": None if any(x is None for x in v) else float(np.mean(v))}
    return {"n": len(ids), "students": boot["students"], "metrics": rows,
            "mode_summary": summaries, "auc_contrasts_descriptive_only": auc_contrasts,
            "paired": dict(zip(names, boot["comparisons"]))}
