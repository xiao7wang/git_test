import sys
from pathlib import Path
from cross_core import sha,read
root=Path(sys.argv[1])
expected={'summary.json':'ca6d16957b3ece2099bb03d8ba08e2a5e3b82e0ed04069f60234d8b8f2a6f0a2',
          'suite_config.json':'783da610a5de56d4924f47dbd8c9ace240bbcebae911d2ed9d3522c32f4b440b'}
for n,d in expected.items():
 if sha(root/n)!=d:raise ValueError('Reference provenance mismatch: '+n)
if read(root/'status.json')['status']!='complete':raise ValueError('Reference suite incomplete')
if read(root/'summary.json')['selected']['A']['checkpoint_sha256']!='b31f849f9b7f2535e00a98a7f8225450c440140ce95066cc434c5babace9732a':raise ValueError('Unexpected A reference')
if not (root/'A_none/dev_predictions.csv.gz').is_file():raise FileNotFoundError('Reference development predictions missing')
print('Existing A reference verified; exact event alignment checked during training',flush=True)
