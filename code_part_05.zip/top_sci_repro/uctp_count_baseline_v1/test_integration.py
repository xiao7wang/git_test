"""End-to-end small-data training, selection, non-overwrite, archive."""
import json,os,shutil,subprocess,sys,tempfile,zipfile,hashlib
from pathlib import Path
from cross_core import write
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='count_e2e_') as tmp:
  root=Path(tmp);pkg=root/'pkg';pkg.mkdir()
  for n in ('count_core.py','run_baseline.py','cross_core.py','review_stats.py','package_results.py'):shutil.copy2(ROOT/n,pkg/n)
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  import numpy as np,pandas as pd
  from count_core import dev_users
  arrays=fixture.data.arrays;dev=dev_users(arrays['student_idx'][arrays['split']==1])
  idx=np.flatnonzero((arrays['split']==1)&np.isin(arrays['student_idx'],list(dev)))
  ref=root/'ref.csv.gz';pd.DataFrame({'record_idx':idx,'student_idx':arrays['student_idx'][idx],'label':arrays['label'][idx]}).to_csv(ref,index=False,compression='gzip')
  cmd=[sys.executable,'-B',str(pkg/'run_baseline.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--reference-dev',str(ref),
       '--output-dir',str(root/'out'),'--device','cpu','--epochs','3','--patience','2','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  result=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if result.returncode:raise RuntimeError(result.stdout)
  s=json.loads((root/'out/summary.json').read_text());h=json.loads((root/'out/history.json').read_text())
  assert s['status']=='complete' and not s['test_evaluated'] and not s['holdout_evaluated']
  assert s['dev']['nll']==min(x['dev']['nll'] for x in h)
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert q.returncode==0,q.stdout
  with zipfile.ZipFile(root/'out/count_baseline_results.zip') as z:
   assert z.testzip() is None;m=json.loads(z.read('manifest.json'))
   assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in m.items())
  bad=pd.read_csv(ref,compression='gzip');bad.loc[0,'label']=1-bad.loc[0,'label'];bad.to_csv(ref,index=False,compression='gzip')
  bad_cmd=cmd.copy();bad_cmd[bad_cmd.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad_cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((root/'bad/status.json').read_text())['status']=='failed'
  print(json.dumps({'synthetic_training':True,'dev_nll_selection':True,'overwrite_guard':True,'reference_identity_guard':True,'archive':True,'real_gpu_tested':False}))
finally:fixture.tearDown()
