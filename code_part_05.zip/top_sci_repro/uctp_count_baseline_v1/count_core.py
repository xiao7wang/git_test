"""Causal historical-count features and a clearly labelled PFA-inspired baseline."""
import hashlib
import numpy as np
import torch
from torch import nn

SALT='decision-v1-20261105:'

def dev_users(values):
    return {int(u) for u in np.unique(values) if hashlib.sha256((SALT+str(int(u))).encode()).digest()[-1]%2==0}

def prior_count_features(arrays,development_users):
    """All training rows plus development validation, in chronological record order.

    Counts include only earlier selected rows for the same student/KC. No test or
    non-development validation labels are accessed. Labels are returned separately.
    """
    a=arrays;split=a['split'];user=a['student_idx'];item=a['item_idx'];q=a['item_q']
    if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires single-KC binary Q')
    if np.any(np.diff(user)<0):raise ValueError('Students not grouped in record order')
    same=(np.diff(user)==0)&(split[1:]<=1)&(split[:-1]<=1)
    if np.any(np.diff(a['timestamp'])[same]<0) or np.any(np.diff(split)[same]<0):raise ValueError('Nonchronological student records')
    selected=(split==0)|((split==1)&np.isin(user,list(development_users)))
    idx=np.flatnonzero(selected)
    if not len(idx):raise ValueError('No selected records')
    u=user[idx].astype(np.int64);it=item[idx].astype(np.int64)
    y=a['label'][idx]
    if not np.isin(y,[0,1]).all():raise ValueError('Invalid selected labels')
    kc=q.argmax(1)[it].astype(np.int64)
    order=np.lexsort((idx,kc,u));su=u[order];sk=kc[order];sy=y[order].astype(np.int64)
    first=np.r_[True,(su[1:]!=su[:-1])|(sk[1:]!=sk[:-1])]
    group_start=np.maximum.accumulate(np.where(first,np.arange(len(idx)),0))
    cumulative=np.cumsum(sy);before_group=np.zeros(len(idx),dtype=np.int64)
    mask=group_start>0;before_group[mask]=cumulative[group_start[mask]-1]
    positive=cumulative-sy-before_group
    negative=np.arange(len(idx))-group_start-positive
    success=np.empty(len(idx),dtype=np.int64);failure=np.empty(len(idx),dtype=np.int64)
    success[order]=positive;failure[order]=negative
    if (success<0).any() or (failure<0).any():raise AssertionError('Negative history count')
    return {'record_idx':idx,'student':u,'item':it,'kc':kc,'label':y.astype(np.float32),
            'success':success,'failure':failure,'split':split[idx]}

class CountModel(nn.Module):
    """logit=student bias + item bias + KC bias + KC weights*log1p counts.

    This is a PFA-inspired modified baseline, not an official PFA reproduction.
    """
    def __init__(self,students,items,kcs):
        super().__init__()
        self.student=nn.Embedding(students,1);self.item=nn.Embedding(items,1);self.kc=nn.Embedding(kcs,3)
        for p in self.parameters():nn.init.zeros_(p)
    def forward(self,student,item,kc,success,failure):
        terms=self.kc(kc)
        return self.student(student).squeeze(-1)+self.item(item).squeeze(-1)+terms[:,0]+terms[:,1]*torch.log1p(success)+terms[:,2]*torch.log1p(failure)
