"""Frozen, native-FP32 validation replay. Imports the HASH-PINNED original model."""
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
BRANCHES = ('NN', 'NS', 'SN', 'SS')
MODES = {'N': 'none', 'S': 'support_only'}
KEYS = ('probability', 'uncertainty', 'evidence')
ATOL = 1e-6
RATE = math.log(2.0) / 168.0


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + '.pending')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')
    tmp.replace(path)


def check_hash(path, expected):
    actual = sha(path)
    if actual != expected:
        raise ValueError(f'Identity changed: {path}; expected={expected}; actual={actual}')


def import_project(project, expected_sources):
    project = Path(project).resolve()
    for name, digest in expected_sources.items():
        check_hash(project / name, digest)
    sys.path.insert(0, str(project))
    from src.data import PreparedData
    from src.factorial_time_model import FactorialTimeCD
    from src.engine import forward
    for module in ('src.data', 'src.model', 'src.engine', 'src.temporal_model', 'src.factorial_time_model'):
        location = Path(sys.modules[module].__file__).resolve()
        if not location.is_relative_to(project):
            raise RuntimeError(f'Wrong imported module: {location}')
    return PreparedData, FactorialTimeCD, forward


def audit_inputs(project, data_root, dataset, seed, expected):
    spec = expected['datasets'][dataset]
    for name, digest in spec['shared_protocol']['source'].items():
        check_hash(Path(project) / name, digest)
    check_hash(Path(data_root) / f'{dataset}_full/manifest.json', spec['shared_protocol']['data_fingerprint'])
    selected = {r['mode']: r for r in spec['runs'] if r['seed'] == seed}
    if set(selected) != {'none', 'support_only'}:
        raise ValueError('Exactly two pinned checkpoints are required')
    for mode, run in selected.items():
        folder = Path(project) / run['relative_run_dir']
        check_hash(folder / 'best_model.pt', run['checkpoint_sha256'])
        for name, digest in run['input_hashes'].items():
            check_hash(folder / name, digest)
        config = read(folder / 'run_config.json')
        args = config['args']
        if (read(folder / 'status.json')['status'] != 'complete' or
                args['time_mode'] != mode or args['seed'] != seed or
                args['variant'] != 'unit_write' or args['eval_update_targets'] != 1 or
                args['evaluate_test'] or config['model_family'] != 'time_factorial_v1'):
            raise ValueError(f'Protocol mismatch: {folder}')
    return selected


def model_digest(model_state):
    h = hashlib.sha256()
    for name, tensor in sorted(model_state.items()):
        value = tensor.detach().cpu().contiguous().numpy()
        h.update(name.encode()); h.update(str(value.dtype).encode())
        h.update(str(value.shape).encode()); h.update(value.tobytes())
    return h.hexdigest()


def frozen_model(cls, checkpoint, replay_mode, device, fingerprint, expected_sources):
    if checkpoint['model_family'] != 'time_factorial_v1' or checkpoint['data_fingerprint'] != fingerprint:
        raise ValueError('Wrong checkpoint family or dataset')
    if any(checkpoint['source_code'].get(k) != v for k, v in expected_sources.items()):
        raise ValueError('Checkpoint source hashes do not match pinned training sources')
    config = dict(checkpoint['model_config'])
    if config['variant'] != 'unit_write' or config['time_mode'] not in MODES.values():
        raise ValueError('Only pinned none/support_only unit_write checkpoints allowed')
    native_rate = 0.0 if config['time_mode'] == 'none' else RATE
    if config['decay_rate_per_hour'] != native_rate:
        raise ValueError('The fixed 168-hour protocol changed')
    if replay_mode not in MODES.values():
        raise ValueError('Unsupported replay mode')
    config.update(time_mode=replay_mode, decay_rate_per_hour=0.0 if replay_mode == 'none' else RATE)
    model = cls(**config)
    model.load_state_dict(checkpoint['model_state'], strict=True)
    model = model.to(device).eval()
    model.requires_grad_(False)
    if model_digest(model.state_dict()) != model_digest(checkpoint['model_state']):
        raise AssertionError('Frozen weights changed during load')
    return model


def selected_users(data, limit_batches=4):
    # Whole original batches preserve native batch layout; no label/metric filtering.
    chosen = []
    for users, sequences in data.batches('valid', 8):
        if any((data.arrays['split'][seq] == 1).any() for seq in sequences):
            chosen.extend(users.tolist())
            if len(chosen) >= limit_batches * 8:
                break
    return np.asarray(chosen, dtype=np.int64)


def batches(data, batch_size, users=None):
    if users is None:
        yield from data.batches('valid', batch_size)
        return
    offsets, splits = data.arrays['user_offsets'], data.arrays['split']
    for start in range(0, len(users), batch_size):
        chosen = users[start:start + batch_size]
        sequences = []
        for user in chosen:
            seq = np.arange(offsets[user], offsets[user+1])
            sequences.append(seq[splits[seq] <= 1])
        yield chosen, sequences


def replay(model, data, forward, device, branch, batch_size=8, chunk_size=100, users=None):
    import torch
    before = model_digest(model.state_dict())
    parts = {key: [] for key in ('record_idx',) + KEYS}
    start = time.monotonic()
    with torch.no_grad():
        for number, (chosen, sequences) in enumerate(batches(data, batch_size, users), 1):
            state = model.init_state(len(chosen), device)
            for batch, indices in data.chunks(chosen, sequences, 'valid', chunk_size, device):
                if (data.arrays['split'][indices[indices >= 0]] > 1).any():
                    raise AssertionError('Test event entered replay')
                outputs, state = forward(model, state, batch, True)
                mask = batch['target_mask'].cpu().numpy()
                if mask.any():
                    parts['record_idx'].append(indices[mask])
                    for key in KEYS:
                        parts[key].append(outputs[key].cpu().numpy()[mask])
            if number == 1 or number % 100 == 0:
                print(json.dumps({'phase': 'replay', 'branch': branch, 'batch': number,
                                  'seconds': round(time.monotonic() - start, 1)}), flush=True)
    if not parts['record_idx']:
        raise ValueError('No validation events')
    result = {key: np.concatenate(values) for key, values in parts.items()}
    order = np.argsort(result['record_idx'], kind='stable')
    result = {key: val[order] for key, val in result.items()}
    wanted = np.flatnonzero(data.arrays['split'] == 1)
    if users is not None:
        wanted = wanted[np.isin(data.arrays['student_idx'][wanted], users)]
    if not np.array_equal(wanted, result['record_idx']):
        raise AssertionError('Validation coverage/order/uniqueness mismatch')
    for key in KEYS:
        if result[key].dtype != np.float32 or not np.isfinite(result[key]).all():
            raise AssertionError(f'Invalid native FP32 {key}')
    if ((result['probability'] < 0) | (result['probability'] > 1)).any():
        raise AssertionError('Invalid probability')
    if model_digest(model.state_dict()) != before:
        raise AssertionError('Parameters changed during frozen replay')
    return result


def compare(left, right, keys=KEYS):
    if not np.array_equal(left['record_idx'], right['record_idx']):
        raise AssertionError('Record identity/order mismatch')
    differences = {}
    for key in keys:
        a, b = np.asarray(left[key]), np.asarray(right[key])
        if a.shape != b.shape or not np.isfinite(a).all() or not np.isfinite(b).all():
            raise AssertionError(f'Invalid comparison array: {key}')
        differences[key] = float(np.max(np.abs(a.astype(float) - b.astype(float)), initial=0))
    return {'success': all(x <= ATOL for x in differences.values()), 'n': len(left['record_idx']),
            'atol': ATOL, 'max_absolute_difference': differences}


def reference_bridge(result, data, path):
    ref = pd.read_csv(path, float_precision='round_trip')
    full_ids = np.flatnonzero(data.arrays['split'] == 1)
    if not np.array_equal(ref['record_idx'].to_numpy(), full_ids):
        raise AssertionError('Original reference coverage/identity changed')
    for key in ('student_idx', 'item_idx', 'source_row', 'split', 'label', 'timestamp'):
        if not np.array_equal(ref[key].to_numpy(), data.arrays[key][full_ids]):
            raise AssertionError(f'Reference metadata mismatch: {key}')
    aligned = ref.set_index('record_idx').loc[result['record_idx']]
    # CSV is a decimal serialization of native float32 output, NOT float64 ground truth.
    reference = {'record_idx': aligned.index.to_numpy()}
    reference.update({key: aligned[key].to_numpy(dtype=np.float32) for key in KEYS})
    report = compare(result, reference)
    report['comparison_space'] = 'native FP32 replay versus CSV restored to its original FP32 precision'
    return report


def cold_guard(results, data):
    ids = results['NN']['record_idx']
    cold = data.arrays['kc_count_before'][ids] == 0
    reports = {}
    for a, b in (('NN', 'NS'), ('SN', 'SS')):
        left = {key: value[cold] for key, value in results[a].items()}
        right = {key: value[cold] for key, value in results[b].items()}
        reports[f'{a}_vs_{b}'] = compare(left, right)
    return {'success': all(x['success'] for x in reports.values()), 'checks': reports,
            'note': 'A cold current KC has no aged state; same-weight readout must agree. Different trained weights need not agree.'}


def validation_frame(data, ids):
    fields = ('student_idx', 'item_idx', 'label', 'split', 'timestamp', 'source_row',
              'delta_t_k_hours', 'kc_count_before', 'student_count_before')
    frame = pd.DataFrame({key: data.arrays[key][ids] for key in fields})
    frame['record_idx'] = ids
    frame['single_kc'] = data.arrays['item_q'][frame.item_idx.to_numpy()].sum(1) == 1
    return frame


def long_followup(data, ids):
    """Conservative long-gap singleton anchors and their NEXT actual same-KC event.

    Reject multi-KC targets and same-time targets instead of skipping over them.
    Match only valid->valid. Each target is unique; no outcome-dependent selection.
    These are observational strata of GLOBAL replay, not isolated-anchor treatment.
    """
    a = data.arrays
    qlist = [np.flatnonzero(row).tolist() for row in a['item_q']]
    next_seen, pairs = {}, []
    for row in range(len(a['split']) - 1, -1, -1):
        if a['split'][row] > 1:
            continue
        user, item = int(a['student_idx'][row]), int(a['item_idx'][row])
        kcs = qlist[item]
        if (a['split'][row] == 1 and len(kcs) == 1 and a['kc_count_before'][row] > 0
                and a['delta_t_k_hours'][row] > 168):
            target = next_seen.get((user, kcs[0]))
            if (target is not None and a['split'][target] == 1 and
                    a['timestamp'][target] > a['timestamp'][row] and
                    len(qlist[int(a['item_idx'][target])]) == 1):
                pairs.append((row, target))
        for kc in kcs:
            next_seen[(user, kc)] = row
    pairs.sort()
    pairs = np.asarray(pairs, dtype=np.int64).reshape(-1, 2)
    if len(pairs) and (len(np.unique(pairs[:, 1])) != len(pairs) or not np.isin(pairs, ids).all()):
        raise AssertionError('Follow-up pair identity failure')
    return pairs
