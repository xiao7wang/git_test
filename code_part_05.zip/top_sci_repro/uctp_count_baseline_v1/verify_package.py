import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
for n,d in json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
 p=root/n
 if p.parent!=root or hashlib.sha256(p.read_bytes()).hexdigest()!=d:raise ValueError('Package changed: '+n)
print('Package integrity verified',flush=True)
