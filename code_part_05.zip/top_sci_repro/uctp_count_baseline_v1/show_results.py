import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);root=Path(p.parse_args().output_dir)
if not (root/'status.json').exists():print('Not started or tests still running; check launch log.')
else:
 s=read(root/'status.json');print('status:',s['status'],'phase:',s.get('phase'),'epoch:',s.get('epoch'),'error:',s.get('error','-'))
 print('A saved running status is not proof of a live process.')
 if (root/'summary.json').exists():
  q=read(root/'summary.json');print('PFA-inspired log-count model; dev NLL:',q['dev']['nll'],'AUC:',q['dev']['auc'],'best epoch:',q['best_epoch'])
 if (root/'count_baseline_results.zip').exists():print('Results archive:',root/'count_baseline_results.zip')
