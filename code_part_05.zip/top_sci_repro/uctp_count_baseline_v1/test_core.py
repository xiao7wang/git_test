import argparse,unittest
import numpy as np
import torch
from count_core import CountModel,prior_count_features

DEVICE='cpu'
def sample():
 return {'student_idx':np.array([0,0,0,0,0,1,1,1]),'item_idx':np.array([0,0,1,0,0,0,0,0]),
 'split':np.array([0,0,0,1,2,0,1,2]),'timestamp':np.array([0,1,2,3,4,0,1,2],dtype=float),
 'label':np.array([1,0,1,1,0,1,0,1],dtype=float),'item_q':np.array([[1,0],[0,1]])}

class CountsTests(unittest.TestCase):
 def test_counts_follow_student_and_kc_and_predict_before_feedback(self):
  f=prior_count_features(sample(),{0,1})
  np.testing.assert_array_equal(f['record_idx'],[0,1,2,3,5,6])
  np.testing.assert_array_equal(f['success'],[0,1,0,1,0,1])
  np.testing.assert_array_equal(f['failure'],[0,0,0,1,0,0])
 def test_future_current_holdout_and_test_labels_cannot_leak(self):
  a=sample();base=prior_count_features(a,{0})
  a['label'][3]=0;a['label'][4]=np.nan;a['label'][6:]=np.nan
  other=prior_count_features(a,{0})
  np.testing.assert_array_equal(base['record_idx'],other['record_idx'])
  np.testing.assert_array_equal(base['success'],other['success'])
  np.testing.assert_array_equal(base['failure'],other['failure'])
 def test_multikc_and_time_order_rejected(self):
  a=sample();a['item_q'][0]=[1,1]
  with self.assertRaises(ValueError):prior_count_features(a,{0})
  a=sample();a['timestamp'][1]=-1
  with self.assertRaises(ValueError):prior_count_features(a,{0})
 def test_vectorized_counts_match_naive_many_students(self):
  rng=np.random.default_rng(42);n_users=25;length=24;n=n_users*length
  users=np.repeat(np.arange(n_users),length);positions=np.tile(np.arange(length),n_users)
  a={'student_idx':users,'item_idx':rng.integers(0,4,n),'split':np.where(positions<12,0,np.where(positions<20,1,2)),
     'timestamp':positions.astype(float),'label':rng.integers(0,2,n),'item_q':np.eye(4,dtype=int)}
  dev={u for u in range(n_users) if u%2==0};actual=prior_count_features(a,dev)
  expected=[];counts={}
  for i in range(n):
   if a['split'][i]==2 or (a['split'][i]==1 and users[i] not in dev):continue
   key=(users[i],a['item_idx'][i]);succ,fail=counts.get(key,(0,0));expected.append((i,succ,fail))
   counts[key]=(succ+int(a['label'][i]),fail+int(1-a['label'][i]))
  np.testing.assert_array_equal(np.column_stack((actual['record_idx'],actual['success'],actual['failure'])),np.array(expected))
 def test_model_fits_and_gradients_are_finite(self):
  device=torch.device(DEVICE);m=CountModel(2,2,2).to(device)
  z=torch.tensor([0,1],device=device);c=torch.tensor([0.,1.],device=device)
  logits=m(z,z,z,c,c);self.assertTrue(torch.equal(logits,torch.zeros_like(logits)))
  loss=torch.nn.functional.binary_cross_entropy_with_logits(logits,torch.tensor([0.,1.],device=device));loss.backward()
  self.assertTrue(all(torch.isfinite(p.grad).all() for p in m.parameters()))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--device',choices=('cpu','cuda'),default='cpu');a=p.parse_args();DEVICE=a.device
 if DEVICE=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 torch.use_deterministic_algorithms(True)
 unittest.main(argv=['test_core'],verbosity=2)
