import json
import csv
from pathlib import Path
from collections import defaultdict

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def normalize_kc(kc):
    if isinstance(kc, list):
        return [int(x) for x in kc]
    if isinstance(kc, str):
        try:
            obj = json.loads(kc)
            if isinstance(obj, list):
                return [int(x) for x in obj]
        except Exception:
            pass
        if "," in kc:
            return [int(x) for x in kc.split(",") if x.strip() != ""]
        return [int(kc)]
    return [int(kc)]

def collect_records_from_file(path):
    data = load_json(path)
    records = []

    # 格式一：平铺日志
    # {"user_id":..., "exer_id":..., "knowledge_code":..., "score":..., "response_time":..., "timestamp":...}
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "exer_id" in data[0]:
        for x in data:
            u = int(x["user_id"])
            e = int(x["exer_id"])
            y = int(float(x["score"]))
            kc = normalize_kc(x["knowledge_code"])
            rt = x.get("response_time", None)
            ts = x.get("timestamp", None)
            records.append((u, e, y, kc, rt, ts))
        return records

    # 格式二：学生序列
    # {"user_id":..., "log_num":..., "logs":[{"exer_id":..., ...}]}
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "logs" in data[0]:
        for stu in data:
            u = int(stu["user_id"])
            for x in stu["logs"]:
                e = int(x["exer_id"])
                y = int(float(x["score"]))
                kc = normalize_kc(x["knowledge_code"])
                rt = x.get("response_time", None)
                ts = x.get("timestamp", None)
                records.append((u, e, y, kc, rt, ts))
        return records

    raise ValueError(f"Unrecognized json format: {path}")

def convert_dataset(src_dir, out_dir, dataset_name):
    src_dir = Path(src_dir)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    config_path = src_dir / "config.json"
    config = load_json(config_path)

    # 兼容不同字段名
    student_num = int(config.get("student_n", config.get("student_num")))
    exercise_num = int(config.get("exer_n", config.get("exercise_num")))
    knowledge_num = int(config.get("knowledge_n", config.get("knowledge_num")))

    files = []
    for name in ["train_set.json", "val_set.json", "valid_set.json", "test_set.json"]:
        p = src_dir / name
        if p.exists():
            files.append(p)

    if not files:
        raise FileNotFoundError(f"No train/val/test json found in {src_dir}")

    all_records = []
    for p in files:
        print("reading:", p)
        all_records.extend(collect_records_from_file(p))

    print("raw records:", len(all_records))

    # 去掉越界样本
    clean = []
    q = [[0 for _ in range(knowledge_num)] for _ in range(exercise_num)]

    for u, e, y, kc_list, rt, ts in all_records:
        if not (0 <= u < student_num):
            continue
        if not (0 <= e < exercise_num):
            continue
        y = 1 if y > 0 else 0
        valid_kcs = [k for k in kc_list if 0 <= k < knowledge_num]
        if not valid_kcs:
            continue

        clean.append((u, e, y, rt, ts))
        for k in valid_kcs:
            q[e][k] = 1

    print("clean records:", len(clean))
    print("student_num:", student_num, "exercise_num:", exercise_num, "knowledge_num:", knowledge_num)

    # HyperCDM 原版使用三列：student_id, exercise_id, score
    data_file = f"{dataset_name}TotalData.csv"
    with open(out_dir / data_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        for u, e, y, rt, ts in clean:
            writer.writerow([u, e, y])

    # 额外保存带时间版本，后面做 TR-HyperCDM / CFT-DCD 时用
    with open(out_dir / f"{dataset_name}TotalData_time.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["student_id", "exercise_id", "score", "response_time", "timestamp"])
        for u, e, y, rt, ts in clean:
            writer.writerow([u, e, y, rt if rt is not None else "", ts if ts is not None else ""])

    with open(out_dir / "q.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(q)

    new_config = {
        "dataset": dataset_name,
        "q_file": "q.csv",
        "data": data_file,
        "student_num": student_num,
        "exercise_num": exercise_num,
        "knowledge_num": knowledge_num
    }

    with open(out_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(new_config, f, ensure_ascii=False, indent=2)

    print("saved to:", out_dir)

if __name__ == "__main__":
    convert_dataset(
        "/home/wangxiao/QCCDM/top_sci_repro/converted_data/assistments_time_neuralcd",
        "/home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM/data/assistments_time_ours",
        "assistments_time_ours"
    )

    convert_dataset(
        "/home/wangxiao/QCCDM/top_sci_repro/converted_data/ednet_kt1_time_neuralcd",
        "/home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM/data/ednet_time_ours",
        "ednet_time_ours"
    )
