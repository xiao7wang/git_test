#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM
source /home/wangxiao/miniconda3/etc/profile.d/conda.sh
conda activate cd5090

echo "===== Step 1. Generate D-only / I-only stats for Assist sample ====="

python - <<'PY'
import json
import math
import numpy as np
from pathlib import Path
from collections import defaultdict

SRC = Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/assistments_time_sample5000_item12000")
OUT_DIR = Path("data/assistments_time_sample5000_item12000")
OUT_D = OUT_DIR / "item_d_stats.csv"
OUT_I = OUT_DIR / "item_i_stats.csv"

cfg = json.load(open(SRC / "config.json", "r", encoding="utf-8"))
exer_n = int(cfg["exer_n"])

train = json.load(open(SRC / "train_set.json", "r", encoding="utf-8"))

scores = defaultdict(list)
for x in train:
    e = int(x["exer_id"])
    y = int(float(x["score"]))
    scores[e].append(y)

diff_feat = np.zeros(exer_n, dtype=np.float32)
count_feat = np.zeros(exer_n, dtype=np.float32)

for e in range(exer_n):
    ys = scores.get(e, [])
    n = len(ys)
    correct = sum(ys) if n > 0 else 0

    # train-only smoothed correctness logit
    p = (correct + 1.0) / (n + 2.0)
    p = min(max(p, 1e-5), 1 - 1e-5)
    diff_feat[e] = math.log(p / (1.0 - p))

    # train-only exposure / reliability
    count_feat[e] = math.log1p(n)

def zscore(a):
    return ((a - a.mean()) / (a.std() + 1e-8)).astype(np.float32)

d = zscore(diff_feat).reshape(-1, 1)
i = zscore(count_feat).reshape(-1, 1)

np.savetxt(OUT_D, d, fmt="%.8f", delimiter=",")
np.savetxt(OUT_I, i, fmt="%.8f", delimiter=",")

print("saved:", OUT_D, d.shape, float(d.min()), float(d.max()))
print("saved:", OUT_I, i.shape, float(i.min()), float(i.max()))
PY

echo "===== Step 2. Generate EdNet DI stats from train split ====="

python - <<'PY'
import json
import math
import numpy as np
from pathlib import Path
from collections import defaultdict

CANDIDATES = [
    Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/ednet_kt1_time_neuralcd"),
    Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/ednet_time_neuralcd"),
    Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/ednet_time_ours"),
]

SRC = None
for p in CANDIDATES:
    if (p / "train_set.json").exists() and (p / "config.json").exists():
        SRC = p
        break

if SRC is None:
    raise RuntimeError("没有找到 EdNet converted_data 目录。请检查 converted_data 下 ednet 目录名。")

OUT_DIR = Path("data/ednet_time_ours")
OUT = OUT_DIR / "item_di_stats.csv"

cfg = json.load(open(SRC / "config.json", "r", encoding="utf-8"))
exer_n = int(cfg.get("exer_n", cfg.get("exercise_n", cfg.get("exercise_num"))))

train = json.load(open(SRC / "train_set.json", "r", encoding="utf-8"))

def iter_records(data):
    # flat list
    if isinstance(data, list) and data and isinstance(data[0], dict) and "exer_id" in data[0]:
        for x in data:
            yield int(x["exer_id"]), int(float(x["score"]))
        return

    # sequence list
    if isinstance(data, list) and data and isinstance(data[0], dict) and "logs" in data[0]:
        for stu in data:
            for x in stu["logs"]:
                yield int(x["exer_id"]), int(float(x["score"]))
        return

    raise ValueError("Unknown train_set.json format")

scores = defaultdict(list)
for e, y in iter_records(train):
    if 0 <= e < exer_n:
        scores[e].append(1 if y > 0 else 0)

diff_feat = np.zeros(exer_n, dtype=np.float32)
count_feat = np.zeros(exer_n, dtype=np.float32)

for e in range(exer_n):
    ys = scores.get(e, [])
    n = len(ys)
    correct = sum(ys) if n > 0 else 0

    p = (correct + 1.0) / (n + 2.0)
    p = min(max(p, 1e-5), 1 - 1e-5)
    diff_feat[e] = math.log(p / (1.0 - p))
    count_feat[e] = math.log1p(n)

def zscore(a):
    return ((a - a.mean()) / (a.std() + 1e-8)).astype(np.float32)

stats = np.stack([zscore(diff_feat), zscore(count_feat)], axis=1)
np.savetxt(OUT, stats, fmt="%.8f", delimiter=",")

print("EdNet SRC:", SRC)
print("saved:", OUT, stats.shape)
print("diff_z range:", float(stats[:,0].min()), float(stats[:,0].max()))
print("count_z range:", float(stats[:,1].min()), float(stats[:,1].max()))
PY

echo "===== Step 3. Build D-only / I-only / EdNet-DI scripts ====="

python - <<'PY'
from pathlib import Path

def patch_item_prior(
    src_script,
    out_script,
    model_tag,
    stats_path,
    attr_name,
    buffer_name,
    mlp_name,
    scale_name,
    input_dim,
    dataset_note
):
    src = Path(src_script)
    out = Path(out_script)
    s = src.read_text(encoding="utf-8")

    if "import numpy as np" not in s:
        if "import numpy" in s:
            s = s.replace("import numpy", "import numpy as np")
        else:
            s = s.replace("import torch", "import numpy as np\nimport torch", 1)

    if "import types" not in s:
        s = s.replace("import numpy as np", "import numpy as np\nimport types", 1)

    target = "        self.net.to(self.device)\n"
    if target not in s:
        raise RuntimeError(f"{src_script}: 没有找到 self.net.to(self.device)")

    insert = f'''        # ================= {model_tag} =================
        # {dataset_note}
        # train-only item prior injection into exercise hypergraph representation.
        if hasattr(self, "{attr_name}") and not hasattr(self.net, "_{attr_name}_wrapped"):
            if not hasattr(self.net, "exercise_emb"):
                raise RuntimeError("self.net.exercise_emb not found.")

            stats_np = np.loadtxt(self.{attr_name}, delimiter=",").astype("float32")
            if stats_np.ndim == 1:
                stats_np = stats_np.reshape(-1, {input_dim})
            stats_tensor = torch.tensor(stats_np, dtype=torch.float32)

            emb_dim = int(self.net.exercise_emb.weight.shape[1])

            self.net.register_buffer("{buffer_name}", stats_tensor)
            self.net.{mlp_name} = nn.Sequential(
                nn.Linear({input_dim}, emb_dim),
                nn.Tanh(),
                nn.Linear(emb_dim, emb_dim)
            )

            # zero-init: initial model is equivalent to original HyperCDM
            nn.init.zeros_(self.net.{mlp_name}[-1].weight)
            nn.init.zeros_(self.net.{mlp_name}[-1].bias)

            self.net.{scale_name} = nn.Parameter(torch.tensor(0.2, dtype=torch.float32))

            _original_convolution = self.net.convolution

            def _prior_convolution(net_self, embedding, adj):
                out = _original_convolution(embedding, adj)

                if embedding is net_self.exercise_emb:
                    delta = net_self.{mlp_name}(getattr(net_self, "{buffer_name}").to(out.device).float())
                    out = out + torch.tanh(net_self.{scale_name}) * delta

                return out

            self.net.convolution = types.MethodType(_prior_convolution, self.net)
            self.net._{attr_name}_wrapped = True

            print("[{model_tag}] injected:",
                  self.{attr_name},
                  "shape=", tuple(stats_tensor.shape),
                  "emb_dim=", emb_dim,
                  "range=", float(stats_tensor.min()), float(stats_tensor.max()))
        # ============================================================

'''

    if f"[{model_tag}] injected" not in s:
        s = s.replace(target, insert + target, 1)

    target2 = "cdm.hyper_build(response_logs)\n"
    if target2 not in s:
        raise RuntimeError(f"{src_script}: 没有找到 cdm.hyper_build(response_logs)")

    set_path = f'''cdm.{attr_name} = "{stats_path}"
print("[{model_tag}] stats path set:", cdm.{attr_name})
'''

    if f"[{model_tag}] stats path set" not in s:
        s = s.replace(target2, target2 + set_path, 1)

    s = s.replace("torch.float64", "torch.float32")
    s = s.replace("epoch=5)", "epoch=3)")
    s = s.replace("epoch=1)", "epoch=3)")

    out.write_text(s, encoding="utf-8")
    print("saved:", out)


patch_item_prior(
    src_script="main_assistments_sample5000_item12000_epoch3.py",
    out_script="main_assistments_sample5000_item12000_donly_epoch3.py",
    model_tag="D-HyperCDM",
    stats_path="data/assistments_time_sample5000_item12000/item_d_stats.csv",
    attr_name="d_stats_path",
    buffer_name="item_d_stats",
    mlp_name="d_mlp",
    scale_name="d_scale",
    input_dim=1,
    dataset_note="Difficulty-only prior; no response time, no frequency."
)

patch_item_prior(
    src_script="main_assistments_sample5000_item12000_epoch3.py",
    out_script="main_assistments_sample5000_item12000_ionly_epoch3.py",
    model_tag="I-HyperCDM",
    stats_path="data/assistments_time_sample5000_item12000/item_i_stats.csv",
    attr_name="i_stats_path",
    buffer_name="item_i_stats",
    mlp_name="i_mlp",
    scale_name="i_scale",
    input_dim=1,
    dataset_note="Item exposure/reliability-only prior; no response time, no difficulty."
)

patch_item_prior(
    src_script="main_ednet_ours.py",
    out_script="main_ednet_ours_di_epoch3.py",
    model_tag="EdNet-DI-HyperCDM",
    stats_path="data/ednet_time_ours/item_di_stats.csv",
    attr_name="ednet_di_stats_path",
    buffer_name="item_di_stats",
    mlp_name="di_mlp",
    scale_name="di_scale",
    input_dim=2,
    dataset_note="EdNet full-data Difficulty + exposure/reliability prior."
)
PY

echo "===== Step 4. Compile scripts ====="

python -m py_compile main_assistments_sample5000_item12000_donly_epoch3.py
python -m py_compile main_assistments_sample5000_item12000_ionly_epoch3.py
python -m py_compile main_ednet_ours_di_epoch3.py

echo "===== Step 5. Run D-only Assist sample ====="
python -u main_assistments_sample5000_item12000_donly_epoch3.py > logs/hypercdm_assist_sample5000_donly_epoch3.log 2>&1

echo "===== D-only finished ====="
grep -n "Evaluation AUC\|average loss" logs/hypercdm_assist_sample5000_donly_epoch3.log || true

echo "===== Step 6. Run I-only Assist sample ====="
python -u main_assistments_sample5000_item12000_ionly_epoch3.py > logs/hypercdm_assist_sample5000_ionly_epoch3.log 2>&1

echo "===== I-only finished ====="
grep -n "Evaluation AUC\|average loss" logs/hypercdm_assist_sample5000_ionly_epoch3.log || true

echo "===== Step 7. Run EdNet DI-HyperCDM full data ====="
python -u main_ednet_ours_di_epoch3.py > logs/hypercdm_ednet_ours_di_epoch3.log 2>&1

echo "===== EdNet DI finished ====="
grep -n "Evaluation AUC\|average loss" logs/hypercdm_ednet_ours_di_epoch3.log || true

echo "===== ALL DONE ====="
