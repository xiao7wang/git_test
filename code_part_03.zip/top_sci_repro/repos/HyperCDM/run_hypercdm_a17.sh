#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM

source /home/wangxiao/miniconda3/etc/profile.d/conda.sh
conda activate cd5090

mkdir -p logs

echo "===== HyperCDM a17 start: $(date) ====="
echo "pwd: $(pwd)"
echo "python: $(which python)"
echo "conda env: $CONDA_DEFAULT_ENV"

python -u main_a17.py > logs/hypercdm_a17_raw.log 2>&1

echo "===== HyperCDM a17 finished: $(date) ====="
