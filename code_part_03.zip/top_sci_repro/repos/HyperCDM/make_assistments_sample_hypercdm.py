import csv
import json
from pathlib import Path
from collections import defaultdict

src_dir = Path("data/assistments_time_ours")
out_dir = Path("data/assistments_time_ours_sample5000")
out_dir.mkdir(parents=True, exist_ok=True)

data_file = src_dir / "assistments_time_oursTotalData.csv"
q_file = src_dir / "q.csv"

max_students = 5000

print("Reading interactions...")
records = []
students = set()

with open(data_file, "r", encoding="utf-8") as f:
    reader = csv.reader(f)
    for row in reader:
        if len(row) < 3:
            continue
        u, e, y = int(row[0]), int(row[1]), int(row[2])
        if len(students) < max_students or u in students:
            students.add(u)
            records.append((u, e, y))
        if len(students) >= max_students and u not in students:
            continue

print("sample students:", len(students))
print("sample records before remap:", len(records))

used_exercises = sorted(set(e for _, e, _ in records))
used_students = sorted(students)

stu_map = {u: i for i, u in enumerate(used_students)}
exer_map = {e: i for i, e in enumerate(used_exercises)}

print("sample exercises:", len(used_exercises))

print("Reading original q.csv...")
orig_q = {}
with open(q_file, "r", encoding="utf-8") as f:
    reader = csv.reader(f)
    for idx, row in enumerate(reader):
        if idx in exer_map:
            orig_q[idx] = [int(float(x)) for x in row]

knowledge_num = len(next(iter(orig_q.values())))
print("knowledge_num:", knowledge_num)

out_data = out_dir / "assistments_time_ours_sample5000TotalData.csv"
with open(out_data, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    for u, e, y in records:
        writer.writerow([stu_map[u], exer_map[e], y])

out_q = out_dir / "q.csv"
with open(out_q, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    for old_e in used_exercises:
        writer.writerow(orig_q[old_e])

config = {
    "dataset": "assistments_time_ours_sample5000",
    "q_file": "q.csv",
    "data": "assistments_time_ours_sample5000TotalData.csv",
    "student_num": len(used_students),
    "exercise_num": len(used_exercises),
    "knowledge_num": knowledge_num
}

with open(out_dir / "config.json", "w", encoding="utf-8") as f:
    json.dump(config, f, ensure_ascii=False, indent=2)

print("saved:", out_dir)
print(config)
