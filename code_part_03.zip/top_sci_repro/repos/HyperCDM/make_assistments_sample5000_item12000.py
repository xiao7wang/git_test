import json
import csv
import random
from pathlib import Path
from collections import Counter, defaultdict

SEED = 2026
MAX_STUDENTS = 5000
MAX_EXERCISES = 12000
MIN_USER_RECORDS_AFTER_FILTER = 5

SRC = Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/assistments_time_neuralcd")
OUT_HYPER = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/HyperCDM/data/assistments_time_sample5000_item12000")
OUT_NEURAL = Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/assistments_time_sample5000_item12000")

OUT_HYPER.mkdir(parents=True, exist_ok=True)
OUT_NEURAL.mkdir(parents=True, exist_ok=True)

random.seed(SEED)

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def normalize_kc(kc):
    if isinstance(kc, list):
        return [int(x) for x in kc]
    if isinstance(kc, str):
        try:
            obj = json.loads(kc)
            if isinstance(obj, list):
                return [int(x) for x in obj]
        except Exception:
            pass
        if "," in kc:
            return [int(x) for x in kc.split(",") if x.strip() != ""]
        return [int(kc)]
    return [int(kc)]

def iter_records_from_file(path, split):
    data = load_json(path)

    # 平铺格式
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "exer_id" in data[0]:
        for x in data:
            yield {
                "split": split,
                "user_id": int(x["user_id"]),
                "exer_id": int(x["exer_id"]),
                "score": int(float(x["score"])),
                "knowledge_code": normalize_kc(x["knowledge_code"]),
                "response_time": x.get("response_time", None),
                "timestamp": x.get("timestamp", None),
            }
        return

    # 学生序列格式
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict) and "logs" in data[0]:
        for stu in data:
            u = int(stu["user_id"])
            for x in stu["logs"]:
                yield {
                    "split": split,
                    "user_id": u,
                    "exer_id": int(x["exer_id"]),
                    "score": int(float(x["score"])),
                    "knowledge_code": normalize_kc(x["knowledge_code"]),
                    "response_time": x.get("response_time", None),
                    "timestamp": x.get("timestamp", None),
                }
        return

    raise ValueError(f"Unknown format: {path}")

# 读 config
config = load_json(SRC / "config.json")
student_n = int(config.get("student_n", config.get("student_num")))
exer_n = int(config.get("exer_n", config.get("exercise_num")))
knowledge_n = int(config.get("knowledge_n", config.get("knowledge_num")))

print("Original config:", student_n, exer_n, knowledge_n)

# 读取所有 split
all_records = []
for fname, split in [
    ("train_set.json", "train"),
    ("val_set.json", "val"),
    ("test_set.json", "test"),
]:
    p = SRC / fname
    if p.exists():
        print("reading:", p)
        all_records.extend(list(iter_records_from_file(p, split)))

print("all raw records:", len(all_records))

# 过滤越界
clean = []
for r in all_records:
    u = r["user_id"]
    e = r["exer_id"]
    kcs = [k for k in r["knowledge_code"] if 0 <= k < knowledge_n]
    if 0 <= u < student_n and 0 <= e < exer_n and kcs:
        r["score"] = 1 if r["score"] > 0 else 0
        r["knowledge_code"] = kcs
        clean.append(r)

print("clean records:", len(clean))

# 按学生统计，先随机采样学生
user_counter = Counter(r["user_id"] for r in clean)
eligible_users = [u for u, c in user_counter.items() if c >= MIN_USER_RECORDS_AFTER_FILTER]
sample_users = set(random.sample(eligible_users, min(MAX_STUDENTS, len(eligible_users))))

records_u = [r for r in clean if r["user_id"] in sample_users]
print("records after user sample:", len(records_u))
print("sample users before item cap:", len(sample_users))

# 在采样学生内取高频题目，限制题目规模
exer_counter = Counter(r["exer_id"] for r in records_u)
top_exercises = set(e for e, _ in exer_counter.most_common(MAX_EXERCISES))

records_ui = [r for r in records_u if r["exer_id"] in top_exercises]

# 去掉过滤后交互太少的学生
user_counter2 = Counter(r["user_id"] for r in records_ui)
final_users = set(u for u, c in user_counter2.items() if c >= MIN_USER_RECORDS_AFTER_FILTER)
records_final = [r for r in records_ui if r["user_id"] in final_users]

used_users = sorted(set(r["user_id"] for r in records_final))
used_exers = sorted(set(r["exer_id"] for r in records_final))

stu_map = {u: i for i, u in enumerate(used_users)}
exer_map = {e: i for i, e in enumerate(used_exers)}

print("final users:", len(used_users))
print("final exercises:", len(used_exers))
print("final records:", len(records_final))

# 构建 Q 矩阵
q = [[0 for _ in range(knowledge_n)] for _ in range(len(used_exers))]
for r in records_final:
    new_e = exer_map[r["exer_id"]]
    for k in r["knowledge_code"]:
        q[new_e][k] = 1

# 写 HyperCDM TotalData
dataset_name = "assistments_time_sample5000_item12000"
hyper_data_file = f"{dataset_name}TotalData.csv"

with open(OUT_HYPER / hyper_data_file, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    for r in records_final:
        writer.writerow([stu_map[r["user_id"]], exer_map[r["exer_id"]], r["score"]])

with open(OUT_HYPER / "q.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerows(q)

hyper_config = {
    "dataset": dataset_name,
    "q_file": "q.csv",
    "data": hyper_data_file,
    "student_num": len(used_users),
    "exercise_num": len(used_exers),
    "knowledge_num": knowledge_n,
    "seed": SEED,
    "sampling": {
        "method": "fixed_student_sample_with_top_exercises",
        "max_students": MAX_STUDENTS,
        "max_exercises": MAX_EXERCISES,
        "min_user_records_after_filter": MIN_USER_RECORDS_AFTER_FILTER
    }
}

with open(OUT_HYPER / "config.json", "w", encoding="utf-8") as f:
    json.dump(hyper_config, f, ensure_ascii=False, indent=2)

# 同时写 NeuralCD 风格 train/val/test，方便后续所有模型在同一子集上公平对比
split_records = defaultdict(list)
for r in records_final:
    item = {
        "user_id": stu_map[r["user_id"]],
        "exer_id": exer_map[r["exer_id"]],
        "knowledge_code": r["knowledge_code"],
        "score": r["score"],
    }
    if r["response_time"] is not None:
        item["response_time"] = r["response_time"]
    if r["timestamp"] is not None:
        item["timestamp"] = r["timestamp"]
    split_records[r["split"]].append(item)

for split, fname in [
    ("train", "train_set.json"),
    ("val", "val_set.json"),
    ("test", "test_set.json"),
]:
    with open(OUT_NEURAL / fname, "w", encoding="utf-8") as f:
        json.dump(split_records[split], f, ensure_ascii=False)

neural_config = {
    "student_n": len(used_users),
    "exer_n": len(used_exers),
    "knowledge_n": knowledge_n,
    "seed": SEED,
    "source": "assistments_time_neuralcd",
    "sampling": hyper_config["sampling"]
}

with open(OUT_NEURAL / "config.json", "w", encoding="utf-8") as f:
    json.dump(neural_config, f, ensure_ascii=False, indent=2)

# 保存映射，方便追溯
with open(OUT_NEURAL / "student_id_map.json", "w", encoding="utf-8") as f:
    json.dump({str(k): v for k, v in stu_map.items()}, f, ensure_ascii=False)
with open(OUT_NEURAL / "exercise_id_map.json", "w", encoding="utf-8") as f:
    json.dump({str(k): v for k, v in exer_map.items()}, f, ensure_ascii=False)

print("saved HyperCDM data to:", OUT_HYPER)
print("saved NeuralCD-style data to:", OUT_NEURAL)
print("split sizes:", {k: len(v) for k, v in split_records.items()})
