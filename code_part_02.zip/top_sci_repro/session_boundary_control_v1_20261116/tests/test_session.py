import copy
import csv
import gzip
import io
import json
import os
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np
from count_time.training import fit_mode
from count_time.common import sha256_file
from session_control.features import build
from session_control.runner import run
from session_control.train import fit


def toy():
    users, items, labels, splits, timestamps = [], [], [], [], []
    for u in range(8):
        users += [u]*6
        items += [0,1,1,0,1,0]
        labels += [(u+1)%2,u%2,1,(u+1)%2,u%2,1]
        splits += [0,0,0,0,1,2]
        timestamps += [0,36000,72001,108002,108002,200000]
    return {"student_idx": np.array(users), "item_idx": np.array(items), "label": np.array(labels),
            "split": np.array(splits), "timestamp": np.array(timestamps, dtype=np.float64),
            "item_q": np.array([[1,0],[0,1]])}


class SessionContract(unittest.TestCase):
    def test_boundaries_crossings_no_current_or_test_label_leak(self):
        arrays = toy()
        f = build(arrays, set(range(8)))
        self.assertEqual(len(f["student"]), 40)  # test rows excluded
        self.assertFalse(f["starts_session"][1])  # exactly 10h is not >10h
        self.assertTrue(f["starts_session"][2])
        self.assertTrue(f["starts_session"][3])
        self.assertFalse(f["starts_session"][4])
        self.assertEqual(f["session_crossings"][3], 2)
        self.assertAlmostEqual(f["session_states"][0][3], .25)
        self.assertEqual(f["session_crossings"][4], 1)  # boundary happened on another KC
        altered = copy.deepcopy(arrays)
        altered["label"][3] = 1 - altered["label"][3]
        altered["label"][arrays["split"] == 2] = 1 - altered["label"][arrays["split"] == 2]
        g = build(altered, set(range(8)))
        for a,b in zip(f["session_states"],g["session_states"]):
            np.testing.assert_array_equal(a[:4], b[:4])
        self.assertEqual(len(g["student"]), 40)

    def test_counts_against_independent_history_sum(self):
        # Construct distinct irregular paths; compute each output from raw past records.
        rng = np.random.default_rng(20261116)
        for trial in range(30):
            n = 30
            gaps = rng.choice([0, 18000, 36000, 36001, 200000], size=n)
            times = np.cumsum(gaps).astype(float)
            kc = rng.integers(0,3,n)
            y = rng.integers(0,2,n)
            split = np.zeros(n,dtype=int); split[20:27]=1; split[27:]=2
            arrays = {"student_idx":np.zeros(n,dtype=int),"item_idx":kc,"label":y,"split":split,
                      "timestamp":times,"item_q":np.eye(3,dtype=int)}
            f = build(arrays,{0})
            true_session = np.r_[0, np.cumsum(np.diff(times[:27]) > 36000)]
            for i in range(27):
                past = [j for j in range(i) if kc[j] == kc[i]]
                a = sum(float(y[j]) * (.5 ** int(true_session[i]-true_session[j])) for j in past)
                b = sum(float(1-y[j]) * (.5 ** int(true_session[i]-true_session[j])) for j in past)
                self.assertAlmostEqual(f["session_states"][0][i], a, places=12)
                self.assertAlmostEqual(f["session_states"][1][i], b, places=12)

    def test_time_bridge_to_previous_implementation(self):
        f = build(toy(), set(range(8)))
        with tempfile.TemporaryDirectory() as tmp:
            old = fit_mode(f, "C_real_time", 1, Path(tmp)/"old", epochs=3, patience=5, batch_size=16, device="cpu")
            new = fit(f, "T_time", 1, Path(tmp)/"new", epochs=3, patience=5, batch_size=16, device="cpu")
            np.testing.assert_allclose(old["probability"],new["probability"],atol=1e-6,rtol=0)
            self.assertEqual([x["train_order_sha256"] for x in old["history"]],
                             [x["train_order_sha256"] for x in new["history"]])

    def test_full_synthetic_run_archive_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)/"result"
            result = run(toy(), set(range(8)), out, device="cpu", epochs=2, patience=3,
                         batch_size=16, repetitions=20)
            self.assertEqual(result["status"], "complete")
            self.assertEqual(json.loads((out/"status.json").read_text())["phase"], "complete")
            with zipfile.ZipFile(result["archive"]["path"]) as z:
                self.assertIsNone(z.testzip())
                self.assertIn("manifest.json", z.namelist())
                self.assertIn("summary.json", z.namelist())
            with self.assertRaises(FileExistsError):
                run(toy(), set(range(8)), out, device="cpu", epochs=1, repetitions=1)

    def test_bad_reference_aborts_before_controls(self):
        f = build(toy(),set(range(8)))
        dev = np.flatnonzero(f["split"] == 1)
        with tempfile.TemporaryDirectory() as tmp:
            archive = Path(tmp)/"fake_reference.zip"
            data = io.StringIO(newline="")
            w = csv.writer(data)
            w.writerow(["record_idx","student_idx","label","probability"])
            for i in dev:
                w.writerow([int(f["record_idx"][i]),int(f["student"][i]),int(f["label"][i]),.01])
            with zipfile.ZipFile(archive,"w") as z:
                for seed in (0,1,2):
                    z.writestr(f"jobs/C_real_time_seed{seed}/dev_predictions.csv.gz",gzip.compress(data.getvalue().encode()))
            out = Path(tmp)/"bad_result"
            with self.assertRaisesRegex(ValueError,"reference bridge failed"):
                run(toy(),set(range(8)),out,reference=archive,reference_sha=sha256_file(archive),device="cpu",
                    epochs=1,patience=2,batch_size=16,repetitions=1)
            self.assertEqual(json.loads((out/"status.json").read_text())["status"],"failed")
            self.assertFalse((out/"jobs"/"S_session_seed0").exists())
            self.assertFalse((out/"session_control_results.zip").exists())


if __name__ == "__main__":
    unittest.main()
