# Session boundary control: exploratory ASSIST development comparison

This package studies whether continuous elapsed-time count features improve a simple count model after adding a fixed practice-session boundary control. It is not a HiTSKT implementation. It reuses the already explored ASSIST development students, not an independent confirmatory sample.

## Data and availability assumptions

The existing prepared-data manifest and project source files are pinned by SHA-256. The prepared-data loader reads its whole stored arrays, including test labels; the feature constructor selects only train and the pre-existing development students, and this run never scores test or holdout. Rows are processed in the existing student/time/record order. Current predictions use history before the current answer; histories assume row-immediate feedback. Event timestamps are only a proxy for exercise start/end or feedback, which are not independently verified. Tied times follow the old record order.

## Fixed modes

Calculate each student's boundary when the current event timestamp minus the immediately preceding event timestamp exceeds **10 hours**, regardless of KC. A KC's previous success/failure counts are multiplied by **0.5 per boundary crossed** since that KC's previous event; both counts are updated only after the current outcome. Ties and exactly 10 hours do not start a session. The use of 10 hours is inspired by the HiTSKT preprint, which defined its gap using next start versus previous end; this code only has event timestamp differences. The 0.5 is a project probe, not a HiTSKT parameter. Neither candidate is asserted to be optimal or calibrated to the 168-hour retention curve.

* `S_session`: session-boundary discounted counts with student/item/KC biases.
* `T_time`: the prior per-KC elapsed-time discounted counts, half-life 168 hours.
* `ST_both`: both pairs of log counts. It has two extra effective KC coefficients relative to S or T, so the comparison includes capacity. S and T have matched effective count-feature capacity.

Three training-order seeds 0, 1, 2, AdamW learning rate 0.01, weight decay 1e-5, batch size 8192, gradient clip 5, up to 20 epochs and patience 5 match the previous count experiment. Each best epoch is selected by development NLL. For each seed the time-only model must reproduce the pinned previous count result on the exact same events before the new controls for that seed run: max absolute probability error <= 1e-5 and NLL error <= 1e-6. Matched initial states and common-epoch train-order hashes are also checked. A failed bridge stops the run and is not a scientific comparison.

The primary contrast is ST minus S on all development events, event-weighted NLL averaged across seeds. Secondary outputs include student-macro NLL, AUC and Brier, T minus S, ST minus T, each seed, first/repeat KC and session-crossing groups. Student-cluster bootstrap intervals condition on these fixed trained models and do not cover fitting or repeated exploration. The results say nothing by themselves about causal effects of waiting on human memory.

## Execution and outputs

`bash run_server.sh server_session_01` verifies the archive sources and the exact previous result reference, requires at least 1 GiB free and a CUDA device, runs local synthetic CPU contracts, and then trains. It refuses to overwrite an existing run or launch log and has no automatic retry or CPU fallback. Previous model/data source directories are read only; test and holdout are not evaluated.

Outputs go under `outputs/server_session_01/`: external `status.json`, `config.json`, `summary.json`, bridge diagnostics, per-model histories, small checkpoints and development prediction files. `session_control_results.zip` contains metadata, results, pseudonymous development row/student identifiers, labels, and predictions, but not the checkpoints or test predictions. Share only in the intended research context. The status inside the ZIP is a packaging snapshot; the external status and launch log's SUCCESS line confirm the full write.

The old nine-model count experiment recorded 46 seconds from feature construction through training and analysis, excluding package verification, data loading, and final packaging on that server. This experiment has similarly sized training and additional grouped bootstrap; 2–10 minutes is a rough planning estimate, not an observed runtime, and server load may make it longer.
