#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_name="${1:-server_session_01}"
if [[ ! "$task_name" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid run name' >&2; exit 2; fi
task_base=/home/wangxiao/QCCDM/top_sci_repro
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_project="$task_base/uctp_cd_time_factorial_v1"
task_data="$task_base/uctp_cd_clean_research/data/assist_full"
task_out="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
mkdir -p "$task_root/outputs"
if [[ -e "$task_out" || -e "$task_log" ]]; then echo 'Output or launch log already exists; refusing overwrite.' >&2; exit 2; fi
( set -o noclobber; : > "$task_log" ) || exit 2
exec > >(tee -a "$task_log") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$task_root/src${PYTHONPATH:+:$PYTHONPATH}"
cd "$task_root"
printf 'Starting %s at %s\n' "$task_name" "$(date --iso-8601=seconds)"
echo 'Stage 1/3: release integrity and free disk'
"$task_python" -B -m session_control.server --verify-only
"$task_python" -B -c 'import shutil,sys; f=shutil.disk_usage(sys.argv[1]).free; print("Free bytes:",f,"Required:",1073741824,flush=True);sys.exit(f<1073741824)' "$task_root/outputs"
echo 'Stage 2/3: synthetic CPU contracts'
"$task_python" -B -m unittest discover -s tests -v
echo 'Stage 3/3: three-seed exploratory ASSIST development controls'
"$task_python" -B -m session_control.server --project-dir "$task_project" --data-dir "$task_data" --output-dir "$task_out"
printf 'SUCCESS: %s/session_control_results.zip\n' "$task_out"
