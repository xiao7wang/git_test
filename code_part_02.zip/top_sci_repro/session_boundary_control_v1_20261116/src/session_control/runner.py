"""Fit three matched exploratory controls and package auditable predictions."""
import csv
import gzip
import hashlib
import json
import time
import zipfile
from pathlib import Path

import numpy as np
from count_time.common import binary_losses, sha256_file, write_json
from count_time.references import validate_reference
from .analysis import MODES, analyze
from .features import build
from .train import fit


def write_events(path, f):
    with gzip.open(path, "wt", encoding="utf-8", newline="") as stream:
        w = csv.writer(stream)
        w.writerow(("record_idx", "student_idx", "label", "kc_idx", "prior_kc_count",
                    "same_kc_gap_hours", "previous_global_event_gap_hours", "starts_session",
                    "same_kc_session_crossings"))
        for i in np.flatnonzero(f["split"] == 1):
            def val(x):
                return "" if np.isnan(x) else format(float(x), ".17g")
            w.writerow((int(f["record_idx"][i]), int(f["student"][i]), int(f["label"][i]),
                        int(f["kc"][i]), int(f["prior_kc_count"][i]), val(f["gap_hours"][i]),
                        val(f["global_gap_hours"][i]), int(f["starts_session"][i]),
                        int(f["session_crossings"][i])))


def package(out):
    names = ["status.json", "config.json", "summary.json", "event_features.csv.gz", "bridge.json"]
    for mode in MODES:
        for seed in (0,1,2):
            base = f"jobs/{mode}_seed{seed}"
            names += [f"{base}/summary.json", f"{base}/history.json", f"{base}/dev_predictions.csv.gz"]
    files = {name:sha256_file(out / name) for name in names}
    manifest = json.dumps({"format": 1, "files": files}, indent=2).encode() + b"\n"
    pending, target = out / "session_control_results.zip.pending", out / "session_control_results.zip"
    if pending.exists() or target.exists():
        raise FileExistsError("result archive already exists")
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_STORED, allowZip64=True) as z:
        for name in names:
            z.write(out / name, arcname=name)
        z.writestr("manifest.json", manifest)
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or len(z.namelist()) != len(names) + 1:
            raise ValueError("result archive check failed")
        for name, expected in files.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f"result member hash mismatch: {name}")
    pending.replace(target)
    return {"path": str(target), "sha256": sha256_file(target), "members": len(names) + 1}


def run(arrays, users, output, *, reference=None, reference_sha=None, device="cpu", epochs=20,
        patience=5, batch_size=8192, repetitions=2000, expected_population=None, metadata=None):
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    status = {"status": "running", "phase": "features", "test_evaluated": False, "holdout_evaluated": False}
    write_json(out / "status.json", status)
    started = time.monotonic()
    try:
        f = build(arrays, users, threshold_hours=10., retention=.5)
        dev = np.flatnonzero(f["split"] == 1)
        observed = {"train": int((f["split"]==0).sum()), "development": len(dev),
                    "development_students": len(np.unique(f["student"][dev])),
                    "eligible": int((f["prior_kc_count"][dev]>=2).sum()),
                    "eligible_students": len(np.unique(f["student"][dev][f["prior_kc_count"][dev]>=2]))}
        if expected_population is not None and observed != expected_population:
            raise ValueError(f"population mismatch: {observed}")
        refs = {}
        if reference is not None:
            for seed in (0,1,2):
                refs[seed] = validate_reference(f, reference,
                    f"jobs/C_real_time_seed{seed}/dev_predictions.csv.gz", reference_sha)["probability"]
        config = {"protocol": "global_session_boundary_count_v1_exploratory",
                  "population": observed, "session_threshold_hours": 10., "boundary_rule": "> 10 hours",
                  "session_retention_per_boundary": .5, "time_half_life_hours": 168.,
                  "seeds": [0,1,2], "max_epochs": epochs, "patience": patience,
                  "batch_size": batch_size, "optimizer": "AdamW lr=.01 weight_decay=1e-5 clip=5",
                  "selection": "development event NLL per model and seed", "device": device,
                  "modes": {"S_session": "session counts only", "T_time": "continuous elapsed time counts only",
                            "ST_both": "session and elapsed time counts"},
                  "parameter_note": "ST has two additional effective KC coefficients; S and T have matched effective capacity",
                  "limitations": ["event timestamp proxy for exercise timing", "row-immediate feedback unverified",
                                  "threshold and retention are fixed candidates, not optimal or matched for decay intensity",
                                  "reused dev is exploratory", "test arrays loaded but test labels excluded from features and scoring"],
                  "test_evaluated": False, "holdout_evaluated": False, "metadata": metadata or {}}
        write_json(out / "config.json", config)
        write_events(out / "event_features.csv.gz", f)
        predictions = {mode:{} for mode in MODES}
        jobs, bridge = {}, {}
        for seed in (0,1,2):
            paired = {}
            # Fail before new controls if the corresponding old time model fails to reproduce.
            for mode in ("T_time", "S_session", "ST_both"):
                status.update(phase="training", mode=mode, seed=seed)
                write_json(out / "status.json", status)
                result = fit(f, mode, seed, out / "jobs" / f"{mode}_seed{seed}", device=device,
                             epochs=epochs, patience=patience, batch_size=batch_size)
                predictions[mode][seed] = result["probability"]
                jobs[f"{mode}_seed{seed}"] = result["summary"]
                paired[mode] = result
                if mode == "T_time" and refs:
                    old = refs[seed]
                    new = result["probability"]
                    delta = float(np.max(np.abs(old-new)))
                    nll_old = binary_losses(f["label"][dev], old)[0].mean()
                    nll_new = binary_losses(f["label"][dev], new)[0].mean()
                    bridge[str(seed)] = {"max_absolute_probability_difference": delta,
                                         "nll_difference": float(nll_new-nll_old),
                                         "probability_tolerance": 1e-5, "nll_tolerance": 1e-6}
                    write_json(out / "bridge.json", bridge)
                    if delta > 1e-5 or abs(nll_new-nll_old) > 1e-6:
                        raise ValueError(f"old continuous-time reference bridge failed for seed {seed}")
            if len({r["summary"]["initial_state_sha256"] for r in paired.values()}) != 1:
                raise AssertionError("model initialization mismatch within seed")
            common = min(len(r["history"]) for r in paired.values())
            for e in range(common):
                if len({r["history"][e]["train_order_sha256"] for r in paired.values()}) != 1:
                    raise AssertionError(f"train order mismatch for seed {seed}, epoch {e+1}")
        write_json(out / "bridge.json", bridge)
        status.update(phase="analysis", mode=None, seed=None)
        write_json(out / "status.json", status)
        result = {"status": "complete", "jobs": jobs, "bridge": bridge,
                  "analysis": analyze(f, predictions, repetitions=repetitions),
                  "seconds_before_packaging": time.monotonic()-started,
                  "test_evaluated": False, "holdout_evaluated": False}
        write_json(out / "summary.json", result)
        status.update(status="complete", phase="packaging_snapshot", seconds=time.monotonic()-started)
        write_json(out / "status.json", status)
        archive = package(out)
        status.update(phase="complete", archive=archive, seconds=time.monotonic()-started)
        write_json(out / "status.json", status)
        return {"status": "complete", "archive": archive}
    except BaseException as exc:
        status.update(status="failed", phase="failed", error=repr(exc), seconds=time.monotonic()-started)
        write_json(out / "status.json", status)
        raise
