"""Pinned server entry: ASSIST development only, no test or holdout scoring."""
import argparse
import json
import platform
import shutil
from pathlib import Path

import numpy as np
import torch
from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from .runner import run

ROOT = Path(__file__).resolve().parents[2]
REFERENCE_SHA = "eab986459c2bea65cd016393da9c85127e2ce7086243e93242eb9b9420509733"
POPULATION = {"train": 1847688, "development": 126854, "development_students": 10036,
              "eligible": 101427, "eligible_students": 9116}


def verify_release():
    manifest = ROOT / "release_manifest.json"
    entries = json.loads(manifest.read_text(encoding="utf-8"))["files"]
    required = {"run_server.sh", "README.md", "tests/test_session.py", "src/session_control/server.py",
                "src/session_control/features.py", "src/session_control/train.py", "src/session_control/runner.py",
                "src/session_control/analysis.py", "src/count_time/features.py", "src/count_time/training.py",
                "references/count_time_increment_results.zip"}
    if not required.issubset(entries) or entries["references/count_time_increment_results.zip"] != REFERENCE_SHA:
        raise ValueError("release manifest missing required files or old reference mismatch")
    for name, expected in entries.items():
        candidate = (ROOT / name).resolve()
        if not candidate.is_relative_to(ROOT) or not candidate.is_file() or sha256_file(candidate) != expected:
            raise ValueError(f"missing, unsafe or modified release file: {name}")
    return {"manifest_sha256": sha256_file(manifest), "file_count": len(entries)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--project-dir")
    parser.add_argument("--data-dir")
    parser.add_argument("--output-dir")
    args = parser.parse_args()
    release = verify_release()
    print(json.dumps({"phase": "release_verified", **release}), flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir, args.data_dir, args.output_dir)):
        parser.error("project, data, and output directories required")
    out, allowed = Path(args.output_dir).resolve(), (ROOT / "outputs").resolve()
    if not out.is_relative_to(allowed) or out == allowed or out.exists():
        raise ValueError("output must be a new child of this release's outputs directory")
    free = shutil.disk_usage(allowed).free
    if free < 1073741824:
        raise OSError(f"free disk space {free} bytes is below 1 GiB")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; no automatic fallback")
    reference = ROOT / "references" / "count_time_increment_results.zip"
    if sha256_file(reference) != REFERENCE_SHA:
        raise ValueError("reference archive changed")
    data = load_prepared(args.project_dir, args.data_dir)
    dev_users = development_users(data.arrays["student_idx"][data.arrays["split"] == 1])
    metadata = {"release": release, "dataset_manifest_sha256": DATA_FINGERPRINT,
                "project_source_sha256": SOURCE_HASHES, "old_reference_sha256": REFERENCE_SHA,
                "python": platform.python_version(), "numpy": np.__version__, "torch": str(torch.__version__),
                "gpu": torch.cuda.get_device_name(), "free_bytes": free}
    result = run(data.arrays, dev_users, out, reference=reference, reference_sha=REFERENCE_SHA, device="cuda",
                 expected_population=POPULATION, metadata=metadata)
    print(json.dumps(result, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
