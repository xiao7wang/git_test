"""Paired prediction comparisons on the repeatedly used development set."""
import numpy as np
from count_time.common import binary_losses, metrics
from count_time.analysis import _intervals

MODES = ("S_session", "T_time", "ST_both")
CONTRASTS = {"ST_minus_S": ("ST_both", "S_session"),
             "T_minus_S": ("T_time", "S_session"),
             "ST_minus_T": ("ST_both", "T_time")}


def group(y, students, predictions, mask, repetitions, seed):
    ids = np.flatnonzero(mask)
    if not len(ids):
        return {"events": 0, "students": 0, "models": {}, "paired": {}}
    labels, users = y[ids], students[ids]
    model_rows, losses = {}, {}
    for mode in MODES:
        rows = [metrics(labels, predictions[mode][s][ids], users) for s in (0,1,2)]
        losses[mode] = [binary_losses(labels, predictions[mode][s][ids])[0] for s in (0,1,2)]
        model_rows[mode] = {"per_seed": rows, "mean": {
            key: (None if any(r[key] is None for r in rows) else float(np.mean([r[key] for r in rows])))
            for key in ("nll", "student_macro_nll", "auc", "brier")}}
    means = {m: np.mean(np.stack(losses[m]), axis=0) for m in MODES}
    columns = np.stack([means[a] - means[b] for a,b in CONTRASTS.values()], axis=1)
    intervals = _intervals(users, columns, repetitions, seed)
    paired = {}
    for (name,(a,b)), value in zip(CONTRASTS.items(), intervals):
        value["per_seed_event_delta"] = [float(np.mean(losses[a][s] - losses[b][s])) for s in (0,1,2)]
        paired[name] = value
    return {"events": len(ids), "students": len(np.unique(users)), "models": model_rows, "paired": paired}


def analyze(f, predictions, repetitions=2000, seed=20261116):
    dev = np.flatnonzero(f["split"] == 1)
    if set(predictions) != set(MODES) or repetitions < 1:
        raise ValueError("invalid mode set or bootstrap count")
    for mode in MODES:
        if set(predictions[mode]) != {0,1,2}:
            raise ValueError("missing seed")
        for p in predictions[mode].values():
            if p.shape != (len(dev),) or not np.isfinite(p).all() or ((p<0)|(p>1)).any():
                raise ValueError("invalid prediction")
    y, users = f["label"][dev], f["student"][dev]
    prior, crossings = f["prior_kc_count"][dev], f["session_crossings"][dev]
    boundary = f["starts_session"][dev]
    groups = {"all_development": np.ones(len(dev), bool), "prior_kc_at_least_2": prior >= 2,
              "first_kc": prior == 0, "repeat_kc": prior > 0,
              "starts_session": boundary, "within_session": ~boundary,
              "repeat_no_session_crossing": (prior > 0) & (crossings == 0),
              "repeat_one_or_more_session_crossings": (prior > 0) & (crossings > 0)}
    return {"scope": "reused ASSIST development; all comparisons exploratory",
            "primary": "ST_minus_S event NLL on all_development, mean of 3 seeds",
            "interval": "student-cluster bootstrap, fixed trained models; not selection-adjusted",
            "bootstrap_repetitions": repetitions, "bootstrap_seed": seed,
            "groups": {k:group(y,users,predictions,v,repetitions,seed+i)
                       for i,(k,v) in enumerate(groups.items())}}
