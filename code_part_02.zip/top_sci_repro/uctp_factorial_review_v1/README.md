# 四组时间实验：第二阶段结果分析包

这是已完成 24 组验证实验的独立统计分析工具。仅需已有 `yydw` 环境的 NumPy、pandas 和 Python 标准库；不使用 GPU、不训练模型、不加载模型执行、不评测 test。

## 输入如何选取

所有输入均位于服务器原工程 `uctp_cd_time_factorial_v1/outputs/`：

- ASSIST 全部 12 组：`server_assist_full_factorial_e20_p5_01/`。
- EDNet none 三组、mean_only 三组、support_only seed0：`server_ednet_full_factorial_e20_p5_01/`。
- EDNet support_only seed1、seed2：`server_ednet_support_resume_20261020_01/`。
- EDNet joint 三组：`server_ednet_joint_resume_20261020_01/`。

不会并入旧目录中失败的 support_only seed1，也不会将旧 temporal_v1 的 joint 混入。本包不移动、不复制、不重命名已有实验目录。

每组需有 `run_config.json`、`status.json`、`history.json`、`validation_metrics.json`、`validation_predictions.csv`、`best_model.pt`。checkpoint 仅做 SHA256 校验，不加载。

先检查四组/三种子的训练预算、代码指纹、数据指纹、参数量、环境、选轮记录、数据行身份和验证指标。用 CSV 恢复原 FP32 概率后重算指标；任何不一致都会停止，并保存 `error.log`。不要通过修改容差或跳过核对解决错误。

## 统计口径

1. 输出三种子均值/样本标准差，保留每个种子的配对差。
2. 主要比较是总体 `support_only − none`。按学生整组配对 bootstrap 2000 次，所有模式/种子使用同一组学生抽样；提供 ΔNLL 和 ΔBrier 的百分位 95% 区间。
3. 同时报告事件等权（所有行平均）和学生等权（先对每个学生平均、再对学生平均），避免只看高频学生主导的结果。
4. 种子平均对比是**三个固定模型的损失差平均**，不是把三个概率平均得到一个集成模型；也不是将同一学生的三个种子预测视作三个独立学生。
5. 提供掌握主效应、支持量主效应与 `joint−mean_only−support_only+none` 交互项。所有差值保留原指标方向：ΔAUC 越正越好，ΔNLL/ΔBrier 越负越好。
6. AUC 输出点估计及种子间描述性差异，本包不计算 AUC bootstrap 区间。
7. 长间隔/历史 KC 子组属于探索性结果，未做多重比较校正。元数据对多 KC 题使用平均 gap/count，这些不是精确下一次同 KC 的锚点窗口。
8. 区间条件于当前验证集和已经按 validation AUC 选好的 checkpoint，不包含重新训练、选轮或反复研究决策的误差。它们不能替代冻结设计后的独立测试。

## 简化服务器步骤

将 `uctp_factorial_review_v1.zip` 上传到服务器 `/home/wangxiao/QCCDM/top_sci_repro/`。

只复制代码框里面的命令，不复制代码框的三个反引号或终端提示符。

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
if [ -e uctp_factorial_review_v1 ]; then
  echo '目录已存在，请保留；直接查看该目录或使用已解压版本'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_factorial_review_v1.zip &&
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_factorial_review_v1.zip .
fi
```

创建或进入同一 tmux 会话：

```bash
tmux new-session -A -s factorial_review
```

在 tmux 内执行一次：

```bash
cd /home/wangxiao/QCCDM/top_sci_repro/uctp_factorial_review_v1
bash run_server.sh server_review_01
```

可通过 `Ctrl+b`、松开、再按 `d` 离开会话。不要按 `Ctrl+c` 复制正在运行终端的文字。

该操作只读预测文件及 checkpoint 校验，不会再跑多天训练。实际耗时取决于磁盘读取和 CPU；逐组 `AUDIT_PASS`、逐子组 `BOOTSTRAP` 会显示进展。脚本正常结束会打印 `REVIEW_COMPLETE` 和结果压缩包路径。

查看状态：

```bash
cat /home/wangxiao/QCCDM/top_sci_repro/uctp_factorial_review_v1/outputs/server_review_01/status.json
```

若 `status=complete`，下载并发回：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_factorial_review_v1/outputs/server_review_01/factorial_review_results.zip`

ZIP 含报告、统计结果、输入校验和，不含模型权重和逐条学生预测。若失败，查看同目录 `error.log`；失败前生成的单数据集 JSON 只是部分输出，不能当完整验收。

## 之后的研究决策

先核对 ASSIST/EDNet 的整体区间、学生等权结果和间隔子组，再确定是否继续“无时间、只改写入尺度”的小规模对照。当前工具不新增该训练实验。即使 support_only 的条件区间都在零以下，也仍需排除写入尺度解释、处理同时间反馈边界问题，并冻结方案后评测 test。
