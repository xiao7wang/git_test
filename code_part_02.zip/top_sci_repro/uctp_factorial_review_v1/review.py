"""Read-only analysis of the 24 completed validation runs, including EDNet reruns."""
import argparse
import hashlib
import json
import math
import platform
import sys
import time
import traceback
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
from review_stats import MODES, SEEDS, analyze_group, groups, metrics

PACKAGE = Path(__file__).resolve().parent
ROOTS = {
    "assist": "server_assist_full_factorial_e20_p5_01",
    "ednet": "server_ednet_full_factorial_e20_p5_01",
    "support_resume": "server_ednet_support_resume_20261020_01",
    "joint_resume": "server_ednet_joint_resume_20261020_01",
}
IDENTITY = ("record_idx", "student_idx", "item_idx", "label", "source_row", "split", "timestamp",
            "response_time", "rt_valid", "delta_t_hours", "delta_t_k_hours", "kc_count_before", "student_count_before")
METRIC_ATOL = 1e-9


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def selected_runs(project, dataset):
    rows = []
    for mode in MODES:
        for seed in SEEDS:
            root = ROOTS[dataset]
            if dataset == "ednet" and mode == "support_only" and seed in (1, 2):
                root = ROOTS["support_resume"]
            if dataset == "ednet" and mode == "joint":
                root = ROOTS["joint_resume"]
            name = f"unit_write_{mode}_seed{seed}"
            rows.append((mode, seed, project / "outputs" / root / name))
    return rows


def signature(config):
    args = config["args"]
    keys = ("variant", "epochs", "patience", "batch_size", "chunk_size", "eval_chunk_size", "ncd_hidden_dim",
            "lr", "weight_decay", "eval_update_targets", "threads", "device", "ack_row_feedback")
    source = config["source_code"]
    required_source = ("train.py", "src/model.py", "src/temporal_model.py", "src/factorial_time_model.py",
                       "src/data.py", "src/engine.py", "src/metrics.py", "src/common.py")
    require(all(key in source for key in required_source), "Missing core source hashes")
    return {"training": {key: args[key] for key in keys}, "data_fingerprint": config["data_fingerprint"],
            "parameters": config["parameters"], "selection": config["selection"],
            "model_base": {k: v for k, v in config["model_config"].items() if k not in ("time_mode", "decay_rate_per_hour")},
            "source": {k: v for k, v in source.items() if k.startswith("src/") or k == "train.py"},
            "environment": config["environment"], "temporal_protocol": config["temporal_protocol"],
            "feedback_protocol": config["protocol"]}


def check_run(folder, dataset, mode, seed):
    config, status = read_json(folder / "run_config.json"), read_json(folder / "status.json")
    args = config["args"]
    require(status.get("status") == "complete", f"Incomplete run: {folder}")
    require(config.get("model_family") == "time_factorial_v1", f"Wrong model family: {folder}")
    require(args["variant"] == "unit_write" and args["time_mode"] == mode and args["seed"] == seed,
            f"Wrong variant/mode/seed: {folder}")
    require(args.get("evaluate_test") is False and status.get("test_evaluated") is False,
            f"Validation-only flags missing or false policy: {folder}")
    require(config.get("test_policy") == "not evaluated", f"Unexpected test policy: {folder}")
    # Do not open test files; their presence is enough to reject a contaminated run.
    require(not any((folder / f).exists() for f in ("test_metrics.json", "test_predictions.csv")),
            f"Test artifacts present in this development run: {folder}")
    manifest = config["data_manifest"]
    require(manifest["dataset"] == dataset and manifest.get("max_students") is None, f"Wrong/full data mismatch: {folder}")
    require(args["epochs"] == 20 and args["patience"] == 5 and args["eval_update_targets"] == 1,
            f"Wrong frozen budget/update protocol: {folder}")
    rate = 0.0 if mode == "none" else math.log(2)/168.0
    require(math.isclose(float(args["decay_rate_per_hour"]), rate, rel_tol=1e-12, abs_tol=1e-15),
            f"Unexpected fixed decay rate: {folder}")
    require(config["model_config"]["time_mode"] == mode and config["model_config"]["decay_rate_per_hour"] == args["decay_rate_per_hour"],
            f"Model/args mismatch: {folder}")
    if mode != "none":
        require(args.get("ack_time_proxy") is True, f"Time proxy not acknowledged: {folder}")
    expected_ckpt = status.get("checkpoint_sha256")
    require(isinstance(expected_ckpt, str) and len(expected_ckpt) == 64, f"Missing checkpoint hash: {folder}")
    require(sha256(folder / "best_model.pt") == expected_ckpt, f"Checkpoint hash mismatch: {folder}")
    history = read_json(folder / "history.json")
    require(1 <= len(history) <= args["epochs"], f"Invalid history length: {folder}")
    require([x["epoch"] for x in history] == list(range(1, len(history)+1)), f"Incomplete epoch history: {folder}")
    scores = [x["valid"]["auc"] if x["valid"]["auc"] is not None else -x["valid"]["nll"] for x in history]
    require(np.isfinite(scores).all(), f"Nonfinite selection score: {folder}")
    best = int(np.argmax(scores)) + 1
    require(status.get("best_epoch") == best, f"Best epoch disagrees with validation selection: {folder}")
    saved_metrics = read_json(folder / "validation_metrics.json")
    require(saved_metrics.get("update_targets") is True, f"Validation target updates disabled: {folder}")
    for k in ("auc", "nll", "brier"):
        a, b = saved_metrics[k], history[best-1]["valid"][k]
        require((a is None and b is None) or (a is not None and b is not None and np.isfinite(a)
                and np.isfinite(b) and abs(a-b) <= 1e-6), f"Final/best-history metric mismatch {k}: {folder}")
    return config, status, saved_metrics, len(history)


def read_predictions(folder, expected_n):
    frame = pd.read_csv(folder / "validation_predictions.csv", float_precision="round_trip")
    require(set(IDENTITY + ("probability", "uncertainty", "evidence")) <= set(frame.columns), f"Missing columns: {folder}")
    require(len(frame) == expected_n and len(frame) > 0, f"Wrong validation record count: {folder}")
    require(not frame.record_idx.duplicated().any(), f"Duplicate record ids: {folder}")
    frame = frame.sort_values("record_idx", kind="stable").reset_index(drop=True)
    for key in ("record_idx", "student_idx", "item_idx", "source_row", "student_count_before"):
        x = frame[key].to_numpy(float)
        require(np.isfinite(x).all() and (x >= 0).all() and (x == np.floor(x)).all(), f"Invalid ids/counts {key}: {folder}")
    require((frame.split == 1).all() and frame.label.isin([0, 1]).all(), f"Non-validation rows/labels: {folder}")
    for key in ("timestamp", "delta_t_hours", "delta_t_k_hours", "kc_count_before", "probability", "uncertainty", "evidence"):
        require(np.isfinite(frame[key].to_numpy(float)).all(), f"Nonfinite {key}: {folder}")
    require((frame[["delta_t_hours", "delta_t_k_hours", "kc_count_before"]].to_numpy() >= 0).all(), f"Negative gaps/counts: {folder}")
    require(frame.rt_valid.isin([True, False]).all(), f"Invalid RT availability: {folder}")
    require(frame.probability.between(0, 1).all(), f"Raw probability outside [0,1]: {folder}")
    # Restore exported native FP32 values before metric computation. Never adjust a tolerance to pass.
    p = frame.probability.to_numpy().astype(np.float32).astype(np.float64)
    computed = metrics(frame.label.to_numpy(), p)
    return frame, p, computed


def check_identity(reference, current):
    require(len(reference) == len(current), "Different validation event counts")
    for key in IDENTITY:
        a, b = reference[key].to_numpy(), current[key].to_numpy()
        equal = (a == b) | (pd.isna(a) & pd.isna(b))
        require(bool(equal.all()), f"Mismatched validation event identity/metadata: {key}")


def audit_dataset(project, dataset):
    shared, reference, expected_n = None, None, None
    pred, audits, configs = {}, [], []
    for mode, seed, folder in selected_runs(project, dataset):
        config, status, saved, epochs = check_run(folder, dataset, mode, seed)
        sig = signature(config)
        if shared is None:
            shared = sig
            expected_n = int(config["data_manifest"]["summary"]["split_rows"]["valid"])
        require(shared == sig, f"Mixed data/source/environment/training protocol within {dataset}: {folder}")
        frame, p, computed = read_predictions(folder, expected_n)
        require(saved["n"] == expected_n, f"Metric count mismatch: {folder}")
        for key in ("auc", "nll", "brier"):
            a, b = computed[key], saved[key]
            require((a is None and b is None) or (a is not None and b is not None and abs(a-b) <= METRIC_ATOL),
                    f"CSV/metrics mismatch for {key}: {folder}; recomputed={a}, saved={b}")
        if reference is None:
            reference = frame[list(IDENTITY)].copy()
        else:
            check_identity(reference, frame)
        pred[(seed, mode)] = p
        record = {"dataset": dataset, "mode": mode, "seed": seed, "path": str(folder),
                  "epochs": epochs, "best_epoch": status["best_epoch"], "metrics": computed,
                  "checkpoint_sha256": status["checkpoint_sha256"],
                  "input_hashes": {name: sha256(folder / name) for name in ("status.json", "run_config.json", "history.json",
                                      "validation_metrics.json", "validation_predictions.csv")}}
        audits.append(record)
        configs.append(config)
        print(f"AUDIT_PASS {dataset}/{folder.name}: n={expected_n}; best_epoch={status['best_epoch']}", flush=True)
    stacked = np.stack([np.stack([pred[(s, mode)] for mode in MODES]) for s in SEEDS])
    return reference, stacked, {"passed": True, "shared_protocol": shared, "runs": audits}, configs


def compare_across_datasets(a, b):
    # Item/user counts and fingerprints differ by dataset; computation and training settings must not.
    for key in ("training", "source", "environment", "temporal_protocol", "selection", "feedback_protocol"):
        require(a[key] == b[key], f"Cross-dataset protocol/source mismatch: {key}")


def fmt(x):
    return "NA" if x is None else f"{x:+.6f}"


def report_markdown(report):
    lines = ["# 四组时间实验：验证集结果审查", "", "本报告读取已完成预测，不重新训练，也不评测测试集。",
             "三个种子作为固定训练模型；置信区间按学生整组配对重采样，条件于本次验证集及已选 checkpoint。",
             "它不包含重新训练、重新选 checkpoint 的不确定性；验证集已被多次用于探索，不能替代独立测试。", "",
             "## 完整性核对", "", "24 个有效 run 的完成状态、验证选轮、checkpoint 校验和、配置/代码/数据指纹、预测记录及指标均通过核对。",
             "EDNet 使用原目录中的 7 组完成结果，以及 support 补跑 2 组、joint 补跑 3 组。旧中断结果没有并入。", "",
             "## 三种子均值", "", "| 数据集 | 模式 | AUC 均值 | AUC 种子样本标准差 | NLL 均值 | Brier 均值 |",
             "|---|---|---:|---:|---:|---:|"]
    interval_notes = []
    for ds, data in report["datasets"].items():
        g = data["groups"]["all"]
        for mode in MODES:
            m = g["mode_summary"][mode]
            lines.append(f"| {ds} | {mode} | {m['auc']['mean']:.6f} | {m['auc']['sample_sd']:.6f} | {m['nll']['mean']:.6f} | {m['brier']['mean']:.6f} |")
    lines += ["", "## 主要比较：support_only − none", "", "负的 ΔNLL/ΔBrier 表示 support_only 更好；正的 ΔAUC 表示更好。",
              "AUC 仅报告点估计，不提供 AUC 置信区间。区间是条件性、未做多重比较校正的百分位区间，不报告确认性显著结论。",
              "", "| 数据集 | 学生数 | ΔAUC | ΔNLL | 学生聚类 95% 区间 | 学生等权 ΔNLL | 学生等权区间 |", "|---|---:|---:|---:|---|---:|---|"]
    for ds, data in report["datasets"].items():
        g = data["groups"]["all"]
        v = g["paired"]["seed_mean/support_only_minus_none/nll"]
        ci = lambda x: "NA" if x is None else f"[{x[0]:+.6f}, {x[1]:+.6f}]"
        lines.append(f"| {ds} | {g['students']} | {fmt(g['auc_contrasts_descriptive_only']['support_only_minus_none']['mean'])} | {fmt(v['delta'])} | {ci(v['ci95'])} | {fmt(v['student_macro_delta'])} | {ci(v['student_macro_ci95'])} |")
        interval = v["ci95"]
        if interval and interval[1] < 0:
            wording = "在本次条件性学生重采样中，整体 ΔNLL 区间位于零以下。"
        elif interval and interval[0] > 0:
            wording = "在本次条件性学生重采样中，整体 ΔNLL 区间位于零以上。"
        else:
            wording = "整体 ΔNLL 区间包含零，当前抽样不确定性不能排除无改善。"
        interval_notes.append(f"{ds}：{wording}")
    lines += [""] + interval_notes
    lines += ["", "## 分组诊断", "", "| 数据集 | 分组 | 记录数 | 学生数 | support−none ΔNLL | 条件性 95% 区间 |", "|---|---|---:|---:|---:|---|"]
    for ds, data in report["datasets"].items():
        for name, g in data["groups"].items():
            if name == "all" or not g["n"]:
                continue
            v = g["paired"]["seed_mean/support_only_minus_none/nll"]
            lines.append(f"| {ds} | {name} | {g['n']} | {g['students']} | {fmt(v['delta'])} | {ci(v['ci95'])} |")
    lines += ["", "分组以已导出的历史元数据为准。多 KC 题的 gap 和 count 是均值；repeated_kc_proxy 表示至少有 KC 历史，不能解释为所有 KC 均重复。",
              "这些组不是精确的锚点后下一次同 KC 窗口；gap=0 也不是完整同时间反馈组敏感性实验。分组区间均属探索性。", "",
              "## 2×2 对比", "", "主效应是跨另一个因子的平均差；interaction = joint − mean_only − support_only + none。",
              "所有差值保持原指标方向：NLL/Brier 越负越好。正的 AUC 交互不意味着 joint 优于 none。",
              "", "| 数据集 | 对比 | ΔAUC | ΔNLL | ΔNLL 条件性区间 |", "|---|---|---:|---:|---|"]
    for ds, data in report["datasets"].items():
        g = data["groups"]["all"]
        for name in ("mean_only_minus_none", "joint_minus_none", "support_main", "mean_main", "interaction"):
            v = g["paired"][f"seed_mean/{name}/nll"]
            lines.append(f"| {ds} | {name} | {fmt(g['auc_contrasts_descriptive_only'][name]['mean'])} | {fmt(v['delta'])} | {ci(v['ci95'])} |")
    lines += ["", "## 研究边界与下一步", "", "- 当前 m 向零衰减、S 向 2 衰减，半衰期固定 168 小时；结论只针对该实现。S 是内部伪计数，并非经过校准的心理学信任或模型置信度。",
              "- support_only 改善仍可能由新旧证据的相对写入尺度解释；本分析不能消除该混淆，也不能替代无时间写入尺度对照。",
              "- 当前 row-immediate feedback 和事件时间代理假设保留；EDNet 同时间组的反馈边界仍需敏感性检查。",
              "- 先审查学生等权/事件等权与长间隔结果，再设计小规模、同预算的写入尺度对照；冻结方案后独立测试。",
              "", "全部种子、Brier 区间、完整分组和文件校验信息见 review.json。"]
    return "\n".join(lines) + "\n"


def run_review(project, out, reps=2000, bootstrap_seed=20261022):
    project, out = Path(project).resolve(), Path(out).resolve()
    require(project.is_dir(), f"Project does not exist: {project}")
    for root in ROOTS.values():
        inputs = (project / "outputs" / root).resolve()
        require(not out.is_relative_to(inputs), "Analysis output must not be inside existing experiment results")
    out.mkdir(parents=True, exist_ok=False)
    start = time.time()
    write_json(out / "status.json", {"status": "running", "started_unix": start})
    try:
        report = {"scope": "validation_only_read_only", "bootstrap_repetitions": reps,
                  "bootstrap_seed": bootstrap_seed, "bootstrap_unit": "student; same paired draws for all seeds/modes",
                  "inference_scope": "conditional on validation cohort and already selected fixed checkpoints; no multiplicity correction",
                  "auc_uncertainty": "not estimated; AUC contrasts descriptive only",
                  "loss_direction": "raw delta: negative NLL/Brier is better", "datasets": {},
                  "analysis_environment": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__},
                  "analysis_source": {p.name: sha256(p) for p in PACKAGE.glob("*.py")}}
        shared = None
        for di, dataset in enumerate(("assist", "ednet")):
            frame, predictions, audit, configs = audit_dataset(project, dataset)
            if shared is not None:
                compare_across_datasets(shared, audit["shared_protocol"])
            shared = audit["shared_protocol"]
            group_results = {}
            # Input configs provide the embedded data manifest; no raw dataset or test records are read.
            for gi, (name, mask) in enumerate(groups(frame).items()):
                print(f"BOOTSTRAP {dataset}/{name}: events={int(mask.sum())}; reps={reps}", flush=True)
                group_results[name] = analyze_group(frame, predictions, mask, reps, bootstrap_seed + 100*di + gi)
            report["datasets"][dataset] = {"audit": audit, "groups": group_results,
                                            "data_manifest": configs[0]["data_manifest"]}
            # Preserve inspectable partial analysis if a later dataset fails; no accepted ZIP on failure.
            write_json(out / f"{dataset}_review.json", report["datasets"][dataset])
        write_json(out / "review.json", report)
        (out / "REPORT.md").write_text(report_markdown(report), encoding="utf-8")
        status = {"status": "complete", "valid_runs": 24, "seconds": time.time()-start,
                  "test_evaluated": False, "trained": False, "inputs_modified": False}
        write_json(out / "status.json", status)
        files = [out / name for name in ("review.json", "REPORT.md", "status.json", "assist_review.json", "ednet_review.json")]
        write_json(out / "result_manifest.json", {p.name: sha256(p) for p in files})
        with zipfile.ZipFile(out / "factorial_review_results.zip", "x", zipfile.ZIP_DEFLATED) as z:
            for p in files + [out / "result_manifest.json"]:
                z.write(p, p.name)
        print("REVIEW_COMPLETE: 24/24 audited; validation-only analysis", flush=True)
        for dataset, data in report["datasets"].items():
            v = data["groups"]["all"]["paired"]["seed_mean/support_only_minus_none/nll"]
            print(f"{dataset}: support-none delta NLL={v['delta']:+.6f}; student cluster CI95={v['ci95']}", flush=True)
        print(f"Upload: {out / 'factorial_review_results.zip'}", flush=True)
        return report
    except BaseException as exc:
        write_json(out / "status.json", {"status": "failed", "error": repr(exc), "seconds": time.time()-start})
        (out / "error.log").write_text(traceback.format_exc(), encoding="utf-8")
        raise


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--bootstrap-repetitions", type=int, default=2000)
    p.add_argument("--bootstrap-seed", type=int, default=20261022)
    a = p.parse_args()
    if a.bootstrap_repetitions < 200:
        p.error("At least 200 bootstrap repetitions required; official wrapper uses 2000")
    out = Path(a.output_dir).resolve()
    if not out.is_relative_to(PACKAGE / "outputs") or out == PACKAGE / "outputs":
        p.error("Output must be a new named directory inside this analysis package's outputs/")
    run_review(a.project_dir, out, a.bootstrap_repetitions, a.bootstrap_seed)


if __name__ == "__main__":
    main()
