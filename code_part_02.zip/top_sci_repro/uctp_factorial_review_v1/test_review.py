"""Synthetic validation tests; no real experiments, checkpoints or datasets are altered."""
import contextlib
import io
import json
import math
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import review
from review_stats import MODES, SEEDS, analyze_group, cluster_intervals, losses, metrics


def fixture(project):
    n = 24
    y = np.tile([0, 1, 1, 0], 6)
    frame = pd.DataFrame({
        "record_idx": np.arange(n), "student_idx": np.repeat(np.arange(6), 4),
        "item_idx": np.arange(n) % 3, "label": y.astype(np.float32), "source_row": np.arange(n),
        "split": np.ones(n, dtype=int), "timestamp": 1_700_000_000 + np.arange(n)*100.,
        "response_time": np.full(n, np.nan), "rt_valid": False,
        "delta_t_hours": np.full(n, 1.), "delta_t_k_hours": np.tile([0, 1, 48, 200.], 6),
        "kc_count_before": np.tile([0, 1, 2, 3.], 6), "student_count_before": np.arange(n),
        "uncertainty": np.full(n, .5, dtype=np.float32), "evidence": np.full(n, 2., dtype=np.float32),
    })
    source = {k: "a"*64 for k in ("train.py", "src/model.py", "src/temporal_model.py", "src/factorial_time_model.py",
                                  "src/data.py", "src/engine.py", "src/metrics.py", "src/common.py")}
    for ds in ("assist", "ednet"):
        for mode, seed, folder in review.selected_runs(project, ds):
            folder.mkdir(parents=True)
            # Identical native FP32 probabilities, with a deliberate mode effect.
            p = np.clip(.3 + .4*y + seed*.005 + {"none": 0, "mean_only": -.03,
                         "support_only": .01, "joint": -.01}[mode]*(2*y-1), 0, 1).astype(np.float32)
            current = frame.copy()
            current["probability"] = p
            current.to_csv(folder / "validation_predictions.csv", index=False)
            m = {**metrics(y, p.astype(float)), "update_targets": True}
            rate = 0 if mode == "none" else math.log(2)/168
            config = {
                "model_family": "time_factorial_v1", "test_policy": "not evaluated", "parameters": 100,
                "selection": "validation AUC; negative NLL if validation has only one label class",
                "data_fingerprint": ds + "fingerprint", "data_manifest": {"dataset": ds, "max_students": None,
                    "summary": {"split_rows": {"train": 50, "valid": n, "test": 10}}},
                "source_code": source, "environment": {"python": "3.11.15", "torch": "2.11.0+cu128"},
                "protocol": "row-immediate", "temporal_protocol": {"mean_decay_target": 0, "support_floor": 2},
                "model_config": {"num_students": 6, "variant": "unit_write", "time_mode": mode, "decay_rate_per_hour": rate},
                "args": {"variant": "unit_write", "time_mode": mode, "seed": seed, "evaluate_test": False,
                         "epochs": 20, "patience": 5, "batch_size": 8, "chunk_size": 50, "eval_chunk_size": 100,
                         "ncd_hidden_dim": 128, "lr": .001, "weight_decay": .00001, "eval_update_targets": 1,
                         "threads": 4, "device": "cuda", "ack_row_feedback": True,
                         "ack_time_proxy": mode != "none", "decay_rate_per_hour": rate},
            }
            (folder / "best_model.pt").write_bytes(b"synthetic checkpoint hash fixture; not a torch model")
            review.write_json(folder / "run_config.json", config)
            review.write_json(folder / "status.json", {"status": "complete", "best_epoch": 1, "test_evaluated": False,
                             "checkpoint_sha256": review.sha256(folder / "best_model.pt")})
            review.write_json(folder / "validation_metrics.json", m)
            review.write_json(folder / "history.json", [{"epoch": i, "valid": m} for i in (1, 2)])


class StatisticsTests(unittest.TestCase):
    def test_auc_ties_and_known_losses(self):
        m = metrics(np.array([0, 1, 0, 1]), np.array([.5]*4))
        self.assertEqual(m["auc"], .5)
        self.assertAlmostEqual(m["nll"], math.log(2))
        self.assertEqual(m["brier"], .25)

    def test_invalid_predictions_rejected(self):
        for p in ([np.nan, .5], [1.01, .5], [-.01, .5]):
            with self.assertRaises(ValueError):
                losses([0, 1], p)

    def test_zero_difference_is_exact_zero(self):
        r = cluster_intervals([0, 0, 1, 2], np.zeros((4, 2)), 50)
        self.assertEqual(r["comparisons"][0]["ci95"], [0., 0.])

    def test_whole_students_and_distinct_estimands(self):
        # Event delta = (3*1-1)/4=.5; equal-student delta=(1-1)/2=0.
        r = cluster_intervals([0, 0, 0, 1], np.array([[1], [1], [1], [-1.]]), 2000)
        v = r["comparisons"][0]
        self.assertEqual(v["delta"], .5)
        self.assertEqual(v["student_macro_delta"], 0)
        self.assertEqual(v["ci95"], [-1., 1.])
        self.assertEqual(v["student_macro_ci95"], [-1., 1.])

    def test_resampling_reproducible(self):
        x = np.arange(8).reshape(4, 2)/10
        self.assertEqual(cluster_intervals([1, 1, 2, 3], x, 123, 42), cluster_intervals([1, 1, 2, 3], x, 123, 42))

    def test_one_student_no_misleading_interval(self):
        r = cluster_intervals([0, 0], np.ones((2, 1)), 20)
        self.assertIsNone(r["comparisons"][0]["ci95"])

    def test_average_losses_not_ensemble_probabilities(self):
        f = pd.DataFrame({"student_idx": [0, 1], "label": [1, 1]})
        p = np.full((3, 4, 2), .5)
        p[:, 2, :] = np.array([.1, .5, .9])[:, None]
        r = analyze_group(f, p, np.array([True, True]), 20, 42)
        wanted = float(np.mean(-np.log([.1, .5, .9])) + np.log(.5))
        self.assertAlmostEqual(r["paired"]["seed_mean/support_only_minus_none/nll"]["delta"], wanted)
        self.assertGreater(wanted, 0)  # Averaging p first would incorrectly give zero.


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.project = self.base / "project"
        fixture(self.project)
        self.folder = review.selected_runs(self.project, "assist")[0][2]

    def tearDown(self):
        self.temp.cleanup()

    def change(self, filename, transform, folder=None):
        path = (folder or self.folder) / filename
        obj = review.read_json(path)
        transform(obj)
        review.write_json(path, obj)

    def check(self):
        return review.check_run(self.folder, "assist", "none", 0)

    def test_completed_reruns_selected_and_old_failure_excluded(self):
        chosen = review.selected_runs(self.project, "ednet")
        names = {m+str(s): p.parent.name for m, s, p in chosen}
        self.assertEqual(names["support_only0"], review.ROOTS["ednet"])
        self.assertEqual(names["support_only1"], review.ROOTS["support_resume"])
        self.assertEqual(names["joint2"], review.ROOTS["joint_resume"])
        old = self.project / "outputs" / review.ROOTS["ednet"] / "unit_write_support_only_seed1"
        old.mkdir()
        review.write_json(old / "status.json", {"status": "failed"})
        with contextlib.redirect_stdout(io.StringIO()):
            _, _, audit, _ = review.audit_dataset(self.project, "ednet")
        self.assertEqual(len(audit["runs"]), 12)

    def test_csv_restores_native_float32_metric_space(self):
        with contextlib.redirect_stdout(io.StringIO()):
            _, _, audit, _ = review.audit_dataset(self.project, "assist")
        self.assertTrue(audit["passed"])

    def test_checkpoint_corruption_rejected(self):
        with (self.folder / "best_model.pt").open("ab") as f:
            f.write(b"bad")
        with self.assertRaisesRegex(ValueError, "Checkpoint hash"):
            self.check()

    def test_test_evaluation_rejected(self):
        self.change("status.json", lambda s: s.update(test_evaluated=True))
        with self.assertRaisesRegex(ValueError, "Validation-only"):
            self.check()

    def test_test_artifact_rejected_without_reading_it(self):
        (self.folder / "test_metrics.json").write_text("invalid JSON, must not be parsed", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Test artifacts"):
            self.check()

    def test_wrong_time_rate_rejected(self):
        self.change("run_config.json", lambda c: c["args"].update(decay_rate_per_hour=.1))
        with self.assertRaisesRegex(ValueError, "decay rate"):
            self.check()

    def test_wrong_best_epoch_rejected(self):
        self.change("status.json", lambda s: s.update(best_epoch=2))
        with self.assertRaisesRegex(ValueError, "Best epoch"):
            self.check()

    def test_failed_status_rejected(self):
        self.change("status.json", lambda s: s.update(status="failed"))
        with self.assertRaisesRegex(ValueError, "Incomplete run"):
            self.check()

    def test_mixed_source_rejected(self):
        other = review.selected_runs(self.project, "assist")[1][2]
        self.change("run_config.json", lambda c: c["source_code"].update({"src/model.py": "b"*64}), other)
        with contextlib.redirect_stdout(io.StringIO()), self.assertRaisesRegex(ValueError, "Mixed data/source"):
            review.audit_dataset(self.project, "assist")

    def test_metric_corruption_rejected(self):
        self.change("validation_metrics.json", lambda c: c.update(nll=c["nll"]+.02))
        with self.assertRaisesRegex(ValueError, "metric mismatch"):
            self.check()

    def test_duplicate_record_rejected(self):
        path = self.folder / "validation_predictions.csv"
        f = pd.read_csv(path)
        f.loc[1, "record_idx"] = f.loc[0, "record_idx"]
        f.to_csv(path, index=False)
        with self.assertRaisesRegex(ValueError, "Duplicate record"):
            review.read_predictions(self.folder, len(f))

    def test_out_of_range_probability_not_hidden_by_float32_rounding(self):
        path = self.folder / "validation_predictions.csv"
        f = pd.read_csv(path)
        f.loc[0, "probability"] = 1.000000001
        f.to_csv(path, index=False)
        with self.assertRaisesRegex(ValueError, "Raw probability outside"):
            review.read_predictions(self.folder, len(f))

    def test_labels_and_metadata_alignment_rejected(self):
        f, _, _ = review.read_predictions(self.folder, 24)
        other = f.copy()
        other.loc[0, "label"] = 1 - other.loc[0, "label"]
        with self.assertRaisesRegex(ValueError, "identity/metadata: label"):
            review.check_identity(f, other)

    def test_full_workflow_preserves_inputs_and_makes_small_archive(self):
        before = {p: review.sha256(p) for p in self.project.rglob("*") if p.is_file()}
        out = self.base / "review"
        with contextlib.redirect_stdout(io.StringIO()):
            result = review.run_review(self.project, out, reps=20)
        self.assertEqual(review.read_json(out / "status.json")["status"], "complete")
        self.assertEqual(before, {p: review.sha256(p) for p in before})
        self.assertEqual(len(result["datasets"]), 2)
        with zipfile.ZipFile(out / "factorial_review_results.zip") as z:
            self.assertIsNone(z.testzip())
            self.assertEqual(len(z.namelist()), 6)
            self.assertTrue(all(not name.endswith((".pt", ".csv")) for name in z.namelist()))
        with self.assertRaises(FileExistsError):
            review.run_review(self.project, out, reps=20)

    def test_failure_saved_and_no_results_archive(self):
        self.change("status.json", lambda s: s.update(status="running"))
        out = self.base / "failed_review"
        with self.assertRaises(ValueError):
            review.run_review(self.project, out, reps=20)
        self.assertEqual(review.read_json(out / "status.json")["status"], "failed")
        self.assertFalse((out / "factorial_review_results.zip").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
