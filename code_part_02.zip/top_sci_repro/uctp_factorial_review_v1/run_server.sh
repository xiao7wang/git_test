#!/usr/bin/env bash
set -euo pipefail
TASK_PYTHON=/home/wangxiao/miniconda3/envs/yydw/bin/python
TASK_PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_PROJECT_DIR=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
TASK_RUN_NAME="${1:-server_review_01}"
if [[ ! "$TASK_RUN_NAME" =~ ^[A-Za-z0-9_]+$ ]]; then
    printf '%s\n' 'Run name must use only letters, digits and underscores.'
    exit 2
fi
if [[ -e "$TASK_PACKAGE_DIR/outputs/$TASK_RUN_NAME" ]]; then
    printf '%s\n' 'Output exists. Inspect it; a new run name is required for an intentional rerun.'
    exit 2
fi
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export MKL_NUM_THREADS=1
"$TASK_PYTHON" -B -m unittest discover -s "$TASK_PACKAGE_DIR" -p test_review.py -v
exec "$TASK_PYTHON" -B -u "$TASK_PACKAGE_DIR/review.py" \
    --project-dir "$TASK_PROJECT_DIR" \
    --output-dir "$TASK_PACKAGE_DIR/outputs/$TASK_RUN_NAME" \
    --bootstrap-repetitions 2000 \
    --bootstrap-seed 20261022
