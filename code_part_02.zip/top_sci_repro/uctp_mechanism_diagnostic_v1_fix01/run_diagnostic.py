"""Independent read-only checkpoint diagnostic. No optimizer; no test view."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def emit(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def import_project(project):
    project = Path(project).resolve()
    pinned = read_json(ROOT / "expected_project_sources.json")
    for name, expected in pinned.items():
        path = project / name
        if not path.is_file() or sha256(path) != expected:
            raise ValueError(f"Project source differs from audited version: {name}; do not bypass")
    if "src" in sys.modules and Path(sys.modules["src"].__file__).resolve().parent != project / "src":
        raise ValueError("A different project is already imported")
    sys.path.insert(0, str(project))
    from src.data import PreparedData
    from src.temporal_model import TemporalCD
    from src.metrics import compute_metrics
    from train import set_seed, choose_device
    return PreparedData, TemporalCD, compute_metrics, set_seed, choose_device


def check_reference(frame, original, arrays, records, atol):
    import numpy as np
    if original.record_idx.duplicated().any():
        raise ValueError("Duplicate reference record IDs")
    original = original.sort_values("record_idx").reset_index(drop=True)
    # Select by known user/record membership, never outcome or model scores.
    old = original.loc[original.record_idx.isin(records)].reset_index(drop=True)
    np.testing.assert_array_equal(frame.record_idx.to_numpy(), records)
    np.testing.assert_array_equal(old.record_idx.to_numpy(), records)
    if not np.all(old.split.to_numpy() == 1):
        raise ValueError("Reference must contain validation predictions")
    for key in ("student_idx", "item_idx", "label"):
        np.testing.assert_array_equal(old[key].to_numpy(), arrays[key][records])
    if not np.allclose(old.timestamp.to_numpy(), arrays["timestamp"][records], rtol=0, atol=1e-6):
        raise ValueError("Reference timestamps differ")
    # Original tensors/CSV columns are float32. CSV uses shortest round-trip
    # decimals; parsing those as float64 otherwise invents large absolute
    # differences for support counts. Restore the original float32 precision.
    raw_errors = {k: float(np.max(np.abs(frame[k].to_numpy(dtype=np.float64)-old[k].to_numpy(dtype=np.float64))))
                  for k in ("probability", "uncertainty", "evidence")}
    errors = {k: float(np.max(np.abs(frame[k].to_numpy(dtype=np.float32)-old[k].to_numpy(dtype=np.float32))))
              for k in ("probability", "uncertainty", "evidence")}
    return {"success": all(np.isfinite(v) and v <= atol for v in errors.values()),
            "n": len(frame), "atol": atol, "max_absolute_difference": errors,
            "comparison_space": "original float32 output precision restored from CSV",
            "raw_float64_vs_csv_decimal_difference": raw_errors}


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--max-students", type=int)
    p.add_argument("--sample-seed", type=int, default=20260928)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=100)
    p.add_argument("--branch-batch-size", type=int, default=128)
    p.add_argument("--half-life-hours", type=float, default=168.)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--bootstrap", type=int, default=1000)
    p.add_argument("--atol", type=float, default=1e-6)
    p.add_argument("--ack-row-feedback", action="store_true")
    p.add_argument("--ack-time-proxy", action="store_true")
    return p


def main():
    p = parser()
    a = p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy:
        p.error("Both --ack-row-feedback and --ack-time-proxy required; real feedback boundaries remain unverified")
    import math
    if min(a.batch_size, a.chunk_size, a.branch_batch_size, a.threads, a.bootstrap) < 1:
        p.error("Sizes, threads and bootstrap must be positive")
    if a.max_students is not None and a.max_students < 1:
        p.error("max-students must be positive")
    if not math.isfinite(a.half_life_hours) or a.half_life_hours <= 0 or not math.isfinite(a.atol) or a.atol < 0:
        p.error("Invalid half-life or tolerance")
    out = Path(a.output_dir).resolve()
    safe_root = ROOT / "outputs"
    if not out.is_relative_to(safe_root) or out == safe_root:
        p.error(f"Output must be a NEW subdirectory of {safe_root}")
    if out.exists():
        raise FileExistsError("Refusing to overwrite output; choose a new name")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    PreparedData, TemporalCD, metrics, set_seed, choose_device = import_project(a.project_dir)
    import numpy as np
    import pandas as pd
    import torch
    from mechanism_core import (snapshot_model_class, plan_windows, replay_reference,
        parameter_digest, branch_predictions, check_invariants, summarize,
        precision_model_copy, precision_audit, PRECISION_PROTOCOL)
    torch.set_num_threads(a.threads)
    set_seed(0)
    device = choose_device(a.device)
    checkpoint = Path(a.checkpoint).resolve()
    original_path = checkpoint.parent / "validation_predictions.csv"
    prior_status = read_json(checkpoint.parent / "status.json")
    prior_config = read_json(checkpoint.parent / "run_config.json")
    if prior_status.get("status") != "complete":
        raise ValueError("Checkpoint run is not complete")
    ckpt_hash, reference_hash = sha256(checkpoint), sha256(original_path)
    if prior_status.get("checkpoint_sha256") != ckpt_hash:
        raise ValueError("Checkpoint differs from original completed run")
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if ckpt.get("model_family") != "temporal_v1":
        raise ValueError("Requires temporal_v1 checkpoint, not an old clean-model checkpoint")
    cfg = ckpt["model_config"]
    if cfg["time_mode"] != "none" or cfg["decay_rate_per_hour"] != 0 or cfg["variant"] not in ("dynamic_only", "unit_write"):
        raise ValueError("This stage requires a none checkpoint with dynamic_only or unit_write writing")
    for name, expected in read_json(ROOT / "expected_project_sources.json").items():
        if ckpt["source_code"].get(name) != expected:
            raise ValueError(f"Checkpoint source mismatch: {name}")
    if cfg != prior_config["model_config"] or ckpt["epoch"] != prior_status["best_epoch"]:
        raise ValueError("Run config/checkpoint/status disagree")
    if prior_config["args"]["eval_update_targets"] != 1:
        raise ValueError("Original predictions must use online target feedback")
    data = PreparedData(a.data_dir)
    if ckpt["data_fingerprint"] != data.fingerprint or prior_config["data_fingerprint"] != data.fingerprint:
        raise ValueError("Checkpoint/data fingerprint differs; do not regenerate data")
    model = snapshot_model_class(TemporalCD)(**cfg).to(device)
    model.load_state_dict(ckpt["model_state"], strict=True)
    del ckpt
    model.eval()
    model.requires_grad_(False)
    before_parameters = parameter_digest(model)
    users = np.arange(len(data.arrays["user_offsets"])-1)
    if a.max_students is not None:
        users = np.sort(np.random.default_rng(a.sample_seed).permutation(users)[:a.max_students])
    started = time.perf_counter()
    plan = plan_windows(data.arrays, users)
    out.mkdir(parents=True, exist_ok=False)
    metadata = {"package_revision": "fix01_20260930", "args": vars(a), "model_config": cfg, "checkpoint_sha256": ckpt_hash,
        "reference_sha256": reference_hash, "data_fingerprint": data.fingerprint,
        "parameter_sha256_before": before_parameters, "selected_students": users.tolist(),
        "protocol": {"view": "valid", "test_evaluated": False, "trained": False,
            "intervention": "single anchor only, NO continued temporal decay",
            "anchor": "previously seen KC, real gap >168h, validation",
            "window": "up to 5 consecutive same-KC valid records within 168h; stop at same-KC tied timestamp",
            "history": "frozen none checkpoint, complete train+past valid, row-immediate assumption",
            "event_time_proxy": True, "feedback_boundaries_verified": False,
            "future_selection": "outcome availability only; never a model input",
            "equivalence": "mass = proportional future-write rescaling for this window, not proof of novelty",
            "precision_protocol": PRECISION_PROTOCOL,
            "historical_replay": "unchanged original float32; reference and NONE-window atol unchanged",
            "branch_readout": "all six modes independently use a frozen float64 copy of the head; float32 audit retained",
            "branch_writes": "unchanged original float32 evidence increments promoted to float64 state accumulators"},
        "runtime": {"python": sys.version, "torch": str(torch.__version__), "device": str(device),
                    "numpy": np.__version__, "pandas": pd.__version__},
        "diagnostic_sources": {f.name: sha256(f) for f in ROOT.glob("*.py")}}
    save(out / "diagnostic_config.json", metadata)
    save(out / "status.json", {"status": "running", "pid": os.getpid(), "started_unix": time.time()})
    try:
        emit({"phase": "plan", "students": len(users), "valid_records": len(plan["validation_records"]),
              "anchors": len(plan["anchor"]), "h1_available": int((plan["paths"][:, 1] >= 0).sum()),
              "h5_available": int((plan["paths"][:, 5] >= 0).sum())})
        reference, ab = replay_reference(model, data, users, plan, device, a.batch_size, a.chunk_size, emit)
        columns = ["record_idx", "student_idx", "item_idx", "label", "split", "timestamp", "probability", "uncertainty", "evidence"]
        old = pd.read_csv(original_path, usecols=columns)
        bridge = check_reference(reference, old, data.arrays, plan["validation_records"], a.atol)
        save(out / "reference_bridge.json", bridge)
        emit({"phase": "reference_bridge", **bridge})
        if not bridge["success"]:
            raise AssertionError("Frozen replay differs from original predictions; stop before interpreting treatments")
        emit({"phase": "single_anchor_branches"})
        precise = precision_model_copy(model)
        precise_hash = parameter_digest(precise)
        frame = branch_predictions(model, data.arrays, plan, ab, device, a.half_life_hours,
                                   a.branch_batch_size, precision_model=precise)
        # Preserve diagnostic evidence EVEN when a gate fails. A saved table is
        # not an accepted experiment: status.json and invariants.json govern that.
        frame.to_csv(out / "diagnostic_predictions.csv.gz", index=False, compression="gzip")
        np.savez_compressed(out / "anchor_states.npz", anchor=plan["anchor"], alpha_beta=ab,
                            gap_hours=plan["gap_hours"], prior_count=plan["prior_count"], paths=plan["paths"])
        audit = precision_audit(frame, reference, a.atol)
        save(out / "precision_audit.json", audit)
        emit({"phase": "precision_audit", **audit})
        invariant = check_invariants(frame, reference, a.atol, precision_mode=PRECISION_PROTOCOL)
        save(out / "invariants.json", invariant)
        emit({"phase": "invariants", **invariant})
        if not invariant["success"]:
            raise AssertionError("Mathematical/reference invariant failed")
        emit({"phase": "summary", "bootstrap_repetitions": a.bootstrap})
        report = summarize(frame, metrics, a.bootstrap)
        report["precision_protocol"] = PRECISION_PROTOCOL
        report["metric_space"] = "All six independent float64 branch readouts; not original float32 checkpoint test metrics"
        report["anchor_coverage"] = {"anchors": len(plan["anchor"]), "h1": int((plan["paths"][:, 1] >= 0).sum()),
            "h5": int((plan["paths"][:, 5] >= 0).sum()), "anchor_tied_rows": int(plan["anchor_tied"].sum())}
        save(out / "summary.json", report)
        after_parameters = parameter_digest(model)
        if parameter_digest(precise) != precise_hash:
            raise AssertionError("Precision reference parameters changed")
        if after_parameters != before_parameters or sha256(checkpoint) != ckpt_hash or sha256(original_path) != reference_hash:
            raise AssertionError("Immutable model/checkpoint/reference changed")
        if sha256(data.path/"manifest.json") != data.fingerprint:
            raise AssertionError("Prepared manifest changed during the diagnostic")
        for filename,key in (("records.npz","records_sha256"),("vocabulary.json","vocabulary_sha256")):
            if sha256(data.path/filename) != data.manifest[key]:
                raise AssertionError(f"Prepared data changed during the diagnostic: {filename}")
        import_project(a.project_dir)  # Recheck original source files at completion.
        status = {"status": "complete", "test_evaluated": False, "trained": False,
                  "parameters_unchanged": True, "inputs_unchanged": True,
                  "precision_reference_unchanged": True, "precision_protocol": PRECISION_PROTOCOL,
                  "validation_records": len(reference), "anchors": len(plan["anchor"]),
                  "seconds": time.perf_counter()-started, "finished_unix": time.time()}
        save(out / "status.json", status)
        emit(status)
    except BaseException as exc:
        save(out / "status.json", {"status": "failed", "error": repr(exc), "trained": False,
                                   "test_evaluated": False, "finished_unix": time.time()})
        raise


if __name__ == "__main__":
    main()
