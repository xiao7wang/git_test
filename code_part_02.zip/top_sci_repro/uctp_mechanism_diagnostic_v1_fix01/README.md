# UCTP mechanism diagnostic — fix01 (2026-09-30)

独立的数值精度修复包，不是新训练模型。原 `uctp_mechanism_diagnostic_v1`、两个研究项目、数据、checkpoint 和旧结果全部保留。

先读 SERVER_GUIDE.md。上传新 ZIP 后解压到新的同名目录，输出使用 `outputs/server_03`。不要覆盖旧目录，也不要在新旧目录同时启动作业。

## 修复依据

服务器 server_02 的 ASSIST 32 人预检：原预测复现误差为 0；mass 与 write_rescale 的状态均值差约 1.11e-16，但 float32 预测相差 8.463859558105469e-6。只读排查确认，最差记录的两组均值同为 0.9999324506522033；float32 除法产生不同结果，经非线性读出放大。用 float64 均值与 float64 读出，概率差为 0。

这不是性能提升证据。也不能据此把全部数值差异一概忽略。

## 三层验证

1. 原始 checkpoint 仍由原项目的 float32 forward 按原学生批次重放；与旧 validation_predictions.csv 比较，atol 仍为 1e-6。
2. 每条窗口仍保存原 float32 分支预测；NONE 与原始窗口预测的检查也仍为 1e-6。
3. 六个分支分别维护自己的 float64 状态，分别调用冻结参数的 float64 预测函数副本。数学等价检查使用这些独立结果，概率 atol 仍为 1e-6；新增状态均值/写入增益 atol=1e-12。

并非把两个分支的输出复制为相同，也没有增大阈值。原 float32 等价检查的差异原样写入 precision_audit.json；即使它超过 1e-6，也明确显示 false，不伪装成通过。它不再被当作高精度数学等价的判据。

## 公平的数值对照

- 六个模式 NONE / MASS / MEAN / JOINT / WRITE_RESCALE / MEAN_WRITE_RESCALE 全部使用同一精度和同一套冻结参数。
- 主表列 `<mode>_probability` 是各自独立计算的 float64 概率。
- `<mode>_probability_float32` 保留原诊断分支的 float32 读出。
- `<mode>_readout_mean_float32` 记录实际单知识点 float32 比例。
- 状态初值仍来自原 float32 模型；后续写入增量仍来自原 float32 difficulty-only 写入函数，再提升为 float64 累加。没有把写入网络也换成高精度来改变干预含义。
- 汇总 AUC/NLL/Brier/ECE、配对 bootstrap 均使用所有模式的 float64 主概率，不混合精度。
- 不把同一模型的 float64 与 float32 差异宣传为方法提升；新主表也不能冒充旧 checkpoint 的原精度测试结果。

## 分支定义与范围

共同初值为 (alpha,beta)，S=alpha+beta，d=exp(-ln(2)*gap/168)，S'=2+(S-2)*d，r=S'/S。

| 模式 | 起点状态 | 后续写入倍率 |
|---|---|---|
| none | (alpha,beta) | 1 |
| mass | r*(alpha,beta) | 1 |
| joint | 1+d*((alpha,beta)-1) | 1 |
| mean | joint/r | 1 |
| write_rescale | (alpha,beta) | 1/r |
| mean_write_rescale | mean | 1/r |

每个 anchor 只干预一次，之后最多观察一周内后续 5 次同 KC 反馈，不继续时间衰减。六份状态独立更新。不预测当前答案后再把当前答案偷偷放回当前预测。

数学上 mass 与 write_rescale 的均值轨迹相同，joint 与 mean_write_rescale 也相同；证据支持量、uncertainty 不必相同。这依赖固定参数、状态无关的原写入函数、单 KC Q、只由均值参与认知读出等当前假设，不是任意模型的一般结论。

## 保持不变的研究限制

- validation only；不重训，不调参，不新增 test 评估。
- 依然是 row-immediate feedback assumption 与 event timestamp proxy；未核实真实反馈边界。
- 首次见到 KC 不算长间隔；同 KC 相同时间戳中断后续窗口，不跳过其反馈。
- 默认只读取两套 dynamic_only_none_seed0 完成的 full pilot checkpoint。
- 返回练习窗口存在选择偏差；窗口匹配组的结论不能直接推广到全部学生。
- bootstrap 是单固定 checkpoint 条件下的探索性学生簇区间，不包含训练 seed 不确定性。
- 本修复不证明 mass 优于 joint，也不证明论文创新成立。

## 文件

- mechanism_core.py：窗口、原精度重放、六分支、独立高精度副本、数值审计与检查。
- run_diagnostic.py：只读旧输入；失败也保留窗口结果及误差报告；状态决定是否验收。
- run_suite.py：顺序执行测试、预检、chunk17、两个 full 诊断；失败立即停止。
- test_diagnostic.py：49 项测试，含当前报错的近 1 比例/高支持量回归。
- show_results.py：只读进度；失败明确打印失败日志，不再提示不存在的 ZIP 可下载。
- inspect_precision.py：保留旧精度只读定位工具；它不是运行新修复流程的入口。
- expected_project_sources.json：原项目源文件 hash，未改。
- IMPLEMENTATION_REPORT.md：修改记录与本地验证边界。

源包不带数据、权重、旧结果、虚拟环境。本地测试通过不代表服务器 GPU/full 已验收，必须让 server_03 自行通过门禁。
