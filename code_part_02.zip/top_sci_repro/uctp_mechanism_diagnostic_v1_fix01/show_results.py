"""Read saved status/results; never launches or changes an experiment."""
import argparse
from pathlib import Path
from run_diagnostic import read_json

def archive_message(root, status):
    archive = root/"diagnostic_results.zip"
    if status["status"] == "complete" and archive.is_file():
        return f"Results archive ready: {archive}"
    if status["status"] == "failed":
        return "FAILED: no accepted results archive. Read the failed job log; do not wait or restart blindly."
    if status["status"] == "complete":
        return "Jobs complete, but results archive is missing. Do not treat a printed path as an existing file."
    return "Results archive not ready. Saved running/packaging status is not proof of a live process."


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output-root",required=True)
    a = p.parse_args()
    root = Path(a.output_root)
    if not (root/"suite_status.json").is_file():
        raise SystemExit(f"No suite_status.json at {root}; confirm the exact output-root. Nothing was started.")
    status = read_json(root/"suite_status.json")
    print(f"Suite status: {status['status']}; active_job={status.get('active_job','-')}")
    print("A saved running status is not proof of a live process.")
    for job in status["jobs"]:
        print(f"{job['name']:<22} returncode={job['returncode']} seconds={job['seconds']:.1f}")
        if job["returncode"] != 0:
            print(f"  Failure log: {root/(job['name']+'.log')}")
    if status.get("error"):
        print(f"Error: {status['error']}")
    for ds in ("assist","ednet"):
        folder = root/f"{ds}_full"
        if not (folder/"summary.json").is_file():
            continue
        s = read_json(folder/"status.json")
        if s["status"] != "complete":
            continue
        r = read_json(folder/"summary.json")
        print(f"\n{ds.upper()} anchors={s['anchors']} valid_records={s['validation_records']}")
        print(f"Reference bridge: {read_json(folder/'reference_bridge.json')['success']}; invariants: {read_json(folder/'invariants.json')['success']}")
        print(f"Metric space: {r.get('metric_space','legacy float32 diagnostic')}")
        if (folder/"precision_audit.json").is_file():
            audit = read_json(folder/"precision_audit.json")
            if audit.get("float32_equivalence_within_original_atol") is False:
                print("  Numerical audit: raw float32 equivalence exceeds 1e-6; see precision_audit.json. Float64/reference gates are separate.")
        for group in ("all_anchors_h0","matched_next1_h0","matched_next1_h1","matched_next5_h5"):
            g = r.get("groups",{}).get(group)
            if not g:
                continue
            print(f"{group}: n={g['n']} students={g['students']}")
            for mode in ("none","mass","mean","joint"):
                m = g["models"][mode]
                auc = "NA" if m["auc"] is None else f"{m['auc']:.6f}"
                nll = "NA" if m["nll"] is None else f"{m['nll']:.6f}"
                print(f"  {mode:<6} AUC={auc} NLL={nll}")
    print(f"\n{archive_message(root,status)}")


if __name__ == "__main__":
    main()
