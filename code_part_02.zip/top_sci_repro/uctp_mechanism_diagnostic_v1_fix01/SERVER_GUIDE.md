# fix01 服务器操作指南（2026-09-30）

本次上传新独立目录，不覆盖旧诊断包或模型。请只复制命令，不复制终端的 (base) 提示符。

## 1. 上传 ZIP

把桌面的 `uctp_mechanism_diagnostic_v1_fix01.zip` 上传到：

    /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01.zip

不需要重新上传数据或 checkpoint。不需要升级 NumPy/pandas/PyTorch。

## 2. 安全解压

    cd /home/wangxiao/QCCDM/top_sci_repro
    if [ -e /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01 ]; then
      printf '%s\n' '新目录已存在，停止解压，不覆盖。请先确认是否已经启动过。'
    else
      /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e \
        /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01.zip \
        /home/wangxiao/QCCDM/top_sci_repro
    fi

新目录里应能找到 run_suite.py、mechanism_core.py 和本指南。

## 3. 开 tmux

在普通 SSH 新终端执行；如果已经在 tmux 中，不要嵌套：

    tmux new-session -s mechanism_fix01

如提示名称已存在，使用以下命令检查原会话，不要重复启动：

    tmux attach-session -t mechanism_fix01

## 4. 在 tmux 内运行一次以下完整命令

    CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 \
    /home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/run_suite.py \
      --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1 \
      --data-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/outputs/server_03 \
      --device cuda \
      --full \
      --ack-row-feedback \
      --ack-time-proxy

它使用旧 full pilot 的 dynamic_only_none_seed0，不训练模型。作业依次为：

1. tests_cpu：49 项 CPU 测试。
2. tests_cuda：49 项 GPU 测试。
3. assist_preflight：同样固定抽样规则的 32 人预检。
4. ednet_preflight：32 人预检。
5. assist_chunk17：同一批人切换 chunk17。
6. ednet_chunk17：同一批人切换 chunk17。
7. 验证六个 float64 和六个 float32 列的 chunk 一致性（atol 不变）。
8. assist_full：ASSIST 全验证集机制诊断。
9. ednet_full：EDNet 全验证集机制诊断。
10. 打包结果。实际独立子进程总数为 8；chunk 比较和打包由运行器完成。

任一门禁失败就停止，不会继续 full。若 output-root 已存在，脚本拒绝覆盖；不要删除或强行重复运行。

退出 tmux 界面但保持任务：先 Ctrl+B，松开，再按 D。不要按 Ctrl+C。
本地小数据秒数不能推算服务器全量时间；本次是重放和诊断，不是多模型多 epoch 训练。

## 5. 查看进度

在新的 SSH 终端运行：

    /home/wangxiao/miniconda3/envs/yydw/bin/python -B \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/show_results.py \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/outputs/server_03

成功：Suite status: complete，8 个 returncode=0，Results archive ready。
失败：Suite status: failed，打印 Failure log 和错误，不再让你等待压缩包。
running/packaging 是保存状态，并非进程存活证明。必要时：

    pgrep -a -u wangxiao -f 'uctp_mechanism_diagnostic_v1_fix01/(run_suite[.]py|run_diagnostic[.]py|test_diagnostic[.]py)'

失败时先贴出对应日志。例如：

    tail -n 160 /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/outputs/server_03/assist_preflight.log

不要把 `float32_equivalence_within_original_atol=false` 单独当成修复失败：旧 float32 误差原样保留在审计里。真正的门禁是原预测 reference_bridge、NONE 原精度窗口比较、独立 float64 等价性及状态一致性。任何门禁 false 仍会停止，不能自行改容差。

## 6. 完成后下载这个文件

    /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix01/outputs/server_03/diagnostic_results.zip

这是文件位置，不是执行命令。VS Code 左侧展开目录，右键下载，发给我即可。
包里包含 precision_audit.json、invariants.json、reference_bridge.json、分支预测和汇总，不需要再次发模型权重。

正常 full 队列预计：
- ASSIST：255916 条验证记录，34515 个严格长间隔起点。
- EDNet：209028 条验证记录，27137 个严格长间隔起点。

保存了 CSV/NPZ 不等于验收成功：fix01 在门禁失败时也保存排查材料，务必以 status 和检查报告为准。

## 7. 文件安全与回退

旧 `uctp_mechanism_diagnostic_v1/outputs/server_01` 和 `server_02` 不动。
旧研究项目、V1-V7、数据和结果不动。新代码仅在 fix01 目录，回退时选择旧目录即可，不需删除任何东西。
