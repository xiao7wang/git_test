# fix01 修改与验证报告

日期：2026-09-30。范围：用户确认的独立诊断精度修复。没有修改模型结构，没有新增研究模块，没有重训或用 test 指标调参。

## 根因证据

用户服务器的真实 ASSIST 预检记录：
- NumPy 1.26.0 / pandas 3.0.3 / PyTorch 2.11.0+cu128。
- 32 名目标学生、312 条验证记录、45 个 anchor、95 条窗口记录。
- 原模型重放完全一致，probability/uncertainty/evidence float32 比较误差均为 0。
- mass/write_rescale 的均值轨迹误差约 1.11e-16，但 3 条 float32 预测差异超过 1e-6。
- 最差 anchor=1270738、horizon=5、record=1270743。
- 两份高精度比例同为 0.9999324506522033。
- 实际 float32 比例为 0.9999324083328247 与 0.9999324679374695。
- 概率分别为 0.9227688908576965 与 0.9227773547172546，差 8.463859558105469e-6。
- 高精度均值+高精度读出概率同为 0.922774885033937，差为 0。

只读 probe 未写文件、未改参数、未训练。这确认本次失败的数值来源，不证明研究方案优越。

## 实施位置

新目录：`C:/Users/xwsws/Desktop/uctp_mechanism_diagnostic_v1_fix01`。
原独立诊断目录和原 ZIP 保留不变。研究项目 8 项源文件 hash 仍由 expected_project_sources.json 验证，没有更新白名单绕过检查。

### mechanism_core.py

- 新增 precision_model_copy：复制冻结 eval 模型并提升至 float64，逐参数验证等值提升，原模型不变。
- 六个分支独立维护 float64 状态、独立调用读出函数。无共享预测、无为等价而直接赋值。
- 原 float32 读出完整保留；写入仍由原 float32 evidence_increment 计算。
- 新增高精度等价门禁、均值/增益门禁和数值审计。
- 原 reference_bridge=1e-6 与 NONE float32 窗口比较=1e-6 不放宽。
- 新增状态均值及增益 atol=1e-12；高精度预测等价 atol=1e-6。
- 原 float32 两等价分支的误差不再混充数学不等价；在 precision_audit.json 明确保留其原始失败布尔值和每模式差异。

### run_diagnostic.py

- 记录 fix01 版本、精度协议与真实 NumPy/pandas 版本。
- summary 所有模式统一使用 float64 主概率。
- 增加 precision_audit.json；失败前也保存诊断 CSV 和 anchor NPZ，避免错误现场丢失。
- 原模型与高精度副本参数都检查未变；旧 checkpoint、旧预测、数据和项目源 hash 继续核验。

### test_diagnostic.py

- 修复原故障注入测试的 float32 明确转换，兼容服务器 pandas/NumPy 组合，不放宽测试。
- 29 项扩展为 49 项。
- 新增接近 0/1 与大支持量、独立读出调用、概率/状态破坏、原精度输出逐值不变、均值与反馈因果顺序、分支批次变化、精度报告字段完整性和 ZIP 提示测试。
- 高精度控制分支被故意破坏仍必须失败；不能靠复制预测或只看最终概率掩盖状态错误。

### run_suite.py / show_results.py

- chunk17 与 chunk100 对六套高精度列和六套原精度列同时校验。
- 打包期间显示 packaging；关闭 ZIP 后才将磁盘状态写为 complete。
- failed 不再打印可下载 ZIP 的误导提示，而是指出失败日志。
- 已存在的输出目录仍拒绝覆盖，不新增自动重试或清理逻辑。

## 数据流

原 checkpoint + 原完整 train/past-valid 历史 -> 原 float32 replay -> 与旧 CSV 对齐门禁
-> 提取共同 anchor 状态 -> 六个独立干预状态
-> 当前答案揭晓前，各自计算 float32 审计预测与 float64 主预测
-> 得到当前答案后，原写入网络计算同一增量，各分支按倍率独立更新
-> 保存现场 -> 原精度/高精度/状态门禁 -> 验证集汇总 -> 不变性核验。

未改变时间代理、逐行反馈假设、窗口抽样、one-hot Q 限制、bootstrap 分组或 half-life=168h。没有新增时间学习参数。

## 本地已完成的验证

1. 49 项 CPU 单元/集成测试全部通过，无失败、错误或跳过。
2. dynamic_only 在 ASSIST、EDNet 真实 smoke checkpoint/data 上跑完整驱动流程。
3. 两套数据原预测桥接 probability/uncertainty/evidence 的误差均为 0。
4. 两套数据高精度等价概率最大误差约 1.11e-16。
5. 两套数据 chunk17/chunk100 的 12 个概率列最大差异均为 0。
6. unit_write 在两套真实 smoke checkpoint/data 上也完成独立诊断。
7. 所有完成作业 parameters_unchanged、inputs_unchanged、precision_reference_unchanged 均为 true。
8. 结果 ZIP 和查看命令能正常工作；失败、缺 ZIP 和运行中提示均有回归测试。

本地完整驱动的 assist_full/ednet_full 是“对传入 smoke 数据跑完整流程”的作业名，绝不代表跑过服务器真实 full 数据。没有本地 CUDA，GPU 49 项测试与真实 full 数据仍待 server_03 验证。没有取得服务器 full checkpoint，不能声称服务器问题已验收通过。

## 不应该作出的研究结论

本次只是使固定参数机制诊断具有可靠数值对照。不能把浮点精度差异写成性能增益，也不能把 mean/support 分离本身宣称为原创。后续须看完整验证集、匹配窗口与学生簇不确定性；本次不触碰 test，不比较或挑选新超参数。

## 后续

按 SERVER_GUIDE.md 上传新 ZIP，解压到独立 fix01 目录，运行 server_03。
任何原始复现或数学门禁失败都会停止并保留现场，不能自行改容差。
全部通过后，把 diagnostic_results.zip 下载回来再作研究判断。
