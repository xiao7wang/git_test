"""Sequential CPU/GPU tests, 32-user checks, optional two full inference jobs."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True
from run_diagnostic import ROOT, import_project, read_json, save, sha256


def compare_chunks(root, datasets):
    import pandas as pd
    import numpy as np
    report = {}
    for ds in datasets:
        left = pd.read_csv(root/f"{ds}_preflight"/"diagnostic_predictions.csv.gz")
        right = pd.read_csv(root/f"{ds}_chunk17"/"diagnostic_predictions.csv.gz")
        identity = ["anchor_record_idx","record_idx","horizon"]
        if not left[identity].equals(right[identity]):
            raise AssertionError("Chunk checks used different episodes")
        errors = {c:float(np.max(np.abs(left[c]-right[c]))) if len(left) else 0.
                  for c in left.columns if c.endswith(("_probability", "_probability_float32"))}
        if len(left) and len(errors) != 12:
            raise AssertionError("Expected all six float64 and six float32 probability columns")
        if any(not np.isfinite(e) or e > 1e-6 for e in errors.values()):
            raise AssertionError(f"Chunk predictions differ: {errors}")
        report[ds] = {"success":True,"n":len(left),"max_absolute_difference":errors}
    save(root/"chunk_comparison.json",report)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--data-root", required=True, help="Existing clean-research/data directory")
    p.add_argument("--output-root", required=True)
    p.add_argument("--assist-run-root")
    p.add_argument("--ednet-run-root")
    p.add_argument("--assist-data-dir", help="Optional exact data directory, e.g. local smoke verification")
    p.add_argument("--ednet-data-dir", help="Optional exact data directory, e.g. local smoke verification")
    p.add_argument("--variant", choices=("dynamic_only","unit_write"), default="dynamic_only")
    p.add_argument("--device", choices=("cpu","cuda"), default="cuda")
    p.add_argument("--full", action="store_true", help="After all preflights pass, run two full VALIDATION diagnostics without training")
    p.add_argument("--ack-row-feedback", action="store_true")
    p.add_argument("--ack-time-proxy", action="store_true")
    a = p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy:
        p.error("Both feedback/time acknowledgements required")
    root = Path(a.output_root).resolve()
    if not root.is_relative_to(ROOT/"outputs") or root == ROOT/"outputs":
        p.error("output-root must be a new subdirectory of package outputs")
    if root.exists():
        raise FileExistsError("Existing suite preserved; use a NEW output root")
    project = Path(a.project_dir).resolve()
    data_root = Path(a.data_root).resolve()
    import_project(project)
    jobs = {}
    for ds in ("assist","ednet"):
        configured = getattr(a,f"{ds}_run_root")
        runs = Path(configured).resolve() if configured else project/"outputs"/f"server_{ds}_full_pilot_e20_p5_seed0_01"/"runs"
        folder = runs/f"{a.variant}_none_seed0"
        configured_data = getattr(a,f"{ds}_data_dir")
        data = Path(configured_data).resolve() if configured_data else data_root/f"{ds}_full"
        required = [folder/x for x in ("best_model.pt","status.json","run_config.json","validation_predictions.csv")]
        required += [data/x for x in ("manifest.json","records.npz","vocabulary.json")]
        for path in required:
            if not path.is_file():
                raise FileNotFoundError(f"Missing existing input: {path}")
        jobs[ds] = (folder/"best_model.pt",data)
    if a.device == "cuda":
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA unavailable; use the yydw interpreter")
    root.mkdir(parents=True,exist_ok=False)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", CUBLAS_WORKSPACE_CONFIG=":4096:8")
    commands = []
    base = [sys.executable,"-B","-u"]
    commands.append(("tests_cpu",base+[str(ROOT/"test_diagnostic.py"),"--project-dir",str(project),
                    "--device","cpu","--report",str(root/"tests_cpu.json")]))
    if a.device == "cuda":
        commands.append(("tests_cuda",base+[str(ROOT/"test_diagnostic.py"),"--project-dir",str(project),
                        "--device","cuda","--report",str(root/"tests_cuda.json")]))
    for stage in ("preflight","chunk17") + (("full",) if a.full else ()):
        for ds,(checkpoint,data) in jobs.items():
            name = f"{ds}_{stage}"
            cmd = base+[str(ROOT/"run_diagnostic.py"),"--project-dir",str(project),"--checkpoint",str(checkpoint),
                        "--data-dir",str(data),"--output-dir",str(root/name),"--device",a.device,
                        "--bootstrap","1000" if stage == "full" else "100",
                        "--chunk-size","17" if stage == "chunk17" else "100",
                        "--ack-row-feedback","--ack-time-proxy"]
            if stage != "full":
                cmd += ["--max-students","32"]
            commands.append((name,cmd))
    save(root/"suite_config.json",{"package_revision":"fix01_20260930", "args":vars(a),"commands":[{"name":n,"argv":c} for n,c in commands],
                                  "python":sys.executable,"trained":False,"test_evaluated":False})
    history = []
    started = time.time()
    def status(state,**extra):
        save(root/"suite_status.json",{"status":state,"pid":os.getpid(),"started_unix":started,
              "updated_unix":time.time(),"jobs":history,"trained":False,"test_evaluated":False,**extra})
    status("running")
    try:
        for name,cmd in commands:
            log_path = root/f"{name}.log"
            print(f"Starting {name}; log: {log_path}",flush=True)
            status("running",active_job=name)
            began = time.time()
            with log_path.open("x",encoding="utf-8") as log:
                process = subprocess.Popen(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env)
                try:
                    code = process.wait()
                except BaseException:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise
            history.append({"name":name,"returncode":code,"seconds":time.time()-began})
            if code != 0:
                raise RuntimeError(f"{name} failed; read {log_path}; old results preserved")
            print(f"Completed {name} ({time.time()-began:.1f}s)",flush=True)
            if name == "ednet_chunk17":
                # Gate full-data runs on cross-run chunk consistency as well.
                compare_chunks(root,jobs)
                print("CHUNK_COMPARISON_PASSED",flush=True)
        status("packaging",full_diagnostics=a.full,seconds=time.time()-started)
        final_status = read_json(root/"suite_status.json")
        final_status.update(status="complete",updated_unix=time.time())
        result_zip = root/"diagnostic_results.zip"
        with zipfile.ZipFile(result_zip,"x",compression=zipfile.ZIP_DEFLATED) as z:
            for path in sorted(root.rglob("*")):
                if path.is_file() and path not in (result_zip,root/"suite_status.json") and path.suffix in (".json",".log",".gz",".npz"):
                    z.write(path,path.relative_to(root).as_posix())
            z.writestr("suite_status.json",json.dumps(final_status,indent=2))
            z.writestr("SCOPE.txt","fix01: frozen none-checkpoint, one-time anchor intervention. No training/test evaluation. All six diagnostic modes use independent float64 readouts; raw float32 audit retained. Original replay and NONE float32 reference gates unchanged. Equivalence is not proof of educational efficacy.\n")
        save(root/"suite_status.json",final_status)
        print(f"ALL_DIAGNOSTICS_COMPLETED\nResults: {result_zip}\nSHA256: {sha256(result_zip)}",flush=True)
    except BaseException as exc:
        status("failed",error=repr(exc))
        raise


if __name__ == "__main__":
    main()
