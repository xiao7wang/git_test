"""Run one frozen A1 validation probe against an accepted clean checkpoint."""
import argparse
import os
from pathlib import Path
import platform
import sys
import time

sys.dont_write_bytecode = True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch

from scale_core import (require, sha, read_json, save, import_clean, parameter_digest,
                        build_context, check_reference, select_rows, probe, summarize)

ROOT = Path(__file__).resolve().parent
DEFAULT_EXPORT = "/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/outputs/server_seed12_valid_export_20260929_01"


def check_package():
    manifest = read_json(ROOT / "PACKAGE_MANIFEST.json")
    for name, expected in manifest["files"].items():
        require(sha(ROOT / name) == expected, f"Package changed: {name}")


def verify_metadata(project, export, job_name, policy):
    """Hash all server inputs before any deserialization or prediction."""
    require(job_name in policy["jobs"], "Job not in accepted inputs")
    job = policy["jobs"][job_name]
    require(job["variant"] == "unit_write" and job["seed"] in (1, 2), "Outside fixed A1 matrix")
    project, export = Path(project).resolve(), Path(export).resolve()
    require(project == Path(job["data_dir"]).resolve().parent.parent, "Unexpected clean project root")
    inputs = {export / "export_plan.json": policy["export_plan_sha256"],
              export / "completed.json": policy["completed_sha256"],
              Path(job["checkpoint"]): job["checkpoint_sha256"]}
    for name, h in policy["source_pins"].items():
        inputs[project / name] = h
    run = Path(job["run"])
    for name, h in job["metadata_hashes"].items():
        inputs[run / name] = h
    evaluation = (export / job["export"]["evaluation_dir"]).resolve()
    require(evaluation.is_relative_to(export), "Invalid evaluation path")
    for name, h in job["export"]["verification"]["files"].items():
        inputs[evaluation / name] = h
    data = Path(job["data_dir"])
    source = policy["data"][job["dataset"]]
    for name, key in (("manifest.json", "fingerprint"), ("records.npz", "records_sha256"),
                      ("vocabulary.json", "vocabulary_sha256")):
        inputs[data / name] = source[key]
    for path, expected in inputs.items():
        require(path.is_file(), f"Missing pinned file: {path}")
        require(sha(path) == expected, f"Pinned input changed: {path}")
    cfg, state, history = [read_json(run / (name + ".json")) for name in ("run_config", "status", "history")]
    ev = read_json(evaluation / "evaluation.json")
    manifest = read_json(data / "manifest.json")
    best = max(history, key=lambda entry: entry["valid"]["auc"])
    require(state["status"] == "complete" and cfg["model_config"]["variant"] == "unit_write", "Wrong training status/model")
    require(state["checkpoint_sha256"] == ev["checkpoint_sha256"] == job["checkpoint_sha256"], "Checkpoint metadata")
    require(best["epoch"] == state["best_epoch"] == ev["epoch"] == job["best_epoch"], "Best epoch changed")
    require(cfg["data_fingerprint"] == ev["data_fingerprint"] == job["data_fingerprint"], "Data fingerprint")
    require(cfg["args"]["seed"] == job["seed"], "Seed changed")
    for key, expected in policy["training_settings"][job["dataset"]].items():
        require(cfg["args"][key] == expected, f"Training config changed: {key}")
    for key, expected in {"view": "valid", "update_targets": 1, "ack_row_feedback": True,
                          "batch_size": 8, "chunk_size": 100}.items():
        require(ev["args"][key] == expected, f"Reference evaluation changed: {key}")
    for name, h in policy["source_pins"].items():
        require(cfg["source_code"][name] == ev["source_code"][name] == h, f"Source metadata changed: {name}")
    require(manifest["feedback_protocol"] == "row_immediate_assumption", "Feedback protocol changed")
    return job, cfg, manifest, evaluation, inputs


def run_job(args, policy, output_base=None):
    output = Path(args.output_dir).resolve()
    base = (ROOT / "outputs") if output_base is None else Path(output_base).resolve()
    require(output != base and output.is_relative_to(base), "Output must be a new package outputs child")
    require(not output.exists(), f"Refusing to overwrite existing output: {output}")
    require(args.ack_row_feedback, "--ack-row-feedback required")
    require(args.device in ("cpu", "cuda") and args.batch_size > 0 and args.threads > 0 and
            args.max_students >= 0 and args.bootstrap_reps >= 1, "Invalid execution settings")
    if args.device == "cuda":
        require(torch.cuda.is_available(), "CUDA unavailable")
    torch.set_num_threads(args.threads)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    started = time.perf_counter()
    output.mkdir(parents=True, exist_ok=False)
    save(output / "status.json", {"status": "running", "job": args.job, "pid": os.getpid()})
    try:
        t = time.perf_counter()
        job, cfg, manifest, evaluation, inputs = verify_metadata(args.project_dir, args.export_root, args.job, policy)
        Model, State = import_clean(args.project_dir, policy["source_pins"])
        ckpt = torch.load(job["checkpoint"], map_location="cpu", weights_only=True)
        require(ckpt.get("model_family") is None, "Converted checkpoint rejected")
        require(ckpt["model_config"] == cfg["model_config"] and ckpt["epoch"] == job["best_epoch"] and
                ckpt["data_fingerprint"] == job["data_fingerprint"], "Checkpoint provenance")
        for name, h in policy["source_pins"].items():
            require(ckpt["source_code"][name] == h, f"Checkpoint source mismatch: {name}")
        model = Model(**ckpt["model_config"])
        model.load_state_dict(ckpt["model_state"], strict=True)
        del ckpt
        model.eval().requires_grad_(False)
        input_seconds = time.perf_counter() - t

        t = time.perf_counter()
        needed = ("student_idx", "item_idx", "timestamp", "split", "item_q", "label",
                  "kc_count_before", "student_count_before")
        with np.load(Path(job["data_dir"]) / "records.npz", allow_pickle=False) as archive:
            arrays = {name: archive[name] for name in needed}
        context = build_context(arrays, cfg["model_config"]["num_students"],
                                cfg["model_config"]["num_items"], cfg["model_config"]["num_knowledges"])
        del arrays
        require(context["valid_count"] == job["n"] and context["valid_count"] == policy["data"][job["dataset"]]["n"],
                "Validation coverage changed")
        reference = pd.read_csv(evaluation / "predictions.csv", float_precision="round_trip")
        reference = reference.sort_values("record_idx").reset_index(drop=True)
        check_reference(reference, context, job["expected_validation"])
        prefix_seconds = time.perf_counter() - t
        rows = select_rows(context, args.max_students)
        save(output / "run_config.json", {"job": job, "args": vars(args),
             "policy_sha256": sha(ROOT / "accepted_inputs.json"), "model_family": "original clean",
             "scope": "frozen validation P/N scale controls; no fitting or test evaluation",
             "feedback_boundaries_verified": manifest["feedback_boundaries_verified"],
             "loaded_npz_fields": list(needed),
             "physical_label_load": "Whole label array may decompress; split<=1 selected before analytical access",
             "test_labels_used": False, "update_targets": True,
             "python": platform.python_version(), "torch": str(torch.__version__),
             "numpy": np.__version__, "pandas": pd.__version__})

        t = time.perf_counter()
        model.to(args.device)
        before = parameter_digest(model)
        predictions, gate = probe(model, State, context, reference, rows, args.batch_size, args.device)
        require(parameter_digest(model) == before, "Parameter drift")
        forward_seconds = time.perf_counter() - t
        save(output / "reference_gate.json", gate)
        t = time.perf_counter()
        from importlib.util import spec_from_file_location, module_from_spec
        metric_spec = spec_from_file_location("scale_pinned_clean_metrics", Path(args.project_dir) / "src/metrics.py")
        metric_module = module_from_spec(metric_spec)
        metric_spec.loader.exec_module(metric_module)
        summary = summarize(predictions, metric_module.compute_metrics, reps=args.bootstrap_reps)
        summary_seconds = time.perf_counter() - t
        for path, expected in inputs.items():
            require(sha(path) == expected, f"Input changed during probe: {path}")
        predictions.to_csv(output / "predictions.csv.gz", index=False, float_format="%.17g", compression="gzip")
        save(output / "summary.json", summary)
        save(output / "input_hashes.json", {str(path): h for path, h in inputs.items()})
        result = {"status": "complete", "job": args.job, "n": len(predictions),
                  "nonfirst_n": int((predictions.kc_count_before > 0).sum()),
                  "seconds": time.perf_counter() - started,
                  "phase_seconds": {"inputs_and_model": input_seconds, "prefix_and_reference": prefix_seconds,
                                    "forward": forward_seconds, "statistics": summary_seconds},
                  "trained": False, "test_evaluated": False, "parameters_changed": False,
                  "source_inputs_unchanged": True, "reference_gate": gate}
        save(output / "status.json", result)
        print(result, flush=True)
        return result
    except BaseException as exc:
        save(output / "status.json", {"status": "failed", "job": args.job,
                                      "error": repr(exc), "seconds": time.perf_counter() - started})
        raise


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--export-root", default=DEFAULT_EXPORT)
    p.add_argument("--job", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--max-students", type=int, default=0)
    p.add_argument("--bootstrap-reps", type=int, default=2000)
    p.add_argument("--ack-row-feedback", action="store_true")
    return p


if __name__ == "__main__":
    check_package()
    run_job(parser().parse_args(), read_json(ROOT / "accepted_inputs.json"))
