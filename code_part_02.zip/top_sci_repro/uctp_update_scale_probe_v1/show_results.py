"""Show A1 status; saved running state alone does not imply live process."""
import argparse
from pathlib import Path
from scale_core import read_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-root", required=True)
    root = Path(p.parse_args().output_root)
    path = root / "suite_status.json"
    if not path.is_file():
        raise SystemExit(f"No suite_status.json in {root}; check upload/extraction and actual run name")
    status = read_json(path)
    print(f"Suite status: {status['status']}; active_job={status.get('active_job', '-')}; saved_pid={status.get('pid')}")
    print("A saved running status does not prove the process is live.")
    for job in status["jobs"]:
        print(f"{job['name']:<45} code={job['returncode']} seconds={job['seconds']:.1f}")
    if status.get("error"):
        print("ERROR:", status["error"])
    for path in sorted(root.glob("*_full/summary.json")):
        entry = read_json(path)
        gate = read_json(path.parent / "reference_gate.json")
        print(f"\n{path.parent.name}; gate={gate}")
        for group in ("nonfirst_kc", "first_kc", "all"):
            current = entry["groups"][group]
            print(f"{group}: n={current['n']}, students={current['students']}")
            for name, metrics in current["metrics"].items():
                if metrics["n"]:
                    print(f"  {name:<9} AUC={metrics['auc']:.6f} NLL={metrics['nll']:.6f} "
                          f"macroNLL={metrics['student_macro_nll']:.6f}")
            if group == "nonfirst_kc":
                for name, pair in current["comparisons"].items():
                    print(f"  {name}: deltaNLL={pair['delta_nll']:.6f} "
                          f"CI={pair['event_interval']['ci95']}")
    archive = root / "a1_results.zip"
    if status["status"] == "complete" and archive.is_file():
        print("\nDownload:", archive)
    elif status["status"] == "failed":
        print("\nFAILED: read failure log; no accepted result archive. Do not restart into this output directory.")


if __name__ == "__main__": main()
