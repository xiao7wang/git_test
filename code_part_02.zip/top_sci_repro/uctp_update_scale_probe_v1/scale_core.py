"""Frozen unit-write scale probe; structural checks and validation scoring."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

MODES = ("u0", "w_half", "w_double", "r_half", "r_double")
PAIRS = tuple((mode, "u0") for mode in MODES[1:]) + tuple(
    (w, r) for w in ("w_half", "w_double") for r in ("r_half", "r_double"))
ATOL = 1e-6


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def import_clean(project, pins):
    project = Path(project).resolve()
    for name, expected in pins.items():
        require(sha(project / name) == expected, f"Pinned source changed: {name}")
    spec = importlib.util.spec_from_file_location("scale_pinned_clean_model", project / "src/model.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module.CleanCD, module.State


def parameter_digest(model):
    h = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        h.update(name.encode())
        a = tensor.detach().cpu().contiguous().numpy()
        h.update(str((a.shape, a.dtype)).encode())
        h.update(a.tobytes())
    return h.hexdigest()


def build_context(arrays, num_students, num_items, num_kcs):
    """Use labels only after restricting to train/valid. Current row excluded."""
    q = np.asarray(arrays["item_q"])
    require(q.shape == (num_items, num_kcs) and np.isin(q, [0, 1]).all() and
            (q.sum(1) == 1).all(), "Only verified single-KC Q is supported")
    full_split = np.asarray(arrays["split"])
    require(np.isin(full_split, [0, 1, 2]).all(), "Invalid split")
    ids = np.flatnonzero(full_split <= 1)
    require(len(ids) > 0, "No train/valid records")
    u = np.asarray(arrays["student_idx"])[ids]
    item = np.asarray(arrays["item_idx"])[ids]
    t = np.asarray(arrays["timestamp"])[ids]
    split = full_split[ids]
    # The source NPZ may decompress the complete label array into memory;
    # test positions are never indexed into the analytical label sequence.
    label = np.asarray(arrays["label"])[ids]
    require(np.issubdtype(u.dtype, np.integer) and np.issubdtype(item.dtype, np.integer), "Noninteger IDs")
    require(((u >= 0) & (u < num_students)).all() and ((item >= 0) & (item < num_items)).all(), "Invalid IDs")
    require(np.isfinite(t).all() and np.isin(label, [0, 1]).all(), "Invalid timestamp/label")
    require((np.diff(u) >= 0).all(), "Student order changed")
    same_user = np.diff(u) == 0
    require((np.diff(t)[same_user] >= 0).all(), "Timestamp order changed")
    require((np.diff(split.astype(int))[same_user] >= 0).all(), "Split order changed")
    kc = q.argmax(1)[item]
    key = u.astype(np.int64) * num_kcs + kc
    order = np.lexsort((ids, key))
    first = np.r_[True, key[order][1:] != key[order][:-1]]
    start = np.maximum.accumulate(np.where(first, np.arange(len(ids)), 0))
    count_ordered = np.arange(len(ids)) - start
    count = np.empty(len(ids), np.int64)
    count[order] = count_ordered
    prior = (label[order] == 1).astype(np.int64)
    cumulative = np.cumsum(prior)
    baseline = np.maximum.accumulate(np.where(first, cumulative - prior, 0))
    positive = np.empty(len(ids), np.int64)
    positive[order] = cumulative - prior - baseline
    negative = count - positive
    require((positive >= 0).all() and (negative >= 0).all(), "Negative prefix")
    first_student = np.r_[True, u[1:] != u[:-1]]
    student_count = np.arange(len(ids)) - np.maximum.accumulate(np.where(first_student, np.arange(len(ids)), 0))
    require(np.array_equal(count, np.asarray(arrays["kc_count_before"])[ids]), "KC prefix mismatch")
    require(np.array_equal(student_count, np.asarray(arrays["student_count_before"])[ids]), "Student prefix mismatch")
    left_tie = np.r_[False, same_user & (np.diff(t) == 0)]
    tied = left_tie | np.r_[left_tie[1:], False]
    valid = split == 1
    require(valid.any() and (split == 0).any(), "Train/valid missing")
    return {"q": q, "record_idx": ids[valid], "student_idx": u[valid],
            "item_idx": item[valid], "timestamp": t[valid], "label": label[valid],
            "kc": kc[valid], "positive": positive[valid], "negative": negative[valid],
            "kc_count_before": count[valid], "student_count_before": student_count[valid],
            "same_time": tied[valid], "train_count": int((split == 0).sum()),
            "valid_count": int(valid.sum())}


def check_reference(frame, context, expected_metrics):
    require(len(frame) == context["valid_count"] and frame.record_idx.is_unique, "Reference coverage")
    require((frame.split == 1).all(), "Reference must be validation only")
    for column in ("record_idx", "student_idx", "item_idx", "label", "timestamp",
                   "kc_count_before", "student_count_before"):
        require(np.array_equal(frame[column].to_numpy(), context[column]), f"Reference mismatch: {column}")
    require(np.isfinite(frame.probability).all() and frame.probability.between(0, 1).all(), "Invalid reference p")
    y = frame.label.to_numpy()
    p = frame.probability.to_numpy().astype(np.float32).astype(float)
    q = np.clip(p, 1e-7, 1 - 1e-7)
    brier = float(np.mean((p - y) ** 2))
    nll = float((-y * np.log(q) - (1 - y) * np.log1p(-q)).mean())
    order = np.argsort(p, kind="stable")
    _, first, sizes = np.unique(p[order], return_index=True, return_counts=True)
    ranks = np.repeat(first + (sizes + 1) / 2, sizes)
    positives = y.sum()
    negatives = len(y) - positives
    require(positives > 0 and negatives > 0, "Reference AUC undefined")
    auc = float((ranks[y[order] == 1].sum() - positives * (positives + 1) / 2) /
                (positives * negatives))
    for name, actual in (("auc", auc), ("nll", nll), ("brier", brier)):
        require(abs(actual - expected_metrics[name]) <= 1e-12, f"Reference metric changed: {name}")


def select_rows(context, max_students):
    if max_students == 0:
        return np.arange(context["valid_count"])
    require(max_students > 0, "Invalid max_students")
    cold = context["kc_count_before"] == 0
    users = np.unique(context["student_idx"][cold])
    selected = np.random.default_rng(20261004).permutation(users)[:max_students]
    require(len(selected) > 0, "No eligible students")
    return np.flatnonzero(np.isin(context["student_idx"], selected))


@torch.inference_mode()
def predict_readout(model, state, student, item, q, factor):
    """Same frozen clean head; factor affects only dynamic logit at readout."""
    alpha = 1 + state.positive.clamp_min(0)
    beta = 1 + state.negative.clamp_min(0)
    mean = alpha / (alpha + beta)
    base = model.student_mastery_logit(student)
    base = base + F.softplus(model.raw_dynamic_scale) * (
        torch.logit(mean.clamp(1e-5, 1 - 1e-5)) * factor)
    mastery = torch.sigmoid(base)
    difficulty = torch.sigmoid(model.item_difficulty_logit(item))
    discrimination = F.softplus(model.item_discrimination_raw(item)).squeeze(-1) + 1e-4
    interaction = discrimination.unsqueeze(-1) * (mastery - difficulty) * q
    q_sum = q.sum(-1).clamp_min(1)
    logit = (model.item_bias(item).squeeze(-1)
             + F.softplus(model.raw_direct_scale) * interaction.sum(-1) / q_sum
             + model.ncd(interaction).squeeze(-1))
    return torch.sigmoid(logit)


@torch.inference_mode()
def predict_modes(model, State, student, item, q, pos, neg):
    require(model.variant == "unit_write" and not model.training, "Frozen unit writer required")
    require(student.ndim == item.ndim == pos.ndim == neg.ndim == 1 and len(student) > 0, "Batch shapes")
    require(q.shape == (len(student), model.num_knowledges) and
            torch.all(q.sum(-1) == 1).item(), "Single-KC batch required")
    require(torch.all(pos >= 0).item() and torch.all(neg >= 0).item(), "Negative counts")
    state = State(pos.unsqueeze(-1) * q, neg.unsqueeze(-1) * q)
    result = {"u0": model.predict(state, student, item, q)["probability"]}
    for mode, c in (("w_half", .5), ("w_double", 2.)):
        scaled = State(state.positive * c, state.negative * c)
        result[mode] = model.predict(scaled, student, item, q)["probability"]
    for mode, d in (("r_half", .5), ("r_double", 2.)):
        result[mode] = predict_readout(model, state, student, item, q, d)
    return result


@torch.inference_mode()
def probe(model, State, context, reference, rows, batch_size, device):
    require(batch_size > 0, "Invalid batch size")
    require(not any(p.requires_grad for p in model.parameters()), "Model must be frozen")
    before = parameter_digest(model)
    rows = np.asarray(rows)
    selected = {k: v[rows] for k, v in context.items() if isinstance(v, np.ndarray) and k != "q"}
    out = {m: np.empty(len(rows), np.float64) for m in MODES}
    gate = {"native_vs_reference": 0., "factor_one_vs_native": 0.,
            "cold_modes_max_difference": 0., "count_equivalence_fp64": 0.,
            "batch_size": batch_size, "atol": ATOL}
    qtable = context["q"]
    for start in range(0, len(rows), batch_size):
        s = slice(start, start + batch_size)
        user = torch.as_tensor(selected["student_idx"][s], dtype=torch.long, device=device)
        item = torch.as_tensor(selected["item_idx"][s], dtype=torch.long, device=device)
        q = torch.as_tensor(qtable[selected["item_idx"][s]], dtype=torch.float32, device=device)
        pos = torch.as_tensor(selected["positive"][s], dtype=torch.float32, device=device)
        neg = torch.as_tensor(selected["negative"][s], dtype=torch.float32, device=device)
        probs = predict_modes(model, State, user, item, q, pos, neg)
        state = State(pos.unsqueeze(-1) * q, neg.unsqueeze(-1) * q)
        alternate = predict_readout(model, state, user, item, q, 1.)
        diff = (probs["u0"] - alternate).abs().max().item()
        gate["factor_one_vs_native"] = max(gate["factor_one_vs_native"], diff)
        for mode in MODES:
            out[mode][s] = probs[mode].cpu().numpy().astype(np.float64)
        saved = reference.probability.to_numpy()[rows[s]].astype(np.float32).astype(float)
        gate["native_vs_reference"] = max(gate["native_vs_reference"],
                                          float(np.max(np.abs(out["u0"][s] - saved))))
        cold = selected["kc_count_before"][s] == 0
        if cold.any():
            for mode in MODES[1:]:
                gate["cold_modes_max_difference"] = max(gate["cold_modes_max_difference"],
                    float(np.max(np.abs(out[mode][s][cold] - out["u0"][s][cold]))))
        p = selected["positive"][s].astype(float)
        n = selected["negative"][s].astype(float)
        for c in (.5, 2.):
            x = (1+c*p)/(2+c*(p+n))
            y = (1/c+p)/(2/c+p+n)
            gate["count_equivalence_fp64"] = max(gate["count_equivalence_fp64"],
                float(np.max(np.abs(x-y))))
    gate["success"] = (gate["native_vs_reference"] <= ATOL and
                       gate["factor_one_vs_native"] <= ATOL and
                       gate["cold_modes_max_difference"] <= ATOL and
                       gate["count_equivalence_fp64"] <= 1e-12)
    require(gate["success"], f"Reference or invariance gate failed: {gate}")
    require(parameter_digest(model) == before, "Model parameters changed")
    frame = pd.DataFrame({k: selected[k] for k in ("record_idx", "student_idx", "item_idx",
        "timestamp", "label", "kc", "positive", "negative", "kc_count_before",
        "student_count_before", "same_time")})
    frame["split"] = 1
    for mode in MODES:
        require(np.isfinite(out[mode]).all() and np.all((out[mode] >= 0) & (out[mode] <= 1)),
                f"Invalid probability {mode}")
        frame[mode + "_probability"] = out[mode]
    return frame, gate


def summarize(frame, metric, reps=2000):
    require(reps > 0, "Invalid bootstrap repetitions")
    count = frame.kc_count_before.to_numpy()
    usercount = frame.student_count_before.to_numpy()
    groups = {"all": np.ones(len(frame), bool), "first_kc": count == 0,
              "nonfirst_kc": count >= 1, "kc1_4": (count >= 1) & (count <= 4),
              "kc5_19": (count >= 5) & (count <= 19), "kc20plus": count >= 20,
              "nonfirst_user_lt50": (count >= 1) & (usercount < 50),
              "nonfirst_user_ge50": (count >= 1) & (usercount >= 50),
              "nonfirst_not_tied": (count >= 1) & ~frame.same_time.to_numpy()}
    y = frame.label.to_numpy()
    users = frame.student_idx.to_numpy()
    _, inv = np.unique(users, return_inverse=True)
    ns = int(inv.max()) + 1
    p = {m: frame[m + "_probability"].to_numpy() for m in MODES}
    losses = {m: -y * np.log(np.clip(p[m], 1e-7, 1-1e-7)) -
              (1-y) * np.log1p(-np.clip(p[m], 1e-7, 1-1e-7)) for m in MODES}
    counts = np.column_stack([np.bincount(inv[mask], minlength=ns) for mask in groups.values()]).astype(float)
    totals = np.stack([np.column_stack([np.bincount(inv[mask], weights=(losses[a]-losses[b])[mask], minlength=ns)
                      for mask in groups.values()]) for a, b in PAIRS]).transpose(0, 2, 1)
    means = np.divide(totals, counts.T[None, :, :], out=np.zeros_like(totals), where=counts.T[None, :, :] > 0)
    rng = np.random.default_rng(20260929)
    event, macro = [], []
    for start in range(0, reps, 40):
        weight = np.stack([np.bincount(rng.integers(ns, size=ns), minlength=ns)
                           for _ in range(min(40, reps-start))]).astype(float)
        numer = (weight @ totals.reshape(-1, ns).T).reshape(-1, len(PAIRS), len(groups))
        mac = (weight @ means.reshape(-1, ns).T).reshape(numer.shape)
        den = weight @ counts
        md = weight @ (counts > 0)
        event.append(np.divide(numer, den[:, None, :], out=np.full_like(numer, np.nan), where=den[:, None, :] > 0))
        macro.append(np.divide(mac, md[:, None, :], out=np.full_like(mac, np.nan), where=md[:, None, :] > 0))
    event, macro = np.concatenate(event), np.concatenate(macro)

    def ci(values):
        finite = values[np.isfinite(values)]
        return {"ci95": np.quantile(finite, [.025, .975]).tolist() if len(finite) else None,
                "valid_resamples": len(finite)}

    result = {"bootstrap_reps": reps, "bootstrap_seed": 20260929,
              "interpretation": "Pointwise exploratory student-cluster intervals conditional on frozen checkpoint",
              "groups": {}}
    for j, (name, mask) in enumerate(groups.items()):
        entry = {"n": int(mask.sum()), "students": int((counts[:, j] > 0).sum()),
                 "metrics": {}, "comparisons": {}}
        for mode in MODES:
            m = metric(y[mask], p[mode][mask])
            c = counts[:, j]
            sums = np.bincount(inv[mask], weights=losses[mode][mask], minlength=ns)
            m["student_macro_nll"] = float((sums[c > 0] / c[c > 0]).mean()) if mask.any() else None
            m["observed_rate"] = float(y[mask].mean()) if mask.any() else None
            m["mean_probability"] = float(p[mode][mask].mean()) if mask.any() else None
            entry["metrics"][mode] = m
        for i, (a, b) in enumerate(PAIRS):
            ma, mb = entry["metrics"][a], entry["metrics"][b]
            entry["comparisons"][a + "_minus_" + b] = {
                "delta_nll": ma["nll"] - mb["nll"] if mask.any() else None,
                "delta_student_macro_nll": ma["student_macro_nll"] - mb["student_macro_nll"] if mask.any() else None,
                "event_interval": ci(event[:, i, j]), "macro_interval": ci(macro[:, i, j])}
        result["groups"][name] = entry
    return result
