# A1 冻结尺度对照：实现说明

日期：2026-10-09。实现范围依据 [A1 实施前方案](../a1_design_20261005/A1_最小尺度对照方案.md)。

## 本次实现

独立目录 `uctp_update_scale_probe_v1`，固定四个 `unit_write` checkpoint 与五种读出设置。在同一模型、相同学生/题目参数与原训练历史下，按正负反馈前缀计算原单位写入、统一减半/加倍写入，以及动态 logit 减半/加倍读出。所有设置用相同的原模型 NCD 头；U0 与 W 模式调用原生 `CleanCD.predict`，R 模式只改变动态 logit 读出倍数。

验证前按 `accepted_inputs.json` 的哈希核对模型权重、原验证导出、训练元数据、预处理数据和核心源码。训练与验证前缀用 `split<=1`，当前响应不进入当前预测。对每个验证记录记录其预测前 P、N、KC 次数及五个预测概率。所有验证概率均新算，旧验证 CSV 只用来对齐并检验 U0。

主组是已见 KC (`kc_count_before>=1`)；首次 KC 为应不变守卫。指标包括事件 NLL、学生宏平均 NLL、AUC、Brier、ECE 和 2,000 次学生簇配对 bootstrap 区间。比较四个变化分支相对 U0 及全部四种 W–R 配对，不挑单一有利分支。

所有设置是固定冻结探针，没有学习参数。统一写入缩放与伪计数缩放、计数相关读出在预测上等价，因此即便 W 有利，也不能声称识别出交互可靠性或证明“必须在写入时做”。

## 数值和数据边界

- 只接受已核验的单题单 KC Q 映射；多 KC 输入拒绝快捷前缀路径。
- 原生顺序回放、跨 chunk 前缀、U0 独立批量读出、原接受预测、batch 128/17 被分别核验，概率容差固定为 `1e-6`。float64 伪计数恒等式单独检验，不用它绕开 FP32 桥接失败。
- `records.npz` 的完整 label 数组可能解压到内存；脚本只索引 train/valid 行构造状态，绝不索引 test label。不能宣称物理上未载入 test 数组。
- 原模型评测协议是逐行反馈；同时间组顺序及跨划分同时间组仍沿用原顺序。`feedback_boundaries_verified=false` 不会因本探针变为 true。
- 结果只支持固定 checkpoint 条件下的预测比较，不包含重新训练、模型选择或独立教育因果测量。

## 文件与服务器流程

| 文件 | 用途 |
|---|---|
| `accepted_inputs.json` | 继承已验收 A0 中四个模型、数据与原验证预测的身份 |
| `scale_core.py` | 严格前缀、五种读出、指标与配对区间 |
| `run_probe.py` | 单模型身份校验、执行与输出 |
| `test_scale.py` | CPU/CUDA 合成测试与临时完整入口 |
| `run_suite.py` | 两设备测试、预检、批量一致性、四个 full 作业、结果打包 |
| `show_results.py` | 状态、失败定位与关键指标查看 |
| `run_server.sh`, `SERVER_GUIDE.md` | yydw/GPU0/tmux 上传运行步骤 |
| `PACKAGE_MANIFEST.json` | 包内源文件哈希锁定 |

本地合成 CPU 测试 8/8 通过，包含配对学生宏平均与显式重采样的独立对照，以及真正跨越 17/50 行边界的长序列回放；真实 full checkpoint 的服务器 CPU/CUDA 检查与四个验证结果尚待运行。原 clean、temporal、mechanism、A0 项目文件和旧实验输出没有被本包修改。
