# A1 冻结尺度对照：服务器运行指南

此包用于既有 `unit_write` checkpoint 的验证集机制检查。五个固定设置：`u0`、`w_half`、`w_double`、`r_half`、`r_double`。**不会训练模型，也不会评测 test。**

## 1. 上传和解压

把本地桌面的 `uctp_update_scale_probe_v1.zip` 上传到服务器：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1.zip`

在远程终端逐行执行：

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
ls -lh uctp_update_scale_probe_v1.zip
if [ -e uctp_update_scale_probe_v1 ]; then
    printf '%s\n' '同名目录已存在，停止解压；请先确认来源。'
else
    /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_update_scale_probe_v1.zip && \
    /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_update_scale_probe_v1.zip .
fi
```

若同名目录已经存在，上面的条件块只打印提示，不会解压覆盖；此时先确认目录来源。上传的 ZIP 中顶层应只有 `uctp_update_scale_probe_v1/`。

## 2. 在 tmux 中一次运行

```bash
tmux new-session -s a1scale
cd /home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1
bash run_server.sh server_a1_01
```

运行命令先验证 checkpoint/原预测/数据哈希，随后执行 CPU 与 CUDA 合成测试、4×32 学生批量一致性检查，最后完成 ASSIST 与 EDNet、seed 1/2 的四个完整验证作业。任何检查失败会停止并保存日志。

tmux 脱离：按 `Ctrl+b`，松开后按 `d`。关闭 VS Code 或 SSH 后任务应继续在 tmux 中运行；前提是服务器本身和 tmux 会话仍在。**不要在运行界面用 Ctrl+C 作为复制快捷键。**

重新进入：

```bash
tmux attach -t a1scale
```

如果以前已用过 `server_a1_01`，请换一个新运行名，例如 `server_a1_02`；程序拒绝覆盖旧结果。运行脚本始终指定 GPU 0 和远程 `yydw` Python，可从 `(base)` shell 启动。

## 3. 查看状态与错误

在另一个 SSH 终端：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/show_results.py \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_01
```

状态 `complete` 且四个 `_full` 作业都 `code=0`、结果包存在，才算完成。状态 `running` 只是文件中上次保存的值；确认进程：

```bash
pgrep -a -u wangxiao -f 'uctp_update_scale_probe_v1/(run_suite[.]py|run_probe[.]py|test_scale[.]py)'
```

若显示 `failed`，根据 `active_job` 或最后一个非零 `code` 找到对应 `.log`，例如：

```bash
tail -n 100 /home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_01/assist_unit_write_seed1_full.log
```

若尚无 `_full` 文件，可能仍在测试或预检；以 `show_results.py` 和进程状态判断。前一个作业失败时，不会再启动后续作业，不要盲目在同一输出目录重新运行。

## 4. 下载给我验收的文件

当状态为 `complete`，请通过 VS Code Remote SSH 下载：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_01/a1_results.zip`

把 ZIP 发给我。我会独立核对逐条身份、U0 桥接、五组预测及 NLL/学生宏平均区间，之后再决定研究方向。现在不要凭终端上一项分数选择新系数或跑 test。

## 5. 实验边界与预期耗时

本包不会重新训练；真实全量运行时长尚未实测。`status.json` 会分开记录输入校验、前缀构造、模型前向和统计所耗时间。前一轮 A0 只处理首次 KC，因此其 77 秒不能作为本次全体验证预测的预计耗时。

原始数据仍采用 `row_immediate_assumption`，`feedback_boundaries_verified=false`。这是沿用此前已验收的在线评测假设；排除同时间评分行的敏感性分析不会改变已经回放的历史。
