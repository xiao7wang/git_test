"""Synthetic A1 tests. Never reads private server records or test results."""
import argparse
from pathlib import Path
import copy
import os
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch

from scale_core import (MODES, build_context, check_reference, import_clean,
                        predict_modes, probe, read_json, save, sha, summarize)
from run_probe import ROOT, run_job

PROJECT = None
DEVICE = "cpu"
MODEL = None
STATE = None
METRIC = None


def fixture():
    # student, item, response, time, split; item 0,2 share KC 0.
    rows = [(0,0,1,0,0),(0,1,0,1,0),(0,2,1,2,0),(0,0,0,3,1),(0,1,1,3,1),
            (0,2,0,4,1),(0,0,1,5,2),
            (1,1,0,0,0),(1,0,1,1,0),(1,0,0,2,1),(1,3,1,3,1),(1,2,1,4,2),
            (2,0,1,0,0),(2,0,0,1,1),(2,1,1,2,1),(2,3,0,3,1),(2,0,0,4,2)]
    raw = np.array(rows, dtype=np.int64)
    x = {"student_idx": raw[:,0].astype(np.int32), "item_idx": raw[:,1].astype(np.int32),
         "label": raw[:,2].astype(np.float32), "timestamp": raw[:,3].astype(np.float64),
         "split": raw[:,4].astype(np.int32), "item_q": np.eye(3, dtype=bool)[[0,1,0,2]],
         "kc_count_before": np.empty(len(raw), np.float32),
         "student_count_before": np.empty(len(raw), np.int32)}
    ucounts, kcounts = {}, {}
    for i, (u, item) in enumerate(zip(x["student_idx"], x["item_idx"])):
        kc = int(x["item_q"][item].argmax())
        x["student_count_before"][i] = ucounts.get(u, 0)
        x["kc_count_before"][i] = kcounts.get((u,kc), 0)
        ucounts[u] = ucounts.get(u, 0) + 1
        kcounts[u,kc] = kcounts.get((u,kc), 0) + 1
    return x


def model():
    torch.manual_seed(13)
    m = MODEL(3, 4, 3, variant="unit_write", ncd_hidden_dim=8).to(DEVICE)
    m.eval().requires_grad_(False)
    return m


@torch.inference_mode()
def sequential(m, arrays, chunk_size=None):
    results, final_states = [], {}
    users = sorted(set(arrays["student_idx"]))
    for u in users:
        indices = np.flatnonzero((arrays["student_idx"] == u) & (arrays["split"] <= 1))
        state = m.init_state(1, DEVICE)
        width = len(indices) if chunk_size is None else chunk_size
        for start in range(0, len(indices), width):
            for i in indices[start:start+width]:
                student = torch.tensor([u], device=DEVICE)
                item = torch.tensor([int(arrays["item_idx"][i])], device=DEVICE)
                q = torch.tensor(arrays["item_q"][arrays["item_idx"][i]:arrays["item_idx"][i]+1],
                                 dtype=torch.float32, device=DEVICE)
                pred = m.predict(state, student, item, q)
                if arrays["split"][i] == 1:
                    results.append((int(i), pred["probability"].item()))
                label = torch.tensor([float(arrays["label"][i])], device=DEVICE)
                state = m.observe(state, q, label, pred["difficulty_scalar"],
                                  torch.tensor([True], device=DEVICE))
        final_states[u] = (state.positive.cpu().numpy(), state.negative.cpu().numpy())
    return dict(results), final_states


def reference_frame(m, arrays, context):
    original, _ = sequential(m, arrays)
    f = pd.DataFrame({key: context[key] for key in ("record_idx", "student_idx", "item_idx",
                      "label", "timestamp", "kc_count_before", "student_count_before")})
    f["split"] = 1
    f["probability"] = np.array([original[int(i)] for i in f.record_idx], np.float32)
    return f


class ScaleTests(unittest.TestCase):
    def setUp(self):
        self.x = fixture()
        self.m = model()
        self.c = build_context(self.x, 3, 4, 3)
        self.ref = reference_frame(self.m, self.x, self.c)

    def test_prefix_and_future_label_permissions(self):
        a = self.c
        np.testing.assert_array_equal(a["positive"]+a["negative"], a["kc_count_before"])
        altered = copy.deepcopy(self.x)
        altered["label"][altered["split"] == 2] = 1-altered["label"][altered["split"] == 2]
        b = build_context(altered, 3, 4, 3)
        for name in ("positive", "negative", "kc_count_before", "student_count_before", "label"):
            np.testing.assert_array_equal(a[name], b[name])
        idx = np.flatnonzero((altered["student_idx"] == 0) & (altered["split"] == 1))[0]
        altered["label"][idx] = 1-altered["label"][idx]
        after = build_context(altered, 3, 4, 3)
        row = np.flatnonzero(a["record_idx"] == idx)[0]
        self.assertEqual((a["positive"][row], a["negative"][row]),
                         (after["positive"][row], after["negative"][row]))
        self.assertNotEqual((a["positive"][row+2], a["negative"][row+2]),
                            (after["positive"][row+2], after["negative"][row+2]))

    def test_native_full_replay_and_chunk_equivalence(self):
        check_reference(self.ref, self.c, METRIC(self.ref.label, self.ref.probability.astype(np.float32)))
        full, states = sequential(self.m, self.x)
        for size in (1, 2, 17, 50):
            chunked, new_states = sequential(self.m, self.x, chunk_size=size)
            self.assertEqual(full, chunked)
            for u in states:
                for old, new in zip(states[u], new_states[u]):
                    np.testing.assert_array_equal(old, new)
        frame, gate = probe(self.m, STATE, self.c, self.ref, np.arange(self.c["valid_count"]), 3, DEVICE)
        self.assertTrue(gate["success"])
        self.assertLessEqual(gate["native_vs_reference"], 1e-6)
        self.assertTrue(np.all(frame.loc[frame.kc_count_before == 0,
                                            [mode+"_probability" for mode in MODES]].nunique(axis=1) == 1))

    def test_long_sequence_crosses_chunk17_and50(self):
        rows = []
        for t in range(83):
            rows.append((0, [0, 2, 1, 3][t % 4], (t * 7 + 1) % 3 != 0,
                         float(t // 2), 0 if t < 53 else 1))
        raw = np.asarray(rows)
        x = {"student_idx": raw[:,0].astype(np.int32), "item_idx": raw[:,1].astype(np.int32),
             "label": raw[:,2].astype(np.float32), "timestamp": raw[:,3].astype(np.float64),
             "split": raw[:,4].astype(np.int32), "item_q": self.x["item_q"].copy(),
             "kc_count_before": np.empty(len(raw),np.float32),
             "student_count_before": np.arange(len(raw),dtype=np.int32)}
        counts = {}
        for i, item in enumerate(x["item_idx"]):
            kc = int(x["item_q"][item].argmax())
            x["kc_count_before"][i] = counts.get(kc,0)
            counts[kc] = counts.get(kc,0)+1
        context = build_context(x, 3, 4, 3)
        full, state = sequential(self.m,x)
        self.assertEqual(len(full),30)
        for chunk in (17,50):
            other, final = sequential(self.m,x,chunk_size=chunk)
            self.assertEqual(full,other)
            for a,b in zip(state[0],final[0]):
                np.testing.assert_array_equal(a,b)
        reference = reference_frame(self.m,x,context)
        frame,gate = probe(self.m,STATE,context,reference,np.arange(len(full)),17,DEVICE)
        self.assertTrue(gate["success"])
        np.testing.assert_allclose(frame.u0_probability.to_numpy(),reference.probability.to_numpy(),atol=1e-6)

    def test_all_five_modes_and_real_counted_updates(self):
        valid = np.arange(self.c["valid_count"])
        frame, _ = probe(self.m, STATE, self.c, self.ref, valid, 2, DEVICE)
        for row in frame.itertuples():
            u = torch.tensor([row.student_idx], device=DEVICE)
            it = torch.tensor([row.item_idx], device=DEVICE)
            q = torch.tensor(self.x["item_q"][row.item_idx:row.item_idx+1],
                             dtype=torch.float32, device=DEVICE)
            p = torch.tensor([row.positive], dtype=torch.float32, device=DEVICE)
            n = torch.tensor([row.negative], dtype=torch.float32, device=DEVICE)
            y = predict_modes(self.m, STATE, u, it, q, p, n)
            for mode in MODES:
                self.assertLess(abs(y[mode].item()-getattr(row, mode+"_probability")), 1e-7)
        # P=1,N=0: a doubled write cannot be reproduced by a constant x2 logit gain.
        positive = frame[(frame.positive == 1) & (frame.negative == 0)]
        self.assertGreater(len(positive), 0)
        self.assertTrue(np.any(np.abs(positive.w_double_probability-positive.r_double_probability) > 1e-6))

    def test_invalid_q_and_count_corruption_rejected(self):
        x = copy.deepcopy(self.x)
        x["item_q"][0,1] = True
        with self.assertRaises(ValueError): build_context(x, 3, 4, 3)
        x = copy.deepcopy(self.x)
        x["kc_count_before"][4] = 99
        with self.assertRaises(ValueError): build_context(x, 3, 4, 3)
        f = self.ref.copy()
        f.loc[0,"label"] = 1-f.loc[0,"label"]
        with self.assertRaises(ValueError): check_reference(f, self.c, METRIC(self.ref.label, self.ref.probability))

    def test_null_comparison_bootstrap(self):
        f, _ = probe(self.m, STATE, self.c, self.ref, np.arange(self.c["valid_count"]), 4, DEVICE)
        for name in MODES[1:]:
            f[name+"_probability"] = f["u0_probability"]
        summary = summarize(f, METRIC, reps=40)
        for group in summary["groups"].values():
            for comparison in group["comparisons"].values():
                if group["n"]:
                    self.assertEqual(comparison["delta_nll"], 0.)
                    self.assertEqual(comparison["event_interval"]["ci95"], [0.,0.])
                else:
                    self.assertIsNone(comparison["delta_nll"])

    def test_paired_macro_and_bootstrap_against_explicit_students(self):
        frame, _ = probe(self.m, STATE, self.c, self.ref, np.arange(self.c["valid_count"]), 4, DEVICE)
        result = summarize(frame, METRIC, reps=60)["groups"]["nonfirst_kc"]["comparisons"]["w_double_minus_u0"]
        f = frame.loc[frame.kc_count_before > 0]
        y = f.label.to_numpy()
        p = f.w_double_probability.to_numpy()
        q = f.u0_probability.to_numpy()
        d = (-y*np.log(p)-(1-y)*np.log1p(-p)) - (-y*np.log(q)-(1-y)*np.log1p(-q))
        users = np.unique(frame.student_idx.to_numpy())
        expected = float(d.mean())
        per_user = {u: d[f.student_idx.to_numpy() == u] for u in users}
        expected_macro = float(np.mean([v.mean() for v in per_user.values() if len(v)]))
        self.assertAlmostEqual(result["delta_nll"], expected)
        self.assertAlmostEqual(result["delta_student_macro_nll"], expected_macro)
        rng = np.random.default_rng(20260929)
        event_draws, macro_draws = [], []
        for _ in range(60):
            selected = users[rng.integers(len(users), size=len(users))]
            chunks = [per_user[u] for u in selected if len(per_user[u])]
            event_draws.append(np.concatenate(chunks).mean() if chunks else np.nan)
            macro_draws.append(np.mean([v.mean() for v in chunks]) if chunks else np.nan)
        for key, values in (("event_interval",event_draws),("macro_interval",macro_draws)):
            a = np.asarray(values)
            a = a[np.isfinite(a)]
            np.testing.assert_allclose(result[key]["ci95"], np.quantile(a,[.025,.975]), atol=1e-14)

    def test_frozen_job_end_to_end_and_overwrite_guard(self):
        with tempfile.TemporaryDirectory() as td:
            work = Path(td)
            project, run, data, export = [work/n for n in ("project", "run", "data", "export")]
            for path in (project, run, export): path.mkdir()
            data = project/"data"/"fake"
            data.mkdir(parents=True)
            evaldir = export/"fake_job"/"attempt_001"
            evaldir.mkdir(parents=True)
            np.savez_compressed(data/"records.npz", **self.x)
            save(data/"vocabulary.json", {"students": [0,1,2]})
            save(data/"manifest.json", {"feedback_protocol": "row_immediate_assumption",
                                             "feedback_boundaries_verified": False})
            (export/"export_plan.json").write_text("{}", encoding="utf-8")
            (export/"completed.json").write_text("{}", encoding="utf-8")
            self.ref.to_csv(evaldir/"predictions.csv", index=False)
            for name in ("metrics.json", "subgroup_metrics.json"):
                save(evaldir/name, {})
            policy = copy.deepcopy(read_json(ROOT/"accepted_inputs.json"))
            pins = policy["source_pins"]
            for name in pins:
                source = PROJECT/name
                target = project/name
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(source.read_bytes())
            config = {"num_students":3,"num_items":4,"num_knowledges":3,
                      "variant":"unit_write","ncd_hidden_dim":8}
            fingerprint = sha(data/"manifest.json")
            torch.save({"model_config":config,"model_state":self.m.cpu().state_dict(),
                        "epoch":1,"data_fingerprint":fingerprint,"source_code":pins},run/"best_model.pt")
            ckhash = sha(run/"best_model.pt")
            cfg = {"model_config":config,"data_fingerprint":fingerprint,"source_code":pins,
                   "args":dict(policy["training_settings"]["assist"],seed=1)}
            save(run/"run_config.json", cfg)
            save(run/"status.json", {"status":"complete","checkpoint_sha256":ckhash,"best_epoch":1})
            save(run/"history.json", [{"epoch":1,"valid":{"auc":.7}}])
            save(evaldir/"evaluation.json", {"checkpoint_sha256":ckhash,"epoch":1,
                 "data_fingerprint":fingerprint,"source_code":pins,
                 "args":{"view":"valid","update_targets":1,"ack_row_feedback":True,
                         "batch_size":8,"chunk_size":100}})
            name = "assist_unit_write_seed1"
            job = policy["jobs"][name]
            job.update({"name":name,"run":str(run),"checkpoint":str(run/"best_model.pt"),
                        "checkpoint_sha256":ckhash,"data_dir":str(data),
                        "data_fingerprint":fingerprint,"best_epoch":1,"n":len(self.ref),
                        "metadata_hashes":{n:sha(run/n) for n in ("run_config.json","status.json","history.json")},
                        "expected_validation":METRIC(self.ref.label, self.ref.probability),
                        "export":{"evaluation_dir":"fake_job/attempt_001","verification":{
                            "files":{n:sha(evaldir/n) for n in ("predictions.csv","metrics.json",
                                    "subgroup_metrics.json","evaluation.json")}}}})
            policy["jobs"] = {name:job}
            policy["data"]["assist"].update({"fingerprint":fingerprint,"records_sha256":sha(data/"records.npz"),
                                             "vocabulary_sha256":sha(data/"vocabulary.json"),"n":len(self.ref)})
            policy["export_plan_sha256"] = sha(export/"export_plan.json")
            policy["completed_sha256"] = sha(export/"completed.json")
            from argparse import Namespace
            args = Namespace(project_dir=str(project),export_root=str(export),job=name,
                             output_dir=str(work/"outputs"/"run1"),device=DEVICE,batch_size=3,
                             threads=2,max_students=0,bootstrap_reps=20,ack_row_feedback=True)
            result = run_job(args, policy, output_base=work/"outputs")
            self.assertEqual(result["status"],"complete")
            self.assertEqual(result["n"],len(self.ref))
            self.assertTrue((work/"outputs"/"run1"/"predictions.csv.gz").is_file())
            with self.assertRaises(ValueError):
                run_job(args, policy, output_base=work/"outputs")


def main():
    global PROJECT, DEVICE, MODEL, STATE, METRIC
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--device", choices=("cpu","cuda"), default="cpu")
    p.add_argument("--report")
    a = p.parse_args()
    PROJECT, DEVICE = Path(a.project_dir), a.device
    policy = read_json(ROOT/"accepted_inputs.json")
    MODEL, STATE = import_clean(PROJECT, policy["source_pins"])
    import importlib.util
    spec = importlib.util.spec_from_file_location("scale_test_clean_metrics", PROJECT/"src/metrics.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    METRIC = module.compute_metrics
    torch.set_num_threads(2)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ScaleTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    report = {"success":result.wasSuccessful(),"tests_run":result.testsRun,
              "failures":[str(test) for test,_ in result.failures],
              "errors":[str(test) for test,_ in result.errors],
              "device":DEVICE,"torch":str(torch.__version__),"skipped":[str(test) for test,_ in result.skipped]}
    if a.report:
        save(a.report, report)
    print(report, flush=True)
    if not result.wasSuccessful(): raise SystemExit(1)


if __name__ == "__main__": main()
