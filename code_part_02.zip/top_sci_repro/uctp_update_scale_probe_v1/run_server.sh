#!/usr/bin/env bash
set -euo pipefail
TASK_PYTHON=/home/wangxiao/miniconda3/envs/yydw/bin/python
TASK_PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TASK_RUN_NAME="${1:-server_a1_01}"
if [[ ! "$TASK_RUN_NAME" =~ ^[A-Za-z0-9_]+$ ]]; then
    printf '%s\n' 'Run name must use only letters, digits, underscores.'
    exit 2
fi
exec env CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 \
    "$TASK_PYTHON" -B -u "$TASK_PACKAGE_DIR/run_suite.py" \
    --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research \
    --export-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/outputs/server_seed12_valid_export_20260929_01 \
    --output-root "$TASK_PACKAGE_DIR/outputs/$TASK_RUN_NAME" \
    --device cuda --full --ack-row-feedback
