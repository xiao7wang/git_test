#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_name="${1:-server_history_weight_01}"
if [[ ! "$task_name" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid run name' >&2; exit 2; fi
task_base=/home/wangxiao/QCCDM
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_data="$task_base/top_sci_repro/uctp_cd_clean_research/data/assist_full"
task_out="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
mkdir -p "$task_root/outputs"
if [[ -e "$task_out" || -e "$task_log" ]]; then echo 'Output or launch log exists; refusing overwrite.' >&2; exit 2; fi
( set -o noclobber; : > "$task_log" ) || exit 2
exec > >(tee -a "$task_log") 2>&1
trap 'task_code=$?; printf "FAILED: exit=%s; see launch log and status.json\n" "$task_code" >&2' ERR
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 PYTHONPATH="$task_root"
cd "$task_root"
printf 'Starting %s at %s\n' "$task_name" "$(date --iso-8601=seconds)"
echo 'Stage 1/4: verify release files and space'
"$task_python" -B -m audit.server --verify-only
"$task_python" -B -c 'import shutil,sys; f=shutil.disk_usage(sys.argv[1]).free; print("Free bytes:",f,"Required:",134217728,flush=True); sys.exit(f<134217728)' "$task_root/outputs"
echo 'Stage 2/4: synthetic contracts'
"$task_python" -B checks/verify.py
echo 'Stage 3/4: train-only history-weight and data-source audit'
"$task_python" -B -m audit.server --data-dir "$task_data" --output-dir "$task_out" --research-root "$task_base"
echo 'Stage 4/4: output and status are complete'
printf 'SUCCESS: %s/history_weight_results.zip\n' "$task_out"
