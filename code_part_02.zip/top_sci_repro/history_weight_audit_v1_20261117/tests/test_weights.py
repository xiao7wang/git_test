import math
import unittest

import numpy as np

from audit import weights


def naive_histories(cross, gaps, first, retention):
    """Deliberately enumerate historical contributions; no recursive update."""
    stage, elapsed, start = [], [], 0
    for i in range(len(first)):
        if first[i]:
            start = i
        left_stage = 0.0
        left_time = 0.0
        for j in range(start, i):
            number = sum(cross[j + 1:i + 1])
            hours = sum(gaps[j + 1:i + 1])
            left_stage += retention ** number
            left_time += 2 ** (-hours / 168.0)
        stage.append(left_stage)
        elapsed.append(left_time)
    return np.array(stage), np.array(elapsed)


class HistoryContracts(unittest.TestCase):
    def test_group_crossing_and_equal_time_order(self):
        # Global boundary includes an intervening event of another KC.
        student = np.array([0, 0, 0, 0, 1, 1])
        kc = np.array([0, 1, 0, 0, 0, 0])
        time = np.array([0, 10 * 3600, 10 * 3600, 21 * 3600, 0, 3600], dtype=float)
        split = np.array([0, 0, 0, 1, 0, 1])
        order = weights.prepare_ordered(student, kc, time, split, np.arange(6))
        self.assertEqual(order['original_position'].tolist(), [0, 2, 3, 1, 4, 5])
        self.assertEqual(order['first'].tolist(), [True, False, False, True, True, False])
        self.assertEqual(order['crossings'].tolist(), [0, 0, 1, 0, 0, 0])
        self.assertEqual(order['gaps_hours'].tolist(), [0., 10., 11., 0., 0., 1.])

    def test_recursion_matches_independent_pairwise_sum(self):
        first = np.array([True, False, False, False, True, False, False])
        cross = np.array([0, 0, 1, 3, 0, 2, 0])
        gaps = np.array([0., 1., 30., 500., 0., 170., 0.])
        for r in (0.0, 0.23, 0.5, 0.99, 1.0):
            actual = weights.history_totals(cross, gaps, first, r)
            expected = naive_histories(cross, gaps, first, r)
            np.testing.assert_allclose(actual[0], expected[0], atol=1e-12, rtol=0)
            np.testing.assert_allclose(actual[1], expected[1], atol=1e-12, rtol=0)

    def test_calibrations_exclude_development(self):
        first = np.array([True, False, False, False])
        cross = np.array([0, 1, 2, 1])
        gap = np.array([0., 168., 336., 168.])
        split = np.array([0, 0, 0, 1])
        a = weights.calibrate(cross, gap, first, split)
        cross[-1], gap[-1] = 999, 999999.
        b = weights.calibrate(cross, gap, first, split)
        self.assertEqual(a['transition']['retention'], b['transition']['retention'])
        self.assertEqual(a['cumulative']['retention'], b['cumulative']['retention'])
        self.assertAlmostEqual(a['transition']['retention'], .5, places=9)
        self.assertAlmostEqual(a['cumulative']['retention'], .5, places=9)

    def test_infeasible_and_unidentifiable_are_reported(self):
        first = np.array([True, False, False])
        split = np.array([0, 0, 0])
        # No crossed boundary: an all-ones stage rule cannot match time decay.
        a = weights.calibrate(np.array([0, 0, 0]), np.array([0., 168., 168.]), first, split)
        self.assertEqual(a['transition']['status'], 'infeasible')
        self.assertEqual(a['cumulative']['status'], 'infeasible')
        b = weights.calibrate(np.array([0, 0, 0]), np.array([0., 0., 0.]), first, split)
        self.assertEqual(b['transition']['status'], 'not_identifiable')
        self.assertEqual(b['cumulative']['status'], 'not_identifiable')

    def test_history_rejects_invalid_order(self):
        with self.assertRaises(ValueError):
            weights.prepare_ordered(np.array([0, 0]), np.array([0, 0]),
                                    np.array([100., 0.]), np.array([0, 0]), np.array([0, 1]))
        with self.assertRaises(ValueError):
            weights.prepare_ordered(np.array([0, 0]), np.array([0, 0]),
                                    np.array([0., 1.]), np.array([1, 0]), np.array([0, 1]))

    def test_selects_only_expected_fields_and_rejects_q_errors(self):
        # A poison object proves the selection function never reads labels.
        class Poison:
            def __array__(self, *args, **kwargs):
                raise AssertionError('labels must not be loaded')
        arrays = {'student_idx': np.array([0, 0, 1]), 'item_idx': np.array([0, 0, 0]),
                  'split': np.array([0, 1, 2]), 'timestamp': np.array([0., 1., 2.]),
                  'item_q': np.array([[1, 0]]), 'label': Poison()}
        selected = weights.select_rows(arrays, development_users={0})
        self.assertEqual(selected['record_idx'].tolist(), [0, 1])
        self.assertEqual(selected['kc'].tolist(), [0, 0])
        arrays['item_q'] = np.array([[1, 1]])
        with self.assertRaises(ValueError):
            weights.select_rows(arrays, development_users={0})

    def test_random_sequences_match_brute_force(self):
        rng = np.random.default_rng(20261117)
        for _ in range(20):
            n = 18
            first = rng.random(n) < .2
            first[0] = True
            cross = rng.integers(0, 4, size=n)
            cross[first] = 0
            gap = rng.random(n) * 250.
            gap[first] = 0.
            actual = weights.history_totals(cross, gap, first, .63)
            expected = naive_histories(cross, gap, first, .63)
            np.testing.assert_allclose(actual[0], expected[0], atol=1e-12, rtol=0)
            np.testing.assert_allclose(actual[1], expected[1], atol=1e-12, rtol=0)


if __name__ == '__main__':
    unittest.main()
