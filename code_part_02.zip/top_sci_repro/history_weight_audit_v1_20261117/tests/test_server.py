import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np

from audit import server
from audit.inventory import inspect_sources
from audit.weights import calibrate, prepare_ordered, select_rows


class PackageContracts(unittest.TestCase):
    def test_end_to_end_keeps_label_array_unread_and_outputs_aggregates(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data = root / 'prepared'
            data.mkdir()
            original = {'student_idx': np.array([0, 0, 0, 1, 1, 1], dtype=np.int32),
                        'item_idx': np.zeros(6, dtype=np.int32),
                        'split': np.array([0, 0, 1, 0, 0, 1], dtype=np.int32),
                        'timestamp': np.array([0., 604800., 608400., 0., 604800., 608400.]),
                        'item_q': np.array([[1]], dtype=bool),
                        # Object arrays cannot be read with allow_pickle=False.
                        'label': np.array(['secret-never-export'], dtype=object)}
            np.savez_compressed(data / 'records.npz', **original)
            (data / 'vocabulary.json').write_text('{}\n', encoding='utf-8')
            manifest = {'schema_version': 1, 'records_sha256': server.sha(data / 'records.npz'),
                        'vocabulary_sha256': server.sha(data / 'vocabulary.json'), 'sources': []}
            (data / 'manifest.json').write_text(json.dumps(manifest), encoding='utf-8')
            fingerprint = server.sha(data / 'manifest.json')
            selected = select_rows(original, {0, 1})
            order = prepare_ordered(selected['student'], selected['kc'], selected['timestamp'],
                                    selected['split'], selected['record_idx'])
            p = np.arange(6)
            prior = p - np.maximum.accumulate(np.where(order['first'], p, 0))
            take = np.flatnonzero(order['split'] == 1)
            take = take[np.argsort(order['record_idx'][take])]
            values = np.column_stack((order['record_idx'][take], order['student'][take], order['kc'][take],
                                      prior[take], order['starts_session'][take], order['crossings'][take])).astype('<i8')
            identity = hashlib.sha256(values.tobytes()).hexdigest()
            c = calibrate(order['crossings'], order['gaps_hours'], order['first'], order['split'])
            patches = {'DATA_FINGERPRINT': fingerprint, 'DEV_IDENTITY_SHA': identity,
                       'EXPECTED_TRAIN': 4, 'EXPECTED_DEV': 2, 'EXPECTED_STUDENTS': 2,
                       'EXPECTED_TRAIN_REPEATS': 2, 'EXPECTED_TRANSITION_R': c['transition']['retention'],
                       'EXPECTED_TRANSITION_MEAN': c['transition']['target']}
            output = root / 'out'
            with patch.multiple(server, **patches), patch.object(server, 'development_users', return_value={0, 1}):
                result = server.run(data, output, root, {'manifest_sha256': 'synthetic'})
                with self.assertRaises(FileExistsError):
                    server.run(data, output, root, {'manifest_sha256': 'synthetic'})
                with (data / 'records.npz').open('ab') as stream:
                    stream.write(b'drift')
                with self.assertRaisesRegex(ValueError, 'hash mismatch'):
                    server.load_prepared(data)
            self.assertEqual(server.sha(data / 'manifest.json'), fingerprint)
            status = json.loads((output / 'status.json').read_text(encoding='utf-8'))
            self.assertEqual(status['status'], 'complete')
            self.assertFalse(status['labels_loaded'])
            with zipfile.ZipFile(result) as z:
                self.assertIsNone(z.testzip())
                self.assertEqual(set(z.namelist()), {'calibration.json', 'analysis.json', 'inventory.json',
                                                     'provenance.json', 'report.md', 'manifest.json'})
                manifest = json.loads(z.read('manifest.json'))['files']
                for name, digest in manifest.items():
                    self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(), digest)
                    self.assertNotIn(b'secret-never-export', z.read(name))
                analysis = json.loads(z.read('analysis.json'))
                self.assertEqual(analysis['groups']['train']['repeated_events'], 2)
                self.assertEqual(analysis['groups']['development_descriptive']['repeated_events'], 2)

    def test_inventory_reads_headers_only_and_marks_independence_unknown(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            folder = root / 'top_sci_repro' / 'unified_experiments' / 'data' / 'assist'
            folder.mkdir(parents=True)
            (folder / 'interactions_raw.csv').write_text('student_id,score\nsecret-student,1\n', encoding='utf-8')
            result = inspect_sources(root, {'sources': []})
            entry = result['named_locations']['unified_assist_interactions_raw.csv']
            self.assertEqual(entry['header'], ['student_id', 'score'])
            self.assertNotIn('secret-student', json.dumps(result))
            self.assertFalse(result['independent_dataset_verified'])
            self.assertFalse(result['feedback_boundaries_verified'])


if __name__ == '__main__':
    unittest.main()
