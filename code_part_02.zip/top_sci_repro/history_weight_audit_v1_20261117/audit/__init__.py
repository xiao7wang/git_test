"""Read-only history-weight and source-provenance audit."""
