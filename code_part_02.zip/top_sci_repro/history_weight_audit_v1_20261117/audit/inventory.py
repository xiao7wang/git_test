"""Bounded metadata-only checks of already-known data-source paths."""
from __future__ import annotations

import csv
import os
from pathlib import Path


def _describe(path, root, header=False):
    entry = {'path': str(path), 'exists': os.path.lexists(path), 'is_symlink': path.is_symlink()}
    if not entry['exists']:
        return entry
    try:
        if entry['is_symlink']:
            entry['link_target'] = os.readlink(path)
        resolved = path.resolve(strict=False)
        entry['resolved_path'] = str(resolved)
        entry['target_exists'] = resolved.exists()
        entry['within_research_root'] = resolved.is_relative_to(root)
        if resolved.is_file():
            entry['bytes'] = resolved.stat().st_size
        elif resolved.is_dir():
            entry['kind'] = 'directory'
        if header and resolved.is_file() and entry['within_research_root']:
            with resolved.open('r', encoding='utf-8-sig', errors='replace', newline='') as stream:
                line = stream.readline(65537)
            if len(line) > 65536:
                entry['header_error'] = 'header exceeds 65536 characters'
            else:
                entry['header'] = next(csv.reader([line]), [])
    except (OSError, ValueError, csv.Error) as exc:
        entry['inspection_error'] = f'{type(exc).__name__}: {exc}'
    return entry


def inspect_sources(root, prepared_manifest):
    """Inspect named locations only: no recursive search, raw rows, or pickle loads."""
    root = Path(root).resolve()
    base = root / 'top_sci_repro'
    locations = []
    for dataset in ('assist', 'ednet'):
        folder = base / 'unified_experiments' / 'data' / dataset
        for name in ('config.json', 'interactions_raw.csv', 'q.csv'):
            locations.append((f'unified_{dataset}_{name}', folder / name, name.endswith('.csv')))
        for split in ('train', 'valid'):
            locations.append((f'unified_{dataset}_{split}', base / 'unified_experiments' / 'splits' / dataset / f'{split}.csv', True))
    ednet = base / 'unified_experiments' / 'data' / 'ednet'
    locations.append(('ednet_time_table', ednet / 'ednet_time_oursTotalData.csv', True))
    raw = root / 'qccdm改进代码' / 'data_raw' / 'ednet'
    for name in ('EdNet-Contents.zip', 'EdNet-KT1.zip', 'EdNet-KT2.zip', 'EdNet-KT3.zip'):
        locations.append((name, raw / name, False))
    for name in ('KT1', 'KT2', 'KT3'):
        locations.append((f'raw_{name}_directory', raw / name, False))
    for user in ('u1.csv', 'u10.csv', 'u100.csv'):
        locations.append((f'kt1_structure_{user}', raw / 'KT1' / 'KT1' / user, True))
    locations.append(('historical_metadata_pickle_not_loaded', root / 'qccdm改进代码' / 'data' / 'ednet_kt1_time' / 'meta.pkl', False))
    found = {key: _describe(path, root, header) for key, path, header in locations}
    source_records = []
    for source in prepared_manifest.get('sources', []):
        if not isinstance(source, dict) or not isinstance(source.get('path'), str):
            continue
        path = Path(source['path'])
        # Only inspect a recorded path whose resolved target stays within the research root.
        inspect_header = path.suffix.lower() == '.csv' and path.name.lower() != 'test.csv'
        source_records.append({'recorded_sha256': source.get('sha256'),
                               **_describe(path, root, inspect_header)})
    return {'scope': 'explicit known locations and prepared-manifest sources, no recursive search',
            'named_locations': found, 'prepared_manifest_sources': source_records,
            'feedback_boundaries_verified': False, 'raw_to_current_identity_verified': False,
            'independent_dataset_verified': False,
            'note': 'existence, symlink targets and CSV headers do not establish lineage, real feedback timing or independence; missing candidates do not prove absence'}
