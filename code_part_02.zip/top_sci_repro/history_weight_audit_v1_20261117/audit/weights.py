"""Label-free, past-only cumulative history and training-only calibration."""
from __future__ import annotations

import math
import numpy as np


def select_rows(arrays, development_users):
    """Select training and authorized development rows without reading labels."""
    required = ('student_idx', 'item_idx', 'split', 'timestamp', 'item_q')
    if any(k not in arrays for k in required):
        raise ValueError('required input array is missing')
    student, item, split, timestamp = (np.asarray(arrays[k]) for k in required[:4])
    q = np.asarray(arrays['item_q'])
    n = len(student)
    if not n or any(a.ndim != 1 or len(a) != n for a in (student, item, split, timestamp)):
        raise ValueError('record arrays must be nonempty equal-length vectors')
    if not all(np.issubdtype(a.dtype, np.integer) for a in (student, item, split)):
        raise ValueError('student, item and split must be integer arrays')
    if not np.isin(split, [0, 1, 2]).all():
        raise ValueError('unsupported split code')
    if q.ndim != 2 or min(q.shape) < 1 or not np.isin(q, [0, 1]).all() or not (q.sum(axis=1) == 1).all():
        raise ValueError('Q must be a single-KC binary matrix')
    dev = np.asarray(sorted(set(int(u) for u in development_users)), dtype=np.int64)
    chosen = (split == 0) | ((split == 1) & np.isin(student, dev))
    idx = np.flatnonzero(chosen)
    if not len(idx):
        raise ValueError('no permitted records')
    u, items, s, t = student[idx], item[idx], split[idx], timestamp[idx].astype(np.float64)
    if (u < 0).any() or (items < 0).any() or (items >= len(q)).any() or not np.isfinite(t).all():
        raise ValueError('invalid selected event identity or timestamp')
    return {'student': u.astype(np.int64), 'kc': np.argmax(q, axis=1)[items].astype(np.int64),
            'timestamp': t, 'split': s.astype(np.int8), 'record_idx': idx.astype(np.int64)}


def prepare_ordered(student, kc, timestamp, split, record_idx, threshold_hours=10.):
    """Order by student/KC/source-row while retaining global session boundaries."""
    student, kc, timestamp, split, record_idx = map(np.asarray, (student, kc, timestamp, split, record_idx))
    n = len(student)
    if not n or any(v.ndim != 1 or len(v) != n for v in (student, kc, timestamp, split, record_idx)):
        raise ValueError('selected record arrays are inconsistent')
    if not all(np.issubdtype(a.dtype, np.integer) for a in (student, kc, split, record_idx)):
        raise ValueError('identity, split and source order must be integer')
    if (student < 0).any() or (kc < 0).any() or not np.isin(split, [0, 1]).all():
        raise ValueError('invalid student, knowledge component, or split')
    if not np.isfinite(timestamp).all() or not math.isfinite(threshold_hours) or threshold_hours <= 0:
        raise ValueError('invalid timestamp or session threshold')
    if (np.diff(record_idx) <= 0).any() or (np.diff(student) < 0).any():
        raise ValueError('source order or student grouping invalid')
    same_student = student[1:] == student[:-1]
    if ((np.diff(timestamp) < 0) & same_student).any() or ((np.diff(split) < 0) & same_student).any():
        raise ValueError('student chronology or train/development ordering invalid')
    global_gap = np.zeros(n, dtype=np.float64)
    global_gap[1:] = np.where(same_student, np.diff(timestamp) / 3600., 0.)
    starts = np.zeros(n, dtype=bool)
    starts[1:] = same_student & (global_gap[1:] > threshold_hours)
    session = np.cumsum(starts, dtype=np.int64)
    order = np.lexsort((record_idx, kc, student))
    u, k, t, s, session = (v[order] for v in (student, kc, timestamp, split, session))
    first = np.r_[True, (u[1:] != u[:-1]) | (k[1:] != k[:-1])]
    crossing = np.zeros(n, dtype=np.int64)
    gap = np.zeros(n, dtype=np.float64)
    crossing[1:] = np.where(first[1:], 0, np.diff(session))
    gap[1:] = np.where(first[1:], 0., np.diff(t) / 3600.)
    if (crossing < 0).any() or (gap < 0).any() or ((np.diff(s) < 0) & ~first[1:]).any():
        raise ValueError('same-KC ordering is not causal')
    return {'first': first, 'crossings': crossing, 'gaps_hours': gap,
            'split': s, 'record_idx': record_idx[order], 'student': u, 'kc': k,
            'original_position': order, 'global_gap_hours': global_gap[order],
            'starts_session': starts[order]}


def _validate_history(crossings, gaps, first):
    k, g, f = np.asarray(crossings), np.asarray(gaps, dtype=np.float64), np.asarray(first, dtype=bool)
    if not len(k) or any(x.ndim != 1 or len(x) != len(k) for x in (k, g, f)):
        raise ValueError('history arrays must be nonempty and aligned')
    if not np.issubdtype(k.dtype, np.integer) or (k < 0).any() or not np.isfinite(g).all() or (g < 0).any():
        raise ValueError('history gaps or crossings invalid')
    if not f[0] or (k[f] != 0).any() or (g[f] != 0).any():
        raise ValueError('group starts must have zero gap and boundary count')
    return k.astype(np.int64, copy=False), g, f


def history_totals(crossings, gaps, first, retention):
    """Total prior-event weights for phase and elapsed-time rules, before each answer."""
    k, g, f = _validate_history(crossings, gaps, first)
    r = float(retention)
    if not math.isfinite(r) or not 0. <= r <= 1.:
        raise ValueError('retention must be within [0, 1]')
    factors = [r ** x for x in range(int(k.max()) + 1)]
    elapsed = np.exp2(-g / 168.).tolist()
    stage_out, time_out = [], []
    a = b = 0.
    for crossing, time_factor, is_first in zip(k.tolist(), elapsed, f.tolist()):
        if is_first:
            a = b = 0.
        else:
            a = (a + 1.) * factors[crossing]
            b = (b + 1.) * time_factor
        stage_out.append(a)
        time_out.append(b)
    return np.asarray(stage_out, dtype=np.float64), np.asarray(time_out, dtype=np.float64)


def _mean_stage(crossings, first, repeated, retention):
    factors = [retention ** x for x in range(max(crossings) + 1)]
    state = total = 0.
    for k, is_first in zip(crossings, first):
        if is_first:
            state = 0.
        else:
            state = (state + 1.) * factors[k]
            total += state
    return total / repeated


def _root(mean_function, target):
    low_value, high_value = mean_function(0.), mean_function(1.)
    tol = 1e-12 * max(1., abs(target), abs(low_value), abs(high_value))
    result = {'target': float(target), 'minimum': float(low_value), 'maximum': float(high_value),
              'retention': None, 'achieved': None}
    if target < low_value - tol or target > high_value + tol:
        return {'status': 'infeasible', **result}
    if abs(high_value - low_value) <= tol:
        return {'status': 'not_identifiable', **result}
    if abs(target - low_value) <= tol:
        r = 0.
    elif abs(target - high_value) <= tol:
        r = 1.
    else:
        lo, hi = 0., 1.
        for _ in range(38):
            mid = (lo + hi) / 2.
            if mean_function(mid) < target:
                lo = mid
            else:
                hi = mid
        r = (lo + hi) / 2.
    return {'status': 'matched', **result, 'retention': float(r), 'achieved': float(mean_function(r))}


def calibrate(crossings, gaps, first, split):
    """Select scalar retention from training timestamps only; no answer input."""
    k, g, f = _validate_history(crossings, gaps, first)
    s = np.asarray(split)
    if s.shape != k.shape or not np.isin(s, [0, 1]).all():
        raise ValueError('invalid selected splits')
    if ((np.diff(s) < 0) & ~f[1:]).any():
        raise ValueError('training may not follow development in a student/KC sequence')
    train = s == 0
    group = np.cumsum(f, dtype=np.int64)[train]
    train_first = np.r_[True, group[1:] != group[:-1]] if len(group) else np.array([], dtype=bool)
    if not len(group) or not np.array_equal(train_first, f[train]):
        raise ValueError('training history starts after a non-training event')
    tk, tg = k[train], g[train]
    repeated = ~train_first
    n = int(repeated.sum())
    if n == 0:
        empty = {'status': 'no_training_repeats', 'retention': None}
        return {'training_repeated_kc_events': 0, 'transition': empty.copy(), 'cumulative': empty.copy()}
    unique, counts = np.unique(tk[repeated], return_counts=True)
    target_one = float(np.exp2(-tg[repeated] / 168.).mean())
    def transition_mean(r):
        return float(np.dot(np.power(r, unique), counts) / n)
    transition = _root(transition_mean, target_one)
    _, time_history = history_totals(tk, tg, train_first, 1.)
    target_history = float(time_history[repeated].mean())
    crossings_list, first_list = tk.tolist(), train_first.tolist()
    def cumulative_mean(r):
        return _mean_stage(crossings_list, first_list, n, r)
    cumulative = _root(cumulative_mean, target_history)
    return {'training_repeated_kc_events': n, 'training_events': int(train.sum()),
            'training_zero_crossing_fraction': float(np.mean(tk[repeated] == 0)),
            'transition': transition, 'cumulative': cumulative,
            'method': 'train repeated-KC events only; no labels; weights conditional on past event timestamps',
            'limits': 'matches one scalar mean, not per-student, per-KC, sign, or full weight distribution'}
