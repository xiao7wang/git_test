"""Server entry for a locked, aggregate-only research audit; no model training."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import time
import zipfile
from pathlib import Path

import numpy as np

from .inventory import inspect_sources
from .weights import calibrate, history_totals, prepare_ordered, select_rows

ROOT = Path(__file__).resolve().parents[1]
DATA_FINGERPRINT = '18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e'
DEV_IDENTITY_SHA = '40ed1800ae857c9f9fb95aad9d4fb936e524006e3967e95ecdff720af491cf6d'
EXPECTED_TRAIN = 1847688
EXPECTED_DEV = 126854
EXPECTED_STUDENTS = 10036
EXPECTED_TRAIN_REPEATS = 1582031
EXPECTED_TRANSITION_R = 0.5784073920891049
EXPECTED_TRANSITION_MEAN = 0.898905739857931
SALT = 'decision-v1-20261105:'
REQUIRED_RELEASE = {'run_server.sh', 'README.md', 'audit/server.py', 'audit/weights.py',
                    'audit/inventory.py', 'tests/test_weights.py', 'checks/verify.py'}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, data):
    path = Path(path)
    pending = path.with_name(path.name + '.pending')
    pending.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    pending.replace(path)


def verify_release():
    path = ROOT / 'release_manifest.json'
    spec = json.loads(path.read_text(encoding='utf-8'))
    files = spec.get('files')
    if not isinstance(files, dict) or not REQUIRED_RELEASE.issubset(files):
        raise ValueError('release manifest missing required files')
    for name, digest in files.items():
        item = (ROOT / name).resolve()
        if not item.is_relative_to(ROOT) or not item.is_file() or sha(item) != digest:
            raise ValueError(f'release file missing or hash mismatch: {name}')
    return {'manifest_sha256': sha(path), 'file_count': len(files)}


def load_prepared(data_dir):
    """Hash-check original prepared inputs; do not load the stored label array."""
    data_dir = Path(data_dir).resolve()
    manifest_path = data_dir / 'manifest.json'
    if sha(manifest_path) != DATA_FINGERPRINT:
        raise ValueError('prepared-data manifest fingerprint differs from previous experiment')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('schema_version') != 1:
        raise ValueError('unsupported prepared-data schema')
    records, vocab = data_dir / 'records.npz', data_dir / 'vocabulary.json'
    before = records.stat()
    if sha(records) != manifest.get('records_sha256') or sha(vocab) != manifest.get('vocabulary_sha256'):
        raise ValueError('prepared records or vocabulary hash mismatch')
    names = ('student_idx', 'item_idx', 'split', 'timestamp', 'item_q')
    with np.load(records, allow_pickle=False) as archive:
        if not set(names).issubset(archive.files):
            raise ValueError('prepared archive is missing required structural arrays')
        arrays = {name: archive[name] for name in names}
    after = records.stat()
    if (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError('prepared records changed during verification or loading')
    return manifest, arrays


def development_users(arrays):
    values = np.unique(arrays['student_idx'][arrays['split'] == 1])
    return {int(x) for x in values if hashlib.sha256((SALT + str(int(x))).encode()).digest()[-1] % 2 == 0}


def check_identity(ordered):
    n = len(ordered['first'])
    pos = np.arange(n, dtype=np.int64)
    start = np.maximum.accumulate(np.where(ordered['first'], pos, 0))
    prior = pos - start
    take = np.flatnonzero(ordered['split'] == 1)
    take = take[np.argsort(ordered['record_idx'][take])]
    cols = (ordered['record_idx'][take], ordered['student'][take], ordered['kc'][take], prior[take],
            ordered['starts_session'][take], ordered['crossings'][take])
    canonical = np.column_stack(cols).astype('<i8', copy=False)
    digest = hashlib.sha256(canonical.tobytes(order='C')).hexdigest()
    if digest != DEV_IDENTITY_SHA:
        raise ValueError('development identity/history hash differs from the received prior result')
    if len(take) != EXPECTED_DEV or len(np.unique(ordered['student'][take])) != EXPECTED_STUDENTS:
        raise ValueError('development population differs from previous experiment')
    return {'dev_event_history_sha256': digest, 'development_events': len(take),
            'development_students': int(len(np.unique(ordered['student'][take]))),
            'columns': ['record_idx', 'student_idx', 'kc_idx', 'prior_kc_count', 'starts_session', 'same_kc_session_crossings'],
            'note': 'digest only; no individual identities or answer labels exported'}


def describe(x):
    x = np.asarray(x, dtype=np.float64)
    if not len(x):
        return {'n': 0, 'mean': None, 'quantiles': None}
    if not np.isfinite(x).all():
        raise ValueError('non-finite quantity in summary')
    return {'n': len(x), 'mean': float(x.mean()),
            'quantile_levels': [0., .1, .25, .5, .75, .9, .99, 1.],
            'quantiles': [float(v) for v in np.quantile(x, [0., .1, .25, .5, .75, .9, .99, 1.])]}


def analyze(ordered, calibration):
    k, gap, first, split = (ordered[x] for x in ('crossings', 'gaps_hours', 'first', 'split'))
    stage05, elapsed = history_totals(k, gap, first, .5)
    candidates = {'stage_0.5': (.5, stage05)}
    for key in ('transition', 'cumulative'):
        entry = calibration[key]
        if entry['status'] == 'matched':
            r = entry['retention']
            weights, same_time = history_totals(k, gap, first, r)
            if not np.array_equal(elapsed, same_time):
                raise AssertionError('time-history reference changed')
            candidates['stage_' + key] = (r, weights)
    result = {}
    for name, code in (('train', 0), ('development_descriptive', 1)):
        mask = (split == code) & ~first
        group = {'repeated_events': int(mask.sum()),
                 'repeated_students': int(len(np.unique(ordered['student'][mask]))),
                 'crossings_zero_fraction': float(np.mean(k[mask] == 0)) if mask.any() else None,
                 'same_kc_gap_hours': describe(gap[mask]),
                 'time_history_weight': describe(elapsed[mask]), 'stage_rules': {}}
        for label, (r, stage) in candidates.items():
            d = stage[mask] - elapsed[mask]
            group['stage_rules'][label] = {'retention': r, 'stage_history_weight': describe(stage[mask]),
                                           'stage_minus_time_history_weight': describe(d),
                                           'stage_greater_fraction': float(np.mean(d > 1e-12)) if len(d) else None,
                                           'stage_less_fraction': float(np.mean(d < -1e-12)) if len(d) else None}
        result[name] = group
    return {'groups': result, 'scope': 'history-weight distributions only; no answer values or prediction metrics',
            'caveat': 'matching a mean does not match distributions, correct/wrong components or student-level exposures'}


def make_report(calibration, analysis, inventory):
    lines = ['# 历史累计权重与数据来源审计', '',
             '本报告不训练模型，不读取答题标签，也不计算预测准确率。',
             '阶段边界按相邻事件时间超过 10 小时定义；连续时间半衰期为 168 小时。', '',
             '## 训练集匹配', '']
    for key, title in (('transition', '单次保留因子'), ('cumulative', '整段历史累计权重')):
        x = calibration[key]
        lines.append(f"- {title}：状态 {x['status']}；阶段保留系数 {x.get('retention')}；目标均值 {x.get('target')}；达到的均值 {x.get('achieved')}。")
    lines.extend(['', '## 重复知识点事件的历史累计权重', ''])
    for name, result in analysis['groups'].items():
        lines.append(f"- {name}：重复事件 {result['repeated_events']}；时间规则平均权重 {result['time_history_weight']['mean']}。")
        for label, row in result['stage_rules'].items():
            lines.append(f"  - {label}：阶段平均权重 {row['stage_history_weight']['mean']}；阶段减时间均值 {row['stage_minus_time_history_weight']['mean']}。")
    lines.extend(['', '数据来源盘点仅检查指定路径、链接和 CSV 表头；不证明原始身份链、反馈时点或数据独立。',
                  '开发集仅作权重分布描述，匹配系数只由训练集决定。',
                  '平均值配平不等于完整分布、学生或正误历史配平；结果不能解释为真实遗忘。', ''])
    return '\n'.join(lines)


def package(output, names):
    output = Path(output)
    entries = {name: sha(output / name) for name in names}
    pending = output / 'history_weight_results.zip.pending'
    final = output / 'history_weight_results.zip'
    if pending.exists() or final.exists():
        raise FileExistsError('refusing to overwrite a result package')
    with zipfile.ZipFile(pending, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name in names:
            z.write(output / name, name)
        z.writestr('manifest.json', json.dumps({'files': entries}, ensure_ascii=False, indent=2) + '\n')
    with zipfile.ZipFile(pending, 'r') as z:
        if z.testzip() is not None or set(z.namelist()) != set(names) | {'manifest.json'} or len(z.namelist()) != len(names) + 1:
            raise ValueError('result ZIP verification failed')
        for name, digest in entries.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise ValueError('result ZIP member hash mismatch')
    pending.replace(final)
    return final


def run(data_dir, output, research_root, release):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    status = {'status': 'running', 'phase': 'load_and_verify', 'test_evaluated': False,
              'holdout_evaluated': False, 'labels_loaded': False}
    status_path = output / 'status.json'
    write_json(status_path, status)
    started = time.monotonic()
    try:
        manifest, arrays = load_prepared(data_dir)
        users = development_users(arrays)
        selected = select_rows(arrays, users)
        del arrays
        if int(np.sum(selected['split'] == 0)) != EXPECTED_TRAIN:
            raise ValueError('training population differs from previous experiment')
        ordered = prepare_ordered(selected['student'], selected['kc'], selected['timestamp'],
                                  selected['split'], selected['record_idx'])
        del selected
        identity = check_identity(ordered)
        status['phase'] = 'training_only_calibration'
        write_json(status_path, status)
        print(json.dumps({'phase': status['phase'], **identity}, ensure_ascii=False), flush=True)
        calibration = calibrate(ordered['crossings'], ordered['gaps_hours'], ordered['first'], ordered['split'])
        old = calibration['transition']
        if (calibration['training_repeated_kc_events'] != EXPECTED_TRAIN_REPEATS or old['status'] != 'matched' or
            abs(old['retention'] - EXPECTED_TRANSITION_R) > 2e-10 or abs(old['target'] - EXPECTED_TRANSITION_MEAN) > 2e-11):
            raise ValueError('training-only transition calibration disagrees with frozen prior result')
        write_json(output / 'calibration.json', calibration)
        status['phase'] = 'history_weight_summaries'
        write_json(status_path, status)
        print(json.dumps({'phase': status['phase'], 'cumulative_status': calibration['cumulative']['status']}, ensure_ascii=False), flush=True)
        analysis = analyze(ordered, calibration)
        write_json(output / 'analysis.json', analysis)
        status['phase'] = 'source_inventory'
        write_json(status_path, status)
        inventory = inspect_sources(research_root, manifest)
        write_json(output / 'inventory.json', inventory)
        provenance = {'prepared_data_manifest_sha256': DATA_FINGERPRINT, 'identity_check': identity,
                      'prior_transition_retention': EXPECTED_TRANSITION_R,
                      'prior_transition_target': EXPECTED_TRANSITION_MEAN,
                      'threshold_hours': 10., 'time_half_life_hours': 168.,
                      'release': release, 'numpy_version': np.__version__, 'python_version': sys.version,
                      'loaded_npz_arrays': ['student_idx', 'item_idx', 'split', 'timestamp', 'item_q'],
                      'not_loaded': ['label', 'response_time'], 'test_time_note': 'full structural arrays are loaded before test rows are excluded; no test outcomes are loaded or scored',
                      'feedback_note': 'event timestamps are proxies; real feedback times not established',
                      'independent_validation': False}
        write_json(output / 'provenance.json', provenance)
        (output / 'report.md').write_text(make_report(calibration, analysis, inventory), encoding='utf-8')
        status['phase'] = 'packaging_final'
        write_json(status_path, status)
        final = package(output, ['calibration.json', 'analysis.json', 'inventory.json', 'provenance.json', 'report.md'])
        status.update(status='complete', phase='complete', seconds=round(time.monotonic() - started, 3),
                      result_archive=str(final), result_sha256=sha(final))
        write_json(status_path, status)
        print(json.dumps({'phase': 'complete', 'archive': str(final), 'sha256': sha(final)}, ensure_ascii=False), flush=True)
        return final
    except BaseException as exc:
        status.update(status='failed', error=f'{type(exc).__name__}: {exc}', seconds=round(time.monotonic() - started, 3))
        write_json(status_path, status)
        raise


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--data-dir')
    parser.add_argument('--output-dir')
    parser.add_argument('--research-root')
    args = parser.parse_args(argv)
    release = verify_release()
    print(json.dumps({'phase': 'release_verified', **release}), flush=True)
    if args.verify_only:
        return
    if not all((args.data_dir, args.output_dir, args.research_root)):
        parser.error('--data-dir, --output-dir and --research-root are required')
    run(args.data_dir, args.output_dir, args.research_root, release)


if __name__ == '__main__':
    main()
