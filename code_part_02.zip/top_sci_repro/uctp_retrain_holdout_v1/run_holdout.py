"""Evaluate nine already-trained checkpoints on exploratory validation holdout."""
import argparse,importlib,json,os,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import torch
from cross_core import import_project,read,sha,write,model_digest,long_followup
from pilot_core import DevelopmentData,development_users,fresh_model,SALT
from holdout_core import check_bridge,summarize

ROOT=Path(__file__).resolve().parent

def check_inputs(seed0,seed12,lock):
    l0=lock['seed0']
    for filename,key in [('summary.json','seed0_summary_sha256'),('suite_config.json','seed0_config_sha256')]:
        if sha(seed0/filename)!=l0[key]:raise ValueError('Seed0 source differs: '+filename)
    for filename,key in [('summary.json','seed12_summary_sha256'),('suite_config.json','seed12_config_sha256')]:
        if sha(seed12/filename)!=lock[key]:raise ValueError('Seed1/2 source differs: '+filename)
    for root in (seed0,seed12):
        if read(root/'status.json')['status']!='complete':raise ValueError('Source suite incomplete')
    candidates=[]
    for rule,e in l0['selected'].items():
        folder=seed0/e['directory']
        if sha(folder/'best_model.pt')!=e['checkpoint_sha256']:raise ValueError('Seed0 checkpoint differs: '+rule)
        st=read(folder/'status.json')
        if st['status']!='complete' or st['seed']!=0 or st['rule']!=rule or st['value']!=e['value'] or st['checkpoint_sha256']!=e['checkpoint_sha256']:
            raise ValueError('Seed0 candidate metadata differs')
        candidates.append((0,rule,e['value'],folder,st))
    for name,e in lock['seed12_runs'].items():
        folder=seed12/name
        for file,key in [('status.json','status_sha256'),('best_model.pt','checkpoint_sha256'),('dev_predictions.csv.gz','dev_predictions_sha256')]:
            if sha(folder/file)!=e[key]:raise ValueError(f'Seed1/2 source differs: {name}/{file}')
        st=read(folder/'status.json')
        if st['status']!='complete' or st['rule']!=e['rule'] or st['value']!=e['value'] or st['seed']!=e['seed']:
            raise ValueError('Seed1/2 candidate metadata differs')
        candidates.append((e['seed'],e['rule'],e['value'],folder,st))
    if sorted((s,r) for s,r,_,_,_ in candidates)!=[(s,r) for s in (0,1,2) for r in ('A','B','C')]:
        raise ValueError('Nine candidates required')
    return sorted(candidates,key=lambda x:(x[0],x[1]))

def main():
    p=argparse.ArgumentParser()
    for n in ('project-dir','data-dir','seed0-dir','seed12-dir','output-dir'):p.add_argument('--'+n,required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--ack-row-feedback',action='store_true');p.add_argument('--ack-time-proxy',action='store_true')
    a=p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy:p.error('Both acknowledgements required')
    if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
    out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
    started=time.monotonic();status={'status':'running','phase':'audit','trained':False,'test_evaluated':False}
    write(out/'status.json',status)
    try:
        lock=read(ROOT/'locked_inputs.json');candidates=check_inputs(Path(a.seed0_dir),Path(a.seed12_dir),lock)
        spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
        Data,Base,_=import_project(a.project_dir,spec['source'])
        if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint']:raise ValueError('Data manifest changed')
        data=Data(a.data_dir)
        if not (data.arrays['item_q'].sum(1)==1).all():raise ValueError('Requires single KC')
        valid_ids=np.flatnonzero(data.arrays['split']==1);valid_users=np.unique(data.arrays['student_idx'][valid_ids])
        dev=development_users(valid_users);hold=set(map(int,valid_users))-dev
        if not dev or not hold:raise ValueError('Missing development or holdout students')
        pairs=long_followup(data,valid_ids)
        engine=importlib.import_module('src.engine');device=torch.device(a.device)
        torch.set_num_threads(4);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
        torch.use_deterministic_algorithms(True)
        config={'data_fingerprint':data.fingerprint,'partition_salt':SALT,'holdout_students':len(hold),
                'candidate_locks':lock,'feedback':'row immediate assumption','time':'event-time proxy',
                'trained':False,'test_evaluated':False,'scope':'exploratory previously used validation students',
                'code_sha256':{n:sha(ROOT/n) for n in ('run_holdout.py','holdout_core.py','pilot_core.py','decision_core.py','cross_core.py','review_stats.py')}}
        write(out/'config.json',config)
        pred={};frame_ref=None;bridges={}
        for seed,rule,value,folder,st in candidates:
            name=f'{rule}_seed{seed}';status['phase']=name;write(out/'status.json',status)
            print('START',name,flush=True)
            ckpt=torch.load(folder/'best_model.pt',map_location='cpu',weights_only=True)
            if ckpt['rule']!=rule or ckpt['seed']!=seed or ckpt['value']!=value or ckpt['data_fingerprint']!=data.fingerprint:
                raise ValueError('Checkpoint metadata mismatch: '+name)
            model,init=fresh_model(Base,data.manifest['summary'],rule,value,seed,device)
            if init!=st['initial_state_sha256']:raise ValueError('Initial model differs: '+name)
            model.load_state_dict(ckpt['model_state'],strict=True);model.eval();model.requires_grad_(False)
            digest=model_digest(model.state_dict())
            if digest!=st['checkpoint_model_state_sha256']:raise ValueError('Checkpoint tensors differ: '+name)
            _,bridge,_=engine.evaluate(model,DevelopmentData(data,sorted(dev)[:32]),device,'valid',8,100,True)
            bridges[name]=check_bridge(bridge,folder/'dev_predictions.csv.gz')
            _,frame,_=engine.evaluate(model,DevelopmentData(data,hold),device,'valid',8,100,True)
            expected=valid_ids[np.isin(data.arrays['student_idx'][valid_ids],list(hold))]
            if not np.array_equal(frame.record_idx.to_numpy(),expected):raise ValueError('Holdout identity mismatch')
            if frame_ref is None:frame_ref=frame[['record_idx','student_idx','label']].copy()
            elif not frame_ref.equals(frame[['record_idx','student_idx','label']]):raise ValueError('Candidate rows differ')
            if model_digest(model.state_dict())!=digest:raise ValueError('Weights changed during evaluation')
            pred[name]=frame.probability.to_numpy(dtype=np.float32)
            print('COMPLETED',name,'records',len(frame),'bridge',bridges[name],flush=True)
        summary=summarize(frame_ref,pred,pairs)
        summary.update(trained=False,test_evaluated=False,bridges=bridges,seconds=time.monotonic()-started)
        frame_ref.to_csv(out/'events.csv.gz',index=False,compression='gzip')
        np.savez_compressed(out/'predictions.npz',record_idx=frame_ref.record_idx.to_numpy(),**pred)
        np.save(out/'selected_pairs.npy',pairs[np.isin(pairs[:,0],frame_ref.record_idx)&np.isin(pairs[:,1],frame_ref.record_idx)],allow_pickle=False)
        write(out/'summary.json',summary)
        status.update(status='complete',phase=None,seconds=time.monotonic()-started);write(out/'status.json',status)
        print('HOLDOUT COMPLETE',flush=True)
    except BaseException as exc:
        status.update(status='failed',error=repr(exc),seconds=time.monotonic()-started);write(out/'status.json',status);raise

if __name__=='__main__':main()
