import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
for name,digest in json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
 p=root/name
 if p.parent!=root or hashlib.sha256(p.read_bytes()).hexdigest()!=digest:raise ValueError('Package changed: '+name)
lock=json.loads((root/'locked_inputs.json').read_text(encoding='utf8'))
hashes=[lock['seed0']['seed0_summary_sha256'],lock['seed0']['seed0_config_sha256'],lock['seed12_summary_sha256'],lock['seed12_config_sha256']]
hashes += [v['checkpoint_sha256'] for v in lock['seed0']['selected'].values()]
hashes += [v[k] for v in lock['seed12_runs'].values() for k in ('checkpoint_sha256','status_sha256','dev_predictions_sha256')]
if len(lock['seed12_runs'])!=6 or any(re.fullmatch('[0-9a-f]{64}',x) is None for x in hashes):raise ValueError('Invalid lock metadata')
print('Package integrity verified',flush=True)
