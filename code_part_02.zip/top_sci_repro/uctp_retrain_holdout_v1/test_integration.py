"""Synthetic training plus nine-model exploratory evaluation."""
import contextlib,io,json,os,shutil,subprocess,sys,tempfile,zipfile,hashlib
from pathlib import Path
import numpy as np,torch
import test_step
from cross_core import write,sha
from pilot_core import DevelopmentData,development_users

ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_screen_v1'))
from screen_core import fit_candidate
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass()
f=test_step.StepTests();f.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='holdout_e2e_') as tmp:
  root=Path(tmp);pkg=root/'pkg';p0=root/'seed0';p12=root/'seed12'
  for p in (pkg,p0,p12):p.mkdir()
  for n in ('run_holdout.py','holdout_core.py','pilot_core.py','decision_core.py','cross_core.py','review_stats.py','package_results.py'):
   shutil.copy2(ROOT/n,pkg/n)
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':f.sources,'data_fingerprint':f.data.fingerprint}}}})
  from src import engine
  torch.set_num_threads(2)
  users=development_users(f.data.arrays['student_idx'][f.data.arrays['split']==1]);dev=DevelopmentData(f.data,users)
  selected={};seed12={}
  for seed in (0,1,2):
   for rule,value in [('A',None),('B',0.8),('C',168)]:
    name=({'A':'A_none','B':'B_0.8','C':'C_168'}[rule] if seed==0 else f'{rule}_seed{seed}')
    folder=(p0 if seed==0 else p12)/name
    with contextlib.redirect_stdout(io.StringIO()):
     row=fit_candidate(dev,f.Base,engine,rule,value,seed,torch.device('cpu'),folder,epochs=1,patience=1,hidden=8)
    if seed==0:selected[rule]={'value':value,'directory':name,'checkpoint_sha256':row['checkpoint_sha256']}
    else:seed12[name]={'rule':rule,'seed':seed,'value':value,'checkpoint_sha256':row['checkpoint_sha256'],
                       'status_sha256':sha(folder/'status.json'),'dev_predictions_sha256':sha(folder/'dev_predictions.csv.gz')}
  for p in (p0,p12):
   write(p/'summary.json',{'synthetic':True});write(p/'suite_config.json',{'synthetic':True});write(p/'status.json',{'status':'complete'})
  lock={'seed0':{'seed0_summary_sha256':sha(p0/'summary.json'),'seed0_config_sha256':sha(p0/'suite_config.json'),'selected':selected},
        'seed12_summary_sha256':sha(p12/'summary.json'),'seed12_config_sha256':sha(p12/'suite_config.json'),'seed12_runs':seed12}
  write(pkg/'locked_inputs.json',lock)
  cmd=[sys.executable,'-B',str(pkg/'run_holdout.py'),'--project-dir',str(PROJECT),'--data-dir',str(f.path),
       '--seed0-dir',str(p0),'--seed12-dir',str(p12),'--output-dir',str(root/'out'),'--device','cpu','--ack-row-feedback','--ack-time-proxy']
  # Synthetic checkpoint uses hidden=8; production requires 128.
  text=(pkg/'run_holdout.py').read_text(encoding='utf8').replace("value,seed,device)\n", "value,seed,device,hidden=8)\n")
  (pkg/'run_holdout.py').write_text(text,encoding='utf8')
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if r.returncode:raise RuntimeError(r.stdout)
  summary=json.loads((root/'out/summary.json').read_text());assert len(summary['rows'])==9 and len(summary['bridges'])==9
  assert summary['students']>0 and not summary['test_evaluated'] and not summary['trained']
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  result=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert result.returncode==0,result.stdout
  with zipfile.ZipFile(root/'out/holdout_results.zip') as z:
   assert z.testzip() is None
   manifest=json.loads(z.read('manifest.json'));assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
  print(json.dumps({'synthetic_nine_models':True,'bridges':9,'holdout_partition':True,'no_test':True,'archive':True,'real_cuda_tested':False}))
finally:f.tearDown()
