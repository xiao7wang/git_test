"""Fixed student partition, prediction checks and paired outcome summaries."""
import numpy as np
import pandas as pd
from review_stats import metrics,losses,cluster_intervals

def check_bridge(frame,path,atol=1e-6):
    ref=pd.read_csv(path,compression='gzip',float_precision='round_trip')
    if ref.record_idx.duplicated().any():raise ValueError('Duplicated development reference records')
    ref=ref.set_index('record_idx')
    if not frame.record_idx.isin(ref.index).all():raise ValueError('Reference missing records')
    aligned=ref.loc[frame.record_idx.to_numpy()]
    if not np.array_equal(aligned.student_idx.to_numpy(),frame.student_idx.to_numpy()) or not np.array_equal(aligned.label.to_numpy(),frame.label.to_numpy()):
        raise ValueError('Reference metadata mismatch')
    left=aligned.probability.to_numpy(dtype=np.float32).astype(np.float64)
    right=frame.probability.to_numpy(dtype=np.float32).astype(np.float64)
    diff=float(np.max(np.abs(left-right),initial=0.0))
    if diff>atol:raise ValueError(f'Development bridge failed: max {diff}')
    return {'n':len(frame),'max_abs_difference':diff,'atol':atol}

def summarize(frame,predictions,pairs,reps=2000):
    ids=frame.record_idx.to_numpy();y=frame.label.to_numpy();users=frame.student_idx.to_numpy()
    if len(ids)==0 or np.any(np.diff(ids)<=0):raise ValueError('Invalid event ordering')
    selected=pairs[np.isin(pairs[:,0],ids)&np.isin(pairs[:,1],ids)]
    left=np.searchsorted(ids,selected[:,0]);right=np.searchsorted(ids,selected[:,1])
    if len(selected) and not np.array_equal(users[left],users[right]):raise ValueError('Pair user mismatch')
    _,inv=np.unique(users,return_inverse=True)
    rows={};losses_by={}
    for name,pred in predictions.items():
        ls=losses(y,pred)[:,0];losses_by[name]=ls
        row=metrics(y,pred);row['student_macro_nll']=float(np.mean(np.bincount(inv,weights=ls)/np.bincount(inv)))
        row['pair_n']=len(selected)
        row['current_nll']=float(ls[left].mean()) if len(left) else None
        row['next_nll']=float(ls[right].mean()) if len(left) else None
        row['two_event_mean_nll']=float(((ls[left]+ls[right])/2).mean()) if len(left) else None
        rows[name]=row
    comparisons={}
    for a,b in (('B','A'),('C','A'),('C','B')):
        diffs=np.stack([losses_by[f'{a}_seed{s}']-losses_by[f'{b}_seed{s}'] for s in (0,1,2)],axis=1)
        data=np.column_stack((diffs,diffs.mean(axis=1)))
        overall=cluster_intervals(users,data,reps,20261109)
        group={'seed0':overall['comparisons'][0],'seed1':overall['comparisons'][1],
               'seed2':overall['comparisons'][2],'seed_mean':overall['comparisons'][3]}
        if len(left):
            for label,vals in [('current',data[left]),('next',data[right]),('two_event_mean',(data[left]+data[right])/2)]:
                group[label]=cluster_intervals(users[left],vals,reps,20261109)['comparisons'][3]
        comparisons[f'{a}_minus_{b}']=group
    return {'n':len(ids),'students':len(np.unique(users)),'pair_n':len(selected),
            'rows':rows,'paired':comparisons,'scope':'exploratory reused validation students; frozen parameters; no test',
            'bootstrap':'students clustered; mean losses across fixed seeds, not probabilities; excludes training and selection uncertainty'}
