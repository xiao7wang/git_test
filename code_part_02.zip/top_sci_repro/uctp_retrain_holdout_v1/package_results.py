import argparse,hashlib,json,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);root=Path(p.parse_args().output_dir).resolve()
if json.loads((root/'status.json').read_text(encoding='utf8'))['status']!='complete':raise ValueError('Evaluation incomplete')
names=['status.json','config.json','summary.json','events.csv.gz','predictions.npz','selected_pairs.npy']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in names}
target=root/'holdout_results.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
 for n in names:z.write(root/n,n)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(target) as z:
 if z.testzip() is not None or any(hashlib.sha256(z.read(k)).hexdigest()!=v for k,v in manifest.items()):raise ValueError('Archive failed verification')
print('RESULTS READY:',target,flush=True)
