#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_holdout_01}"
if [[ ! "$NAME" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid name' >&2; exit 2; fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
SEED0=/home/wangxiao/QCCDM/top_sci_repro/uctp_retrain_screen_v1/outputs/server_screen_01
SEED12=/home/wangxiao/QCCDM/top_sci_repro/uctp_retrain_confirm_seeds_v1_fix01/outputs/server_seeds_fix01
OUT="$DIR/outputs/$NAME";LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]];then echo 'Existing output preserved; choose a new name' >&2;exit 2;fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$DIR/verify_package.py"
"$PY" -B "$DIR/test_holdout.py"
for DEVICE in cpu cuda;do
 echo "Starting $DEVICE tests"
 "$PY" -B "$DIR/test_step.py" --project-dir "$PROJECT" --device "$DEVICE" --report "$DIR/outputs/${NAME}_${DEVICE}_tests.json"
 "$PY" -B "$DIR/test_decision.py" --project-dir "$PROJECT" --device "$DEVICE"
done
"$PY" -B -u "$DIR/run_holdout.py" --project-dir "$PROJECT" --data-dir "$DATA" --seed0-dir "$SEED0" --seed12-dir "$SEED12" --output-dir "$OUT" --device cuda --ack-row-feedback --ack-time-proxy
"$PY" -B "$DIR/package_results.py" --output-dir "$OUT"
