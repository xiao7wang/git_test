import unittest,tempfile
from pathlib import Path
import numpy as np
import pandas as pd
from holdout_core import summarize,check_bridge

class HoldoutTests(unittest.TestCase):
    def test_matched_losses_and_three_seed_average(self):
        f=pd.DataFrame({'record_idx':[0,1,2,3],'student_idx':[1,1,2,2],'label':[1,0,1,0]})
        preds={f'{r}_seed{s}':np.array([.7,.3,.7,.3]) for s in range(3) for r in 'ABC'}
        out=summarize(f,preds,np.array([[0,1],[2,3]]),reps=20)
        self.assertEqual(out['pair_n'],2)
        self.assertEqual(out['paired']['C_minus_B']['seed_mean']['delta'],0)
        self.assertEqual(out['paired']['C_minus_B']['two_event_mean']['delta'],0)

    def test_bridge_rejects_changed_predictions_and_labels(self):
        f=pd.DataFrame({'record_idx':[1,2],'student_idx':[4,5],'label':[1,0],'probability':np.array([.7,.3],dtype=np.float32)})
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'reference.csv.gz';f.to_csv(path,index=False,compression='gzip')
            self.assertEqual(check_bridge(f,path)['n'],2)
            bad=f.copy();bad.loc[0,'probability']=.5
            with self.assertRaises(ValueError):check_bridge(bad,path)
            bad=f.copy();bad.loc[0,'label']=0
            with self.assertRaises(ValueError):check_bridge(bad,path)

if __name__=='__main__':unittest.main(verbosity=2)
