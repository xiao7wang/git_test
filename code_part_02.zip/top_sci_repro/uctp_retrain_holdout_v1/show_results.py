import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);root=Path(p.parse_args().output_dir)
if not (root/'status.json').exists():print('Not started or tests still running; check launch log.')
else:
 s=read(root/'status.json');print('status:',s['status'],'phase:',s.get('phase'),'error:',s.get('error','-'))
 print('A saved running status is not proof of a live process.')
 if (root/'summary.json').exists():
  result=read(root/'summary.json');print('events:',result['n'],'students:',result['students'],'pairs:',result['pair_n'])
  for k,v in result['rows'].items():print(k,'NLL:',v['nll'],'student NLL:',v['student_macro_nll'],'AUC:',v['auc'])
  print('C minus B, paired seed mean:',result['paired']['C_minus_B']['seed_mean'])
 if (root/'holdout_results.zip').exists():print('Results archive:',root/'holdout_results.zip')
