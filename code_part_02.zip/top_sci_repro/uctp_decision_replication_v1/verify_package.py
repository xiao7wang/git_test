"""Verify the immutable release before running on the server."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'PACKAGE_MANIFEST.json').read_text(encoding='utf-8'))
for name, expected in manifest.items():
    path = root / name
    if path.parent != root or not path.is_file():
        raise ValueError('Missing or unsafe release member: ' + name)
    with path.open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    if actual != expected:
        raise ValueError('Release member changed: ' + name)
print(f'Package files verified: {len(manifest)}', flush=True)
