"""Package only a completed seed-0 screening result, with a manifest."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--output-root', type=Path, required=True)
args = parser.parse_args()
root = args.output_root.resolve()
for mode in ('preflight', 'full'):
    status = json.loads((root / mode / 'status.json').read_text(encoding='utf-8'))
    if status['status'] != 'complete':
        raise ValueError(mode + ' has not completed')
if not (root / 'full/summary.json').is_file():
    raise FileNotFoundError('Missing result summary')
files = sorted(p for d in ('preflight', 'full') for p in (root / d).rglob('*') if p.is_file())
manifest = {}
for path in files:
    with path.open('rb') as stream:
        manifest[path.relative_to(root).as_posix()] = hashlib.file_digest(stream, 'sha256').hexdigest()
archive = root / 'decision_results.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, allowZip64=True) as z:
    for path in files:
        z.write(path, path.relative_to(root).as_posix())
    z.writestr('result_manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise ValueError('Archive CRC failure')
print('RESULTS READY:', archive, flush=True)
