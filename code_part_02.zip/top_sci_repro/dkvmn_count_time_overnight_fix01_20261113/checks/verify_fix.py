"""Frozen repair measurement: original checks plus regression and GPU-smoke hook."""
import argparse
import contextlib
import io
import sys
import unittest
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests"), str(ROOT / "checks")]


class RepairRegression(unittest.TestCase):
    def test_chunk_accepts_one_float32_ulp_but_rejects_large_or_nan(self):
        from test_model import assert_chunk_close
        original = torch.tensor([1.], dtype=torch.float32)
        one_ulp = torch.nextafter(original, torch.full_like(original, float("inf")))
        assert_chunk_close(original, one_ulp)
        with self.assertRaises(AssertionError):
            assert_chunk_close(original, original + 2e-6)
        with self.assertRaises(AssertionError):
            assert_chunk_close(original, torch.full_like(original, float("nan")))

    def test_gpu_smoke_executes_full_synthetic_suite_on_cpu(self):
        from gpu_preflight import run_smoke
        with contextlib.redirect_stdout(io.StringIO()):
            result = run_smoke("cpu")
        self.assertEqual(result["hybrid_jobs"], 4)
        self.assertEqual(result["negative_jobs"], 9)
        self.assertTrue(result["archive_verified"])

    def test_server_launcher_calls_gpu_smoke(self):
        script = (ROOT / "run_server.sh").read_bytes()
        self.assertIn(b"checks/gpu_preflight.py", script)
        self.assertNotIn(b"\r", script)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    original = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    repair = unittest.defaultTestLoader.loadTestsFromTestCase(RepairRegression)
    result = unittest.TextTestRunner(verbosity=1).run(unittest.TestSuite([original, repair]))
    failed = len(result.failures) + len(result.errors)
    print(failed, flush=True)
    return 1 if args.strict and failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
