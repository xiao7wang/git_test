"""Frozen measurement: count failed tests; zero is target."""
import argparse
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests")]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    result = unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.discover(str(ROOT / "tests")))
    failed = len(result.failures) + len(result.errors)
    print(failed, flush=True)
    return 1 if args.strict and failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
