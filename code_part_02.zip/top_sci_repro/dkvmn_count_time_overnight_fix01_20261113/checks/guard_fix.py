"""Ensure the repair does not change scientific code, protocol or source locks."""
import hashlib
import json
import runpy
from pathlib import Path

root = Path(__file__).resolve().parents[1]
runpy.run_path(str(root / "checks/guard.py"), run_name="__main__")
manifest = json.loads((root / "contracts/fix_source_hashes.json").read_text(encoding="utf-8"))
for name, expected in manifest["files"].items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    assert actual == expected, f"protected scientific source changed: {name}"
print("Original scientific model, training protocol, source locks and other tests unchanged")
