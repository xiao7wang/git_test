"""Frozen experiment protocol and exact previous source verification."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
protocol = json.loads((root / "contracts/protocol.json").read_text(encoding="utf-8"))
manifest = json.loads((root / "contracts/vendor_manifest.json").read_text(encoding="utf-8"))
assert protocol["fixed_discount"] == .8 and protocol["time_half_life_hours"] == 168.
assert protocol["hybrid_seeds"] == [1, 2] and protocol["negative_gap_shuffle_seeds"] == [11, 29, 47]
assert protocol["hybrid_jobs"] == ["fixed_08_seed1", "time_168h_seed1", "fixed_08_seed2", "time_168h_seed2"]
assert protocol["batch_size"] == 8 and protocol["chunk_size"] == 50 and protocol["max_epochs"] == 20
assert protocol["test_evaluated"] is False and protocol["holdout_evaluated"] is False
for name, expected in manifest["files"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
assert len(manifest["files"]) >= 15
print("Frozen protocol and previous source integrity verified")
