"""Exercise the actual training path on a tiny synthetic CUDA dataset.

The only CPU mode is the explicitly requested local smoke-test mode. Formal
server preflight never falls back to CPU and does not touch real data.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import sys
import tempfile
import zipfile
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tests")]
from count_time.runner import run_in_memory as run_previous_count
from fixed_controls.references import load_dkvmn, load_prior
from helpers import FakeData, sample_arrays, synthetic_dk
from overnight.runner import run_in_memory


def run_smoke(device):
    if device not in ("cpu", "cuda"):
        raise ValueError("synthetic smoke device must be cpu or cuda")
    if device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; synthetic GPU preflight will not fall back to CPU")
    captured = io.StringIO()
    try:
        with tempfile.TemporaryDirectory(prefix="overnight_synthetic_preflight_") as tmp, contextlib.redirect_stdout(captured):
            root = Path(tmp)
            metadata = {"data_fingerprint": "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e",
                        "release": {"manifest_sha256": "eeb721367e1a334dbbcab3dc52fc59ddce9656ddfa0d23fded583712c9a98b7e"}}
            run_previous_count(sample_arrays(), set(range(6)), root / "prior", device=device,
                               epochs=2, patience=2, batch_size=16, repetitions=20, run_metadata=metadata)
            prior_path = root / "prior" / "count_time_increment_results.zip"
            prior = load_prior(prior_path, hashlib.sha256(prior_path.read_bytes()).hexdigest())
            dk_path, dk_hash = synthetic_dk(root, prior)
            dkvmn = load_dkvmn(dk_path, dk_hash, prior["events"])
            output = root / "suite"
            result = run_in_memory(FakeData(), set(range(6)), output, prior, dkvmn, device=device,
                                   epochs=2, patience=2, batch_size=3, count_batch_size=16,
                                   chunk_size=5, repetitions=20, run_metadata={"synthetic_test": True})
            summary = result["summary"]
            if result["status"] != "complete" or len(summary["hybrid_jobs"]) != 4 or len(summary["negative_jobs"]) != 9:
                raise AssertionError("synthetic GPU suite did not complete the fixed job list")
            if set(summary["hybrid_pairing"]) != {"1", "2"} or not all(
                    row["initial_state_matches"] and row["matching_common_epochs"] > 0
                    for row in summary["hybrid_pairing"].values()):
                raise AssertionError("synthetic paired initialization or ordering check failed")
            archive = output / "overnight_results.zip"
            with zipfile.ZipFile(archive) as z:
                if z.testzip() is not None:
                    raise ValueError("synthetic result archive CRC failure")
                manifest = json.loads(z.read("manifest.json"))["files"]
                if set(z.namelist()) != set(manifest) | {"manifest.json"}:
                    raise ValueError("synthetic result archive member list differs")
                for name, expected in manifest.items():
                    if hashlib.sha256(z.read(name)).hexdigest() != expected:
                        raise ValueError(f"synthetic result archive member mismatch: {name}")
            return {"device": device, "hybrid_jobs": 4, "negative_jobs": 9, "archive_verified": True,
                    "torch": str(torch.__version__),
                    "gpu": torch.cuda.get_device_name(0) if device == "cuda" else None}
    except BaseException:
        print("SYNTHETIC_PREFLIGHT_FAILED; recent synthetic log follows:", flush=True)
        print(captured.getvalue()[-8000:], flush=True)
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cpu-smoke", action="store_true", help="explicit local development check only")
    args = parser.parse_args()
    device = "cpu" if args.cpu_smoke else "cuda"
    result = run_smoke(device)
    print("SYNTHETIC_PREFLIGHT_PASSED", json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
