import unittest

import numpy as np

from count_time.features import construct
from helpers import sample_arrays
from overnight.surrogate import pseudo_states


class PseudoGapTests(unittest.TestCase):
    def test_training_pool_only_and_exact_recursive_counts(self):
        data = construct(sample_arrays(), set(range(6)))
        fake = pseudo_states(data, 11)
        train = (data["split"] == 0) & (data["prior_kc_count"] > 0)
        dev = (data["split"] == 1) & (data["prior_kc_count"] > 0)
        np.testing.assert_array_equal(np.sort(fake["pseudo_gap_hours"][train]), np.sort(data["gap_hours"][train]))
        self.assertTrue(set(fake["pseudo_gap_hours"][dev]).issubset(set(data["gap_hours"][train])))
        self.assertEqual(fake["audit"]["source"], "training gaps only")
        for i in range(len(data["record_idx"])):
            prior = [j for j in range(i) if data["student"][j] == data["student"][i] and data["kc"][j] == data["kc"][i]]
            want = [0., 0.]
            for offset, j in enumerate(prior):
                selected = prior[offset + 1:] + [i]
                multiplier = np.prod(np.exp2(-fake["pseudo_gap_hours"][selected] / 168.))
                want[int(1 - data["label"][j])] += multiplier
            self.assertAlmostEqual(fake["success"][i], want[0], places=10)
            self.assertAlmostEqual(fake["failure"][i], want[1], places=10)

    def test_future_development_timestamps_and_test_labels_do_not_affect_pseudo_features(self):
        arrays = sample_arrays()
        first = pseudo_states(construct(arrays, set(range(6))), 29)
        changed = {key: value.copy() for key, value in arrays.items()}
        changed["timestamp"][arrays["split"] >= 1] += 123456.
        changed["label"][arrays["split"] == 2] = -1
        second = pseudo_states(construct(changed, set(range(6))), 29)
        for name in ("success", "failure", "pseudo_gap_hours"):
            np.testing.assert_array_equal(first[name], second[name])

    def test_distinct_maps_preserve_training_marginal(self):
        data = construct(sample_arrays(), set(range(6)))
        a, b = pseudo_states(data, 11), pseudo_states(data, 47)
        train = (data["split"] == 0) & (data["prior_kc_count"] > 0)
        np.testing.assert_array_equal(np.sort(a["pseudo_gap_hours"][train]), np.sort(b["pseudo_gap_hours"][train]))
        self.assertFalse(np.array_equal(a["pseudo_gap_hours"][train], b["pseudo_gap_hours"][train]))
