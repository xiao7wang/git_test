from __future__ import annotations

import gzip
import hashlib
import io
import json
import zipfile
from pathlib import Path

import numpy as np
import torch

from count_time.runner import run_in_memory


def sample_arrays():
    students, items, labels, splits, stamps = [], [], [], [], []
    for user in range(6):
        for step in range(13):
            students.append(user)
            items.append(step % 3)
            labels.append((step + 2 * user + (step // 3)) % 2)
            splits.append(0 if step < 8 else (1 if step < 12 else 2))
            stamps.append(float(step * 1800 + (step // 4) * 500000 + user * 60))
    return {"student_idx": np.asarray(students, dtype=np.int64),
            "item_idx": np.asarray(items, dtype=np.int64),
            "label": np.asarray(labels, dtype=np.float32),
            "split": np.asarray(splits, dtype=np.int8),
            "timestamp": np.asarray(stamps, dtype=np.float64),
            "item_q": np.eye(3, dtype=np.int8),
            "user_offsets": np.arange(0, 6 * 13 + 1, 13, dtype=np.int64)}


class FakeData:
    def __init__(self, arrays=None):
        self.arrays = sample_arrays() if arrays is None else arrays
        self.manifest = {"summary": {"students": 6, "items": 3, "knowledges": 3}}
        self.fingerprint = "synthetic"

    def chunks(self, users, sequences, view, chunk_size, device):
        for start in range(0, max(map(len, sequences)), chunk_size):
            width = min(chunk_size, max(map(len, sequences)) - start)
            idx = np.full((len(users), width), -1, dtype=np.int64)
            for row, sequence in enumerate(sequences):
                part = sequence[start:start + width]
                idx[row, :len(part)] = part
            active = idx >= 0
            safe = np.maximum(idx, 0)
            item = self.arrays["item_idx"][safe]
            q = self.arrays["item_q"][item].astype(np.float32) * active[..., None]
            batch = {"student_idx": torch.as_tensor(users, dtype=torch.long, device=device),
                     "item_idx": torch.as_tensor(item, dtype=torch.long, device=device),
                     "q": torch.as_tensor(q, device=device),
                     "label": torch.as_tensor(self.arrays["label"][safe], device=device),
                     "timestamp": torch.as_tensor(self.arrays["timestamp"][safe], dtype=torch.float64, device=device),
                     "active_mask": torch.as_tensor(active, device=device),
                     "target_mask": torch.as_tensor(active & (self.arrays["split"][safe] == (0 if view == "train" else 1)), device=device)}
            yield batch, idx


def synthetic_prior(temp):
    root = Path(temp) / "prior"
    metadata = {"data_fingerprint": "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e",
                "release": {"manifest_sha256": "eeb721367e1a334dbbcab3dc52fc59ddce9656ddfa0d23fded583712c9a98b7e"}}
    run_in_memory(sample_arrays(), set(range(6)), root, device="cpu", epochs=2, patience=2,
                  batch_size=16, repetitions=20, run_metadata=metadata)
    path = root / "count_time_increment_results.zip"
    return path, hashlib.sha256(path.read_bytes()).hexdigest()


def synthetic_dk(temp, prior):
    events = prior["events"]
    rows = io.StringIO()
    rows.write("record_idx,student_idx,label\n")
    for rid, student, label in zip(events["record_idx"], events["student_idx"], events["label"]):
        rows.write(f"{rid},{student},{label}\n")
    packed = io.BytesIO()
    np.savez_compressed(packed, record_idx=events["record_idx"],
                        **{f"bias_seed{s}": np.full(len(events["label"]), .5, dtype=np.float32) for s in range(3)})
    files = {"events.csv.gz": gzip.compress(rows.getvalue().encode()), "predictions.npz": packed.getvalue(),
             "status.json": b'{"status":"complete"}',
             "config.json": json.dumps({"feedback": "row immediate assumption", "test_evaluated": False,
                                         "holdout_evaluated": False}).encode()}
    manifest = {name: hashlib.sha256(data).hexdigest() for name, data in files.items()}
    path = Path(temp) / "dkvmn.zip"
    with zipfile.ZipFile(path, "x") as bundle:
        for name, data in files.items():
            bundle.writestr(name, data)
        bundle.writestr("manifest.json", json.dumps(manifest))
    return path, hashlib.sha256(path.read_bytes()).hexdigest()
