import contextlib
import hashlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from fixed_controls.references import load_dkvmn, load_prior
from helpers import FakeData, synthetic_dk, synthetic_prior
from overnight import runner


class SuiteTests(unittest.TestCase):
    def test_synthetic_full_suite_and_incremental_packages(self):
        with tempfile.TemporaryDirectory() as temp, contextlib.redirect_stdout(io.StringIO()):
            path, digest = synthetic_prior(temp)
            prior = load_prior(path, digest)
            dkpath, dkhash = synthetic_dk(temp, prior)
            dk = load_dkvmn(dkpath, dkhash, prior["events"])
            output = Path(temp) / "suite"
            result = runner.run_in_memory(FakeData(), set(range(6)), output, prior, dk,
                                          device="cpu", epochs=2, patience=2, batch_size=3,
                                          count_batch_size=16, chunk_size=5, repetitions=20,
                                          run_metadata={"synthetic_test": True})
            self.assertEqual(result["status"], "complete")
            self.assertTrue((output / "partial_negative_controls.zip").is_file())
            for job in ("fixed_08_seed1", "time_168h_seed1", "fixed_08_seed2", "time_168h_seed2"):
                self.assertTrue((output / f"partial_{job}.zip").is_file())
            with zipfile.ZipFile(output / "overnight_results.zip") as z:
                self.assertIsNone(z.testzip())
                manifest = json.loads(z.read("manifest.json"))
                self.assertEqual(set(z.namelist()), set(manifest["files"]) | {"manifest.json"})
                for name, expected in manifest["files"].items():
                    self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(), expected)
                self.assertFalse(any(name.endswith(".pt") for name in z.namelist()))
                summary = json.loads(z.read("summary.json"))
                self.assertFalse(summary["test_evaluated"])
                self.assertFalse(summary["holdout_evaluated"])
                self.assertEqual(len(summary["hybrid_jobs"]), 4)
                self.assertEqual(len(summary["negative_jobs"]), 9)
                self.assertEqual(len([n for n in z.namelist() if n.endswith("dev_predictions.csv.gz")]), 13)
            with self.assertRaises(FileExistsError):
                runner.run_in_memory(FakeData(), {0}, output, prior, dk, device="cpu")

    def test_linux_launcher_and_protocol(self):
        root = Path(__file__).resolve().parents[1]
        script = (root / "run_server.sh").read_bytes()
        self.assertNotIn(b"\r", script)
        self.assertIn(b"PYTHONDONTWRITEBYTECODE", script)
        self.assertIn(b"--strict", script)
        self.assertIn(b"overnight.server", script)
        self.assertNotIn(b"not implemented", script.lower())
        spec = json.loads((root / "contracts/protocol.json").read_text(encoding="utf-8"))
        self.assertEqual(spec["hybrid_seeds"], [1, 2])
        self.assertEqual(len(spec["hybrid_jobs"]), 4)
