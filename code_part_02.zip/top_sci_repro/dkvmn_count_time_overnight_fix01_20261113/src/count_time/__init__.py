"""Exploratory fixed-event versus real-time count histories."""
