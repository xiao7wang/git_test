"""Pinned, development-only server entry point for the count-time experiment."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
from pathlib import Path

import numpy as np
import torch

from .common import sha256_file
from .runner import run_in_memory


ROOT = Path(__file__).resolve().parents[2]
SOURCE_HASHES = {
    "src/__init__.py": "4872c24b12231d9d45ea87639568a515279029ef800437ef10ebeb76536b0756",
    "src/common.py": "ff7cd011cca57ead68dbbc949d73a6b0dfe5312552ae687c16de47db8f974266",
    "src/data.py": "5ef7fd7e5c5dcce177d00b7e8e2cb2ca1b858c3a6ab8a473ec664d081804e291",
    "src/engine.py": "e837897568588cded2bf6f17f10ef5fab4f254c71b9a5529ee9d0c54025538f8",
    "src/factorial_time_model.py": "1c581b18b27f00fd388fc43f2438b215087a524bc96d1d8a40128e797708b016",
    "src/metrics.py": "9c19d3abe8a090776663df1877b206640522792203d21a22a7e0f64a4e087a7b",
    "src/model.py": "b10a590430cb96b3f10ba4da4d56bd9c67094dd8cfb396ece923a782799fadb8",
    "src/temporal_model.py": "27bda6ac554b0fad354cee748ecbcc0fb3574a4d753ee78510a59d4bce19ab4b",
    "train.py": "1a54ac766eedfb2f9b0ce641da349272735d7975ff9906cab46a3f5664faf07d",
}
DATA_FINGERPRINT = "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e"
SALT = "decision-v1-20261105:"


def verify_release():
    path = ROOT / "release_manifest.json"
    if not path.is_file():
        raise FileNotFoundError("release_manifest.json is missing; use the delivered ZIP package")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    entries = manifest.get("files")
    if not isinstance(entries, dict) or not entries:
        raise ValueError("release manifest has no files")
    required = {"run_server.sh", "contracts/protocol.json", "checks/verify.py",
                "src/count_time/server.py", "references/count_baseline_results.zip",
                "references/count_seedrep_results.zip"}
    if not required.issubset(entries):
        raise ValueError("release manifest is missing required entries")
    for name, digest in entries.items():
        candidate = (ROOT / name).resolve()
        if not candidate.is_relative_to(ROOT) or not candidate.is_file():
            raise ValueError(f"invalid or missing release file: {name}")
        if sha256_file(candidate) != digest:
            raise ValueError(f"release file hash differs: {name}")
    return {"manifest_sha256": sha256_file(path), "file_count": len(entries)}


def development_users(values):
    return {int(value) for value in np.unique(values)
            if hashlib.sha256((SALT + str(int(value))).encode()).digest()[-1] % 2 == 0}


def load_prepared(project, data_dir):
    project, data_dir = Path(project).resolve(), Path(data_dir).resolve()
    for name, digest in SOURCE_HASHES.items():
        if sha256_file(project / name) != digest:
            raise ValueError(f"prior project source hash differs: {name}")
    if sha256_file(data_dir / "manifest.json") != DATA_FINGERPRINT:
        raise ValueError("ASSIST prepared-data manifest fingerprint differs")
    sys.path.insert(0, str(project))
    from src.data import PreparedData
    imported = Path(sys.modules["src.data"].__file__).resolve()
    if not imported.is_relative_to(project):
        raise RuntimeError(f"wrong prepared-data module imported: {imported}")
    data = PreparedData(data_dir)
    if data.fingerprint != DATA_FINGERPRINT:
        raise ValueError("prepared data fingerprint differs")
    return data


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    for name in ("project-dir", "data-dir", "reference-dir", "output-dir"):
        parser.add_argument("--" + name)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--ack-row-feedback", action="store_true")
    parser.add_argument("--ack-time-proxy", action="store_true")
    args = parser.parse_args(argv)
    release = verify_release()
    print(json.dumps({"phase": "release_verified", **release}), flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir, args.data_dir, args.reference_dir, args.output_dir)):
        parser.error("project, data, reference, and output directories are required")
    if not args.ack_row_feedback or not args.ack_time_proxy:
        parser.error("acknowledge row-immediate feedback and event-time proxy assumptions")
    output = Path(args.output_dir).resolve()
    output_base = (ROOT / "outputs").resolve()
    if not output.is_relative_to(output_base) or output == output_base:
        raise ValueError("output must be a new subdirectory of the package outputs directory")
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; no automatic CPU fallback")
    protocol = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    if (protocol["dataset_manifest_sha256"] != DATA_FINGERPRINT or
            protocol["student_partition_salt"] != SALT or
            protocol["fixed_event_discount"] != 0.8 or
            protocol["real_time_half_life_hours"] != 168.0 or
            protocol["modes"] != ["A_none", "B_fixed", "C_real_time"] or
            protocol["seeds"] != [0, 1, 2] or
            protocol["max_epochs"] != 20 or protocol["patience"] != 5 or
            protocol["batch_size"] != 8192 or protocol["learning_rate"] != 0.01 or
            protocol["weight_decay"] != 1e-5 or protocol["gradient_clip"] != 5.0 or
            protocol["bootstrap_repetitions"] != 2000 or protocol["bootstrap_seed"] != 20261112 or
            protocol["primary_contrast"] != "C_real_time minus B_fixed" or
            protocol["test_evaluated"] or protocol["holdout_evaluated"]):
        raise ValueError("frozen protocol differs from this implementation")
    reference_dir = Path(args.reference_dir).resolve()
    ref0 = reference_dir / "count_baseline_results.zip"
    ref12 = reference_dir / "count_seedrep_results.zip"
    ref_sources = {
        0: {"archive": ref0, "member": "dev_predictions.csv.gz",
            "sha256": protocol["references"][ref0.name]},
        1: {"archive": ref12, "member": "seed1/dev_predictions.csv.gz",
            "sha256": protocol["references"][ref12.name]},
        2: {"archive": ref12, "member": "seed2/dev_predictions.csv.gz",
            "sha256": protocol["references"][ref12.name]},
    }
    for ref in ref_sources.values():
        if sha256_file(ref["archive"]) != ref["sha256"]:
            raise ValueError(f"locked reference archive differs: {ref['archive']}")
    data = load_prepared(args.project_dir, args.data_dir)
    splits = data.arrays["split"]
    all_users = data.arrays["student_idx"]
    dev_users = development_users(all_users[splits == 1])
    train_n = int(np.sum(splits == 0))
    dev_n = int(np.sum((splits == 1) & np.isin(all_users, list(dev_users))))
    if (train_n, dev_n, len(dev_users)) != (1847688, 126854, 10036):
        raise ValueError(f"source coverage differs: train={train_n}, dev={dev_n}, students={len(dev_users)}")
    metadata = {
        "release": release, "data_fingerprint": data.fingerprint,
        "project_source_sha256": SOURCE_HASHES,
        "python": platform.python_version(), "numpy": np.__version__, "torch": str(torch.__version__),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "gpu": torch.cuda.get_device_name(0) if args.device == "cuda" else None,
        "prepared_data_dir": str(Path(args.data_dir).resolve()),
        "project_dir": str(Path(args.project_dir).resolve()),
        "test_label_note": "prepared archive is loaded as a whole; test labels are excluded from feature construction and scoring",
    }
    result = run_in_memory(data.arrays, dev_users, output, device=args.device,
                           epochs=protocol["max_epochs"], patience=protocol["patience"],
                           batch_size=protocol["batch_size"],
                           repetitions=protocol["bootstrap_repetitions"],
                           run_metadata=metadata, reference_sources=ref_sources)
    print(json.dumps({"status": result["status"], "archive": result["archive"]}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
