"""Paired fixed-model development analysis, clustered by student."""
from __future__ import annotations

import numpy as np

from .common import binary_losses, metrics
from .features import MODES


CONTRASTS = {
    "C_real_time_minus_B_fixed": ("C_real_time", "B_fixed"),
    "B_fixed_minus_A_none": ("B_fixed", "A_none"),
    "C_real_time_minus_A_none": ("C_real_time", "A_none"),
}


def _intervals(students, columns, repetitions, seed):
    _, inverse = np.unique(students, return_inverse=True)
    counts = np.bincount(inverse).astype(np.float64)
    sums = np.stack([np.bincount(inverse, weights=columns[:, j])
                     for j in range(columns.shape[1])], axis=1)
    means = sums / counts[:, None]
    point, macro = sums.sum(axis=0) / counts.sum(), means.mean(axis=0)
    if len(counts) < 2:
        return [{"event_delta": float(point[j]), "event_ci95": None,
                 "student_macro_delta": float(macro[j]), "student_macro_ci95": None}
                for j in range(columns.shape[1])]
    rng = np.random.default_rng(seed)
    event_boot = np.empty((repetitions, columns.shape[1]), dtype=np.float64)
    macro_boot = np.empty_like(event_boot)
    for begin in range(0, repetitions, 16):
        size = min(16, repetitions - begin)
        draw = rng.integers(0, len(counts), size=(size, len(counts)))
        event_boot[begin:begin + size] = sums[draw].sum(axis=1) / counts[draw].sum(axis=1)[:, None]
        macro_boot[begin:begin + size] = means[draw].mean(axis=1)
    event_ci = np.quantile(event_boot, [.025, .975], axis=0)
    macro_ci = np.quantile(macro_boot, [.025, .975], axis=0)
    return [{"event_delta": float(point[j]), "event_ci95": event_ci[:, j].tolist(),
             "student_macro_delta": float(macro[j]), "student_macro_ci95": macro_ci[:, j].tolist()}
            for j in range(columns.shape[1])]


def _calibration(labels, probability):
    bins = np.minimum((probability * 10).astype(int), 9)
    rows = []
    ece = 0.0
    for index in range(10):
        take = bins == index
        n = int(take.sum())
        if not n:
            continue
        predicted = float(probability[take].mean())
        observed = float(labels[take].mean())
        ece += n / len(labels) * abs(predicted - observed)
        rows.append({"bin": index, "n": n, "mean_probability": predicted,
                     "observed_rate": observed})
    return {"binning": "10 equal-width probability bins; descriptive only", "ece": ece, "bins": rows}


def _group(labels, students, predictions, mask, repetitions, seed, include_calibration=False):
    indices = np.flatnonzero(mask)
    if not len(indices):
        return {"n": 0, "students": 0, "metrics": {}, "paired": {}}
    y, user = labels[indices], students[indices]
    rows, losses = {}, {}
    for mode in MODES:
        rows[mode], losses[mode] = {}, []
        for model_seed in (0, 1, 2):
            probability = predictions[mode][model_seed][indices]
            value = metrics(y, probability, user)
            if include_calibration:
                value["calibration"] = _calibration(y, probability)
            rows[mode][model_seed] = value
            losses[mode].append(binary_losses(y, probability)[0])
    mean_loss = {mode: np.stack(losses[mode], axis=0).mean(axis=0) for mode in MODES}
    columns = np.stack([mean_loss[a] - mean_loss[b] for a, b in CONTRASTS.values()], axis=1)
    intervals = _intervals(user, columns, repetitions, seed)
    paired = dict(zip(CONTRASTS, intervals))
    for name, (a, b) in CONTRASTS.items():
        paired[name]["per_seed_event_delta"] = [
            float((losses[a][s] - losses[b][s]).mean()) for s in (0, 1, 2)
        ]
        paired[name]["interpretation"] = (
            "negative favors first named model; fixed trained models; "
            "student-cluster percentile interval; not adjusted for model selection"
        )
    summary = {}
    for mode in MODES:
        summary[mode] = {}
        for metric in ("nll", "auc", "brier", "student_macro_nll"):
            values = [rows[mode][s][metric] for s in (0, 1, 2)]
            summary[mode][metric] = {
                "mean": None if any(v is None for v in values) else float(np.mean(values)),
                "sample_sd": None if any(v is None for v in values) else float(np.std(values, ddof=1)),
            }
    return {"n": len(y), "students": len(np.unique(user)), "metrics": rows,
            "model_summary": summary, "paired": paired}


def analyze(features, predictions, *, repetitions=2000, seed=20261112):
    if repetitions < 1:
        raise ValueError("bootstrap repetitions must be positive")
    indices = np.flatnonzero(features["split"] == 1)
    if not len(indices):
        raise ValueError("no development predictions to analyze")
    labels = features["label"][indices]
    students = features["student"][indices]
    checked = {}
    for mode in MODES:
        if mode not in predictions or set(predictions[mode]) != {0, 1, 2}:
            raise ValueError(f"missing or extra seeds for {mode}")
        checked[mode] = {}
        for model_seed in (0, 1, 2):
            p = np.asarray(predictions[mode][model_seed], dtype=np.float64)
            if p.shape != labels.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f"invalid predictions for {mode} seed {model_seed}")
            checked[mode][model_seed] = p
    if set(predictions) != set(MODES):
        raise ValueError("unexpected model mode")
    overall = _group(labels, students, checked, np.ones(len(labels), dtype=bool), repetitions, seed,
                     include_calibration=True)
    previous = features["prior_kc_count"][indices]
    gap = features["gap_hours"][indices]
    groups = {
        "first_kc": previous == 0,
        "repeat_zero_gap": (previous > 0) & (gap == 0),
        "repeat_gap_0_to_24h": (previous > 0) & (gap > 0) & (gap <= 24),
        "repeat_gap_24_to_168h": (previous > 0) & (gap > 24) & (gap <= 168),
        "repeat_gap_gt_168h": (previous > 0) & (gap > 168),
    }
    result_groups = {name: _group(labels, students, checked, mask, repetitions, seed + number + 1)
                     for number, (name, mask) in enumerate(groups.items())}
    _, inverse, student_counts = np.unique(students, return_inverse=True, return_counts=True)
    event_student_count = student_counts[inverse]
    activity = {"1_to_5": event_student_count <= 5,
                "6_to_10": (event_student_count >= 6) & (event_student_count <= 10),
                "11_to_20": (event_student_count >= 11) & (event_student_count <= 20),
                "21_or_more": event_student_count >= 21}
    activity_results = {name: _group(labels, students, checked, mask, repetitions, seed + 100 + number)
                        for number, (name, mask) in enumerate(activity.items())}
    return {"overall": overall, "groups": result_groups, "development_activity_groups": activity_results,
            "bootstrap_repetitions": repetitions, "bootstrap_seed": seed,
            "scope": "reused development; fixed selected models; exploratory comparisons",
            "activity_note": "per-student scored development events, not total history or activity",
            "group_note": "first-KC and same-KC elapsed time are based on selected allowed history",
            "uncertainty_note": "cluster bootstrap excludes training, tuning, and model-selection uncertainty"}
