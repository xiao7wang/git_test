"""Build a self-contained, hash-verified ZIP from tracked source and two references."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def build(destination, count0, count12):
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".zip" or destination.exists():
        raise FileExistsError(f"ZIP destination must be new: {destination}")
    protocol = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    files = {}
    tracked = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"],
                             check=True, stdout=subprocess.PIPE).stdout
    for raw in tracked.split(b"\0"):
        if not raw:
            continue
        name = raw.decode("utf-8")
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(f"tracked file missing: {name}")
        data = path.read_bytes()
        if name.endswith(".sh") and b"\r" in data:
            raise ValueError(f"shell script must use LF line endings: {name}")
        files[name] = data
    for path in (Path(count0), Path(count12)):
        data = path.read_bytes()
        expected = protocol["references"].get(path.name)
        if expected is None or hashlib.sha256(data).hexdigest() != expected:
            raise ValueError(f"reference archive does not match locked protocol: {path}")
        files[f"references/{path.name}"] = data
    manifest = {"format": 1, "files": {name: hashlib.sha256(data).hexdigest()
                                       for name, data in sorted(files.items())}}
    files["release_manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2,
                                                   sort_keys=True) + "\n").encode("utf-8")
    pending = destination.with_suffix(destination.suffix + ".pending")
    if pending.exists():
        raise FileExistsError(f"pending archive is preserved: {pending}")
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name, data in sorted(files.items()):
            compression = zipfile.ZIP_STORED if name.startswith("references/") else zipfile.ZIP_DEFLATED
            bundle.writestr(name, data, compress_type=compression)
    with zipfile.ZipFile(pending) as bundle:
        if bundle.testzip() is not None:
            raise ValueError("release ZIP CRC failure")
        for name, data in files.items():
            if bundle.read(name) != data:
                raise ValueError(f"release ZIP member differs: {name}")
    pending.replace(destination)
    return {"path": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "bytes": destination.stat().st_size, "entries": len(files)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--count0", required=True)
    parser.add_argument("--count12", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output, args.count0, args.count12), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
