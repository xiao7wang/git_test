"""Pack only selected development artifacts and verify every archive member."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

from .common import sha256_file
from .features import MODES


def package_results(output_dir):
    root = Path(output_dir)
    archive = root / "count_time_increment_results.zip"
    pending = root / "count_time_increment_results.zip.pending"
    if archive.exists() or pending.exists():
        raise FileExistsError("result archive already exists; not overwriting")
    names = ["status.json", "config.json", "summary.json", "events.csv.gz"]
    names += [f"jobs/{mode}_seed{seed}/{name}" for seed in (0, 1, 2) for mode in MODES
              for name in ("summary.json", "history.json", "dev_predictions.csv.gz")]
    hashes = {}
    for name in names:
        path = root / name
        if not path.is_file():
            raise FileNotFoundError(f"required result missing: {name}")
        hashes[name] = sha256_file(path)
    manifest = {"format": 1, "files": hashes,
                "checkpoint_policy": "best weights remain on server; not included in result ZIP"}
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED) as bundle:
        for name in names:
            bundle.write(root / name, arcname=name)
        bundle.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(pending) as bundle:
        bad = bundle.testzip()
        if bad is not None:
            raise ValueError(f"result archive CRC failure: {bad}")
        for name, expected in hashes.items():
            if hashlib.sha256(bundle.read(name)).hexdigest() != expected:
                raise ValueError(f"result archive hash mismatch: {name}")
    pending.replace(archive)
    return {"path": str(archive), "sha256": sha256_file(archive), "files": len(names)}
