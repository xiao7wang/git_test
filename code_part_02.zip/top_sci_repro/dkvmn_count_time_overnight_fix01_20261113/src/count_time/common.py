"""Deterministic hashes, metric calculations, and atomic local JSON writes."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path, data):
    target = Path(path)
    temporary = target.with_suffix(target.suffix + ".pending")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                         encoding="utf-8")
    temporary.replace(target)


def binary_losses(labels, probability):
    labels = np.asarray(labels, dtype=np.float64)
    probability = np.asarray(probability, dtype=np.float64)
    if labels.ndim != 1 or labels.shape != probability.shape or not len(labels):
        raise ValueError("labels and probabilities must be nonempty aligned vectors")
    if not np.isin(labels, [0, 1]).all() or not np.isfinite(probability).all():
        raise ValueError("invalid labels or probabilities")
    if ((probability < 0) | (probability > 1)).any():
        raise ValueError("probability outside [0,1]")
    clipped = np.clip(probability, 1e-7, 1 - 1e-7)
    nll = np.where(labels == 1, -np.log(clipped), -np.log1p(-clipped))
    brier = (probability - labels) ** 2
    return nll, brier


def metrics(labels, probability, students):
    nll, brier = binary_losses(labels, probability)
    labels, probability, students = np.asarray(labels), np.asarray(probability), np.asarray(students)
    if students.shape != labels.shape:
        raise ValueError("student identities do not align")
    order = np.argsort(probability, kind="stable")
    _, start, sizes = np.unique(probability[order], return_index=True, return_counts=True)
    ranks = np.repeat(start + (sizes + 1) / 2.0, sizes)
    positives = int(labels.sum())
    negatives = len(labels) - positives
    auc = (float((ranks[labels[order] == 1].sum() - positives * (positives + 1) / 2)
                 / (positives * negatives)) if positives and negatives else None)
    _, inverse = np.unique(students, return_inverse=True)
    counts = np.bincount(inverse)
    student_loss = np.bincount(inverse, weights=nll) / counts
    return {"n": len(labels), "students": len(counts), "nll": float(nll.mean()),
            "auc": auc, "brier": float(brier.mean()), "student_macro_nll": float(student_loss.mean())}


def model_digest(state_dict):
    digest = hashlib.sha256()
    for name, tensor in sorted(state_dict.items()):
        value = tensor.detach().cpu().contiguous().numpy()
        digest.update(name.encode())
        digest.update(str(value.dtype).encode())
        digest.update(str(value.shape).encode())
        digest.update(value.tobytes())
    return digest.hexdigest()
