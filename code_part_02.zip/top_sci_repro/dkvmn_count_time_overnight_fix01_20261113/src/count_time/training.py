"""Matched PFA-inspired log-count model and per-run dev-NLL selection."""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from .common import metrics, model_digest, sha256_file, write_json
from .features import MODES


class CountModel(nn.Module):
    """Same trainable architecture as the earlier self-written count variant."""

    def __init__(self, students, items, kcs):
        super().__init__()
        self.student = nn.Embedding(students, 1)
        self.item = nn.Embedding(items, 1)
        self.kc = nn.Embedding(kcs, 3)
        for parameter in self.parameters():
            nn.init.zeros_(parameter)

    def forward(self, student, item, kc, success, failure):
        terms = self.kc(kc)
        return (self.student(student).squeeze(-1) + self.item(item).squeeze(-1) + terms[:, 0]
                + terms[:, 1] * torch.log1p(success) + terms[:, 2] * torch.log1p(failure))


def fit_mode(features, mode, seed, output_dir, *, epochs=20, patience=5,
             batch_size=8192, learning_rate=0.01, weight_decay=1e-5, device="cpu"):
    if mode not in MODES or seed not in (0, 1, 2):
        raise ValueError("invalid mode or seed")
    if min(epochs, patience, batch_size) < 1 or learning_rate <= 0 or weight_decay < 0:
        raise ValueError("invalid optimizer settings")
    train_idx = np.flatnonzero(features["split"] == 0)
    valid_idx = np.flatnonzero(features["split"] == 1)
    if not len(train_idx) or not len(valid_idx):
        raise ValueError("both training and development need observations")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    chosen_device = torch.device(device)
    if chosen_device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable")
    torch.set_num_threads(4)
    torch.manual_seed(seed)
    if chosen_device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    success, failure = features["states"][mode]
    tensors = {name: torch.as_tensor(features[name], dtype=torch.long, device=chosen_device)
               for name in ("student", "item", "kc")}
    tensors["success"] = torch.as_tensor(success, dtype=torch.float32, device=chosen_device)
    tensors["failure"] = torch.as_tensor(failure, dtype=torch.float32, device=chosen_device)
    tensors["label"] = torch.as_tensor(features["label"], dtype=torch.float32, device=chosen_device)
    train = torch.as_tensor(train_idx, dtype=torch.long, device=chosen_device)
    valid = torch.as_tensor(valid_idx, dtype=torch.long, device=chosen_device)
    model = CountModel(features["n_students"], features["n_items"], features["n_kcs"]).to(chosen_device)
    initial_hash = model_digest(model.state_dict())
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)

    def logits(indices):
        return model(*(tensors[key][indices] for key in ("student", "item", "kc", "success", "failure")))

    history = []
    best_nll, best_epoch, stale = float("inf"), None, 0
    for epoch in range(1, epochs + 1):
        tick = time.monotonic()
        model.train()
        permuted = train[torch.randperm(len(train), device=chosen_device)]
        order = permuted.detach().cpu().numpy().astype("<i8", copy=False)
        order_hash = hashlib.sha256(order.tobytes()).hexdigest()
        total = 0.0
        for start in range(0, len(train), batch_size):
            indices = permuted[start:start + batch_size]
            optimizer.zero_grad(set_to_none=True)
            loss = F.binary_cross_entropy_with_logits(logits(indices), tensors["label"][indices])
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("nonfinite training loss")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0, error_if_nonfinite=True)
            optimizer.step()
            total += float(loss.detach()) * len(indices)
        model.eval()
        with torch.no_grad():
            probability = torch.sigmoid(logits(valid)).cpu().numpy()
        observed = metrics(features["label"][valid_idx], probability, features["student"][valid_idx])
        nll = observed["nll"]
        improved = nll < best_nll
        if improved:
            best_nll, best_epoch, stale = nll, epoch, 0
            pending = out / "best_model.pending.pt"
            torch.save({"model_state": model.state_dict(), "epoch": epoch,
                        "dev_nll": nll, "mode": mode, "seed": seed}, pending)
            pending.replace(out / "best_model.pt")
        else:
            stale += 1
        row = {"epoch": epoch, "train_bce": total / len(train), "dev": observed,
               "train_order_sha256": order_hash, "improved": improved,
               "seconds": time.monotonic() - tick}
        history.append(row)
        write_json(out / "history.json", history)
        print(json.dumps({"mode": mode, "seed": seed, "epoch": epoch, "dev_nll": nll,
                          "improved": improved, "seconds": row["seconds"]}), flush=True)
        if stale >= patience:
            break
    checkpoint = torch.load(out / "best_model.pt", map_location=chosen_device, weights_only=True)
    model.load_state_dict(checkpoint["model_state"], strict=True)
    model.eval()
    with torch.no_grad():
        probability = torch.sigmoid(logits(valid)).cpu().numpy()
    final = metrics(features["label"][valid_idx], probability, features["student"][valid_idx])
    if abs(final["nll"] - best_nll) > 1e-7:
        raise AssertionError("selected checkpoint does not reproduce development NLL")
    with gzip.open(out / "dev_predictions.csv.gz", "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("record_idx", "student_idx", "label", "probability"))
        for index, p in zip(valid_idx, probability):
            writer.writerow((int(features["record_idx"][index]), int(features["student"][index]),
                             int(features["label"][index]), format(float(p), ".9g")))
    summary = {"status": "complete", "mode": mode, "seed": seed, "epochs": len(history),
               "best_epoch": best_epoch, "dev": final, "initial_state_sha256": initial_hash,
               "checkpoint_sha256": sha256_file(out / "best_model.pt"),
               "checkpoint_model_state_sha256": model_digest(model.state_dict()),
               "test_evaluated": False, "holdout_evaluated": False,
               "seconds": time.monotonic() - started}
    write_json(out / "summary.json", summary)
    return {"summary": summary, "history": history, "probability": probability.astype(np.float64)}
