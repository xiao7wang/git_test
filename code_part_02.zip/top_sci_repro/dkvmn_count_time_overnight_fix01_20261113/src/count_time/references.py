"""Verify existing development references without using new test outcomes."""
from __future__ import annotations

import csv
import gzip
import io
import zipfile

import numpy as np

from .common import sha256_file


def validate_reference(features, archive, member, expected_sha256):
    if sha256_file(archive) != expected_sha256:
        raise ValueError(f"reference archive SHA256 changed: {archive}")
    with zipfile.ZipFile(archive) as bundle:
        with bundle.open(member) as compressed:
            with gzip.GzipFile(fileobj=compressed) as raw:
                with io.TextIOWrapper(raw, encoding="utf-8", newline="") as text:
                    reader = csv.DictReader(text)
                    required = {"record_idx", "student_idx", "label", "probability"}
                    if reader.fieldnames is None or not required.issubset(reader.fieldnames):
                        raise ValueError("reference lacks required columns")
                    values = [(int(r["record_idx"]), int(r["student_idx"]), float(r["label"]),
                               float(r["probability"])) for r in reader]
    if not values:
        raise ValueError("empty reference")
    reference = np.asarray(values, dtype=np.float64)
    valid = np.flatnonzero(features["split"] == 1)
    expected = np.stack((features["record_idx"][valid], features["student"][valid],
                         features["label"][valid]), axis=1)
    if reference.shape != (len(valid), 4) or not np.array_equal(reference[:, :3], expected):
        raise ValueError("reference development event/student/label identity mismatch")
    p = reference[:, 3]
    if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
        raise ValueError("invalid reference probability")
    return {"n": len(valid), "sha256": expected_sha256, "probability": p}
