"""Causal same-student/KC historical counts under three fixed rules.

Only selected train and development labels participate. First encounters have
no history. At repeated encounters the history is discounted before prediction,
and the current label is appended only after the features have been recorded.
"""
from __future__ import annotations

import math

import numpy as np


MODES = ("A_none", "B_fixed", "C_real_time")


def construct(arrays, development_users, *, fixed_discount=0.8, half_life_hours=168.0):
    fixed_discount = float(fixed_discount)
    half_life_hours = float(half_life_hours)
    if not (math.isfinite(fixed_discount) and 0 < fixed_discount <= 1):
        raise ValueError("fixed_discount must be in (0, 1]")
    if not (math.isfinite(half_life_hours) and half_life_hours > 0):
        raise ValueError("half_life_hours must be positive and finite")
    needed = ("student_idx", "item_idx", "label", "split", "timestamp", "item_q")
    if any(name not in arrays for name in needed):
        raise ValueError("missing a required source array")
    users_all = np.asarray(arrays["student_idx"])
    items_all = np.asarray(arrays["item_idx"])
    splits_all = np.asarray(arrays["split"])
    timestamps_all = np.asarray(arrays["timestamp"])
    labels_all = np.asarray(arrays["label"])
    q = np.asarray(arrays["item_q"])
    n = len(users_all)
    if n == 0 or any(a.ndim != 1 or len(a) != n for a in
                     (users_all, items_all, splits_all, timestamps_all, labels_all)):
        raise ValueError("row arrays must be nonempty equal-length vectors")
    if q.ndim != 2 or not q.shape[0] or not q.shape[1]:
        raise ValueError("item_q must be a nonempty matrix")
    if not np.isin(q, [0, 1]).all() or not (q.sum(axis=1) == 1).all():
        raise ValueError("only binary single-KC Q matrices are supported")
    if not np.isin(splits_all, [0, 1, 2]).all():
        raise ValueError("unknown split code")
    if (users_all < 0).any() or (items_all < 0).any() or (items_all >= len(q)).any():
        raise ValueError("student/item index out of range")

    development_users = np.asarray(sorted(set(int(u) for u in development_users)), dtype=np.int64)
    chosen = (splits_all == 0) | ((splits_all == 1) & np.isin(users_all, development_users))
    record_idx = np.flatnonzero(chosen).astype(np.int64)
    if not len(record_idx):
        raise ValueError("no allowed train/development records")
    u = users_all[record_idx].astype(np.int64)
    item = items_all[record_idx].astype(np.int64)
    split = splits_all[record_idx].astype(np.int8)
    y = labels_all[record_idx].astype(np.float64)
    time = timestamps_all[record_idx].astype(np.float64)
    if not np.isin(y, [0, 1]).all():
        raise ValueError("selected labels must be binary")
    if not np.isfinite(time).all():
        raise ValueError("selected timestamps must be finite")
    if (np.diff(u) < 0).any():
        raise ValueError("students must be grouped in source record order")
    same_user = u[1:] == u[:-1]
    if ((time[1:] < time[:-1]) & same_user).any():
        raise ValueError("selected student records are not chronological")
    if ((split[1:] < split[:-1]) & same_user).any():
        raise ValueError("train and development splits interleave")
    kc = np.argmax(q, axis=1)[item].astype(np.int64)

    states = {mode: (np.empty(len(u), dtype=np.float64), np.empty(len(u), dtype=np.float64))
              for mode in MODES}
    gap = np.full(len(u), np.nan, dtype=np.float64)
    prior_count = np.empty(len(u), dtype=np.int64)
    order = np.lexsort((record_idx, kc, u))
    last_student, last_kc = -1, -1
    positives = [0.0, 0.0, 0.0]
    negatives = [0.0, 0.0, 0.0]
    seen = 0
    last_time = 0.0
    coefficient = math.log(2.0) / (3600.0 * half_life_hours)
    for index in order:
        student, concept = int(u[index]), int(kc[index])
        if student != last_student or concept != last_kc:
            positives = [0.0, 0.0, 0.0]
            negatives = [0.0, 0.0, 0.0]
            seen = 0
            last_student, last_kc = student, concept
        now = float(time[index])
        prior_count[index] = seen
        if seen:
            seconds = now - last_time
            if seconds < 0:
                raise ValueError("same-KC timestamp decreased")
            gap[index] = seconds / 3600.0
            factor = math.exp(-coefficient * seconds)
            positives[1] *= fixed_discount
            negatives[1] *= fixed_discount
            positives[2] *= factor
            negatives[2] *= factor
        for mode_index, mode in enumerate(MODES):
            states[mode][0][index] = positives[mode_index]
            states[mode][1][index] = negatives[mode_index]
        outcome = int(y[index])
        for mode_index in range(3):
            positives[mode_index] += outcome
            negatives[mode_index] += 1 - outcome
        last_time = now
        seen += 1
    return {
        "record_idx": record_idx, "student": u, "item": item, "kc": kc,
        "label": y.astype(np.float32), "split": split, "timestamp": time,
        "gap_hours": gap, "prior_kc_count": prior_count, "states": states,
        "n_students": int(users_all.max()) + 1, "n_items": int(q.shape[0]),
        "n_kcs": int(q.shape[1]),
    }


def check_legacy_counts(features):
    """Independently recompute the original cumulative log-count features."""
    u, kc, y, idx = (features[key] for key in ("student", "kc", "label", "record_idx"))
    order = np.lexsort((idx, kc, u))
    sorted_u, sorted_k, sorted_y = u[order], kc[order], y[order].astype(np.int64)
    first = np.r_[True, (sorted_u[1:] != sorted_u[:-1]) | (sorted_k[1:] != sorted_k[:-1])]
    group_start = np.maximum.accumulate(np.where(first, np.arange(len(idx)), 0))
    cumulative = np.cumsum(sorted_y)
    before = np.zeros(len(idx), dtype=np.int64)
    mask = group_start > 0
    before[mask] = cumulative[group_start[mask] - 1]
    positive_sorted = cumulative - sorted_y - before
    negative_sorted = np.arange(len(idx)) - group_start - positive_sorted
    positive, negative = np.empty(len(idx), dtype=np.int64), np.empty(len(idx), dtype=np.int64)
    positive[order], negative[order] = positive_sorted, negative_sorted
    actual_positive, actual_negative = features["states"]["A_none"]
    return {
        "match": bool(np.array_equal(actual_positive, positive) and
                      np.array_equal(actual_negative, negative)),
        "events": len(idx),
        "method": "independent vectorized group cumulative sum",
    }
