"""Run the fixed three-by-three development-only experiment."""
from __future__ import annotations

import csv
import gzip
import json
import time
from pathlib import Path

import numpy as np

from .analysis import analyze
from .common import metrics, write_json
from .features import MODES, check_legacy_counts, construct
from .package import package_results
from .references import validate_reference
from .training import fit_mode


def _write_events(path, features):
    users = features["student"]
    starts = np.r_[True, users[1:] != users[:-1]]
    begin = np.maximum.accumulate(np.where(starts, np.arange(len(users)), 0))
    prior_student = np.arange(len(users)) - begin
    dev = np.flatnonzero(features["split"] == 1)
    with gzip.open(path, "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("record_idx", "student_idx", "label", "kc_idx", "prior_kc_count",
                         "prior_student_count_selected_history", "same_kc_gap_hours"))
        for i in dev:
            gap = features["gap_hours"][i]
            writer.writerow((int(features["record_idx"][i]), int(users[i]),
                             int(features["label"][i]), int(features["kc"][i]),
                             int(features["prior_kc_count"][i]), int(prior_student[i]),
                             "" if np.isnan(gap) else format(float(gap), ".17g")))


def run_in_memory(arrays, development_users, output_dir, *, device="cpu", epochs=20,
                  patience=5, batch_size=8192, repetitions=2000, run_metadata=None,
                  reference_sources=None):
    output = Path(output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if not development_users:
        raise ValueError("development student set is empty")
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    status = {"status": "running", "phase": "features", "test_evaluated": False,
              "holdout_evaluated": False}
    write_json(output / "status.json", status)
    try:
        feature_started = time.monotonic()
        print("Constructing chronological same-KC histories", flush=True)
        data = construct(arrays, development_users, fixed_discount=0.8, half_life_hours=168.0)
        selected_train = np.flatnonzero(data["split"] == 0)
        selected_dev = np.flatnonzero(data["split"] == 1)
        if not len(selected_train) or not len(selected_dev):
            raise ValueError("training or development is empty")
        if not set(data["student"][selected_dev]).issubset(development_users):
            raise ValueError("non-development student entered evaluation")
        legacy = check_legacy_counts(data)
        if not legacy["match"]:
            raise AssertionError("undiscounted counts differ from original vectorized count definition")
        reference_probability = {}
        if reference_sources is not None:
            if set(reference_sources) != {0, 1, 2}:
                raise ValueError("three locked count references are required")
            for seed in (0, 1, 2):
                source = reference_sources[seed]
                reference_probability[seed] = validate_reference(
                    data, source["archive"], source["member"], source["sha256"])["probability"]
        feature_seconds = time.monotonic() - feature_started
        print(json.dumps({"phase": "features_complete", "selected_train": len(selected_train),
                          "development": len(selected_dev), "seconds": feature_seconds}), flush=True)
        config = {
            "protocol": "count_time_increment_exploratory_v1",
            "model": "PFA-inspired log-count with student/item/KC biases; not canonical PFA",
            "modes": list(MODES), "seeds": [0, 1, 2], "fixed_discount": 0.8,
            "half_life_hours": 168.0, "epochs_max": epochs, "patience": patience,
            "batch_size": batch_size, "learning_rate": 0.01, "weight_decay": 1e-5,
            "gradient_clip": 5.0, "device": device, "selection": "development event NLL",
            "training_rows": len(selected_train), "development_events": len(selected_dev),
            "development_students": int(len(np.unique(data["student"][selected_dev]))),
            "bootstrap_repetitions": repetitions, "bootstrap_seed": 20261112,
            "feedback": "predict before row-immediate feedback; platform timing unverified",
            "time": "event timestamp proxy; real-time decay uses elapsed same-KC hours",
            "time_ties": "B discounts every repeated event; C leaves history unchanged at zero gap",
            "parameter_note": "0.8 and 168h came from previous Beta-state exploration and are not established optima for count model",
            "legacy_feature_check": legacy, "feature_construction_seconds": feature_seconds,
            "reference_event_identity_checked": bool(reference_sources is not None),
            "test_evaluated": False, "holdout_evaluated": False,
            "metadata": run_metadata or {},
        }
        write_json(output / "config.json", config)
        _write_events(output / "events.csv.gz", data)
        predictions = {mode: {} for mode in MODES}
        jobs, baseline_reference_check = {}, {}
        for seed in (0, 1, 2):
            per_seed = {}
            for mode in MODES:
                status.update(phase="training", mode=mode, seed=seed)
                write_json(output / "status.json", status)
                print(json.dumps({"phase": "job_start", "mode": mode, "seed": seed}), flush=True)
                result = fit_mode(data, mode, seed, output / "jobs" / f"{mode}_seed{seed}",
                                  epochs=epochs, patience=patience, batch_size=batch_size, device=device)
                predictions[mode][seed] = result["probability"]
                jobs[f"{mode}_seed{seed}"] = result["summary"]
                per_seed[mode] = result
                if mode == "A_none" and seed in reference_probability:
                    reference = reference_probability[seed]
                    current = result["probability"]
                    y = data["label"][selected_dev]
                    students = data["student"][selected_dev]
                    old_metrics = metrics(y, reference, students)
                    new_metrics = result["summary"]["dev"]
                    max_probability_difference = float(np.max(np.abs(current - reference)))
                    nll_difference = float(new_metrics["nll"] - old_metrics["nll"])
                    baseline_reference_check[str(seed)] = {
                        "max_absolute_probability_difference": max_probability_difference,
                        "nll_difference": nll_difference,
                        "nll_absolute_tolerance": 1e-6,
                        "max_probability_absolute_tolerance": 1e-5,
                    }
                    write_json(output / "baseline_reference_check.json", baseline_reference_check)
                    if abs(nll_difference) > 1e-6 or max_probability_difference > 1e-5:
                        raise ValueError(f"undiscounted baseline did not reproduce prior prediction for seed {seed}")
            initial = {item["summary"]["initial_state_sha256"] for item in per_seed.values()}
            if len(initial) != 1:
                raise AssertionError(f"initial model states differ within seed {seed}")
            common_epochs = min(len(item["history"]) for item in per_seed.values())
            for epoch in range(common_epochs):
                order = {item["history"][epoch]["train_order_sha256"] for item in per_seed.values()}
                if len(order) != 1:
                    raise AssertionError(f"training order differs within seed {seed}, epoch {epoch+1}")
        status.update(phase="analysis", mode=None, seed=None)
        write_json(output / "status.json", status)
        summary = {"status": "complete", "scope": "reused ASSIST development only; exploratory",
                   "jobs": jobs, "analysis": analyze(data, predictions, repetitions=repetitions),
                   "baseline_reference_check": baseline_reference_check,
                   "test_evaluated": False, "holdout_evaluated": False,
                   "seconds_before_packaging": time.monotonic() - started}
        write_json(output / "summary.json", summary)
        status.update(status="complete", phase="complete", seconds=time.monotonic() - started)
        write_json(output / "status.json", status)
        archive = package_results(output)
        print("RESULTS READY:", archive["path"], flush=True)
        return {"status": "complete", "archive": archive, "summary": summary}
    except BaseException as exc:
        status.update(status="failed", error=repr(exc), seconds=time.monotonic() - started)
        write_json(output / "status.json", status)
        raise
