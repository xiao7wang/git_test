"""Build a self-contained, digest-verified release without source data."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def build(destination, count_reference, dkvmn_reference):
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".zip" or destination.exists():
        raise FileExistsError(f"ZIP destination must be new: {destination}")
    protocol = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    paths = [ROOT / "run_server.sh", ROOT / "README.md", ROOT / ".gitattributes", ROOT / ".gitignore"]
    for name in ("src/count_time", "src/fixed_controls", "src/dkvmn_ref", "src/overnight", "tests", "checks"):
        paths.extend(sorted((ROOT / name).glob("*.py")))
    paths.extend(sorted((ROOT / "contracts").glob("*.json")))
    paths.append(ROOT / "vendor/pykt_LICENSE.txt")
    files = {}
    for path in paths:
        name = path.relative_to(ROOT).as_posix()
        payload = path.read_bytes()
        if name.endswith(".sh") and b"\r" in payload:
            raise ValueError(f"shell script must use LF: {name}")
        files[name] = payload
    vendor = json.loads((ROOT / "contracts/vendor_manifest.json").read_text(encoding="utf-8"))["files"]
    for name, expected in vendor.items():
        if hashlib.sha256(files[name]).hexdigest() != expected:
            raise ValueError(f"prior source changed: {name}")
    for path, name, expected in ((Path(count_reference), "count_time_increment_results.zip", protocol["count_reference_sha256"]),
                                 (Path(dkvmn_reference), "dkvmn_seedrep_results_20261111.zip", protocol["dkvmn_reference_sha256"])):
        payload = path.read_bytes()
        if hashlib.sha256(payload).hexdigest() != expected:
            raise ValueError(f"prior archive SHA-256 differs: {path}")
        files[f"references/{name}"] = payload
    manifest = {"format": 1, "files": {name: hashlib.sha256(payload).hexdigest() for name, payload in sorted(files.items())}}
    files["release_manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    pending = destination.with_suffix(destination.suffix + ".pending")
    if pending.exists():
        raise FileExistsError(f"pending release is preserved: {pending}")
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED) as z:
        for name, payload in sorted(files.items()):
            z.writestr(name, payload, compress_type=zipfile.ZIP_STORED if name.startswith("references/") else zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or set(z.namelist()) != set(files):
            raise ValueError("release CRC or member list failure")
        for name, payload in files.items():
            if z.read(name) != payload:
                raise ValueError(f"release archive member differs: {name}")
    pending.replace(destination)
    return {"path": str(destination), "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(),
            "bytes": destination.stat().st_size, "entries": len(files)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--count-reference", required=True)
    parser.add_argument("--dkvmn-reference", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output, args.count_reference, args.dkvmn_reference), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
