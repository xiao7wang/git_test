"""Pinned server entry point; no test or holdout evaluation."""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SALT, SOURCE_HASHES, development_users, load_prepared
from fixed_controls.references import load_dkvmn, load_prior
from .runner import run_in_memory

ROOT = Path(__file__).resolve().parents[2]


def verify_release():
    path = ROOT / "release_manifest.json"
    if not path.is_file():
        raise FileNotFoundError("release manifest missing; use the delivered ZIP")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    entries = manifest.get("files")
    required = {"run_server.sh", "contracts/protocol.json", "contracts/vendor_manifest.json",
                "checks/verify.py", "checks/guard.py", "src/overnight/server.py", "src/overnight/train.py",
                "src/dkvmn_ref/upstream.py", "src/dkvmn_ref/bias.py", "vendor/pykt_LICENSE.txt",
                "references/count_time_increment_results.zip", "references/dkvmn_seedrep_results_20261111.zip"}
    if not isinstance(entries, dict) or not required.issubset(entries):
        raise ValueError("release manifest lacks required files")
    for name, expected in entries.items():
        path_item = (ROOT / name).resolve()
        if not path_item.is_relative_to(ROOT) or not path_item.is_file() or sha256_file(path_item) != expected:
            raise ValueError(f"release file missing or SHA-256 mismatch: {name}")
    vendor = json.loads((ROOT / "contracts/vendor_manifest.json").read_text(encoding="utf-8"))["files"]
    for name, expected in vendor.items():
        if name not in entries or sha256_file(ROOT / name) != expected:
            raise ValueError(f"prior source mismatch: {name}")
    expected_pykt = "28b42859bc4210682efaf3492fdf6edb3c3e37b8466ccaac041c3018c48fd77c"
    expected_bias = "1374c6000111da1d323cccd81a2600e6dd8ff6a84c7e2f43857c6eec57f3321c"
    if sha256_file(ROOT / "src/dkvmn_ref/upstream.py") != expected_pykt or sha256_file(ROOT / "src/dkvmn_ref/bias.py") != expected_bias:
        raise ValueError("upstream DKVMN or previous bias adapter differs from prior reference")
    return {"manifest_sha256": sha256_file(path), "file_count": len(entries)}


def _protocol():
    p = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    if (p["dataset_manifest_sha256"] != DATA_FINGERPRINT or p["student_partition_salt"] != SALT or
            p["count_reference_sha256"] != "eab986459c2bea65cd016393da9c85127e2ce7086243e93242eb9b9420509733" or
            p["dkvmn_reference_sha256"] != "d08d0584aa49d15aa7657428a565ba016a89ffaeb654db64e9d07cb3f4fb4a32" or
            p["fixed_discount"] != .8 or p["time_half_life_hours"] != 168. or
            p["negative_gap_shuffle_seeds"] != [11, 29, 47] or p["negative_count_training_seeds"] != [0, 1, 2] or
            p["hybrid_modes"] != ["fixed_08", "time_168h"] or p["hybrid_seeds"] != [1, 2] or
            p["hybrid_jobs"] != ["fixed_08_seed1", "time_168h_seed1", "fixed_08_seed2", "time_168h_seed2"] or
            p["batch_size"] != 8 or p["chunk_size"] != 50 or p["max_epochs"] != 20 or p["patience"] != 5 or
            p["optimizer"] != "Adam" or p["learning_rate"] != .001 or p["gradient_clip"] != 5. or
            p["memory_slots"] != 20 or p["embedding_dim"] != 32 or p["dropout"] != .2 or
            p["bootstrap_repetitions"] != 2000 or p["bootstrap_seed"] != 20261123 or
            p["primary_contrast"] != "hybrid_time_168h minus hybrid_fixed_08, paired mean per-event NLL across seeds 1 and 2" or
            p["test_evaluated"] is not False or p["holdout_evaluated"] is not False):
        raise ValueError("frozen experiment protocol differs from implementation")
    return p


def _verify_dk_reference_settings(path):
    with zipfile.ZipFile(path) as bundle:
        configs = [json.loads(bundle.read(f"bias_seed{seed}/config.json")) for seed in (1, 2)]
    for seed, cfg in zip((1, 2), configs):
        if (cfg["seed"] != seed or cfg["variant"] != "bias" or cfg["dim_s"] != 32 or cfg["memory_slots"] != 20 or
                cfg["dropout"] != .2 or cfg["optimizer"] != "Adam" or cfg["lr"] != .001 or
                cfg["batch_size"] != 8 or cfg["chunk_size"] != 50 or cfg["epochs_max"] != 20 or cfg["patience"] != 5 or
                cfg["data_fingerprint"] != DATA_FINGERPRINT or cfg["student_partition_salt"] != SALT or
                not cfg["feedback"].startswith("row immediate assumption") or
                cfg["train_expected_events"] != 1847688 or cfg["development_events"] != 126854 or cfg["development_students"] != 10036 or
                cfg["test_evaluated"] is not False or cfg["holdout_evaluated"] is not False or
                cfg["source_archive_sha256"] != "b3267c5cec072ab7a605e25a70b938e3a7aa7800ad79d67554a02ce745d56640"):
            raise ValueError(f"previous DKVMN seed {seed} protocol mismatch")
    return {"prior_seeds": [1, 2], "matched_old_architecture": "bias DKVMN; hybrid adds count readout",
            "note": "previous results do not contain initial-state hashes; initialization/order are proven between new paired jobs only"}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    for name in ("project-dir", "data-dir", "reference-dir", "output-dir"):
        parser.add_argument("--" + name)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--ack-row-feedback", action="store_true")
    parser.add_argument("--ack-time-proxy", action="store_true")
    args = parser.parse_args(argv)
    release, protocol = verify_release(), _protocol()
    print(json.dumps({"phase": "release_verified", **release}), flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir, args.data_dir, args.reference_dir, args.output_dir)):
        parser.error("project, data, reference and output directories are required")
    if not args.ack_row_feedback or not args.ack_time_proxy:
        parser.error("row feedback and event-time proxy assumptions must be acknowledged")
    output = Path(args.output_dir).resolve()
    base = (ROOT / "outputs").resolve()
    if not output.is_relative_to(base) or output == base:
        raise ValueError("output must be a new subdirectory of package outputs")
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if args.device != "cuda" or not torch.cuda.is_available():
        raise RuntimeError("this production protocol requires CUDA; no automatic fallback")
    free = shutil.disk_usage(base).free
    print(json.dumps({"phase": "disk_check", "free_bytes": free}), flush=True)
    if free < 512 * 1024 * 1024:
        raise OSError("less than 512 MiB free for logs, checkpoints and result snapshots")
    reference = Path(args.reference_dir).resolve()
    prior = load_prior(reference / "count_time_increment_results.zip", protocol["count_reference_sha256"])
    dkpath = reference / "dkvmn_seedrep_results_20261111.zip"
    dk = load_dkvmn(dkpath, protocol["dkvmn_reference_sha256"], prior["events"])
    dk_protocol = _verify_dk_reference_settings(dkpath)
    prior_env = prior["config"]["metadata"]
    if str(torch.__version__) != prior_env["torch"] or np.__version__ != prior_env["numpy"]:
        raise RuntimeError("PyTorch or NumPy differs from previous count experiment; cannot verify matched permutations")
    print(json.dumps({"phase": "references_verified", "development_events": len(prior["events"]["label"]),
                      "development_students": int(len(np.unique(prior["events"]["student_idx"])))}), flush=True)
    data = load_prepared(args.project_dir, args.data_dir)
    splits, students = data.arrays["split"], data.arrays["student_idx"]
    dev_users = development_users(students[splits == 1])
    train_n = int(np.sum(splits == 0))
    dev_n = int(np.sum((splits == 1) & np.isin(students, list(dev_users))))
    if (train_n, dev_n, len(dev_users)) != (1847688, 126854, 10036):
        raise ValueError(f"source coverage mismatch: train={train_n}, dev={dev_n}, students={len(dev_users)}")
    metadata = {"release": release, "data_fingerprint": data.fingerprint, "project_source_sha256": SOURCE_HASHES,
                "prior_count_sha256": protocol["count_reference_sha256"], "prior_dkvmn_sha256": protocol["dkvmn_reference_sha256"],
                "prior_dkvmn_protocol": dk_protocol, "python": platform.python_version(), "numpy": np.__version__,
                "pandas": pd.__version__, "torch": str(torch.__version__), "gpu": torch.cuda.get_device_name(0),
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "free_bytes_at_start": free,
                "prepared_data_dir": str(Path(args.data_dir).resolve()), "project_dir": str(Path(args.project_dir).resolve()),
                "test_label_note": "prepared archive loads all arrays including test labels; test rows are excluded from feature construction and scoring"}
    result = run_in_memory(data, dev_users, output, prior, dk, device=args.device,
                           epochs=protocol["max_epochs"], patience=protocol["patience"],
                           batch_size=protocol["batch_size"], count_batch_size=8192,
                           chunk_size=protocol["chunk_size"], repetitions=protocol["bootstrap_repetitions"],
                           run_metadata=metadata)
    print(json.dumps({"status": result["status"], "archive": result["archive"]}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
