"""Sequential paired hybrids plus train-only pseudo-gap development controls."""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from count_time.common import write_json
from count_time.features import check_legacy_counts, construct
from count_time.training import fit_mode
from fixed_controls.references import validate_features, validate_training_provenance
from .analysis import analyze_hybrids, analyze_surrogates
from .package import package_results
from .surrogate import pseudo_states
from .train import dense_history, fit_hybrid

MAPPINGS = (11, 29, 47)
COUNT_SEEDS = (0, 1, 2)
JOBS = (("fixed_08", 1), ("time_168h", 1), ("fixed_08", 2), ("time_168h", 2))


def run_in_memory(data, development_users, output_dir, prior, dkvmn, *, device="cpu",
                  epochs=20, patience=5, batch_size=8, count_batch_size=8192, chunk_size=50,
                  repetitions=2000, run_metadata=None):
    output = Path(output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if not development_users:
        raise ValueError("development user set is empty")
    if min(epochs, patience, batch_size, count_batch_size, chunk_size, repetitions) < 1:
        raise ValueError("training and bootstrap sizes must be positive")
    output.mkdir(parents=True, exist_ok=False)
    status_path = output / "status.json"
    started = time.monotonic()
    status = {"status": "running", "phase": "features", "active_job": None, "epoch": None,
              "completed_negative": [], "completed_hybrid": [], "test_evaluated": False,
              "holdout_evaluated": False}
    write_json(status_path, status)
    try:
        feature_started = time.monotonic()
        print(json.dumps({"phase": "features_start", "protocol": "fixed_0.8_and_time_168h"}), flush=True)
        features = construct(data.arrays, development_users, fixed_discount=.8, half_life_hours=168.)
        train = np.flatnonzero(features["split"] == 0)
        dev = np.flatnonzero(features["split"] == 1)
        if not len(train) or not len(dev) or not set(features["student"][dev]).issubset(development_users):
            raise ValueError("invalid train/development selection")
        legacy = check_legacy_counts(features)
        if not legacy["match"]:
            raise ValueError("independent undiscounted count audit failed")
        identity = validate_features(features, prior["events"])
        expected_ids = prior["events"]["record_idx"]
        (output / "events.csv.gz").write_bytes(prior["events_bytes"])
        total_rows = len(data.arrays["student_idx"])
        histories = {"fixed_08": dense_history(features, "B_fixed", total_rows),
                     "time_168h": dense_history(features, "C_real_time", total_rows)}
        config = {"protocol": "dkvmn_count_time_overnight_exploratory_v1",
                  "hybrid_description": "bias DKVMN plus shared architecture with two zero-initialized per-KC log-count coefficients",
                  "hybrid_modes": {"fixed_08": "same-KC fixed event retention 0.8", "time_168h": "same-KC elapsed time half-life 168h"},
                  "hybrid_jobs": [f"{m}_seed{s}" for m, s in JOBS], "hybrid_seeds": [1, 2],
                  "negative_gap_shuffle_seeds": list(MAPPINGS), "negative_count_training_seeds": list(COUNT_SEEDS),
                  "negative_control": "training repeated gaps shuffled; development pseudo-gaps sampled exclusively from training gap pool",
                  "epochs_max": epochs, "patience": patience, "batch_size": batch_size, "chunk_size": chunk_size,
                  "count_batch_size": count_batch_size, "hybrid_optimizer": "Adam lr=.001, no weight decay, clip=5",
                  "count_optimizer": "AdamW lr=.01, weight_decay=1e-5, clip=5",
                  "selection": "development event NLL separately per job", "bootstrap_repetitions": repetitions,
                  "bootstrap_seed": 20261123, "device": device, "train_events": len(train),
                  "development_events": len(dev), "development_students": int(len(np.unique(features["student"][dev]))),
                  "feedback": "predict before row-immediate feedback; actual platform timing unverified",
                  "time": "event-time proxy; same-KC interval; not verified actual forgetting or feedback time",
                  "selection_bias": "this development set has been used repeatedly and prior results motivated this design",
                  "feature_audit": {"prior_event_identity": identity, "undiscounted_counts": legacy,
                                    "seconds": time.monotonic() - feature_started},
                  "prior_count_archive_sha256": prior["archive_sha256"], "metadata": run_metadata or {},
                  "test_evaluated": False, "holdout_evaluated": False}
        write_json(output / "config.json", config)
        print(json.dumps({"phase": "features_complete", "selected_train": len(train), "development": len(dev),
                          "seconds": config["feature_audit"]["seconds"]}), flush=True)
        negative_predictions, negative_jobs, mapping_audit = {}, {}, {}
        for mapping in MAPPINGS:
            status.update(phase="negative_gap_construction", active_job=f"pseudo_map{mapping}", epoch=None)
            write_json(status_path, status)
            fake = pseudo_states(features, mapping)
            mapping_audit[str(mapping)] = fake["audit"]
            modified = dict(features)
            modified["states"] = dict(features["states"])
            modified["states"]["B_fixed"] = (fake["success"], fake["failure"])
            negative_predictions[mapping] = {}
            for seed in COUNT_SEEDS:
                name = f"pseudo_map{mapping}_seed{seed}"
                status.update(phase="negative_training", active_job=name, epoch=None)
                write_json(status_path, status)
                print(json.dumps({"phase": "negative_job_start", "mapping": mapping, "seed": seed}), flush=True)
                job = fit_mode(modified, "B_fixed", seed, output / "jobs" / name, epochs=epochs,
                               patience=patience, batch_size=count_batch_size, device=device)
                provenance = validate_training_provenance(job["summary"], job["history"], prior, seed)
                write_json(output / "jobs" / name / "candidate.json", {"mapping_seed": mapping, "training_seed": seed,
                                                                          "prior_count_training_provenance": provenance})
                negative_predictions[mapping][seed] = job["probability"]
                negative_jobs[name] = {"training": job["summary"], "prior_count_training_provenance": provenance}
                status["completed_negative"].append(name)
                write_json(status_path, status)
        status.update(phase="negative_analysis", active_job=None, epoch=None)
        write_json(status_path, status)
        negative_analysis = analyze_surrogates(prior["events"], prior["predictions"]["C_real_time"],
                                               prior["predictions"]["B_fixed"], negative_predictions,
                                               repetitions=repetitions)
        write_json(output / "negative_summary.json", {"analysis": negative_analysis, "mapping_audit": mapping_audit,
                                                       "jobs": negative_jobs, "scope": "development only, exploratory"})
        neg_files = ["status.json", "config.json", "events.csv.gz", "negative_summary.json"]
        neg_files += [f"jobs/pseudo_map{m}_seed{s}/{filename}" for m in MAPPINGS for s in COUNT_SEEDS
                      for filename in ("summary.json", "history.json", "candidate.json", "dev_predictions.csv.gz")]
        partial_negative = package_results(output, "partial_negative_controls.zip", neg_files)
        print(json.dumps({"phase": "negative_complete", "partial_archive": partial_negative}), flush=True)
        hybrid_jobs, hybrid_predictions, job_histories, pairing = {}, {"fixed_08": {}, "time_168h": {}}, {}, {}
        for mode, seed in JOBS:
            name = f"{mode}_seed{seed}"
            status.update(phase="hybrid_start", active_job=name, epoch=0)
            write_json(status_path, status)
            print(json.dumps({"phase": "hybrid_start", "mode": mode, "seed": seed}), flush=True)
            reference = f"fixed_08_seed{seed}"
            expected_initial = hybrid_jobs[reference]["initial_state_sha256"] if mode == "time_168h" else None
            expected_order = job_histories[reference] if mode == "time_168h" else None
            job = fit_hybrid(data, development_users, expected_ids, histories[mode], mode, seed,
                             output / "jobs" / name, status, status_path, device=device, epochs=epochs,
                             patience=patience, batch_size=batch_size, chunk_size=chunk_size,
                             expected_initial_hash=expected_initial, expected_history=expected_order)
            hybrid_jobs[name], job_histories[name] = job["summary"], job["history"]
            hybrid_predictions[mode][seed] = job["probability"]
            if mode == "time_168h":
                if hybrid_jobs[reference]["initial_state_sha256"] != job["summary"]["initial_state_sha256"]:
                    raise ValueError(f"hybrid initial states differ for seed {seed}")
                common = min(len(job_histories[reference]), len(job["history"]))
                if not common or any(job_histories[reference][i]["train_order_sha256"] != job["history"][i]["train_order_sha256"]
                                     for i in range(common)):
                    raise ValueError(f"hybrid shuffled student order differs for seed {seed}")
                pairing[str(seed)] = {"initial_state_matches": True, "matching_common_epochs": common,
                                      "fixed_epochs": len(job_histories[reference]), "time_epochs": len(job["history"])}
            status["completed_hybrid"].append(name)
            status.update(phase="hybrid_job_complete", active_job=None, epoch=None)
            write_json(status_path, status)
            files = list(neg_files)
            files += [f"jobs/{completed}/{f}" for completed in status["completed_hybrid"] for f in
                      ("summary.json", "history.json", "dev_predictions.csv.gz")]
            snapshot = package_results(output, f"partial_{name}.zip", files)
            print(json.dumps({"phase": "hybrid_complete", "job": name, "partial_archive": snapshot}), flush=True)
        status.update(phase="hybrid_analysis", active_job=None, epoch=None)
        write_json(status_path, status)
        predictions = {"hybrid_fixed": hybrid_predictions["fixed_08"], "hybrid_time": hybrid_predictions["time_168h"],
                       "dkvmn_bias": {s: dkvmn[s] for s in (1, 2)},
                       "count_fixed": {s: prior["predictions"]["B_fixed"][s] for s in (1, 2)},
                       "count_time": {s: prior["predictions"]["C_real_time"][s] for s in (1, 2)}}
        analysis = analyze_hybrids(prior["events"], predictions, repetitions=repetitions)
        summary = {"status": "complete", "scope": "same reused ASSIST development set; exploratory",
                   "hybrid_jobs": hybrid_jobs, "negative_jobs": negative_jobs, "hybrid_pairing": pairing,
                   "analysis": analysis, "negative_analysis": negative_analysis, "mapping_audit": mapping_audit,
                   "test_evaluated": False, "holdout_evaluated": False,
                   "seconds_before_packaging": time.monotonic() - started}
        write_json(output / "summary.json", summary)
        status.update(status="complete", phase="complete", active_job=None, epoch=None,
                      seconds=time.monotonic() - started)
        write_json(status_path, status)
        names = neg_files + ["summary.json"]
        names += [f"jobs/{m}_seed{s}/{f}" for m, s in JOBS for f in
                  ("summary.json", "history.json", "dev_predictions.csv.gz")]
        archive = package_results(output, "overnight_results.zip", names)
        print("RESULTS READY:", archive["path"], flush=True)
        return {"status": "complete", "archive": archive, "summary": summary}
    except BaseException as exc:
        status.update(status="failed", error=repr(exc), seconds=time.monotonic() - started)
        write_json(status_path, status)
        raise
