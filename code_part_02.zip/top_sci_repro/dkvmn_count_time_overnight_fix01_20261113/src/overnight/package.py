"""Non-overwriting snapshots and final results; every member has a digest."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

from count_time.common import sha256_file


def package_results(output_dir, name, files):
    root = Path(output_dir).resolve()
    if Path(name).name != name or not name.endswith(".zip"):
        raise ValueError("invalid result archive name")
    archive = root / name
    pending = root / (name + ".pending")
    if archive.exists() or pending.exists():
        raise FileExistsError(f"result snapshot already exists: {archive}")
    if len(set(files)) != len(files) or not files:
        raise ValueError("duplicate or empty result file list")
    hashes = {}
    for name in files:
        path = (root / name).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise FileNotFoundError(f"required result file missing or invalid: {name}")
        hashes[name] = sha256_file(path)
    manifest = {"format": 1, "files": hashes,
                "checkpoint_policy": "best and last model weights remain on server; not included in ZIP"}
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED) as z:
        for name in files:
            z.write(root / name, arcname=name,
                    compress_type=zipfile.ZIP_STORED if name.endswith(".gz") else zipfile.ZIP_DEFLATED)
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or set(z.namelist()) != set(files) | {"manifest.json"}:
            raise ValueError("snapshot CRC or member list failure")
        for name, expected in hashes.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f"snapshot member differs: {name}")
    pending.replace(archive)
    return {"path": str(archive), "sha256": sha256_file(archive), "files": len(files)}
