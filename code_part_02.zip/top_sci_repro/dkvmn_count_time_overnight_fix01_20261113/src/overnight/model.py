"""Prior bias DKVMN plus the same two-coefficient per-KC historical readout."""
from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F

from dkvmn_ref.bias import BiasDKVMN


class CountHybrid(BiasDKVMN):
    """Both variants use this exact architecture; only count histories differ.

    Coefficients are zero initialized without consuming random draws, so an
    untrained hybrid is exactly the earlier student/item-bias DKVMN. Counts are
    causal per-KC histories computed before each response; no extra parameter
    or time information enters the underlying DKVMN memory update.
    """
    def __init__(self, base, n_students, n_items):
        super().__init__(base, n_students, n_items)
        self.history_weights = nn.Parameter(torch.zeros(base.num_c, 2))

    def forward_chunk(self, students, items, kcs, answers, active_mask, feedback_mask,
                      state, success, failure):
        if kcs.ndim != 2 or any(t.shape != kcs.shape for t in
                               (items, answers, active_mask, feedback_mask, success, failure)) or students.shape != (kcs.shape[0],):
            raise ValueError("hybrid input shapes differ")
        model = self.base
        if model.emb_type != "qid":
            raise ValueError("only qid is supported")
        active = active_mask.bool()
        update = active & feedback_mask.bool()
        safe_q = torch.where(active, kcs, torch.zeros_like(kcs))
        safe_i = torch.where(active, items, torch.zeros_like(items))
        safe_y = torch.where(update, answers, torch.zeros_like(answers))
        if bool(((safe_q < 0) | (safe_q >= model.num_c)).any()) or bool(((safe_y < 0) | (safe_y > 1)).any()) or bool(((safe_i < 0) | (safe_i >= len(self.item_bias))).any()) or bool(((students < 0) | (students >= len(self.student_bias))).any()):
            raise ValueError("invalid student, item, KC or available response")
        key = model.k_emb_layer(safe_q)
        val = model.v_emb_layer(safe_q + model.num_c * safe_y)
        weights = torch.softmax(torch.matmul(key, model.Mk.T), dim=-1)
        erase, add = torch.sigmoid(model.e_layer(val)), torch.tanh(model.a_layer(val))
        # Use the same embedding lookup primitive as the existing DKVMN, so
        # repeated-KC gradients honor PyTorch's deterministic CUDA setting.
        correction_weights = F.embedding(safe_q, self.history_weights)
        correction = correction_weights[..., 0] * torch.log1p(success) + correction_weights[..., 1] * torch.log1p(failure)
        sb, ib = self.student_bias[students], self.item_bias[safe_i]
        outputs = []
        for t in range(kcs.shape[1]):
            w = weights[:, t]
            read = (w.unsqueeze(-1) * state).sum(-2)
            hidden = torch.tanh(model.f_layer(torch.cat([read, key[:, t]], dim=-1)))
            logit = model.p_layer(model.dropout_layer(hidden)).squeeze(-1) + sb + ib[:, t] + correction[:, t]
            outputs.append(torch.sigmoid(logit))
            wr = w.unsqueeze(-1)
            updated = state * (1 - wr * erase[:, t].unsqueeze(1)) + wr * add[:, t].unsqueeze(1)
            state = torch.where(update[:, t, None, None], updated, state)
        if not outputs:
            raise ValueError("empty sequence chunk")
        return torch.stack(outputs, dim=1), state
