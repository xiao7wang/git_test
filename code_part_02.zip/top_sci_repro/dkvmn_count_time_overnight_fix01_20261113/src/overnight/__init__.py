"""Exploratory paired hybrid and train-only pseudo-gap controls."""
