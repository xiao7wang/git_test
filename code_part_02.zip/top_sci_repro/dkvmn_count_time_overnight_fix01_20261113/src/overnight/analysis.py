"""Paired development comparisons with fixed-model student-cluster intervals."""
from __future__ import annotations

import numpy as np

from count_time.analysis import _intervals
from count_time.common import binary_losses, metrics


def _group(events, predictions, contrasts, mask, repetitions, seed):
    indices = np.flatnonzero(mask)
    if not len(indices):
        return {"n": 0, "students": 0, "models": {}, "paired": {}}
    y = events["label"][indices]
    students = events["student_idx"][indices]
    losses, models = {}, {}
    for name, values in predictions.items():
        if set(values) != {1, 2}:
            raise ValueError(f"hybrid analysis requires exactly seeds 1 and 2: {name}")
        rows = {s: metrics(y, np.asarray(values[s])[indices], students) for s in (1, 2)}
        losses[name] = {s: binary_losses(y, np.asarray(values[s])[indices])[0] for s in (1, 2)}
        models[name] = {"per_seed": rows, "mean": {k: (None if any(rows[s][k] is None for s in (1, 2))
                        else float(np.mean([rows[s][k] for s in (1, 2)])))
                        for k in ("nll", "student_macro_nll", "auc", "brier")}}
    delta = {name: np.mean(np.stack([losses[a][s] - losses[b][s] for s in (1, 2)]), axis=0)
             for name, (a, b) in contrasts.items()}
    intervals = _intervals(students, np.stack(list(delta.values()), axis=1), repetitions, seed)
    paired = dict(zip(delta, intervals))
    for name, (a, b) in contrasts.items():
        paired[name]["per_seed_event_delta"] = {str(s): float(np.mean(losses[a][s] - losses[b][s])) for s in (1, 2)}
    return {"n": len(indices), "students": int(len(np.unique(students))), "models": models, "paired": paired}


def analyze_hybrids(events, predictions, repetitions=2000, seed=20261123):
    labels = np.asarray(events["label"])
    for mode, values in predictions.items():
        for seed_id in (1, 2):
            p = np.asarray(values[seed_id])
            if p.shape != labels.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f"invalid hybrid comparison probabilities: {mode}/{seed_id}")
    contrasts = {"hybrid_time_minus_hybrid_fixed": ("hybrid_time", "hybrid_fixed"),
                 "hybrid_time_minus_dkvmn_bias": ("hybrid_time", "dkvmn_bias"),
                 "hybrid_fixed_minus_dkvmn_bias": ("hybrid_fixed", "dkvmn_bias"),
                 "hybrid_time_minus_count_time": ("hybrid_time", "count_time"),
                 "hybrid_fixed_minus_count_fixed": ("hybrid_fixed", "count_fixed")}
    past, gap = events["prior_kc_count"], events["same_kc_gap_hours"]
    groups = {"first_kc": past == 0, "repeat_0_to_24h": (past > 0) & (gap > 0) & (gap <= 24),
              "repeat_24_to_168h": (past > 0) & (gap > 24) & (gap <= 168),
              "repeat_gt_168h": (past > 0) & (gap > 168),
              "repeat_zero_gap": (past > 0) & (gap == 0)}
    return {"primary_contrast": "hybrid_time_minus_hybrid_fixed",
            "overall": _group(events, predictions, contrasts, np.ones(len(labels), dtype=bool), repetitions, seed),
            "groups": {name: _group(events, predictions, contrasts, mask, repetitions, seed + i + 1)
                       for i, (name, mask) in enumerate(groups.items())},
            "bootstrap_repetitions": repetitions, "bootstrap_seed": seed,
            "uncertainty_note": "cluster intervals condition on selected fitted models, not training/selection uncertainty",
            "reference_note": "DKVMN-only and count-only differ in model architecture; their comparisons do not isolate time",
            "scope": "two paired seeds on repeatedly reused development data; not independent confirmation"}


def analyze_surrogates(events, real_predictions, fixed_predictions, fake_predictions, repetitions=2000, seed=20261123):
    y, students = events["label"], events["student_idx"]
    if set(fake_predictions) != {11, 29, 47}:
        raise ValueError("three predeclared pseudo-gap mappings are required")
    summaries, per_map_losses = {}, {}
    for mapping in (11, 29, 47):
        if set(fake_predictions[mapping]) != {0, 1, 2}:
            raise ValueError("each pseudo-gap mapping requires three fixed training seeds")
        per_map_losses[mapping], summaries[str(mapping)] = {}, {}
        for s in (0, 1, 2):
            p = np.asarray(fake_predictions[mapping][s])
            if p.shape != y.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError("invalid pseudo-gap probability")
            per_map_losses[mapping][s] = binary_losses(y, p)[0]
            summaries[str(mapping)][str(s)] = metrics(y, p, students)
    real = {s: binary_losses(y, real_predictions[s])[0] for s in (0, 1, 2)}
    fixed = {s: binary_losses(y, fixed_predictions[s])[0] for s in (0, 1, 2)}
    mean_fake_by_seed = {s: np.mean(np.stack([per_map_losses[m][s] for m in (11, 29, 47)]), axis=0) for s in (0, 1, 2)}
    diffs = {"real_time_minus_pseudo_gap": np.mean(np.stack([real[s] - mean_fake_by_seed[s] for s in (0, 1, 2)]), axis=0),
             "fixed_08_minus_pseudo_gap": np.mean(np.stack([fixed[s] - mean_fake_by_seed[s] for s in (0, 1, 2)]), axis=0)}
    boot = _intervals(students, np.stack(list(diffs.values()), axis=1), repetitions, seed + 400)
    return {"models_by_mapping_and_seed": summaries, "paired": dict(zip(diffs, boot)),
            "scope": "reused development, 3 fixed pseudo-gap mappings and 3 training-order seeds",
            "method": "training gaps permuted within training; development replacement gaps sampled from training only; response order unchanged",
            "limitation": "not a formal permutation test; replacement changes association and may change the evaluation gap marginal; matched training does not imply a causal intervention",
            "uncertainty_note": "intervals condition on fitted selected models and omit training and selection uncertainty"}
