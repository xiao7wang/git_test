"""Empirical pseudo-gaps: training pool only, original answer chronology retained."""
from __future__ import annotations

import math

import numpy as np


def _quantiles(values):
    values = np.asarray(values, dtype=np.float64)
    if not len(values):
        return None
    return {"n": len(values), "zero_fraction": float(np.mean(values == 0)),
            "p10_median_p90_hours": np.quantile(values, [.1, .5, .9]).tolist()}


def pseudo_states(features, mapping_seed):
    """Permute actual training gaps; sample evaluation gaps from training only.

    Permutation and samples depend on training timestamps, an explicit seed and
    the permitted event indices, but not any development timestamp or label.
    The current response is added only after its features have been recorded.
    Original timestamps are still used separately for descriptive subgroups.
    """
    split = np.asarray(features["split"])
    prior = np.asarray(features["prior_kc_count"])
    gap = np.asarray(features["gap_hours"], dtype=np.float64)
    n = len(split)
    if n == 0 or any(len(features[k]) != n for k in ("record_idx", "student", "kc", "label")):
        raise ValueError("selected feature arrays are empty or misaligned")
    if not np.isin(split, [0, 1]).all() or not np.isin(features["label"], [0, 1]).all():
        raise ValueError("only permitted train/development events with binary labels are allowed")
    train_repeat = np.flatnonzero((split == 0) & (prior > 0))
    dev_repeat = np.flatnonzero((split == 1) & (prior > 0))
    pool = gap[train_repeat]
    if not len(pool) or not np.isfinite(pool).all() or (pool < 0).any():
        raise ValueError("training repeated same-KC gaps unavailable or invalid")
    rng = np.random.default_rng(int(mapping_seed))
    pseudo = np.full(n, np.nan, dtype=np.float64)
    pseudo[train_repeat] = rng.permutation(pool)
    pseudo[dev_repeat] = rng.choice(pool, size=len(dev_repeat), replace=True)
    success, failure = np.empty(n, dtype=np.float64), np.empty(n, dtype=np.float64)
    order = np.lexsort((features["record_idx"], features["kc"], features["student"]))
    last = None
    pos = neg = 0.
    for index in order:
        key = (int(features["student"][index]), int(features["kc"][index]))
        if key != last:
            pos = neg = 0.
            last = key
            if prior[index] != 0:
                raise ValueError("first selected student/KC row has nonzero prior count")
        else:
            if prior[index] <= 0 or not math.isfinite(float(pseudo[index])):
                raise ValueError("missing replacement gap for repeated student/KC")
            factor = math.exp2(-float(pseudo[index]) / 168.)
            pos *= factor
            neg *= factor
        success[index], failure[index] = pos, neg
        y = int(features["label"][index])
        pos += y
        neg += 1 - y
    return {"success": success, "failure": failure, "pseudo_gap_hours": pseudo,
            "audit": {"source": "training gaps only", "mapping_seed": int(mapping_seed),
                      "train_actual": _quantiles(pool), "train_surrogate": _quantiles(pseudo[train_repeat]),
                      "development_actual_descriptive_only": _quantiles(gap[dev_repeat]),
                      "development_surrogate": _quantiles(pseudo[dev_repeat]),
                      "warning": "not a formal exchangeability-based permutation test; development surrogate marginal can differ from actual gaps"}}
