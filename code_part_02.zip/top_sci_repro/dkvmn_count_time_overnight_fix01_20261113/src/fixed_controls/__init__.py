"""Exploratory fixed-event discount strength controls."""
