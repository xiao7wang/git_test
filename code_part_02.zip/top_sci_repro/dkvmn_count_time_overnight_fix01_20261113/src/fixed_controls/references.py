"""Verify locked earlier artifacts before reusing any development prediction."""
from __future__ import annotations

import csv
import gzip
import hashlib
import io
import json
import zipfile

import numpy as np

from count_time.common import binary_losses, sha256_file

MODES = ("A_none", "B_fixed", "C_real_time")
SEEDS = (0, 1, 2)
DATA_FINGERPRINT = "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e"
PRIOR_MANIFEST = "eeb721367e1a334dbbcab3dc52fc59ddce9656ddfa0d23fded583712c9a98b7e"
PRIOR_ACTUAL_SHA256 = "eab986459c2bea65cd016393da9c85127e2ce7086243e93242eb9b9420509733"
PRIOR_TRANSCRIPTION_ERROR = "eab986459c2be65cd016393da9c85127e2ce7086243e93242eb9b9420509733"


def corrected_prior_hash(protocol):
    """Retain the frozen record and explicitly correct its 63-character typo.

    The 64-character value is the independently computed SHA-256 of the
    received artifact; it also matches the previous independent JSON review.
    Both values are recorded in the output, not silently rewritten.
    """
    if protocol.get("prior_result_sha256") != PRIOR_TRANSCRIPTION_ERROR:
        raise ValueError("unexpected prior reference transcription record")
    return PRIOR_ACTUAL_SHA256


def _verified_members(path, expected_hash, *, flat_manifest=False):
    if sha256_file(path) != expected_hash:
        raise ValueError(f"reference archive SHA-256 mismatch: {path}")
    with zipfile.ZipFile(path) as bundle:
        names = bundle.namelist()
        if len(set(names)) != len(names) or bundle.testzip() is not None:
            raise ValueError("reference ZIP contains duplicates or a CRC failure")
        manifest = json.loads(bundle.read("manifest.json"))
        files = manifest if flat_manifest else manifest["files"]
        if set(names) != set(files) | {"manifest.json"}:
            raise ValueError("reference manifest does not match archive members")
        result = {}
        for name, digest in files.items():
            content = bundle.read(name)
            if hashlib.sha256(content).hexdigest() != digest:
                raise ValueError(f"reference member SHA-256 mismatch: {name}")
            result[name] = content
    return result


def _csv(content):
    with gzip.open(io.BytesIO(content), "rt", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream))


def _integer_column(rows, key):
    values = np.asarray([float(row[key]) for row in rows], dtype=np.float64)
    if not np.isfinite(values).all() or not np.equal(values, np.floor(values)).all():
        raise ValueError(f"invalid integer column: {key}")
    return values.astype(np.int64)


def _identity(rows):
    return {key: _integer_column(rows, key) for key in ("record_idx", "student_idx", "label")}


def _check_identity(actual, expected):
    for key in ("record_idx", "student_idx", "label"):
        if not np.array_equal(actual[key], expected[key]):
            raise ValueError(f"development row identity mismatch: {key}")


def _check_probabilities(values, size):
    values = np.asarray(values, dtype=np.float64)
    if values.shape != (size,) or not np.isfinite(values).all() or ((values < 0) | (values > 1)).any():
        raise ValueError("invalid reference prediction probabilities")
    return values


def load_prior(path, expected_hash):
    members = _verified_members(path, expected_hash)
    status, config = (json.loads(members[name]) for name in ("status.json", "config.json"))
    if status.get("status") != "complete" or config.get("test_evaluated") is not False or config.get("holdout_evaluated") is not False:
        raise ValueError("prior run did not finish as a development-only experiment")
    metadata = config.get("metadata", {})
    if metadata.get("data_fingerprint") != DATA_FINGERPRINT or metadata.get("release", {}).get("manifest_sha256") != PRIOR_MANIFEST:
        raise ValueError("prior dataset or code release fingerprint differs")
    if config.get("fixed_discount") != 0.8 or config.get("half_life_hours") != 168.0:
        raise ValueError("unexpected prior fixed or time-decay rule")
    rows = _csv(members["events.csv.gz"])
    if not rows:
        raise ValueError("prior development rows are empty")
    events = _identity(rows)
    for key in ("kc_idx", "prior_kc_count", "prior_student_count_selected_history"):
        events[key] = _integer_column(rows, key)
    events["same_kc_gap_hours"] = np.asarray([float(row["same_kc_gap_hours"]) if row["same_kc_gap_hours"] else np.nan
                                              for row in rows], dtype=np.float64)
    if not np.isin(events["label"], [0, 1]).all() or (np.diff(events["record_idx"]) <= 0).any():
        raise ValueError("prior event identity is invalid or not strictly ordered")
    gap = events["same_kc_gap_hours"]
    previous = events["prior_kc_count"]
    if (previous < 0).any() or np.any(np.isnan(gap) != (previous == 0)) or np.any(gap[previous > 0] < 0) or not np.isfinite(gap[previous > 0]).all():
        raise ValueError("prior same-KC gap metadata is inconsistent")
    predictions, histories, jobs = {mode: {} for mode in MODES}, {}, {}
    for mode in MODES:
        for seed in SEEDS:
            name = f"{mode}_seed{seed}"
            prefix = f"jobs/{name}/"
            summary = json.loads(members[prefix + "summary.json"])
            history = json.loads(members[prefix + "history.json"])
            if summary.get("status") != "complete" or summary.get("mode") != mode or summary.get("seed") != seed or not history:
                raise ValueError(f"invalid prior job metadata: {name}")
            pred_rows = _csv(members[prefix + "dev_predictions.csv.gz"])
            _check_identity(_identity(pred_rows), events)
            probability = _check_probabilities(np.asarray([float(row["probability"]) for row in pred_rows], dtype=np.float32), len(rows))
            nll = float(binary_losses(events["label"], probability)[0].mean())
            if abs(nll - summary["dev"]["nll"]) > 1e-7:
                raise ValueError(f"prior prediction NLL disagrees with job summary: {name}")
            predictions[mode][seed], histories[name], jobs[name] = probability, history, summary
    return {"events": events, "events_bytes": members["events.csv.gz"], "predictions": predictions,
            "histories": histories, "jobs": jobs, "config": config, "archive_sha256": expected_hash}


def load_dkvmn(path, expected_hash, events):
    members = _verified_members(path, expected_hash, flat_manifest=True)
    status, config = (json.loads(members[name]) for name in ("status.json", "config.json"))
    if status.get("status") != "complete" or config.get("test_evaluated") is not False or config.get("holdout_evaluated") is not False:
        raise ValueError("DKVMN reference is not completed development-only output")
    if config.get("feedback") != "row immediate assumption":
        raise ValueError("DKVMN feedback assumption differs")
    _check_identity(_identity(_csv(members["events.csv.gz"])), events)
    with np.load(io.BytesIO(members["predictions.npz"]), allow_pickle=False) as values:
        if not np.array_equal(values["record_idx"], events["record_idx"]):
            raise ValueError("DKVMN prediction IDs disagree with development events")
        return {seed: _check_probabilities(values[f"bias_seed{seed}"], len(events["label"])) for seed in SEEDS}


def validate_features(features, events):
    dev = np.flatnonzero(features["split"] == 1)
    users = features["student"]
    starts = np.r_[True, users[1:] != users[:-1]]
    begin = np.maximum.accumulate(np.where(starts, np.arange(len(users)), 0))
    mapping = {"record_idx": features["record_idx"][dev], "student_idx": users[dev],
               "label": features["label"][dev], "kc_idx": features["kc"][dev],
               "prior_kc_count": features["prior_kc_count"][dev],
               "prior_student_count_selected_history": (np.arange(len(users)) - begin)[dev],
               "same_kc_gap_hours": features["gap_hours"][dev]}
    for key, values in mapping.items():
        if not np.array_equal(values, events[key], equal_nan=True):
            raise ValueError(f"new features do not match prior development metadata: {key}")
    return {"match": True, "events": len(dev), "students": int(len(np.unique(users[dev])))}


def validate_training_provenance(summary, history, prior, seed):
    key = f"B_fixed_seed{seed}"
    old_summary, old_history = prior["jobs"][key], prior["histories"][key]
    if summary.get("mode") != "B_fixed" or summary.get("seed") != seed:
        raise ValueError("new job mode/seed is inconsistent")
    if summary.get("initial_state_sha256") != old_summary.get("initial_state_sha256"):
        raise ValueError("initial model state differs from prior control")
    common = min(len(history), len(old_history))
    if not common:
        raise ValueError("training history is empty")
    for index in range(common):
        if history[index]["epoch"] != old_history[index]["epoch"] or history[index]["train_order_sha256"] != old_history[index]["train_order_sha256"]:
            raise ValueError(f"training order differs from prior control at epoch {index + 1}")
    return {"initial_state_matches": True, "common_epochs": common,
            "prior_epochs": len(old_history), "new_epochs": len(history)}
