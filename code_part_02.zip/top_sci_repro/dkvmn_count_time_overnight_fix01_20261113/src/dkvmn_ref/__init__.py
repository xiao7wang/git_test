"""Pinned pyKT DKVMN and earlier streaming adapters."""
