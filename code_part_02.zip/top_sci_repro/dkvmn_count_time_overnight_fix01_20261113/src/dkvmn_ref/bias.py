"""DKVMN extension with additive student/item logits; upstream module unmodified."""
import torch
from torch import nn

class BiasDKVMN(nn.Module):
    def __init__(self,base,n_students,n_items):
        super().__init__();self.base=base
        # torch.zeros does not consume RNG; underlying DKVMN init remains matched.
        self.student_bias=nn.Parameter(torch.zeros(n_students))
        self.item_bias=nn.Parameter(torch.zeros(n_items))

    def forward_chunk(self,students,items,kcs,answers,active_mask,feedback_mask,state):
        if kcs.ndim!=2 or any(t.shape!=kcs.shape for t in (items,answers,active_mask,feedback_mask)) or students.shape!=(kcs.shape[0],):raise ValueError('Input shapes differ')
        model=self.base
        if model.emb_type!='qid':raise ValueError('qid only')
        active=active_mask.bool();update=active&feedback_mask.bool()
        safe_q=torch.where(active,kcs,torch.zeros_like(kcs));safe_i=torch.where(active,items,torch.zeros_like(items));safe_y=torch.where(update,answers,torch.zeros_like(answers))
        if bool(((safe_q<0)|(safe_q>=model.num_c)).any()) or bool(((safe_y<0)|(safe_y>1)).any()) or bool(((safe_i<0)|(safe_i>=len(self.item_bias))).any()) or bool(((students<0)|(students>=len(self.student_bias))).any()):raise ValueError('Invalid indices or labels')
        key=model.k_emb_layer(safe_q);val=model.v_emb_layer(safe_q+model.num_c*safe_y)
        weights=torch.softmax(torch.matmul(key,model.Mk.T),dim=-1);erase=torch.sigmoid(model.e_layer(val));add=torch.tanh(model.a_layer(val))
        sb=self.student_bias[students];ib=self.item_bias[safe_i];outputs=[]
        for t in range(kcs.shape[1]):
            w=weights[:,t];read=(w.unsqueeze(-1)*state).sum(-2)
            hidden=torch.tanh(model.f_layer(torch.cat([read,key[:,t]],dim=-1)))
            logit=model.p_layer(model.dropout_layer(hidden)).squeeze(-1)+sb+ib[:,t]
            outputs.append(torch.sigmoid(logit))
            wr=w.unsqueeze(-1);updated=state*(1-wr*erase[:,t].unsqueeze(1))+wr*add[:,t].unsqueeze(1)
            state=torch.where(update[:,t,None,None],updated,state)
        if not outputs:raise ValueError('Empty chunk')
        return torch.stack(outputs,dim=1),state
