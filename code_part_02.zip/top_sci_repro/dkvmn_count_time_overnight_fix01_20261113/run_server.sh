#!/usr/bin/env bash
set -euo pipefail

task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_name="${1:-server_overnight_01}"
if [[ ! "$task_name" =~ ^[A-Za-z0-9_-]+$ ]]; then
  printf 'Invalid run name: %s\n' "$task_name" >&2
  exit 2
fi
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_project=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
task_data=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
task_output="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
mkdir -p "$task_root/outputs"
if [[ -e "$task_output" || -e "$task_log" ]]; then
  printf 'Run output or launch log already exists; refusing to overwrite: %s\n' "$task_name" >&2
  exit 2
fi
( set -o noclobber; : > "$task_log" ) || { echo 'Cannot create a new launch log' >&2; exit 2; }
exec > >(tee -a "$task_log") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$task_root/src${PYTHONPATH:+:$PYTHONPATH}"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "$task_root"
printf 'Starting %s at %s\n' "$task_name" "$(date --iso-8601=seconds)"
echo 'Stage 1/4: verify release, protocol and pinned source files'
"$task_python" -B -m overnight.server --verify-only
"$task_python" -B checks/guard_fix.py
echo 'Stage 2/4: synthetic CPU regression checks (not full-data results)'
"$task_python" -B checks/verify_fix.py --strict
echo 'Stage 3/4: synthetic CUDA training and checkpoint preflight'
"$task_python" -B checks/gpu_preflight.py
echo 'Stage 4/4: negative controls, then four paired DKVMN hybrid jobs'
"$task_python" -B -m overnight.server \
  --project-dir "$task_project" --data-dir "$task_data" \
  --reference-dir "$task_root/references" --output-dir "$task_output" \
  --device cuda --ack-row-feedback --ack-time-proxy
printf 'SUCCESS: %s/overnight_results.zip\n' "$task_output"
