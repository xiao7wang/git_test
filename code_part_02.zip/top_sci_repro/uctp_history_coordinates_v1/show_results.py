import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if not (d/'status.json').exists():raise SystemExit('No status file: check launch log')
s=json.loads((d/'status.json').read_text(encoding='utf8'));print('status:',s.get('status'),'phase:',s.get('phase'),'model:',s.get('model'),'epoch:',s.get('epoch'),'error:',s.get('error','-'))
print('Saved running status does not prove a live process.')
if (d/'summary.json').exists():
 r=json.loads((d/'summary.json').read_text(encoding='utf8'))
 for name,x in r['rows'].items():
  v=x['seconds'];print(name,'NLL=',round(x['dev']['nll'],6),'macro NLL=',round(x['student_macro_nll'],6),'AUC=',round(x['dev']['auc'],6),'best=',x['best_epoch'],'seconds=',round(v,1) if v is not None else 'previous run')
 for name,x in r['paired'].items():print(name,'delta NLL=',round(x['delta'],6),'CI95=',x['ci95'])
 print('Exploratory development only. Both and difference_nonlinear each use two coefficients per KC; sum is a scale-related proxy, not pure total.')
if (d/'coordinate_results.zip').exists():print('Results archive:',d/'coordinate_results.zip')
