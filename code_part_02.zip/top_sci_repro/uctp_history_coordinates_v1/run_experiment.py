"""Exploratory matched-coordinate comparison; train and development only."""
import argparse, json, os, platform, time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,prior_count_features,SALT
from coordinates import CoordinateModel
from cross_core import import_project,read,sha,write
from review_stats import metrics,losses,cluster_intervals
ROOT=Path(__file__).resolve().parent

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if min(a.epochs,a.patience)<1:raise ValueError('Invalid epoch or patience')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
 started=time.monotonic();status={'status':'running','phase':'verify','test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  lock=read(ROOT/'locked_p1.json');p1=Path(a.p1_dir)
  for name,digest in lock['p1_files'].items():
   if sha(p1/name)!=digest:raise ValueError('P1 source changed: '+name)
  old_cfg=read(p1/'config.json')
  if read(p1/'status.json')['status']!='complete' or old_cfg['test_evaluated'] or old_cfg['holdout_evaluated'] or old_cfg['feedback']!='row immediate assumption':raise ValueError('P1 protocol mismatch')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
  Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old_cfg['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  if sha(ROOT/'count_core.py')!=old_cfg['code_sha256']['count_core.py']:raise ValueError('Historical feature source differs')
  data=Data(a.data_dir);dev=dev_users(data.arrays['student_idx'][data.arrays['split']==1])
  status['phase']='features';write(out/'status.json',status);print('Building prior counts',flush=True)
  f=prior_count_features(data.arrays,dev);ti=np.flatnonzero(f['split']==0);vi=np.flatnonzero(f['split']==1)
  if not len(ti) or not len(vi):raise ValueError('Empty partition')
  ref=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student'),('label','label')]:
   if not np.array_equal(ref[col].to_numpy(),f[key][vi]):raise ValueError('P1 event identity mismatch: '+col)
  device=torch.device(a.device);torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
  torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  tensor={k:torch.as_tensor(f[k],dtype=torch.long if k in ('student','item','kc') else torch.float32,device=device) for k in ('student','item','kc','success','failure','label')}
  tr=torch.as_tensor(ti,dtype=torch.long,device=device);va=torch.as_tensor(vi,dtype=torch.long,device=device);dims=data.manifest['summary']
  config={'protocol':'exploratory development only; no test or holdout','data_fingerprint':data.fingerprint,'partition_salt':SALT,'feedback':'row immediate assumption',
   'difference':'(log1p(success)-log1p(failure))/sqrt(2)','sum':'(log1p(success)+log1p(failure))/sqrt(2)',
   'modes':'difference; sum; difference plus tanh(difference); both; all allocate two weights per KC, with unused feature masked',
   'interpretation':'sum is a scale-related proxy, not solely total attempts; both has one more effective coefficient than difference; nonlinear control has two coefficients using difference only',
   'regularization':'identical AdamW decay; difference and both use same difference coordinate; nonlinear control uses a different second feature with potentially different scale; effective capacity not equated',
   'seed':0,'epochs_max':a.epochs,'patience':a.patience,'optimizer':'AdamW','lr':.01,'weight_decay':1e-5,'batch_size':8192,'gradient_clip':5,
   'selection':'development event NLL','device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),
   'train_rows':len(tr),'development_rows':len(va),'development_students':len(dev),'source_p1_files':lock['p1_files'],
   'code_sha256':{n:sha(ROOT/n) for n in ('run_experiment.py','coordinates.py','count_core.py','cross_core.py','review_stats.py')},
   'test_evaluated':False,'holdout_evaluated':False};write(out/'config.json',config)
  probs={};rows={}
  for mode in CoordinateModel.MODES:
   status.update(phase='training',model=mode,epoch=0);write(out/'status.json',status);torch.manual_seed(0)
   if device.type=='cuda':torch.cuda.manual_seed_all(0)
   model=CoordinateModel(dims['students'],dims['items'],dims['knowledges'],mode).to(device)
   opt=torch.optim.AdamW(model.parameters(),lr=.01,weight_decay=1e-5);rng=torch.Generator(device=device).manual_seed(0)
   best=float('inf');stale=0;history=[];model_begin=time.monotonic()
   def logits(ix):return model(*(tensor[k][ix] for k in ('student','item','kc','success','failure')))
   for epoch in range(1,a.epochs+1):
    t=time.monotonic();status.update(epoch=epoch);write(out/'status.json',status)
    model.train();perm=tr[torch.randperm(len(tr),device=device,generator=rng)];total=0.0
    for j in range(0,len(tr),8192):
     ix=perm[j:j+8192];opt.zero_grad(set_to_none=True);loss=F.binary_cross_entropy_with_logits(logits(ix),tensor['label'][ix])
     if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite loss')
     loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*len(ix)
    model.eval()
    with torch.no_grad():p=torch.sigmoid(logits(va)).cpu().numpy()
    met=metrics(f['label'][vi],p);nll=float(met['nll']);history.append({'epoch':epoch,'train_bce':total/len(tr),'dev':met,'seconds':time.monotonic()-t})
    write(out/(mode+'_history.json'),history);print(json.dumps({'mode':mode,'epoch':epoch,'dev_nll':nll,'seconds':history[-1]['seconds']}),flush=True)
    if nll<best:
     best=nll;stale=0;tmp=out/(mode+'.pending.pt');torch.save({'model_state':model.state_dict(),'epoch':epoch,'dev_nll':nll,'mode':mode,'data_fingerprint':data.fingerprint},tmp);tmp.replace(out/(mode+'.pt'))
    else:stale+=1
    if stale>=a.patience:break
   ck=torch.load(out/(mode+'.pt'),map_location=device,weights_only=True);model.load_state_dict(ck['model_state']);model.eval()
   with torch.no_grad():p=torch.sigmoid(logits(va)).cpu().numpy()
   met=metrics(f['label'][vi],p)
   if abs(met['nll']-best)>1e-7:raise AssertionError('Best checkpoint mismatch')
   probs[mode]=p;rows[mode]={'dev':met,'best_epoch':ck['epoch'],'epochs':len(history),'seconds':time.monotonic()-model_begin,'allocated_parameters':sum(x.numel() for x in model.parameters()),'checkpoint_sha256':sha(out/(mode+'.pt'))}
  status.update(phase='paired_analysis',model=None);write(out/'status.json',status)
  y=f['label'][vi];students=f['student'][vi]
  for mode in ('R0','R1','R2'):
   key='previous_'+mode;probs[key]=ref[mode].to_numpy(dtype=np.float32);rows[key]={'dev':metrics(y,probs[key]),'best_epoch':None,'epochs':None,'seconds':None,'allocated_parameters':None,'checkpoint_sha256':None}
  ls={k:losses(y,v)[:,0] for k,v in probs.items()};_,inv,n=np.unique(students,return_inverse=True,return_counts=True)
  for k in rows:rows[k]['student_macro_nll']=float(np.mean(np.bincount(inv,weights=ls[k])/n))
  names=['both_minus_difference','both_minus_difference_nonlinear','sum_minus_difference','both_minus_sum','both_minus_previous_R2']
  col=np.stack([ls['both']-ls['difference'],ls['both']-ls['difference_nonlinear'],ls['sum']-ls['difference'],ls['both']-ls['sum'],ls['both']-ls['previous_R2']],axis=1)
  boot=cluster_intervals(students,col,1000,20261109)
  pd.DataFrame({'record_idx':f['record_idx'][vi],'student_idx':students,'label':y,**probs}).to_csv(out/'dev_predictions.csv.gz',index=False,compression='gzip')
  summary={'status':'complete','rows':rows,'paired':dict(zip(names,boot['comparisons'])),
   'scope':'exploratory development, seed 0; no test or holdout; both has more effective parameters',
   'confidence_interval':'fixed models student cluster bootstrap; excludes training/selection uncertainty','test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-started}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-started);write(out/'status.json',status);print('EXPERIMENT COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-started);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
