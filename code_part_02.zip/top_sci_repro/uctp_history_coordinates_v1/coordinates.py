"""Matched coordinate-space comparison, with identical allocated parameters."""
import math
import torch
from torch import nn

class CoordinateModel(nn.Module):
    MODES=('difference','sum','difference_nonlinear','both')
    def __init__(self,students,items,kcs,mode):
        super().__init__()
        if mode not in self.MODES:raise ValueError('Unknown mode')
        self.mode=mode
        self.student=nn.Embedding(students,1);self.item=nn.Embedding(items,1)
        self.kc_bias=nn.Embedding(kcs,1);self.kc_weights=nn.Embedding(kcs,2)
        for p in self.parameters():nn.init.zeros_(p)

    def forward(self,student,item,kc,success,failure):
        p=torch.log1p(success);n=torch.log1p(failure)
        diff=(p-n)/math.sqrt(2);summ=(p+n)/math.sqrt(2)
        weights=self.kc_weights(kc)
        z=self.student(student).squeeze(-1)+self.item(item).squeeze(-1)+self.kc_bias(kc).squeeze(-1)
        if self.mode in ('difference','difference_nonlinear','both'):z=z+weights[:,0]*diff
        if self.mode in ('sum','both'):z=z+weights[:,1]*summ
        if self.mode=='difference_nonlinear':z=z+weights[:,1]*torch.tanh(diff)
        return z
