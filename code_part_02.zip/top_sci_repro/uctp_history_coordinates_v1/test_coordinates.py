import math,unittest
import torch
from coordinates import CoordinateModel

class Tests(unittest.TestCase):
 def test_same_allocated_parameters_and_mask(self):
  models=[CoordinateModel(2,2,2,m) for m in ('difference','sum','both')]
  self.assertEqual(len({sum(x.numel() for x in m.parameters()) for m in models}),1)
  s=torch.tensor([0,1]);k=torch.tensor([0,1]);p=torch.tensor([9.,0.]);n=torch.tensor([1.,4.])
  for model in models:
   with torch.no_grad():model.kc_weights.weight[:]=torch.tensor([[.4,.3],[-.2,.5]])
  outputs=[m(s,s,k,p,n) for m in models]
  self.assertTrue(torch.allclose(outputs[0]+outputs[1],outputs[2],atol=1e-6))
  d=(torch.log1p(p)-torch.log1p(n))/math.sqrt(2);sm=(torch.log1p(p)+torch.log1p(n))/math.sqrt(2)
  self.assertTrue(torch.allclose(outputs[2],torch.tensor([.4,-.2])*d+torch.tensor([.3,.5])*sm))
  nonlinear=CoordinateModel(2,2,2,'difference_nonlinear')
  with torch.no_grad():nonlinear.kc_weights.weight[:]=torch.tensor([[.4,.3],[-.2,.5]])
  self.assertTrue(torch.allclose(nonlinear(s,s,k,p,n),torch.tensor([.4,-.2])*d+torch.tensor([.3,.5])*torch.tanh(d)))
 def test_sum_not_pure_total(self):
  # Same total, different product: the sum of log-counts can still differ.
  x=torch.log1p(torch.tensor([9.,5.]))+torch.log1p(torch.tensor([1.,5.]))
  self.assertFalse(torch.isclose(x[0],x[1]))
if __name__=='__main__':unittest.main()
