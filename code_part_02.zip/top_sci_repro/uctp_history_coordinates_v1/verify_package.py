import hashlib,json
from pathlib import Path
d=Path(__file__).resolve().parent
for n,h in json.loads((d/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
 if (d/n).parent!=d or hashlib.sha256((d/n).read_bytes()).hexdigest()!=h:raise ValueError('Package changed: '+n)
print('Package integrity verified')
