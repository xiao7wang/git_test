"""Sequential seed 1/2 runs; paired fixed-model development summaries."""
import argparse,json,os,subprocess,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import read,sha,write
from review_stats import metrics,losses,cluster_intervals
ROOT=Path(__file__).resolve().parent
JOBS=(('original',1),('bias',1),('original',2),('bias',2))

def main():
 p=argparse.ArgumentParser()
 for n in ('project-dir','data-dir','p1-dir','original-dir','bias-dir','output-dir'):p.add_argument('--'+n,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');a=p.parse_args()
 if not a.ack_row_feedback:p.error('Row-immediate feedback acknowledgement required')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);start=time.monotonic();status={'status':'running','phase':'source_verify','active_job':None,'completed':[],'test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  locks=read(ROOT/'locked_seed0.json');sources={'original':Path(a.original_dir),'bias':Path(a.bias_dir)}
  for variant,root in sources.items():
   for n,d in locks[variant]['files'].items():
    if sha(root/n)!=d:raise ValueError(f'Prior {variant} changed: {n}')
  cfg={'scope':'development only; one run per model per seed 1,2; no test or holdout','source_seed0_files':{k:v['files'] for k,v in locks.items()},
   'jobs':[f'{v}_seed{s}' for v,s in JOBS],'seed0':'prior separately trained locked models','feedback':'row immediate assumption',
   'train_order':'seed 0 prior uses epoch-1; seeds 1,2 use seed*10000 + epoch-1; matched between variants within each seed',
   'epochs_max':a.epochs,'patience':a.patience,'batch_size':a.batch_size,'chunk_size':a.chunk_size,'device':a.device,
   'code_sha256':{n:sha(ROOT/n) for n in ('run_suite.py','run_job.py','bias_adapter.py','streaming_dkvmn.py','run_pilot.py','count_core.py','cross_core.py','review_stats.py')},
   'test_evaluated':False,'holdout_evaluated':False};write(out/'config.json',cfg)
  for variant,seed in JOBS:
   name=f'{variant}_seed{seed}';status.update(phase='job',active_job=name);write(out/'status.json',status)
   log=out/(name+'.log');print('Starting',name,'log:',log,flush=True)
   cmd=[sys.executable,'-B','-u',str(ROOT/'run_job.py'),'--project-dir',a.project_dir,'--data-dir',a.data_dir,'--p1-dir',a.p1_dir,
    '--original-dir',a.original_dir,'--bias-dir',a.bias_dir,'--output-dir',str(out/name),'--variant',variant,'--seed',str(seed),
    '--device',a.device,'--batch-size',str(a.batch_size),'--chunk-size',str(a.chunk_size),'--epochs',str(a.epochs),'--patience',str(a.patience),'--ack-row-feedback']
   with log.open('x',encoding='utf8') as f:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env=dict(os.environ,PYTHONUNBUFFERED='1',PYTHONDONTWRITEBYTECODE='1'))
   if result.returncode!=0:raise RuntimeError(f'{name} failed (exit {result.returncode}); read {log}')
   if read(out/name/'status.json')['status']!='complete':raise RuntimeError(name+' did not complete')
   status['completed'].append(name);write(out/'status.json',status);print('Completed',name,flush=True)
  status.update(phase='aggregate',active_job=None);write(out/'status.json',status)
  orig0=pd.read_csv(sources['original']/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  bias0=pd.read_csv(sources['bias']/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(orig0[col].to_numpy(),bias0[col].to_numpy()):raise ValueError('Seed0 event identity differs: '+col)
  if not np.array_equal(orig0.probability.to_numpy(np.float32),bias0.original_dkvmn.to_numpy(np.float32)) or not np.array_equal(orig0.reference_log_count_R2.to_numpy(np.float32),bias0.reference_log_count_R2.to_numpy(np.float32)):raise ValueError('Seed0 reference predictions differ')
  predictions={'original_seed0':orig0.probability.to_numpy(np.float32),'bias_seed0':bias0.probability.to_numpy(np.float32),'count_R2_seed0':orig0.reference_log_count_R2.to_numpy(np.float32)}
  for variant,seed in JOBS:
   name=f'{variant}_seed{seed}';f=pd.read_csv(out/name/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
   for col in ('record_idx','student_idx','label'):
    if not np.array_equal(orig0[col].to_numpy(),f[col].to_numpy()):raise ValueError(name+' identity differs: '+col)
   predictions[name]=f.probability.to_numpy(np.float32)
  y=orig0.label.to_numpy();students=orig0.student_idx.to_numpy();_,inv,counts=np.unique(students,return_inverse=True,return_counts=True)
  ls={k:losses(y,v)[:,0] for k,v in predictions.items()};rows={}
  for k,v in predictions.items():rows[k]={'dev':metrics(y,v),'student_macro_nll':float(np.mean(np.bincount(inv,weights=ls[k])/counts))}
  columns=[];names=[]
  for seed in (0,1,2):
   for baseline in ('original_seed'+str(seed),'count_R2_seed0'):
    columns.append(ls['bias_seed'+str(seed)]-ls[baseline]);names.append('bias_seed'+str(seed)+'_minus_'+baseline)
  columns.append(np.mean([ls[f'bias_seed{s}']-ls[f'original_seed{s}'] for s in (0,1,2)],axis=0));names.append('bias_minus_original_mean_loss_three_fixed_seeds')
  columns.append(np.mean([ls[f'bias_seed{s}']-ls['count_R2_seed0'] for s in (0,1,2)],axis=0));names.append('bias_mean_loss_three_fixed_seeds_minus_count_seed0')
  boot=cluster_intervals(students,np.stack(columns,axis=1),1000,20261110)
  aggregates={}
  for v in ('original','bias'):
   aggregates[v]={}
   for metric in ('nll','auc','brier','student_macro_nll'):
    values=[rows[f'{v}_seed{s}']['student_macro_nll'] if metric=='student_macro_nll' else rows[f'{v}_seed{s}']['dev'][metric] for s in (0,1,2)]
    aggregates[v][metric]={'mean':float(np.mean(values)),'sample_sd':float(np.std(values,ddof=1)),'per_seed':values}
  summaries={f'{v}_seed{s}':read(out/f'{v}_seed{s}'/'summary.json') for v,s in JOBS}
  orig0[['record_idx','student_idx','label']].to_csv(out/'events.csv.gz',index=False,compression='gzip')
  np.savez_compressed(out/'predictions.npz',record_idx=orig0.record_idx.to_numpy(),**predictions)
  summary={'status':'complete','n':len(y),'students':len(counts),'rows':rows,'seed_aggregates':aggregates,'paired':dict(zip(names,boot['comparisons'])),
   'job_summaries':summaries,'scope':'reused ASSIST development; 3 seeds per DKVMN, one seed for count reference; no test or holdout',
   'confidence_interval':'student cluster bootstrap conditional on fixed trained selected models; seed-mean is mean paired per-event loss not averaged prediction; excludes training/selection uncertainty',
   'test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-start}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-start);write(out/'status.json',status);print('ALL FOUR JOBS COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-start);write(out/'status.json',status);raise
if __name__=='__main__':main()
