#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_seedrep_01}"
if [[ ! "$NAME" =~ ^[A-Za-z0-9_-]+$ ]];then echo 'Invalid name' >&2;exit 2;fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
P1=/home/wangxiao/QCCDM/top_sci_repro/uctp_history_repr_p1_v1/outputs/server_p1_01
ORIGINAL=/home/wangxiao/QCCDM/top_sci_repro/uctp_dkvmn_train_v1/outputs/server_dktrain_01
BIAS=/home/wangxiao/QCCDM/top_sci_repro/uctp_dkvmn_bias_v1/outputs/server_dkbias_01
OUT="$DIR/outputs/$NAME";LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]];then echo 'Existing output preserved' >&2;exit 2;fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$DIR/verify_package.py"
"$PY" -B "$DIR/test_streaming_dkvmn.py"
"$PY" -B "$DIR/test_bias_adapter.py"
"$PY" -B -u "$DIR/run_suite.py" --project-dir "$PROJECT" --data-dir "$DATA" --p1-dir "$P1" --original-dir "$ORIGINAL" --bias-dir "$BIAS" --output-dir "$OUT" --device cuda --batch-size 8 --chunk-size 50 --epochs 20 --patience 5 --ack-row-feedback
"$PY" -B "$DIR/package_results.py" --output-dir "$OUT"
