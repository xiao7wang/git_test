import argparse,hashlib,json,zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if json.loads((d/'status.json').read_text(encoding='utf8'))['status']!='complete':raise ValueError('Suite not complete')
names=['status.json','config.json','summary.json','events.csv.gz','predictions.npz']
for job in ('original_seed1','bias_seed1','original_seed2','bias_seed2'):
 names.extend(f'{job}/{n}' for n in ('status.json','config.json','summary.json','history.json'))
m={n:hashlib.sha256((d/n).read_bytes()).hexdigest() for n in names};target=d/'dkvmn_seedrep_results.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for n in names:z.write(d/n,n)
 z.writestr('manifest.json',json.dumps(m,indent=2))
with zipfile.ZipFile(target) as z:
 if z.testzip() is not None or any(hashlib.sha256(z.read(n)).hexdigest()!=v for n,v in m.items()):raise ValueError('Archive verification failed')
print('RESULTS READY:',target)
