import copy,importlib.util,unittest
from pathlib import Path
import torch
from bias_adapter import BiasDKVMN
from streaming_dkvmn import initial_memory,forward_chunk
spec=importlib.util.spec_from_file_location('user_dkvmn',Path(__file__).resolve().parent/'pykt/models/dkvmn.py');up=importlib.util.module_from_spec(spec);spec.loader.exec_module(up)

class Tests(unittest.TestCase):
 def setUp(self):
  torch.manual_seed(0);self.base=up.DKVMN(5,8,4,dropout=0).eval();self.model=BiasDKVMN(self.base,3,6).eval()
  self.u=torch.tensor([0,1]);self.i=torch.tensor([[0,1,2,3],[1,2,3,4]]);self.q=torch.tensor([[0,1,2,3],[2,1,0,4]]);self.y=torch.tensor([[1,0,1,0],[0,1,0,1]]);self.m=torch.ones_like(self.q,dtype=torch.bool)
 def test_zero_bias_matches_original_and_memory(self):
  p,s=self.model.forward_chunk(self.u,self.i,self.q,self.y,self.m,self.m,initial_memory(self.base,2))
  old,t=forward_chunk(self.base,self.q,self.y,self.m,self.m,initial_memory(self.base,2))
  self.assertTrue(torch.allclose(p,old,atol=1e-7));self.assertTrue(torch.allclose(s,t,atol=1e-7))
 def test_same_initialization_rng(self):
  torch.manual_seed(12);a=up.DKVMN(5,8,4,dropout=0);seq1=torch.rand(5)
  torch.manual_seed(12);b=BiasDKVMN(up.DKVMN(5,8,4,dropout=0),3,6);seq2=torch.rand(5)
  self.assertTrue(torch.equal(seq1,seq2))
  for (name,x),(name2,y) in zip(a.named_parameters(),b.base.named_parameters()):self.assertEqual(name,name2);self.assertTrue(torch.equal(x,y))
 def test_bias_logit_and_chunk_consistency(self):
  with torch.no_grad():self.model.student_bias[:]=torch.tensor([.3,-.1,0]);self.model.item_bias[:]=torch.arange(6)*.1
  out,st=self.model.forward_chunk(self.u,self.i,self.q,self.y,self.m,self.m,initial_memory(self.base,2))
  old,_=forward_chunk(self.base,self.q,self.y,self.m,self.m,initial_memory(self.base,2))
  expected=torch.sigmoid(torch.logit(old)+self.model.student_bias[self.u,None]+self.model.item_bias[self.i])
  self.assertTrue(torch.allclose(out,expected,atol=1e-7))
  a,m=self.model.forward_chunk(self.u,self.i[:,:2],self.q[:,:2],self.y[:,:2],self.m[:,:2],self.m[:,:2],initial_memory(self.base,2))
  b,ms=self.model.forward_chunk(self.u,self.i[:,2:],self.q[:,2:],self.y[:,2:],self.m[:,2:],self.m[:,2:],m)
  self.assertTrue(torch.allclose(out,torch.cat((a,b),1),atol=1e-7));self.assertTrue(torch.allclose(st,ms,atol=1e-7))
 def test_current_answer_cannot_affect_its_prediction(self):
  p,_=self.model.forward_chunk(self.u,self.i,self.q,self.y,self.m,self.m,initial_memory(self.base,2));y=self.y.clone();y[:,2]=1-y[:,2]
  r,_=self.model.forward_chunk(self.u,self.i,self.q,y,self.m,self.m,initial_memory(self.base,2));self.assertTrue(torch.allclose(p[:,:3],r[:,:3],atol=1e-7))
if __name__=='__main__':unittest.main()
