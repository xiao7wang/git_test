"""Train one prespecified DKVMN variant and seed; dev-only early stopping."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics
from streaming_dkvmn import initial_memory,forward_chunk
from bias_adapter import BiasDKVMN
from run_pilot import load_upstream,selected_sequences,batches
ROOT=Path(__file__).resolve().parent

def forward(model,base,variant,b,state):
 if variant=='original':return forward_chunk(base,b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)
 return model.forward_chunk(b['student_idx'],b['item_idx'],b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)

def evaluate(model,base,variant,data,users,device,chunk,batch):
 model.eval();records=[];start=time.monotonic()
 with torch.no_grad():
  for chosen,seq in batches(data,users,'valid',batch):
   state=initial_memory(base,len(chosen))
   for b,idx in data.chunks(chosen,seq,'valid',chunk,device):
    p,state=forward(model,base,variant,b,state);mask=b['target_mask'].cpu().numpy()
    if mask.any():
     ids=idx[mask];records.append(pd.DataFrame({'record_idx':ids,'student_idx':data.arrays['student_idx'][ids],'label':data.arrays['label'][ids],'probability':p.cpu().numpy()[mask]}))
 if not records:raise ValueError('No development events')
 return pd.concat(records,ignore_index=True).sort_values('record_idx').reset_index(drop=True),time.monotonic()-start

def save_checkpoint(out,name,contents):
 tmp=out/(name+'.pending');torch.save(contents,tmp);tmp.replace(out/name)

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if a.seed not in (1,2) or a.variant not in ('original','bias') or min(a.batch_size,a.chunk_size,a.epochs,a.patience)<1:raise ValueError('Invalid job settings')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
 status={'status':'running','phase':'source_verify','variant':a.variant,'seed':a.seed,'epoch':0,'test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  lock=read(ROOT/'locked_seed0.json');lock1=read(ROOT/'locked_p1.json');sources={'original':Path(a.original_dir),'bias':Path(a.bias_dir)};p1=Path(a.p1_dir)
  for variant,root in sources.items():
   for n,h in lock[variant]['files'].items():
    if sha(root/n)!=h:raise ValueError(f'Seed0 {variant} changed: {n}')
  for n,h in lock1['p1_files'].items():
   if sha(p1/n)!=h:raise ValueError('P1 source changed: '+n)
  old={k:read(v/'config.json') for k,v in sources.items()};p1cfg=read(p1/'config.json')
  for k,root in sources.items():
   if read(root/'status.json')['status']!='complete' or old[k]['test_evaluated'] or old[k]['holdout_evaluated'] or old[k]['source_p1_files']!=lock1['p1_files']:raise ValueError('Prior run incomplete or protocol mismatch: '+k)
   if (old[k]['batch_size'],old[k]['chunk_size'],old[k]['epochs_max'],old[k]['patience'],old[k]['optimizer'],old[k]['lr'])!=(a.batch_size,a.chunk_size,a.epochs,a.patience,'Adam',.001):raise ValueError('Prior training settings differ: '+k)
   for n in ('run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py'):
    if sha(ROOT/n)!=old[k]['code_sha256'][n]:raise ValueError('Shared implementation changed: '+n)
  if sha(ROOT/'bias_adapter.py')!=old['bias']['code_sha256']['bias_adapter.py']:raise ValueError('Bias implementation differs')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or any(x['data_fingerprint']!=spec['data_fingerprint'] for x in [old['original'],old['bias'],p1cfg]):raise ValueError('Data fingerprint differs')
  DKVMN,source=load_upstream()
  if any(x['source_archive_sha256']!=source['archive_sha256'] or x['source_dkvmn_sha256']!=sha(ROOT/'pykt/models/dkvmn.py') for x in old.values()):raise ValueError('Upstream source differs')
  data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires binary single-KC items')
  users=np.unique(arr['student_idx'][arr['split']==0]).astype(np.int64);dev=np.asarray(sorted(dev_users(arr['student_idx'][arr['split']==1])),dtype=np.int64)
  ids=np.flatnonzero((arr['split']==1)&np.isin(arr['student_idx'],dev));ref=pd.read_csv(sources['original']/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
   expected=ids if key=='record_idx' else arr[key][ids]
   if not np.array_equal(ref[col].to_numpy(),expected):raise ValueError('Development identity mismatch: '+col)
  train_expected=int(np.sum(arr['split']==0))
  if any(train_expected!=v['train_expected_events'] or len(ids)!=v['development_events'] for v in old.values()):raise ValueError('Event coverage differs')
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(a.seed)
  if device.type=='cuda':torch.cuda.manual_seed_all(a.seed)
  torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  dims=data.manifest['summary'];base=DKVMN(num_c=int(dims['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
  model=base if a.variant=='original' else BiasDKVMN(base,int(dims['students']),int(dims['items'])).to(device)
  cfg={'purpose':'prespecified paired seed replication, development only','variant':a.variant,'seed':a.seed,'data_fingerprint':data.fingerprint,'student_partition_salt':SALT,
   'feedback':'row immediate assumption; predict before feedback; train history plus selected development users prior validation answers',
   'features':'KC and history; bias variant additionally uses student and item ID; no time or response-time',
   'source_seed0_files':{k:v['files'] for k,v in lock.items()},'source_p1_files':lock1['p1_files'],'source_archive_sha256':source['archive_sha256'],
   'code_sha256':{n:sha(ROOT/n) for n in ('run_job.py','bias_adapter.py','run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')},
   'dim_s':32,'memory_slots':20,'dropout':.2,'optimizer':'Adam','lr':.001,'batch_size':a.batch_size,'chunk_size':a.chunk_size,'gradient_clip':5,
   'epochs_max':a.epochs,'patience':a.patience,'selection':'development event NLL, strict improvement; patience',
   'train_order':'numpy default_rng(seed*10000 + epoch-1); identical between variants for each seed',
   'train_students':len(users),'train_expected_events':train_expected,'development_students':len(dev),'development_events':len(ids),
   'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg);model.eval();check=next((x[:64] for x in selected_sequences(data,users,'train') if len(x)>=2),None)
  if check is None:raise ValueError('No suitable train sequence')
  kt=torch.as_tensor(q.argmax(1)[arr['item_idx'][check]][None,:],device=device,dtype=torch.long);it=torch.as_tensor(arr['item_idx'][check][None,:],device=device,dtype=torch.long)
  yt=torch.as_tensor(arr['label'][check][None,:],device=device,dtype=torch.long);ut=torch.as_tensor([arr['student_idx'][check[0]]],device=device,dtype=torch.long);mask=torch.ones_like(kt,dtype=torch.bool)
  with torch.no_grad():
   official=base(kt,yt)
   if a.variant=='original':adapted,_=forward_chunk(base,kt,yt,mask,mask,initial_memory(base,1))
   else:adapted,_=model.forward_chunk(ut,it,kt,yt,mask,mask,initial_memory(base,1))
  bridge=float(torch.max(torch.abs(official-adapted)).item())
  if bridge>1e-6:raise ValueError(f'Upstream bridge differs: {bridge}')
  opt=torch.optim.Adam(model.parameters(),lr=.001);history=[];best=float('inf');best_epoch=None;stale=0
  for epoch in range(1,a.epochs+1):
   status.update(phase='training',epoch=epoch,best_epoch=best_epoch);write(out/'status.json',status);print(json.dumps({'phase':'training_start','variant':a.variant,'seed':a.seed,'epoch':epoch}),flush=True)
   order=np.random.default_rng(a.seed*10000+epoch-1).permutation(users);model.train()
   if device.type=='cuda':torch.cuda.synchronize()
   start=time.monotonic();total=0.;train_n=0;steps=0;batch_n=0
   for chosen,seq in batches(data,order,'train',a.batch_size):
    batch_n+=1;state=initial_memory(base,len(chosen))
    for b,_ in data.chunks(chosen,seq,'train',a.chunk_size,device):
     opt.zero_grad(set_to_none=True);p,state=forward(model,base,a.variant,b,state);m=b['target_mask'];n=int(m.sum().item())
     if n:
      loss=F.binary_cross_entropy(p[m].clamp(1e-6,1-1e-6),b['label'][m])
      if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
      loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*n;train_n+=n;steps+=1
     state=state.detach()
    if batch_n%40==0:print(json.dumps({'phase':'training','variant':a.variant,'seed':a.seed,'epoch':epoch,'batch':batch_n,'total_batches':int((len(order)+a.batch_size-1)//a.batch_size),'train_events':train_n,'elapsed_seconds':time.monotonic()-start}),flush=True)
   if device.type=='cuda':torch.cuda.synchronize()
   train_sec=time.monotonic()-start
   if train_n!=train_expected:raise ValueError(f'Training coverage mismatch: {train_n}')
   status['phase']='development_replay';write(out/'status.json',status);print(json.dumps({'phase':'development_replay','variant':a.variant,'seed':a.seed,'epoch':epoch}),flush=True)
   frame,eval_sec=evaluate(model,base,a.variant,data,dev,device,a.chunk_size,a.batch_size)
   for col in ('record_idx','student_idx','label'):
    if not np.array_equal(frame[col].to_numpy(),ref[col].to_numpy()):raise ValueError('Development identity mismatch: '+col)
   met=metrics(frame.label.to_numpy(),frame.probability.to_numpy());nll=float(met['nll'])
   if not np.isfinite(nll):raise FloatingPointError('Nonfinite development NLL')
   improved=nll<best
   if improved:
    best=nll;best_epoch=epoch;stale=0;save_checkpoint(out,'best_model.pt',{'model_state':model.state_dict(),'variant':a.variant,'seed':a.seed,'epoch':epoch,'data_fingerprint':data.fingerprint,'dev_nll':nll})
    frame.to_csv(out/'best_dev_predictions.csv.gz',index=False,compression='gzip')
   else:stale+=1
   h={'epoch':epoch,'train_events':train_n,'optimizer_steps':steps,'train_bce':total/train_n,'train_seconds':train_sec,'dev':met,'dev_seconds':eval_sec,'improved':improved,'best_epoch':best_epoch,'stale':stale};history.append(h);write(out/'history.json',history)
   save_checkpoint(out,'last_epoch.pt',{'model_state':model.state_dict(),'optimizer_state':opt.state_dict(),'variant':a.variant,'seed':a.seed,'epoch':epoch,'best_epoch':best_epoch,'best_nll':best,'stale':stale,'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if device.type=='cuda' else None,'data_fingerprint':data.fingerprint})
   print(json.dumps({'phase':'epoch_complete',**h}),flush=True)
   if stale>=a.patience:break
  status['phase']='chunk_preflight';write(out/'status.json',status);sample=dev[:min(32,len(dev))]
  f50,_=evaluate(model,base,a.variant,data,sample,device,a.chunk_size,a.batch_size);f17,_=evaluate(model,base,a.variant,data,sample,device,17,a.batch_size)
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(f50[col].to_numpy(),f17[col].to_numpy()):raise ValueError('Chunk preflight identity mismatch')
  diff=float(np.max(np.abs(f50.probability.to_numpy(float)-f17.probability.to_numpy(float)),initial=0))
  if diff>1e-6:raise ValueError(f'Chunk preflight discrepancy: {diff}')
  summary={'status':'complete','variant':a.variant,'seed':a.seed,'epochs':len(history),'best_epoch':best_epoch,'best_dev':min(history,key=lambda h:h['dev']['nll'])['dev'],
   'upstream_bridge_max_abs':bridge,'chunk17_max_abs':diff,'chunk_preflight_students':len(sample),'chunk_preflight_model':'last epoch',
   'stop_reason':'early_stopping' if stale>=a.patience else 'epoch_limit','best_checkpoint_sha256':sha(out/'best_model.pt'),'last_checkpoint_sha256':sha(out/'last_epoch.pt'),
   'scope':'exploratory development one seed; no test or holdout','test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-begin}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,epoch=len(history),best_epoch=best_epoch,seconds=time.monotonic()-begin);write(out/'status.json',status);print('JOB COMPLETE',a.variant,a.seed,flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for n in ('project-dir','data-dir','p1-dir','original-dir','bias-dir','output-dir','variant'):p.add_argument('--'+n,required=True)
 p.add_argument('--seed',type=int,required=True);p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
