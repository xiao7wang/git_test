import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if not (d/'status.json').exists():raise SystemExit('No status file: check launch log')
s=json.loads((d/'status.json').read_text(encoding='utf8'));print('suite:',s.get('status'),'phase:',s.get('phase'),'active:',s.get('active_job'),'completed:',len(s.get('completed',[])),'/4','error:',s.get('error','-'))
print('Saved running status does not prove a live process.')
for name in ('original_seed1','bias_seed1','original_seed2','bias_seed2'):
 path=d/name/'status.json'
 if path.exists():
  r=json.loads(path.read_text(encoding='utf8'));print(name,r.get('status'),'phase:',r.get('phase'),'epoch:',r.get('epoch'),'best:',r.get('best_epoch'),'error:',r.get('error','-'))
 else:print(name,'not_started')
if (d/'summary.json').exists():
 r=json.loads((d/'summary.json').read_text(encoding='utf8'))
 for n,x in r['seed_aggregates'].items():print(n,'mean NLL:',x['nll']['mean'],'mean macro NLL:',x['student_macro_nll']['mean'],'mean AUC:',x['auc']['mean'])
 print('mean paired bias-original:',r['paired']['bias_minus_original_mean_loss_three_fixed_seeds'])
 print('Development only; three DKVMN seeds; count reference seed 0 only.')
if (d/'dkvmn_seedrep_results.zip').exists():print('Results archive:',d/'dkvmn_seedrep_results.zip')
