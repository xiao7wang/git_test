#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wangxiao/QCCDM/top_sci_repro"
CONDA="/home/wangxiao/miniconda3/etc/profile.d/conda.sh"
ENV_NAME="cd5090"

cd "$ROOT"
mkdir -p logs/overnight results/baseline_summary scripts

echo "===== [0] make grouped main table ====="
python scripts/19_make_grouped_main_table.py > logs/overnight/make_grouped_main_table.log 2>&1 || true

echo "===== [1] ORCDF 5 seeds ====="
ORCDF_DIR="$ROOT/repos/ORCDF"
ORCDF_SRC="$ORCDF_DIR/exp_orcdf_nowandb.py"
ORCDF_RUN_DIR="$ORCDF_DIR/scripts_multiseed"
ORCDF_LOG_DIR="$ORCDF_DIR/logs/baseline/orcdf_assist_sample_5seed"

if [ -f "$ORCDF_SRC" ]; then
  mkdir -p "$ORCDF_RUN_DIR" "$ORCDF_LOG_DIR"

  for s in 0 1 2 3 4; do
    echo "===== ORCDF seed $s ====="
    ORCDF_DST="$ORCDF_RUN_DIR/exp_orcdf_nowandb_seed${s}.py"

    python - <<PY
from pathlib import Path
import re

src = Path("$ORCDF_SRC")
dst = Path("$ORCDF_DST")
text = src.read_text(encoding="utf-8", errors="ignore")

# 尽量兼容常见写法：seed=0, 'seed':0, "seed":0
text = re.sub(r"(\bseed\s*=\s*)\d+", rf"\g<1>$s", text)
text = re.sub(r"(['\"]seed['\"]\s*:\s*)\d+", rf"\g<1>$s", text)

# ORCDF seed0 12ep 里 best 在 epoch2，3 epoch 已足够覆盖最优点；若源码没有该字段则不变
text = re.sub(r"(\bepoch\s*=\s*)\d+", r"\g<1>3", text)
text = re.sub(r"(['\"]epoch['\"]\s*:\s*)\d+", r"\g<1>3", text)
text = re.sub(r"(\bepochs\s*=\s*)\d+", r"\g<1>3", text)
text = re.sub(r"(['\"]epochs['\"]\s*:\s*)\d+", r"\g<1>3", text)

dst.write_text(text, encoding="utf-8")
print("wrote", dst)
PY

    cd "$ORCDF_DIR"
    source "$CONDA"
    conda activate "$ENV_NAME"
    python -u "$ORCDF_DST" > "$ORCDF_LOG_DIR/seed${s}.log" 2>&1 || {
      echo "ORCDF seed $s failed, see $ORCDF_LOG_DIR/seed${s}.log"
      continue
    }
  done
else
  echo "ORCDF script not found: $ORCDF_SRC"
fi

echo "===== [2] HyperCDM sample 5 seeds, guarded ====="
HYP_DIR="$ROOT/repos/HyperCDM"
HYP_RUN_DIR="$HYP_DIR/scripts_multiseed"
HYP_LOG_DIR="$HYP_DIR/logs/baseline/hypercdm_assist_sample_5seed"

if [ -d "$HYP_DIR" ]; then
  cd "$HYP_DIR"
  mkdir -p "$HYP_RUN_DIR" "$HYP_LOG_DIR"

  HYP_SRC=""
  for f in main*assist*sample*.py main*sample*assist*.py; do
    if [ -f "$f" ]; then
      HYP_SRC="$f"
      break
    fi
  done

  if [ -z "$HYP_SRC" ]; then
    echo "No HyperCDM sample script found. Skip HyperCDM to avoid accidentally running full dataset."
  else
    echo "Using HyperCDM source script: $HYP_SRC"

    for s in 0 1 2 3 4; do
      echo "===== HyperCDM seed $s ====="
      HYP_DST="$HYP_RUN_DIR/${HYP_SRC%.py}_seed${s}.py"

      python - <<PY
from pathlib import Path
import re

src = Path("$HYP_SRC")
dst = Path("$HYP_DST")
text = src.read_text(encoding="utf-8", errors="ignore")

# 替换常见随机种子写法
text = re.sub(r"(\bseed\s*=\s*)\d+", rf"\g<1>$s", text)
text = re.sub(r"(\brandom_seed\s*=\s*)\d+", rf"\g<1>$s", text)
text = re.sub(r"(['\"]seed['\"]\s*:\s*)\d+", rf"\g<1>$s", text)
text = re.sub(r"(['\"]random_seed['\"]\s*:\s*)\d+", rf"\g<1>$s", text)

# 如果脚本有日志名，尽量避免覆盖
text = text.replace("hypercdm_assist_sample5000_original_rerun.log", f"hypercdm_assist_sample5000_seed$s.log")
text = text.replace("hypercdm_assistments_ours.log", f"hypercdm_assistments_seed$s.log")

dst.write_text(text, encoding="utf-8")
print("wrote", dst)
PY

      source "$CONDA"
      conda activate "$ENV_NAME"
      python -u "$HYP_DST" > "$HYP_LOG_DIR/seed${s}.log" 2>&1 || {
        echo "HyperCDM seed $s failed, see $HYP_LOG_DIR/seed${s}.log"
        continue
      }
    done
  fi
else
  echo "HyperCDM dir not found: $HYP_DIR"
fi

echo "===== [3] overnight done ====="
cd "$ROOT"
python scripts/19_make_grouped_main_table.py > logs/overnight/make_grouped_main_table_after.log 2>&1 || true

echo "Finished at $(date)"
