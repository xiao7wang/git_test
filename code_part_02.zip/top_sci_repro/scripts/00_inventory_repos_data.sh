#!/usr/bin/env bash
set -e

ROOT=/home/wangxiao/QCCDM/top_sci_repro
echo "===== repos ====="
find $ROOT/repos -maxdepth 2 -type d | sed "s#$ROOT/repos/##" | sort | head -n 120

echo
echo "===== existing converted data ====="
find $ROOT -maxdepth 5 -type d \( -name "*assist*" -o -name "*ednet*" -o -name "*junyi*" \) | sort

echo
echo "===== key files in repos ====="
for r in CausalCDF Dynamic-Cognitive-Diagnosis HO-NCD HyperCDM Neural_Cognitive_Diagnosis-NeuralCD NeuralCD_TRG ORCDF Intelligent-Education; do
  echo
  echo "----- $r -----"
  find $ROOT/repos/$r -maxdepth 3 -type f \( -name "main*.py" -o -name "train*.py" -o -name "run*.sh" -o -name "*.yaml" -o -name "*.yml" -o -name "config*.txt" -o -name "README*" \) 2>/dev/null | head -n 60
done
