import json
import csv
import ast
from pathlib import Path
from collections import defaultdict

src = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data")
dst = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/CausalCDF/CasualCDF/data/a0910_ease")
dst.mkdir(parents=True, exist_ok=True)

def load_json(name):
    return json.load(open(src / name, "r", encoding="utf-8"))

def parse_kc(v):
    if isinstance(v, list):
        return [int(x) for x in v]
    if isinstance(v, int):
        return [int(v)]
    if isinstance(v, str):
        s = v.strip()
        if s.startswith("["):
            return [int(x) for x in ast.literal_eval(s)]
        if "," in s:
            return [int(x) for x in s.split(",") if x.strip()]
        return [int(s)]
    raise ValueError(f"bad kc: {v}")

def flatten(obj):
    rows = []
    for entry in obj:
        if isinstance(entry, dict) and "exer_id" in entry:
            rows.append((
                int(entry["user_id"]),
                int(entry["exer_id"]),
                int(entry["score"]),
                parse_kc(entry["knowledge_code"])
            ))
        elif isinstance(entry, dict) and "logs" in entry:
            uid = int(entry["user_id"])
            for r in entry["logs"]:
                rows.append((
                    uid,
                    int(r["exer_id"]),
                    int(r["score"]),
                    parse_kc(r["knowledge_code"])
                ))
        else:
            raise ValueError(f"unsupported entry: {str(entry)[:300]}")
    return rows

splits = {
    "train": flatten(load_json("train_set.json")),
    "valid": flatten(load_json("val_set.json")),
    "test": flatten(load_json("test_set.json")),
}

item2kc = defaultdict(set)
item_correct = defaultdict(int)
item_total = defaultdict(int)

for split, rows in splits.items():
    print(split, "records:", len(rows))
    for uid, iid, score, kc_list in rows:
        for k in kc_list:
            item2kc[iid].add(k)
        if split == "train":
            item_correct[iid] += int(score)
            item_total[iid] += 1

# ease = train correct rate
# 正确率越高，题越容易，diff 越大；符合源码 scores * diff 的方向
raw_ease = {}
for iid in item2kc:
    if item_total[iid] > 0:
        raw_ease[iid] = item_correct[iid] / item_total[iid]
    else:
        raw_ease[iid] = 0.5

vals = list(raw_ease.values())
mn, mx = min(vals), max(vals)

def norm_ease(iid):
    e = raw_ease.get(iid, 0.5)
    if mx > mn:
        z = (e - mn) / (mx - mn)
    else:
        z = 0.5
    return 0.5 + z  # [0.5, 1.5]

for split, rows in splits.items():
    out = dst / f"{split}.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["user_id", "item_id", "score", "diff"])
        for uid, iid, score, kc_list in rows:
            w.writerow([uid, iid, score, norm_ease(iid)])
    print("wrote", out)

with (dst / "item.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["item_id", "knowledge_code"])
    for iid in sorted(item2kc):
        w.writerow([iid, str(sorted(item2kc[iid]))])

print("wrote", dst / "item.csv")
print("summary:",
      "max_user", max(uid for rows in splits.values() for uid, _, _, _ in rows),
      "num_items", len(item2kc),
      "max_item", max(item2kc),
      "max_kc", max(k for ks in item2kc.values() for k in ks),
      "raw_ease_min", mn,
      "raw_ease_max", mx)
