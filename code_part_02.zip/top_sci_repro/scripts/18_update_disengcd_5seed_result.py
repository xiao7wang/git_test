import csv
from pathlib import Path

csv_path = Path("results/baseline_summary/current_baseline_seed0.csv")

with csv_path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    rows = list(reader)

rows = [r for r in rows if r.get("model") != "DisenGCD-fixed"]

rows.append({
    "model": "DisenGCD-fixed",
    "dataset": "ASSIST09_repo_default",
    "source": "repos/Intelligent-Education/DisenGCD/DisenGCD/logs/baseline/disengcd_default_cpu_5seed_e28/seed0.log",
    "best_epoch": "28",
    "AUC": "0.775880",
    "ACC": "0.736866",
    "F1": "0.812769",
    "RMSE": "0.419371",
    "DOA": "",
    "note": "repo-default split; CPU DGL reproduction; 5seed AUC=0.774802±0.000840, ACC=0.734627±0.001334, F1=0.810845±0.001206, RMSE=0.420054±0.000559; graph files regenerated and code bugs fixed"
})

with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Updated current_baseline_seed0.csv")
for r in rows:
    print(r["model"], r["dataset"], r["AUC"], r["ACC"], r["F1"], r["RMSE"])
