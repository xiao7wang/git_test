import csv
from pathlib import Path

src = Path("results/baseline_summary/current_baseline_seed0.csv")
out = Path("results/baseline_summary/current_baseline_seed0_table.md")

rows = list(csv.DictReader(src.open("r", encoding="utf-8")))

with out.open("w", encoding="utf-8") as f:
    f.write("# Current Reproduced Baselines, seed0\n\n")
    f.write("| Model | Dataset | Best epoch | AUC | ACC | F1 | RMSE | DOA | Note |\n")
    f.write("|---|---|---:|---:|---:|---:|---:|---:|---|\n")
    for r in rows:
        f.write(
            f"| {r['model']} | {r['dataset']} | {r['best_epoch']} | "
            f"{r['AUC']} | {r['ACC']} | {r['F1']} | {r['RMSE']} | {r['DOA']} | {r['note']} |\n"
        )

print(out)
print(out.read_text(encoding="utf-8"))
