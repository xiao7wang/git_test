import csv
import re
from pathlib import Path

csv_path = Path("results/baseline_summary/current_baseline_seed0.csv")
log_path = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Intelligent-Education/DisenGCD/DisenGCD/logs/baseline/disengcd_default_cpu_seed0_epoch40_b2048.log")

text = log_path.read_text(encoding="utf-8", errors="ignore")

m = re.search(
    r"FINAL_BEST epoch=(\d+), accuracy=([0-9.]+), rmse=([0-9.]+), auc=([0-9.]+), precision=([0-9.]+), recall=([0-9.]+), f1=([0-9.]+)",
    text
)

if not m:
    raise RuntimeError("Cannot find FINAL_BEST line.")

best_epoch, acc, rmse, auc, precision, recall, f1 = m.groups()

new_row = {
    "model": "DisenGCD-fixed",
    "dataset": "ASSIST09_repo_default",
    "source": "repos/Intelligent-Education/DisenGCD/DisenGCD/logs/baseline/disengcd_default_cpu_seed0_epoch40_b2048.log",
    "best_epoch": best_epoch,
    "AUC": auc,
    "ACC": acc,
    "F1": f1,
    "RMSE": rmse,
    "DOA": "",
    "note": "repo-default split; CPU DGL reproduction; graph files regenerated from item-concept relations; fixed import/device/forward/output bugs; best observed epoch under repo evaluation protocol"
}

with csv_path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    rows = list(reader)

rows = [r for r in rows if r.get("model") != "DisenGCD-fixed"]
rows.append(new_row)

with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Updated DisenGCD-fixed:")
print(new_row)
print("\nCurrent table:")
for r in rows:
    print(r["model"], r["dataset"], r["AUC"], r["ACC"], r["F1"], r["RMSE"])
