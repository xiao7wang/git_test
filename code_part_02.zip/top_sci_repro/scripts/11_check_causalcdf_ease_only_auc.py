import csv
from pathlib import Path
from sklearn.metrics import roc_auc_score, accuracy_score, f1_score
import numpy as np

root = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/CausalCDF/CasualCDF/data/a0910_ease")

for split in ["valid", "test"]:
    y_true = []
    score = []

    with (root / f"{split}.csv").open("r", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            y_true.append(int(float(r["score"])))
            score.append(float(r["diff"]))

    y_true = np.array(y_true)
    score = np.array(score)

    pred = (score >= 1.0).astype(int)

    print(
        split,
        "ease_only_auc=", f"{roc_auc_score(y_true, score):.6f}",
        "ease_only_acc=", f"{accuracy_score(y_true, pred):.6f}",
        "ease_only_f1=", f"{f1_score(y_true, pred):.6f}",
        "pos_rate=", f"{y_true.mean():.6f}",
        "score_min=", f"{score.min():.6f}",
        "score_max=", f"{score.max():.6f}",
    )
