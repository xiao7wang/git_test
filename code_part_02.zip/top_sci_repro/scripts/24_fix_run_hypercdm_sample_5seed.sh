#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wangxiao/QCCDM/top_sci_repro"
HYP_DIR="$ROOT/repos/HyperCDM"
CONDA="/home/wangxiao/miniconda3/etc/profile.d/conda.sh"
ENV_NAME="cd5090"

SRC="$HYP_DIR/main_assistments_sample5000_item12000_epoch3.py"
LOG_DIR="$HYP_DIR/logs/baseline/hypercdm_assist_sample_5seed_fixed"
RUN_DIR="$HYP_DIR/scripts_multiseed"

mkdir -p "$LOG_DIR" "$RUN_DIR"

if [ ! -f "$SRC" ]; then
  echo "Missing source script: $SRC"
  exit 1
fi

source "$CONDA"
conda activate "$ENV_NAME"

export PYTHONPATH="$HYP_DIR:$ROOT:${PYTHONPATH:-}"

cd "$HYP_DIR"

echo "Using source script: $SRC"
echo "Using PYTHONPATH: $PYTHONPATH"

for s in 0 1 2 3 4; do
  echo "===== HyperCDM seed $s ====="

  DST="$RUN_DIR/main_assistments_sample5000_item12000_epoch3_seed${s}_fixed.py"

  python - "$SRC" "$DST" "$s" <<'PY'
from pathlib import Path
import re
import sys

src = Path(sys.argv[1])
dst = Path(sys.argv[2])
seed = sys.argv[3]

text = src.read_text(encoding="utf-8", errors="ignore")

patterns = [
    (r"(\bseed\s*=\s*)\d+", rf"\g<1>{seed}"),
    (r"(\brandom_seed\s*=\s*)\d+", rf"\g<1>{seed}"),
    (r"""(['"]seed['"]\s*:\s*)\d+""", rf"\g<1>{seed}"),
    (r"""(['"]random_seed['"]\s*:\s*)\d+""", rf"\g<1>{seed}"),
]

for pat, repl in patterns:
    text = re.sub(pat, repl, text)

text = text.replace(
    "hypercdm_assist_sample5000_original_rerun.log",
    f"hypercdm_assist_sample5000_seed{seed}.log"
)
text = text.replace(
    "hypercdm_assist_sample5000_item12000_epoch3.log",
    f"hypercdm_assist_sample5000_item12000_seed{seed}_epoch3.log"
)

dst.write_text(text, encoding="utf-8")
print("wrote", dst)
PY

  python -u "$DST" > "$LOG_DIR/seed${s}.log" 2>&1 || {
    echo "HyperCDM seed $s failed, see $LOG_DIR/seed${s}.log"
    continue
  }
done

echo "HyperCDM original sample 5 seeds finished."
