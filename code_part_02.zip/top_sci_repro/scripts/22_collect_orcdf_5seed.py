import re
import ast
import csv
import statistics as st
from pathlib import Path

log_dir = Path("repos/ORCDF/logs/baseline/orcdf_assist_sample_5seed_fixed")
out_csv = Path("results/baseline_summary/orcdf_assist_sample_5seed_fixed.csv")
out_txt = Path("results/baseline_summary/orcdf_assist_sample_5seed_fixed_summary.txt")
out_csv.parent.mkdir(parents=True, exist_ok=True)

rows = []

for seed in range(5):
    p = log_dir / f"seed{seed}.log"
    if not p.exists():
        print(f"missing seed{seed}: {p}")
        continue

    text = p.read_text(encoding="utf-8", errors="ignore")

    if "Traceback" in text or "RuntimeError" in text or "Error" in text:
        print(f"warning: error marker in {p}")

    epoch_matches = list(re.finditer(r"\[Epoch\s+(\d+)\]", text))
    metric_matches = list(re.finditer(r"\{[^{}]*'acc'[^{}]*'auc'[^{}]*'rmse'[^{}]*\}", text, re.S))

    if not metric_matches:
        print(f"no metric dict for seed{seed}")
        continue

    best = None
    for i, mm in enumerate(metric_matches):
        metrics = ast.literal_eval(mm.group(0))
        epoch = i + 1
        if i < len(epoch_matches):
            epoch = int(epoch_matches[i].group(1))

        # 日志里是百分数，统一转为小数
        row = {
            "seed": seed,
            "best_epoch": epoch,
            "AUC": float(metrics["auc"]) / 100.0,
            "ACC": float(metrics["acc"]) / 100.0,
            "F1": float(metrics["f1"]) / 100.0,
            "RMSE": float(metrics["rmse"]) / 100.0,
            "DOA": float(metrics.get("doa", 0.0)) / 100.0,
            "AP": float(metrics.get("ap", 0.0)) / 100.0,
            "MAD": float(metrics.get("mad", 0.0)) / 100.0,
        }

        if best is None or row["AUC"] > best["AUC"]:
            best = row

    rows.append(best)

fieldnames = ["seed", "best_epoch", "AUC", "ACC", "F1", "RMSE", "DOA", "AP", "MAD"]

with out_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

lines = ["seed,best_epoch,AUC,ACC,F1,RMSE,DOA,AP,MAD"]
for r in rows:
    lines.append(
        f"{r['seed']},{r['best_epoch']},"
        f"{r['AUC']:.6f},{r['ACC']:.6f},{r['F1']:.6f},"
        f"{r['RMSE']:.6f},{r['DOA']:.6f},{r['AP']:.6f},{r['MAD']:.6f}"
    )

if len(rows) >= 2:
    lines.append("")
    lines.append("mean±std")
    for k in ["AUC", "ACC", "F1", "RMSE", "DOA", "AP", "MAD"]:
        vals = [r[k] for r in rows]
        lines.append(f"{k}: {st.mean(vals):.6f} ± {st.stdev(vals):.6f}")

out_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("\n".join(lines))
print(f"\nsaved csv: {out_csv}")
print(f"saved summary: {out_txt}")
