import csv
import re
from pathlib import Path

csv_path = Path("results/baseline_summary/current_baseline_seed0.csv")
log_path = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/CausalCDF/logs/baseline/causalcdf_ncdm_causal_fix_a0910_ease_seed0_epoch10.log")

text = log_path.read_text(encoding="utf-8", errors="ignore")

m = re.search(
    r"FINAL_TEST accuracy=([0-9.]+), precision=([0-9.]+), rmse=([0-9.]+), recall=([0-9.]+), auc=([0-9.]+), f1=([0-9.]+)",
    text
)

if not m:
    raise RuntimeError("Cannot find complete FINAL_TEST line in log.")

acc, precision, rmse, recall, auc, f1 = m.groups()

new_row = {
    "model": "CausalCDF-NCDM-fixed",
    "dataset": "ASSIST09_official_converted",
    "source": "repos/CausalCDF/logs/baseline/causalcdf_ncdm_causal_fix_a0910_ease_seed0_epoch10.log",
    "best_epoch": "10",
    "AUC": auc,
    "ACC": acc,
    "F1": f1,
    "RMSE": rmse,
    "DOA": "",
    "note": "fixed reproduction under unified protocol; diff uses train item ease=correct_rate normalized to [0.5,1.5]; original difficulty direction caused positive-class collapse"
}

with csv_path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    rows = list(reader)

# 删除旧的 CausalCDF-NCDM-fixed 行，防止重复追加
rows = [r for r in rows if r.get("model") != "CausalCDF-NCDM-fixed"]
rows.append(new_row)

with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Appended CausalCDF-NCDM-fixed:")
print(new_row)
print("\nCurrent table:")
for r in rows:
    print(r["model"], r["dataset"], r["AUC"], r["ACC"], r["F1"], r["RMSE"])
