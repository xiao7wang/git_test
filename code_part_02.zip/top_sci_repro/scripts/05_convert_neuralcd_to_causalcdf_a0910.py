import json
import csv
import ast
from pathlib import Path
from collections import defaultdict, Counter

src = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data")
dst = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/CausalCDF/CasualCDF/data/a0910")
dst.mkdir(parents=True, exist_ok=True)

def load_json(name):
    return json.load(open(src / name, "r", encoding="utf-8"))

def parse_kc(v):
    if isinstance(v, list):
        return [int(x) for x in v]
    if isinstance(v, int):
        return [int(v)]
    if isinstance(v, str):
        s = v.strip()
        if s.startswith("["):
            return [int(x) for x in ast.literal_eval(s)]
        if "," in s:
            return [int(x) for x in s.split(",") if x.strip()]
        return [int(s)]
    raise ValueError(f"bad kc: {v}")

def flatten(obj):
    rows = []
    for entry in obj:
        # flat interaction: train_set.json
        if isinstance(entry, dict) and "exer_id" in entry:
            uid = int(entry["user_id"])
            iid = int(entry["exer_id"])
            score = int(entry["score"])
            kc = parse_kc(entry["knowledge_code"])
            rows.append((uid, iid, score, kc))
        # sequence format: val_set.json / test_set.json
        elif isinstance(entry, dict) and "logs" in entry:
            uid = int(entry["user_id"])
            for r in entry["logs"]:
                iid = int(r["exer_id"])
                score = int(r["score"])
                kc = parse_kc(r["knowledge_code"])
                rows.append((uid, iid, score, kc))
        else:
            raise ValueError(f"unsupported entry: {str(entry)[:300]}")
    return rows

splits = {
    "train": flatten(load_json("train_set.json")),
    "valid": flatten(load_json("val_set.json")),
    "test": flatten(load_json("test_set.json")),
}

item2kc = defaultdict(set)
train_count = Counter()

for split, rows in splits.items():
    print(split, "records:", len(rows))
    for uid, iid, score, kc_list in rows:
        for k in kc_list:
            item2kc[iid].add(k)
        if split == "train":
            train_count[iid] += 1

def diff(iid):
    # 只用 train 统计曝光频次，避免 valid/test 泄露
    return int(train_count.get(iid, 1))

for split, rows in splits.items():
    out = dst / f"{split}.csv"
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["user_id", "item_id", "score", "diff"])
        for uid, iid, score, kc_list in rows:
            w.writerow([uid, iid, score, diff(iid)])
    print("wrote", out)

with (dst / "item.csv").open("w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["item_id", "knowledge_code"])
    for iid in sorted(item2kc):
        w.writerow([iid, str(sorted(item2kc[iid]))])

print("wrote", dst / "item.csv")
print("summary:",
      "max_user", max(uid for rows in splits.values() for uid, _, _, _ in rows),
      "num_items", len(item2kc),
      "max_item", max(item2kc),
      "max_kc", max(k for ks in item2kc.values() for k in ks))
