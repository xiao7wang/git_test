#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wangxiao/QCCDM/top_sci_repro"
ORCDF_DIR="$ROOT/repos/ORCDF"
CONDA="/home/wangxiao/miniconda3/etc/profile.d/conda.sh"
ENV_NAME="cd5090"

LOG_DIR="$ORCDF_DIR/logs/baseline/orcdf_assist_sample_5seed_fixed"
mkdir -p "$LOG_DIR"

source "$CONDA"
conda activate "$ENV_NAME"

export PYTHONPATH="$ORCDF_DIR:$ROOT:${PYTHONPATH:-}"

cd "$ORCDF_DIR"

for s in 0 1 2 3 4; do
  echo "===== ORCDF seed $s ====="

  python -u exp_orcdf_nowandb.py \
    --method 'orcdf-w|o-' \
    --data_type assist_sample5000_item12000 \
    --test_size 0.2 \
    --epoch 3 \
    --seed "$s" \
    --device cuda:0 \
    --gcn_layers 3 \
    --latent_dim 32 \
    --batch_size 4096 \
    --exp_type cdm \
    --lr 0.004 \
    --if_type ncd \
    --keep_prob 1.0 \
    --weight_decay 0.0 \
    --ssl_temp 0.5 \
    --ssl_weight 0.001 \
    --flip_ratio 0.15 \
    > "$LOG_DIR/seed${s}.log" 2>&1 || {
      echo "ORCDF seed $s failed, see $LOG_DIR/seed${s}.log"
      continue
    }
done

echo "ORCDF 5 seeds finished."
