import os
import json
import argparse
from collections import defaultdict

def pick(obj, keys, default=None):
    for k in keys:
        if k in obj:
            return obj[k]
    return default

def to_list(x):
    if isinstance(x, list):
        return x
    return [x]

def safe_int(x, default=None):
    try:
        return int(float(x))
    except Exception:
        return default

def safe_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default

def read_jsonl(path):
    rows = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows

def collect_raw_records(jsonl_path):
    records = []
    rows = read_jsonl(jsonl_path)

    for line_id, obj in enumerate(rows):
        uid = pick(obj, ["user_id", "uid", "student_id", "stu_id"])
        item = pick(obj, ["item_id", "question_id", "problem_id", "exer_id", "exercise_id"])
        know = pick(obj, ["know_id", "knowledge_id", "skill_id", "concept_id"])
        label = pick(obj, ["label", "correct", "score", "response"])
        rt = pick(obj, ["response_time", "elapsed_time", "rt"], 0)
        ts = pick(obj, ["timestamp", "start_time", "time"], line_id)

        if uid is None or item is None or know is None or label is None:
            continue

        if isinstance(item, list):
            items = to_list(item)
            knows = to_list(know)
            labels = to_list(label)
            rts = to_list(rt) if isinstance(rt, list) else [0] * len(items)
            tss = to_list(ts) if isinstance(ts, list) else list(range(len(items)))

            n = min(len(items), len(knows), len(labels), len(rts), len(tss))
            for i in range(n):
                y = safe_int(labels[i], -1)
                if y not in [0, 1]:
                    continue

                k = knows[i]
                if isinstance(k, list):
                    k_list = [safe_int(x) for x in k if safe_int(x) is not None]
                else:
                    k_list = [safe_int(k)]

                k_list = [x for x in k_list if x is not None]
                if len(k_list) == 0:
                    continue

                records.append({
                    "user_raw": safe_int(uid),
                    "item_raw": safe_int(items[i]),
                    "know_raw_list": k_list,
                    "score": y,
                    "response_time": safe_float(rts[i]),
                    "timestamp": safe_int(tss[i], i)
                })
        else:
            y = safe_int(label, -1)
            if y not in [0, 1]:
                continue

            if isinstance(know, list):
                k_list = [safe_int(x) for x in know if safe_int(x) is not None]
            else:
                k_list = [safe_int(know)]

            k_list = [x for x in k_list if x is not None]
            if len(k_list) == 0:
                continue

            records.append({
                "user_raw": safe_int(uid),
                "item_raw": safe_int(item),
                "know_raw_list": k_list,
                "score": y,
                "response_time": safe_float(rt),
                "timestamp": safe_int(ts, line_id)
            })

    return records

def build_maps(all_records):
    users = sorted(set(r["user_raw"] for r in all_records if r["user_raw"] is not None))
    items = sorted(set(r["item_raw"] for r in all_records if r["item_raw"] is not None))
    knows = sorted(set(k for r in all_records for k in r["know_raw_list"] if k is not None))

    # NeuralCD 原仓库 README 说 ids/codes 从 1 开始，这里统一映射到 1..N
    user_map = {x: i + 1 for i, x in enumerate(users)}
    item_map = {x: i + 1 for i, x in enumerate(items)}
    know_map = {x: i + 1 for i, x in enumerate(knows)}

    return user_map, item_map, know_map

def convert_records_to_users(records, user_map, item_map, know_map, min_logs=2):
    user_logs = defaultdict(list)

    for r in records:
        uid = user_map.get(r["user_raw"])
        iid = item_map.get(r["item_raw"])
        k_list = [know_map[k] for k in r["know_raw_list"] if k in know_map]

        if uid is None or iid is None or len(k_list) == 0:
            continue

        user_logs[uid].append({
            "exer_id": iid,
            "score": int(r["score"]),
            "knowledge_code": k_list,

            # 原版 NeuralCD 不用下面两个字段，但后面加 TRG 要用，所以先保留
            "response_time": float(r["response_time"]),
            "timestamp": int(r["timestamp"]) if r["timestamp"] is not None else 0
        })

    out = []
    for uid, logs in user_logs.items():
        logs = sorted(logs, key=lambda x: x.get("timestamp", 0))
        if len(logs) >= min_logs:
            out.append({
                "user_id": uid,
                "log_num": len(logs),
                "logs": logs
            })

    return out

def save_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--src_dir", required=True)
    parser.add_argument("--out_dir", required=True)
    parser.add_argument("--min_logs", type=int, default=2)
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    train_records = collect_raw_records(os.path.join(args.src_dir, "train.jsonl"))
    valid_records = collect_raw_records(os.path.join(args.src_dir, "valid.jsonl"))
    test_records = collect_raw_records(os.path.join(args.src_dir, "test.jsonl"))

    all_records = train_records + valid_records + test_records
    user_map, item_map, know_map = build_maps(all_records)

    train_users = convert_records_to_users(train_records, user_map, item_map, know_map, args.min_logs)
    valid_users = convert_records_to_users(valid_records, user_map, item_map, know_map, args.min_logs)
    test_users = convert_records_to_users(test_records, user_map, item_map, know_map, args.min_logs)

    save_json(train_users, os.path.join(args.out_dir, "train_set.json"))
    save_json(valid_users, os.path.join(args.out_dir, "val_set.json"))
    save_json(test_users, os.path.join(args.out_dir, "test_set.json"))

    # 兼容原仓库可能用到 log_data.json
    save_json(train_users + valid_users + test_users, os.path.join(args.out_dir, "log_data.json"))

    meta = {
        "student_n": len(user_map) + 1,
        "exer_n": len(item_map) + 1,
        "knowledge_n": len(know_map) + 1,
        "train_users": len(train_users),
        "valid_users": len(valid_users),
        "test_users": len(test_users),
        "train_logs": sum(x["log_num"] for x in train_users),
        "valid_logs": sum(x["log_num"] for x in valid_users),
        "test_logs": sum(x["log_num"] for x in test_users)
    }

    save_json(meta, os.path.join(args.out_dir, "meta_neuralcd.json"))

    # 生成 NeuralCD config.txt
    with open(os.path.join(args.out_dir, "config.txt"), "w", encoding="utf-8") as f:
        f.write("student_n,exer_n,knowledge_n\n")
        f.write(f"{meta['student_n']},{meta['exer_n']},{meta['knowledge_n']}\n")

    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print("saved to:", args.out_dir)

if __name__ == "__main__":
    main()
