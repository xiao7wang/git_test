#!/usr/bin/env bash
set -e

ROOT=/home/wangxiao/QCCDM/top_sci_repro/repos

for r in CausalCDF HO-NCD Neural_Cognitive_Diagnosis-NeuralCD Dynamic-Cognitive-Diagnosis; do
  echo
  echo "==================== $r ===================="
  cd $ROOT/$r
  echo "---- python files ----"
  find . -maxdepth 3 -type f -name "*.py" | sort | head -n 80
  echo
  echo "---- readme/config/run ----"
  find . -maxdepth 3 -type f \( -iname "README*" -o -name "*.sh" -o -name "*.yaml" -o -name "*.yml" -o -name "config*.txt" \) | sort
  echo
  echo "---- argparse/dataset hints ----"
  grep -R "argparse\|dataset\|data_type\|ASSIST\|assist\|junyi\|ednet\|epoch\|AUC\|auc" -n . 2>/dev/null | head -n 120 || true
done
