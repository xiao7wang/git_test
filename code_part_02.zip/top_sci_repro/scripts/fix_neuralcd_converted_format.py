import os
import json
import argparse

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def save_json(obj, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)

def flatten_train(train_users):
    flat = []
    for user in train_users:
        uid = int(user["user_id"])
        for log in user["logs"]:
            item = {
                "user_id": uid,
                "exer_id": int(log["exer_id"]),
                "knowledge_code": [int(x) for x in log["knowledge_code"]],
                "score": int(log["score"])
            }

            # 保留 RT 和 timestamp，后面加 TRG 会用
            if "response_time" in log:
                item["response_time"] = float(log["response_time"])
            if "timestamp" in log:
                item["timestamp"] = int(log["timestamp"])

            flat.append(item)
    return flat

def infer_config(train_flat, valid_users, test_users):
    max_user = 0
    max_item = 0
    max_know = 0

    def update_from_log(uid, log):
        nonlocal max_user, max_item, max_know
        max_user = max(max_user, int(uid))
        max_item = max(max_item, int(log["exer_id"]))
        for k in log["knowledge_code"]:
            max_know = max(max_know, int(k))

    for log in train_flat:
        update_from_log(log["user_id"], log)

    for users in [valid_users, test_users]:
        for user in users:
            uid = user["user_id"]
            for log in user["logs"]:
                update_from_log(uid, log)

    return max_user, max_item, max_know

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_dir", required=True)
    args = parser.parse_args()

    train_path = os.path.join(args.data_dir, "train_set.json")
    valid_path = os.path.join(args.data_dir, "val_set.json")
    test_path = os.path.join(args.data_dir, "test_set.json")

    train_obj = load_json(train_path)
    valid_users = load_json(valid_path)
    test_users = load_json(test_path)

    # 如果 train_set 已经是平铺格式，就不重复处理
    if len(train_obj) > 0 and "logs" in train_obj[0]:
        train_flat = flatten_train(train_obj)
        save_json(train_flat, train_path)
        print("train_set.json fixed: user-level -> flat interaction-level")
    else:
        train_flat = train_obj
        print("train_set.json already flat")

    student_n, exer_n, knowledge_n = infer_config(train_flat, valid_users, test_users)

    config_path = os.path.join(args.data_dir, "config.txt")
    with open(config_path, "w", encoding="utf-8") as f:
        f.write("student_n,exer_n,knowledge_n\n")
        f.write(f"{student_n},{exer_n},{knowledge_n}\n")

    meta = {
        "student_n": student_n,
        "exer_n": exer_n,
        "knowledge_n": knowledge_n,
        "train_logs": len(train_flat),
        "valid_users": len(valid_users),
        "test_users": len(test_users),
        "valid_logs": sum(x["log_num"] for x in valid_users),
        "test_logs": sum(x["log_num"] for x in test_users)
    }

    save_json(meta, os.path.join(args.data_dir, "meta_neuralcd_fixed.json"))

    print(json.dumps(meta, indent=2, ensure_ascii=False))
    print("fixed dir:", args.data_dir)

if __name__ == "__main__":
    main()
