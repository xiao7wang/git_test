import re
import csv
import statistics as st
from pathlib import Path

log_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Intelligent-Education/DisenGCD/DisenGCD/logs/baseline/disengcd_default_cpu_5seed_e28")
out_csv = Path("results/baseline_summary/disengcd_default_cpu_5seed_e28.csv")
out_txt = Path("results/baseline_summary/disengcd_default_cpu_5seed_e28_summary.txt")
out_csv.parent.mkdir(parents=True, exist_ok=True)

rows = []

for seed in [0, 1, 2, 3, 4]:
    p = log_dir / f"seed{seed}.log"
    if not p.exists():
        print(f"missing seed{seed}: {p}")
        continue

    text = p.read_text(encoding="utf-8", errors="ignore")

    if "Traceback" in text or "RuntimeError" in text:
        print(f"warning: error marker found in {p}")

    m = re.search(
        r"FINAL_BEST epoch=(\d+), accuracy=([0-9.]+), rmse=([0-9.]+), auc=([0-9.]+), precision=([0-9.]+), recall=([0-9.]+), f1=([0-9.]+)",
        text
    )

    if not m:
        print(f"no FINAL_BEST for seed{seed}: {p}")
        continue

    best_epoch, acc, rmse, auc, precision, recall, f1 = m.groups()

    rows.append({
        "seed": seed,
        "best_epoch": int(best_epoch),
        "AUC": float(auc),
        "ACC": float(acc),
        "F1": float(f1),
        "RMSE": float(rmse),
        "Precision": float(precision),
        "Recall": float(recall),
    })

with out_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=["seed", "best_epoch", "AUC", "ACC", "F1", "RMSE", "Precision", "Recall"]
    )
    writer.writeheader()
    writer.writerows(rows)

lines = []
lines.append("seed,best_epoch,AUC,ACC,F1,RMSE,Precision,Recall")

for r in rows:
    lines.append(
        f"{r['seed']},{r['best_epoch']},"
        f"{r['AUC']:.6f},{r['ACC']:.6f},{r['F1']:.6f},"
        f"{r['RMSE']:.6f},{r['Precision']:.6f},{r['Recall']:.6f}"
    )

if len(rows) >= 2:
    lines.append("")
    lines.append("mean±std")
    for k in ["AUC", "ACC", "F1", "RMSE", "Precision", "Recall"]:
        vals = [r[k] for r in rows]
        lines.append(f"{k}: {st.mean(vals):.6f} ± {st.stdev(vals):.6f}")

out_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("\n".join(lines))
print(f"\nsaved csv: {out_csv}")
print(f"saved summary: {out_txt}")
