import csv
from pathlib import Path

rows = []

def add(model, dataset, source, auc=None, acc=None, f1=None, rmse=None, doa=None, best_epoch=None, note=""):
    rows.append({
        "model": model,
        "dataset": dataset,
        "source": source,
        "best_epoch": best_epoch if best_epoch is not None else "",
        "AUC": auc if auc is not None else "",
        "ACC": acc if acc is not None else "",
        "F1": f1 if f1 is not None else "",
        "RMSE": rmse if rmse is not None else "",
        "DOA": doa if doa is not None else "",
        "note": note
    })

add(
    model="ORCDF",
    dataset="assist_sample5000_item12000",
    source="repos/ORCDF/logs/orcdf_assist_sample_original_12ep.log",
    best_epoch=2,
    auc=0.7538,
    acc=0.7432,
    f1=0.8331,
    rmse=0.4174,
    doa=0.6920,
    note="12 epoch run; best AUC at epoch 2; later epochs decrease"
)

add(
    model="HyperCDM",
    dataset="assistments_time_sample5000_item12000",
    source="repos/HyperCDM/logs/hypercdm_assist_sample5000_original_rerun.log",
    best_epoch="rerun_current",
    auc=0.746149,
    acc=0.742392,
    f1=0.833148,
    rmse="",
    doa=0.646806,
    note="rerun result; previous run had AUC around 0.7488; need multi-seed average"
)

out = Path("/home/wangxiao/QCCDM/top_sci_repro/results/baseline_summary/current_baseline_seed0.csv")
out.parent.mkdir(parents=True, exist_ok=True)

fieldnames = ["model", "dataset", "source", "best_epoch", "AUC", "ACC", "F1", "RMSE", "DOA", "note"]

with out.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("model,dataset,best_epoch,AUC,ACC,F1,RMSE,DOA")
for r in rows:
    print(f"{r['model']},{r['dataset']},{r['best_epoch']},{r['AUC']},{r['ACC']},{r['F1']},{r['RMSE']},{r['DOA']}")

print(f"\nSaved to {out}")
