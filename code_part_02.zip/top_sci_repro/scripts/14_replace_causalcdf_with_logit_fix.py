import csv
from pathlib import Path

csv_path = Path("results/baseline_summary/current_baseline_seed0.csv")

with csv_path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    rows = list(reader)

rows = [
    r for r in rows
    if r.get("model") not in {
        "CausalCDF-NCDM-fixed",
        "CausalCDF-NCDM-logit-fix"
    }
]

rows.append({
    "model": "CausalCDF-NCDM-logit-fix",
    "dataset": "ASSIST09_official_converted",
    "source": "repos/CausalCDF/logs/baseline/causalcdf_logit_fix_5seed/seed0.log",
    "best_epoch": "10",
    "AUC": "0.723440",
    "ACC": "0.702426",
    "F1": "0.792463",
    "RMSE": "0.440536",
    "DOA": "",
    "note": "logit residual fixed reproduction; 5seed AUC=0.723577±0.000192; multiplicative version was dominated by item-ease prior"
})

with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

for r in rows:
    print(r["model"], r["dataset"], r["AUC"], r["ACC"], r["F1"], r["RMSE"])
