import csv
from pathlib import Path
from collections import defaultdict

src = Path("results/baseline_summary/current_baseline_seed0.csv")
out_md = Path("results/baseline_summary/main_table_grouped.md")
out_csv = Path("results/baseline_summary/main_table_grouped.csv")

rows = list(csv.DictReader(src.open("r", encoding="utf-8")))

# 补充当前已完成的 5-seed 结果，注意 seed0 表仍保留 seed0 数值，note 里保留均值方差
five_seed_map = {
    "CausalCDF-NCDM-logit-fix": {
        "AUC_5seed": "0.723577 ± 0.000192",
        "ACC_5seed": "0.701923 ± 0.000699",
        "F1_5seed": "0.791195 ± 0.002378",
        "RMSE_5seed": "0.440475 ± 0.000146",
    },
    "DisenGCD-fixed": {
        "AUC_5seed": "0.774802 ± 0.000840",
        "ACC_5seed": "0.734627 ± 0.001334",
        "F1_5seed": "0.810845 ± 0.001206",
        "RMSE_5seed": "0.420054 ± 0.000559",
    },
    "ORCDF": {
        "AUC_5seed": "0.753480 ± 0.001486",
        "ACC_5seed": "0.745100 ± 0.003323",
        "F1_5seed": "0.832700 ± 0.004815",
        "RMSE_5seed": "0.416900 ± 0.001311",
    },
}

fieldnames = [
    "dataset", "model", "best_epoch",
    "AUC_seed0", "ACC_seed0", "F1_seed0", "RMSE_seed0", "DOA",
    "AUC_5seed", "ACC_5seed", "F1_5seed", "RMSE_5seed",
    "source", "note"
]

clean = []
for r in rows:
    m = r["model"]
    fs = five_seed_map.get(m, {})
    clean.append({
        "dataset": r.get("dataset", ""),
        "model": m,
        "best_epoch": r.get("best_epoch", ""),
        "AUC_seed0": r.get("AUC", ""),
        "ACC_seed0": r.get("ACC", ""),
        "F1_seed0": r.get("F1", ""),
        "RMSE_seed0": r.get("RMSE", ""),
        "DOA": r.get("DOA", ""),
        "AUC_5seed": fs.get("AUC_5seed", ""),
        "ACC_5seed": fs.get("ACC_5seed", ""),
        "F1_5seed": fs.get("F1_5seed", ""),
        "RMSE_5seed": fs.get("RMSE_5seed", ""),
        "source": r.get("source", ""),
        "note": r.get("note", ""),
    })

with out_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(clean)

groups = defaultdict(list)
for r in clean:
    groups[r["dataset"]].append(r)

with out_md.open("w", encoding="utf-8") as f:
    f.write("# Grouped Baseline Main Table\n\n")
    f.write("Important: datasets/splits are grouped separately. Do not directly compare rows from different splits.\n\n")

    for dataset in sorted(groups):
        f.write(f"## {dataset}\n\n")
        f.write("| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |\n")
        f.write("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|\n")
        for r in groups[dataset]:
            f.write(
                f"| {r['model']} | {r['best_epoch']} | {r['AUC_seed0']} | {r['ACC_seed0']} | "
                f"{r['F1_seed0']} | {r['RMSE_seed0']} | {r['DOA']} | "
                f"{r['AUC_5seed']} | {r['ACC_5seed']} | {r['F1_5seed']} | {r['RMSE_5seed']} | "
                f"{r['note']} |\n"
            )
        f.write("\n")

print("saved:", out_csv)
print("saved:", out_md)
print(out_md.read_text(encoding="utf-8"))
