import re
from pathlib import Path
import statistics as st
import csv

log_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/CausalCDF/logs/baseline/causalcdf_fixed_5seed")
out_csv = Path("results/baseline_summary/causalcdf_fixed_5seed.csv")
out_txt = Path("results/baseline_summary/causalcdf_fixed_5seed_summary.txt")
out_csv.parent.mkdir(parents=True, exist_ok=True)

rows = []

for seed in range(5):
    p = log_dir / f"seed{seed}.log"
    if not p.exists():
        print(f"missing seed{seed}: {p}")
        continue

    text = p.read_text(encoding="utf-8", errors="ignore")

    m = re.search(
        r"FINAL_TEST accuracy=([0-9.]+), precision=([0-9.]+), rmse=([0-9.]+), recall=([0-9.]+), auc=([0-9.]+), f1=([0-9.]+)",
        text
    )

    if not m:
        print(f"no FINAL_TEST for seed{seed}: {p}")
        continue

    acc, precision, rmse, recall, auc, f1 = map(float, m.groups())
    rows.append({
        "seed": seed,
        "AUC": auc,
        "ACC": acc,
        "F1": f1,
        "RMSE": rmse,
        "Precision": precision,
        "Recall": recall,
    })

with out_csv.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=["seed", "AUC", "ACC", "F1", "RMSE", "Precision", "Recall"])
    writer.writeheader()
    writer.writerows(rows)

lines = []
lines.append("seed,AUC,ACC,F1,RMSE,Precision,Recall")
for r in rows:
    lines.append(f"{r['seed']},{r['AUC']:.6f},{r['ACC']:.6f},{r['F1']:.6f},{r['RMSE']:.6f},{r['Precision']:.6f},{r['Recall']:.6f}")

if len(rows) >= 2:
    lines.append("")
    lines.append("mean±std")
    for k in ["AUC", "ACC", "F1", "RMSE", "Precision", "Recall"]:
        vals = [r[k] for r in rows]
        lines.append(f"{k}: {st.mean(vals):.6f} ± {st.stdev(vals):.6f}")

out_txt.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("\n".join(lines))
print(f"\nsaved csv: {out_csv}")
print(f"saved summary: {out_txt}")
