import csv
from pathlib import Path

csv_path = Path("results/baseline_summary/current_baseline_seed0.csv")

with csv_path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    rows = list(reader)

for r in rows:
    if r.get("model") == "ORCDF":
        r["source"] = "repos/ORCDF/logs/baseline/orcdf_assist_sample_5seed_fixed/seed0.log"
        r["best_epoch"] = "2"
        r["AUC"] = "0.753800"
        r["ACC"] = "0.743200"
        r["F1"] = "0.833100"
        r["RMSE"] = "0.417400"
        r["DOA"] = "0.692000"
        r["note"] = (
            "sample split; 5seed AUC=0.753480±0.001486, "
            "ACC=0.745100±0.003323, F1=0.832700±0.004815, "
            "RMSE=0.416900±0.001311, DOA=0.688480±0.013667; "
            "best epoch selected by AUC within 3 epochs"
        )

with csv_path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print("Updated ORCDF in current_baseline_seed0.csv")
for r in rows:
    print(r["model"], r["dataset"], r["AUC"], r["ACC"], r["F1"], r["RMSE"], r["DOA"])
