import csv
from pathlib import Path

path = Path("results/baseline_summary/current_baseline_seed0.csv")
rows = []
seen = set()

with path.open("r", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    fieldnames = reader.fieldnames
    for row in reader:
        key = tuple(row.get(k, "") for k in fieldnames)
        if key not in seen:
            seen.add(key)
            rows.append(row)

with path.open("w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(rows)

print(f"dedup done: {len(rows)} rows kept")
for r in rows:
    print(r["model"], r["dataset"], r["AUC"])
