"""Run the complete synthetic bridge on GPU before any real-data training."""
import sys
import tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"));sys.path.insert(0,str(ROOT/"contract_tests"))
import torch
from test_pipeline import exercise_full_run
if __name__=="__main__":
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable: no automatic CPU fallback")
    with tempfile.TemporaryDirectory(prefix="session_hybrid_gpu_") as tmp:
        exercise_full_run(Path(tmp),"cuda")
    print("Synthetic CUDA session hybrid pipeline: PASS",flush=True)
