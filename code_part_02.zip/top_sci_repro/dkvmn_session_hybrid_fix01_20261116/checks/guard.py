"""Protect previous source code, frozen tests and both previous result ZIPs."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    entries=json.loads((ROOT/"contracts"/"protected_hashes.json").read_text(encoding="utf-8"))
    for name,digest in entries.items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file():
            raise ValueError(f"missing or unsafe protected file: {name}")
        h=hashlib.sha256(p.read_bytes()).hexdigest()
        if h!=digest:
            raise ValueError(f"protected file changed: {name}")
    print(f"Protected files verified: {len(entries)}")
    return 0
if __name__=="__main__": raise SystemExit(main())
