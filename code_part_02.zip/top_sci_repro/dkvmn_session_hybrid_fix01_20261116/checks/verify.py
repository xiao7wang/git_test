"""Return a numeric failure count; --strict makes failures block the server."""
import argparse
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "contract_tests"))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "contract_tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    failed = len(result.failures) + len(result.errors) + len(result.unexpectedSuccesses)
    print(failed, flush=True)
    return 1 if args.strict and failed else 0

if __name__ == "__main__":
    sys.exit(main())
