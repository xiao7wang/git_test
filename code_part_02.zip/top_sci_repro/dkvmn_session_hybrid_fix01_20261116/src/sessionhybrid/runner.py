"""Train session-history DKVMN hybrids against pinned existing hybrid predictions."""
import json
import shutil
import time
from pathlib import Path
import numpy as np
from count_time.common import write_json
from count_time.features import check_legacy_counts
from fixed_controls.references import validate_features
from overnight.package import package_results
from session_control.features import build
from .analysis import analyze
from .train import dense_history,fit_hybrid


def validate_session_events(f,reference):
    dev=np.flatnonzero(f["split"]==1)
    mapping={"record_idx":"record_idx","student_idx":"student","label":"label","kc_idx":"kc",
             "prior_kc_count":"prior_kc_count","starts_session":"starts_session",
             "same_kc_session_crossings":"session_crossings"}
    for name,key in mapping.items():
        if not np.array_equal(np.asarray(reference[name]),f[key][dev]):
            raise ValueError(f"session reference event identity differs: {name}")
    for name,key in (("same_kc_gap_hours","gap_hours"),
                     ("previous_global_event_gap_hours","global_gap_hours")):
        if not np.allclose(np.asarray(reference[name]),f[key][dev],atol=1e-10,rtol=0,equal_nan=True):
            raise ValueError(f"session reference interval differs: {name}")
    return {"match":True,"events":len(dev),"students":int(len(np.unique(f["student"][dev])))}


def _free(path,required):
    free=shutil.disk_usage(path).free
    print(json.dumps({"phase":"free_space_check","free_bytes":free,"required":required}),flush=True)
    if free<required: raise OSError(f"insufficient free disk: {free} < {required}")


def run_in_memory(data,users,output,old,session_ref,*,device="cpu",epochs=20,patience=5,batch_size=8,
                  chunk_size=50,repetitions=2000,expected_population=None,min_free=0,run_metadata=None):
    out=Path(output).resolve()
    if out.exists(): raise FileExistsError(f"output already exists: {out}")
    if not users or min(epochs,patience,batch_size,chunk_size,repetitions)<1:
        raise ValueError("invalid users or execution settings")
    out.mkdir(parents=True,exist_ok=False)
    status_path=out/"status.json";started=time.monotonic()
    status={"status":"running","phase":"feature_construction","active_job":None,"epoch":None,
            "completed_seeds":[],"test_evaluated":False,"holdout_evaluated":False}
    write_json(status_path,status)
    try:
        _free(out,min_free)
        f=build(data.arrays,users,threshold_hours=10.,retention=.5)
        legacy=check_legacy_counts(f)
        if not legacy["match"]: raise ValueError("undiscounted histories failed independent audit")
        old_identity=validate_features(f,old["events"])
        session_identity=validate_session_events(f,session_ref["events"])
        dev=np.flatnonzero(f["split"]==1);eligible=dev[f["prior_kc_count"][dev]>=2]
        population={"train":int(np.sum(f["split"]==0)),"development":len(dev),
                    "development_students":int(len(np.unique(f["student"][dev]))),"eligible":len(eligible),
                    "eligible_students":int(len(np.unique(f["student"][eligible])))}
        if expected_population is not None and population!=expected_population:
            raise ValueError(f"population differs: {population}")
        f["states"]["session_05"]=f["session_states"]
        session_history=dense_history(f,"session_05",len(data.arrays["student_idx"]))
        ids=old["events"]["record_idx"]
        (out/"events.csv.gz").write_bytes(old["events_bytes"])
        (out/"session_events.csv.gz").write_bytes(session_ref["events_bytes"])
        np.savez_compressed(out/"reference_predictions.npz",record_idx=ids,
            **{f"{m}_seed{s}":old["predictions"][m][s] for m in ("fixed_08","time_168h") for s in (1,2)})
        write_json(out/"old_provenance.json",{"archive_sha256":old.get("archive_sha256"),
            "session_result_sha256":session_ref.get("sha256"),"jobs":old["jobs"],"histories":old["histories"]})
        config={"protocol":"dkvmn_session_boundary_05_exploratory_v1","population":population,
                "threshold_hours":10.,"retention_per_boundary":.5,"seeds":[1,2],
                "model":"same bias DKVMN + two same-KC log-count coefficients; history rule changes",
                "baseline_modes":["time_168h","fixed_08"],"selection":"development event NLL separately per job",
                "max_epochs":epochs,"patience":patience,"batch_size":batch_size,"chunk_size":chunk_size,
                "optimizer":"Adam lr=.001, no weight decay, clip=5","old_event_identity":old_identity,
                "session_event_identity":session_identity,"undiscounted_check":legacy,
                "primary":"session_05 minus time_168h on all development event NLL, mean seeds 1 and 2",
                "feedback":"predict before row-immediate feedback; platform timing not independently verified",
                "time":"event timestamp proxy; session boundary is not a confirmed feedback boundary",
                "selection_note":"0.5 chosen after earlier development results; repeated development use is exploratory",
                "test_label_note":"arrays loaded include test labels; selected feature construction and scoring exclude test",
                "bootstrap_repetitions":repetitions,"bootstrap_seed":20261116,
                "test_evaluated":False,"holdout_evaluated":False,"metadata":run_metadata or {}}
        write_json(out/"config.json",config)
        common=["status.json","config.json","events.csv.gz","session_events.csv.gz","reference_predictions.npz","old_provenance.json"]
        new_predictions={};pairing={}
        for seed in (1,2):
            _free(out,min_free)
            status.update(phase="training_start",active_job=f"session_05_seed{seed}",epoch=0)
            write_json(status_path,status)
            name=f"session_05_seed{seed}";base=f"time_168h_seed{seed}"
            result=fit_hybrid(data,users,ids,session_history,"session_05",seed,out/"jobs"/name,status,status_path,
                device=device,epochs=epochs,patience=patience,batch_size=batch_size,chunk_size=chunk_size,
                expected_initial_hash=old["jobs"][base]["initial_state_sha256"],expected_history=old["histories"][base])
            oldhist,newhist=old["histories"][base],result["history"]
            common_epochs=min(len(oldhist),len(newhist))
            if not common_epochs or any(oldhist[i]["train_order_sha256"]!=newhist[i]["train_order_sha256"]
                                        for i in range(common_epochs)):
                raise ValueError(f"training order differs for seed {seed}")
            pairing[str(seed)]={"initial_state_matches":True,"matching_common_epochs":common_epochs,
                                "previous_epochs":len(oldhist),"new_epochs":len(newhist)}
            new_predictions[seed]=result["probability"]
            status["completed_seeds"].append(seed);status.update(phase="seed_complete",active_job=None,epoch=None)
            write_json(status_path,status);write_json(out/"pairing.json",pairing)
            if seed==1:
                names=common+["pairing.json"]+[f"jobs/{name}/{x}" for x in ("summary.json","history.json","dev_predictions.csv.gz")]
                partial=package_results(out,"partial_session_seed1.zip",names)
                print(json.dumps({"phase":"seed1_complete","partial_archive":partial},ensure_ascii=False),flush=True)
        predictions={"session_05":new_predictions,"time_168h":old["predictions"]["time_168h"],
                     "fixed_08":old["predictions"]["fixed_08"]}
        status.update(phase="analysis",active_job=None,epoch=None);write_json(status_path,status)
        analysis=analyze(old["events"],session_ref["events"],predictions,repetitions=repetitions)
        write_json(out/"analysis.json",analysis);write_json(out/"pairing.json",pairing)
        status.update(phase="packaging_final",active_job=None,epoch=None);write_json(status_path,status)
        files=common+["analysis.json","pairing.json"]+[f"jobs/session_05_seed{s}/{x}" for s in (1,2)
                   for x in ("summary.json","history.json","dev_predictions.csv.gz")]
        _free(out,min_free)
        archive=package_results(out,"dkvmn_session_results.zip",files)
        status.update(status="complete",phase="complete",result_archive=archive,seconds=time.monotonic()-started)
        write_json(status_path,status)
        print(json.dumps({"phase":"complete","archive":archive},ensure_ascii=False),flush=True)
        return {"status":"complete","archive":archive}
    except BaseException as exc:
        status.update(status="failed",error=repr(exc),seconds=time.monotonic()-started)
        write_json(status_path,status)
        raise
