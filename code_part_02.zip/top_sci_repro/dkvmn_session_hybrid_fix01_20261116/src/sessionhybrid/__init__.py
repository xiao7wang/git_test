"""Exploratory DKVMN session-boundary controls."""
