"""Pinned production entry point: development-only, matched previous controls."""
import argparse
import json
import os
import platform
import shutil
from pathlib import Path
import numpy as np
import torch
from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from lagprobe.references import load_legacy
from lagprobe.server import verify_previous_config
from .references import load_session_reference
from .runner import run_in_memory

ROOT=Path(__file__).resolve().parents[2]
OLD_SHA="115a3ddf9cda66d88a8e1aa66e1c41793d3ffa0bbc0349d7c3bb6198ae75745c"
SESSION_SHA="c49634100ce00363c6792a37a6e910d609cc9dc1399a124eb54290c430e9736a"
POPULATION={"train":1847688,"development":126854,"development_students":10036,
            "eligible":101427,"eligible_students":9116}


def verify_release():
    path=ROOT/"release_manifest.json";manifest=json.loads(path.read_text(encoding="utf-8"))
    entries=manifest.get("files")
    required={"run_server.sh","README.md","contracts/protocol.json","contracts/protected_hashes.json",
              "checks/verify.py","checks/guard.py","checks/gpu_preflight.py","contract_tests/test_pipeline.py",
              "src/sessionhybrid/server.py","src/sessionhybrid/runner.py","src/sessionhybrid/references.py",
              "src/sessionhybrid/train.py","src/sessionhybrid/analysis.py","src/session_control/features.py",
              "src/overnight/train.py","src/overnight/model.py","vendor/pykt_LICENSE.txt",
              "references/overnight_results.zip","references/calibrated_session_results.zip"}
    if not isinstance(entries,dict) or not required.issubset(entries):
        raise ValueError("release manifest is incomplete")
    for name,digest in entries.items():
        candidate=(ROOT/name).resolve()
        if not candidate.is_relative_to(ROOT) or not candidate.is_file() or sha256_file(candidate)!=digest:
            raise ValueError(f"release file missing, unsafe or modified: {name}")
    protected=json.loads((ROOT/"contracts/protected_hashes.json").read_text(encoding="utf-8"))
    if any(entries.get(k)!=v for k,v in protected.items()):
        raise ValueError("protected previous source or contract differs")
    previous=(ROOT/"src/overnight/train.py").read_text(encoding="utf-8")
    derived=previous.replace("from .model import CountHybrid","from overnight.model import CountHybrid")
    derived=derived.replace('if mode not in ("fixed_08", "time_168h") or seed not in (1, 2):',
                            'if mode not in ("fixed_08", "time_168h", "session_05") or seed not in (1, 2):')
    if derived!=(ROOT/"src/sessionhybrid/train.py").read_text(encoding="utf-8"):
        raise ValueError("session trainer differs beyond its two declared changes")
    if entries["references/overnight_results.zip"]!=OLD_SHA or entries["references/calibrated_session_results.zip"]!=SESSION_SHA:
        raise ValueError("pinned reference archive differs")
    return {"manifest_sha256":sha256_file(path),"file_count":len(entries)}


def protocol():
    p=json.loads((ROOT/"contracts/protocol.json").read_text(encoding="utf-8"))
    if (p.get("protocol")!="dkvmn_session_boundary_05_exploratory_v1" or
        p.get("dataset_manifest_sha256")!=DATA_FINGERPRINT or p.get("previous_hybrid_result_sha256")!=OLD_SHA or
        p.get("previous_session_result_sha256")!=SESSION_SHA or p.get("session_threshold_hours")!=10. or
        p.get("retention_per_boundary")!=.5 or p.get("seeds")!=[1,2] or p.get("max_epochs")!=20 or
        p.get("patience")!=5 or p.get("batch_size")!=8 or p.get("chunk_size")!=50 or
        p.get("bootstrap_repetitions")!=2000 or p.get("bootstrap_seed")!=20261116 or
        p.get("minimum_free_bytes")!=1073741824 or p.get("population")!=POPULATION or
        p.get("primary")!="session_05 minus time_168h event NLL on all development, mean seeds 1 and 2" or
        p.get("test_evaluated") is not False or p.get("holdout_evaluated") is not False):
        raise ValueError("frozen protocol differs from implementation")
    return p


def main(argv=None):
    parser=argparse.ArgumentParser();parser.add_argument("--verify-only",action="store_true")
    for name in ("project-dir","data-dir","output-dir"): parser.add_argument("--"+name)
    parser.add_argument("--ack-row-feedback",action="store_true");parser.add_argument("--ack-time-proxy",action="store_true")
    args=parser.parse_args(argv)
    release,spec=verify_release(),protocol()
    print(json.dumps({"phase":"release_verified",**release}),flush=True)
    if args.verify_only: return 0
    if not all((args.project_dir,args.data_dir,args.output_dir)): parser.error("project, data, and output dirs are required")
    if not args.ack_row_feedback or not args.ack_time_proxy: parser.error("feedback and timestamp assumptions must be acknowledged")
    output,allowed=Path(args.output_dir).resolve(),(ROOT/"outputs").resolve()
    if not output.is_relative_to(allowed) or output==allowed or output.exists():
        raise ValueError("output must be a new child of this package's outputs directory")
    if not torch.cuda.is_available(): raise RuntimeError("CUDA unavailable; no automatic CPU fallback")
    free=shutil.disk_usage(allowed).free
    if free<spec["minimum_free_bytes"]: raise OSError(f"insufficient free disk space: {free}")
    old=load_legacy(ROOT/"references/overnight_results.zip",OLD_SHA)
    environment=verify_previous_config(old)
    session=load_session_reference(ROOT/"references/calibrated_session_results.zip",SESSION_SHA)
    print(json.dumps({"phase":"previous_references_verified","events":len(old["events"]["label"])}),flush=True)
    data=load_prepared(args.project_dir,args.data_dir)
    arrays=data.arrays
    users=development_users(arrays["student_idx"][arrays["split"]==1])
    metadata={"release":release,"environment":environment,"python":platform.python_version(),
              "gpu":torch.cuda.get_device_name(0),"cuda_visible_devices":os.environ.get("CUDA_VISIBLE_DEVICES"),
              "data_fingerprint":data.fingerprint,"project_source_sha256":SOURCE_HASHES,
              "previous_hybrid_sha256":OLD_SHA,"previous_session_sha256":SESSION_SHA,"free_bytes_at_start":free}
    result=run_in_memory(data,users,output,old,session,device="cuda",epochs=spec["max_epochs"],
        patience=spec["patience"],batch_size=spec["batch_size"],chunk_size=spec["chunk_size"],
        repetitions=spec["bootstrap_repetitions"],expected_population=spec["population"],
        min_free=spec["minimum_free_bytes"],run_metadata=metadata)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return 0


if __name__=="__main__": raise SystemExit(main())
