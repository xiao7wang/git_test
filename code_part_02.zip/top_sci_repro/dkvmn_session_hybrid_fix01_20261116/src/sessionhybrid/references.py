"""Read pinned session event metadata from the latest completed prior experiment."""
import json
import numpy as np
from fixed_controls.references import _verified_members, _csv, _integer_column


def load_session_reference(path,expected_sha):
    files=_verified_members(path,expected_sha)
    status=json.loads(files["status.json"]);config=json.loads(files["config.json"])
    if (status.get("status")!="complete" or status.get("test_evaluated") is not False or
        status.get("holdout_evaluated") is not False or
        config.get("protocol")!="training_mean_calibrated_session_control_v1_exploratory" or
        config.get("threshold_hours")!=10. or config.get("half_life_hours")!=168. or
        config.get("metadata",{}).get("dataset_manifest_sha256")!="18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e" or
        config.get("metadata",{}).get("release",{}).get("manifest_sha256")!="83690ac3da7fae6bf6079c29972814e50c0a486a5abcb9aa1ee83d18c3be59a0" or
        config.get("test_evaluated") is not False or config.get("holdout_evaluated") is not False):
        raise ValueError("session reference protocol, completion or source differs")
    rows=_csv(files["event_features.csv.gz"])
    if not rows:
        raise ValueError("session reference has no events")
    ints=("record_idx","student_idx","label","kc_idx","prior_kc_count","starts_session","same_kc_session_crossings")
    events={k:_integer_column(rows,k) for k in ints}
    for key in ("same_kc_gap_hours","previous_global_event_gap_hours"):
        events[key]=np.asarray([float(row[key]) if row[key] else np.nan for row in rows],dtype=np.float64)
    if ((np.diff(events["record_idx"])<=0).any() or not np.isin(events["label"],[0,1]).all() or
        not np.isin(events["starts_session"],[0,1]).all() or (events["same_kc_session_crossings"]<0).any()):
        raise ValueError("invalid previous session metadata")
    return {"events":events,"events_bytes":files["event_features.csv.gz"],"sha256":expected_sha}
