"""Student-cluster paired analyses for the new fixed-architecture controls."""
import numpy as np
from overnight.analysis import _group


def analyze(events,session_events,predictions,*,repetitions=2000,seed=20261116):
    y=np.asarray(events["label"]);prior=np.asarray(events["prior_kc_count"])
    crosses=np.asarray(session_events["same_kc_session_crossings"])
    if y.ndim!=1 or not len(y) or prior.shape!=y.shape or crosses.shape!=y.shape or repetitions<1:
        raise ValueError("analysis events do not align")
    required={"session_05","time_168h","fixed_08"}
    if set(predictions)!=required:
        raise ValueError("prediction conditions differ")
    for mode,by_seed in predictions.items():
        if set(by_seed)!={1,2}: raise ValueError(f"missing seeds for {mode}")
        for p in by_seed.values():
            p=np.asarray(p)
            if p.shape!=y.shape or not np.isfinite(p).all() or ((p<0)|(p>1)).any():
                raise ValueError(f"invalid predictions for {mode}")
    contrasts={"session_minus_time":("session_05","time_168h"),
               "session_minus_fixed":("session_05","fixed_08"),
               "time_minus_fixed":("time_168h","fixed_08")}
    groups={"prior_kc_at_least_2":prior>=2,"first_kc":prior==0,"repeat_kc":prior>0,
            "repeat_no_session_crossing":(prior>0)&(crosses==0),
            "repeat_one_or_more_session_crossings":(prior>0)&(crosses>0)}
    return {"overall":_group(events,predictions,contrasts,np.ones(len(y),bool),repetitions,seed),
            "groups":{name:_group(events,predictions,contrasts,mask,repetitions,seed+i+1)
                      for i,(name,mask) in enumerate(groups.items())},
            "primary":"session_minus_time on all development events; paired seed mean",
            "bootstrap":{"unit":"student","repetitions":repetitions,"seed":seed,
                "scope":"conditional on fitted selected models; training and selection uncertainty not included"},
            "scope":"same repeatedly used development set; exploratory; not an intervention on students"}
