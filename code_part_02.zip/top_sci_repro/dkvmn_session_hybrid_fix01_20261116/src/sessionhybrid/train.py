"""Streaming DKVMN training with exact development-event coverage."""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from count_time.common import metrics, model_digest, sha256_file, write_json
from dkvmn_ref.bias import BiasDKVMN
from dkvmn_ref.streaming import initial_memory
from dkvmn_ref.upstream import DKVMN
from overnight.model import CountHybrid


def batches(data, users, view, batch_size):
    a = data.arrays
    upper = 0 if view == "train" else 1
    for start in range(0, len(users), batch_size):
        selected = users[start:start + batch_size]
        sequences = []
        for user in selected:
            rows = np.arange(a["user_offsets"][user], a["user_offsets"][user + 1])
            sequences.append(rows[a["split"][rows] <= upper])
        if any(len(rows) for rows in sequences):
            yield selected, sequences


def dense_history(features, source, total_rows):
    ids = np.asarray(features["record_idx"])
    success, failure = features["states"][source]
    if len(ids) != len(success) or len(ids) != len(failure) or (ids < 0).any() or (ids >= total_rows).any():
        raise ValueError("invalid selected history array shape")
    if not np.isfinite(success).all() or not np.isfinite(failure).all() or (success < 0).any() or (failure < 0).any():
        raise ValueError("history counts must be finite and nonnegative")
    included = np.zeros(total_rows, dtype=bool)
    positive = np.zeros(total_rows, dtype=np.float32)
    negative = np.zeros(total_rows, dtype=np.float32)
    included[ids] = True
    positive[ids] = success
    negative[ids] = failure
    return {"success": positive, "failure": negative, "included": included}


def history_for(indices, histories, device):
    active = indices >= 0
    if not histories["included"][indices[active]].all():
        raise ValueError("a nonselected event entered the hybrid history lookup")
    safe = np.maximum(indices, 0)
    # Padded rows get zeros, independent of row zero and ignored by masks.
    success = np.where(active, histories["success"][safe], 0.)
    failure = np.where(active, histories["failure"][safe], 0.)
    return (torch.as_tensor(success, dtype=torch.float32, device=device),
            torch.as_tensor(failure, dtype=torch.float32, device=device))


def forward(model, batch, histories, indices, device):
    success, failure = history_for(indices, histories, device)
    return model.forward_chunk(batch["student_idx"], batch["item_idx"], batch["q"].argmax(-1),
                               batch["label"].long(), batch["active_mask"], batch["active_mask"],
                               batch["state"], success, failure)


def evaluate(model, data, users, history, device, chunk_size, batch_size, expected_ids):
    model.eval()
    pieces = []
    with torch.no_grad():
        for chosen, sequences in batches(data, users, "valid", batch_size):
            state = initial_memory(model.base, len(chosen))
            for batch, indices in data.chunks(chosen, sequences, "valid", chunk_size, device):
                batch["state"] = state
                probability, state = forward(model, batch, history, indices, device)
                mask = batch["target_mask"].cpu().numpy()
                if mask.any():
                    pieces.append((indices[mask], probability.detach().cpu().numpy()[mask]))
    if not pieces:
        raise ValueError("no development events")
    ids = np.concatenate([p[0] for p in pieces])
    probability = np.concatenate([p[1] for p in pieces]).astype(np.float64)
    order = np.argsort(ids, kind="stable")
    ids, probability = ids[order], probability[order]
    if not np.array_equal(ids, expected_ids) or not np.isfinite(probability).all() or ((probability < 0) | (probability > 1)).any():
        raise ValueError("hybrid development coverage, order or probabilities differ")
    labels = data.arrays["label"][ids]
    students = data.arrays["student_idx"][ids]
    return probability, metrics(labels, probability, students)


def _bridge(model, data, users, history, device, chunk_size, batch_size):
    model.eval()
    for chosen, sequences in batches(data, users, "train", batch_size):
        for batch, indices in data.chunks(chosen, sequences, "train", chunk_size, device):
            state = initial_memory(model.base, len(chosen))
            success, failure = history_for(indices, history, device)
            with torch.no_grad():
                old, old_state = BiasDKVMN.forward_chunk(model, batch["student_idx"], batch["item_idx"],
                    batch["q"].argmax(-1), batch["label"].long(), batch["active_mask"], batch["active_mask"], state.clone())
                new, new_state = model.forward_chunk(batch["student_idx"], batch["item_idx"],
                    batch["q"].argmax(-1), batch["label"].long(), batch["active_mask"], batch["active_mask"],
                    state.clone(), success, failure)
            delta = max(float(torch.max(torch.abs(old - new))), float(torch.max(torch.abs(old_state - new_state))))
            if delta > 1e-6:
                raise ValueError(f"zero-weight bridge to prior bias DKVMN failed: {delta}")
            return delta
    raise ValueError("no train batch for DKVMN bridge")


def _save(path, value):
    pending = path.with_suffix(path.suffix + ".pending")
    torch.save(value, pending)
    pending.replace(path)


def _write_predictions(path, ids, data, probability):
    with gzip.open(path, "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("record_idx", "student_idx", "label", "probability"))
        for idx, value in zip(ids, probability):
            writer.writerow((int(idx), int(data.arrays["student_idx"][idx]), int(data.arrays["label"][idx]),
                             format(float(value), ".9g")))


def fit_hybrid(data, development_users, expected_ids, history, mode, seed, output, status,
               root_status_path, *, device="cpu", epochs=20, patience=5, batch_size=8, chunk_size=50,
               expected_initial_hash=None, expected_history=None):
    if mode not in ("fixed_08", "time_168h", "session_05") or seed not in (1, 2):
        raise ValueError("invalid hybrid mode/seed")
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    torch.set_num_threads(4)
    torch.manual_seed(seed)
    if device == "cuda":
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    dims = data.manifest["summary"]
    base = DKVMN(num_c=int(dims["knowledges"]), dim_s=32, size_m=20, dropout=.2).to(device)
    model = CountHybrid(base, int(dims["students"]), int(dims["items"])).to(device)
    initial_hash = model_digest(model.state_dict())
    if expected_initial_hash is not None and initial_hash != expected_initial_hash:
        raise ValueError("paired hybrid initialization differs before training")
    train_users = np.unique(data.arrays["student_idx"][data.arrays["split"] == 0]).astype(np.int64)
    dev_users = np.asarray(sorted(development_users), dtype=np.int64)
    train_expected = int(np.sum(data.arrays["split"] == 0))
    bridge = _bridge(model, data, train_users, history, device, chunk_size, batch_size)
    optimizer = torch.optim.Adam(model.parameters(), lr=.001)
    best_nll, best_epoch, stale = float("inf"), None, 0
    history_rows = []
    for epoch in range(1, epochs + 1):
        status.update(phase="hybrid_training", active_job=f"{mode}_seed{seed}", epoch=epoch)
        write_json(root_status_path, status)
        tick = time.monotonic()
        order = np.random.default_rng(seed * 10000 + epoch - 1).permutation(train_users)
        order_hash = hashlib.sha256(order.astype("<i8", copy=False).tobytes()).hexdigest()
        if expected_history is not None and epoch <= len(expected_history) and order_hash != expected_history[epoch - 1]["train_order_sha256"]:
            raise ValueError(f"paired hybrid training order differs before epoch {epoch}")
        model.train()
        total, train_n, steps = 0., 0, 0
        n_batches = (len(order) + batch_size - 1) // batch_size
        for batch_number, (chosen, sequences) in enumerate(batches(data, order, "train", batch_size), 1):
            state = initial_memory(base, len(chosen))
            for batch, indices in data.chunks(chosen, sequences, "train", chunk_size, device):
                optimizer.zero_grad(set_to_none=True)
                batch["state"] = state
                probability, state = forward(model, batch, history, indices, device)
                mask = batch["target_mask"]
                n = int(mask.sum().item())
                if n:
                    loss = F.binary_cross_entropy(probability[mask].clamp(1e-6, 1 - 1e-6), batch["label"][mask])
                    if not bool(torch.isfinite(loss)):
                        raise FloatingPointError("nonfinite hybrid training loss")
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 5., error_if_nonfinite=True)
                    optimizer.step()
                    total += float(loss.detach()) * n
                    train_n += n
                    steps += 1
                state = state.detach()
            if batch_number % 40 == 0:
                print(json.dumps({"phase": "hybrid_training", "mode": mode, "seed": seed, "epoch": epoch,
                                  "batch": batch_number, "total_batches": n_batches, "train_events": train_n,
                                  "elapsed_seconds": round(time.monotonic() - tick, 1)}), flush=True)
        if train_n != train_expected:
            raise ValueError(f"hybrid training coverage mismatch: {train_n} != {train_expected}")
        train_seconds = time.monotonic() - tick
        status["phase"] = "hybrid_development"
        write_json(root_status_path, status)
        evaluation_start = time.monotonic()
        probability, observed = evaluate(model, data, dev_users, history, device, chunk_size, batch_size, expected_ids)
        eval_seconds = time.monotonic() - evaluation_start
        improved = observed["nll"] < best_nll
        if improved:
            best_nll, best_epoch, stale = observed["nll"], epoch, 0
            _save(output / "best_model.pt", {"model_state": model.state_dict(), "epoch": epoch,
                                             "mode": mode, "seed": seed, "dev_nll": best_nll})
        else:
            stale += 1
        row = {"epoch": epoch, "train_events": train_n, "optimizer_steps": steps,
               "train_bce": total / train_n, "train_seconds": train_seconds, "dev": observed,
               "dev_seconds": eval_seconds, "train_order_sha256": order_hash,
               "improved": improved, "best_epoch": best_epoch, "stale": stale}
        history_rows.append(row)
        write_json(output / "history.json", history_rows)
        _save(output / "last_epoch.pt", {"model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                                         "epoch": epoch, "seed": seed, "mode": mode, "best_epoch": best_epoch,
                                         "best_nll": best_nll, "stale": stale, "torch_rng": torch.get_rng_state(),
                                         "cuda_rng": torch.cuda.get_rng_state_all() if device == "cuda" else None})
        print(json.dumps({"phase": "hybrid_epoch_complete", "mode": mode, "seed": seed, **row}), flush=True)
        if stale >= patience:
            break
    # Test the last trained model under two chunk widths on the same sampled students.
    sample = dev_users[:min(32, len(dev_users))]
    sample_ids = expected_ids[np.isin(data.arrays["student_idx"][expected_ids], sample)]
    p_a, _ = evaluate(model, data, sample, history, device, chunk_size, batch_size, sample_ids)
    p_b, _ = evaluate(model, data, sample, history, device, 17, batch_size, sample_ids)
    chunk_difference = float(np.max(np.abs(p_a - p_b), initial=0.))
    if chunk_difference > 1e-6:
        raise ValueError(f"hybrid chunk replay mismatch: {chunk_difference}")
    checkpoint = torch.load(output / "best_model.pt", map_location=device, weights_only=True)
    model.load_state_dict(checkpoint["model_state"], strict=True)
    probability, final = evaluate(model, data, dev_users, history, device, chunk_size, batch_size, expected_ids)
    if abs(final["nll"] - best_nll) > 1e-7:
        raise ValueError("selected hybrid checkpoint does not reproduce its development NLL")
    _write_predictions(output / "dev_predictions.csv.gz", expected_ids, data, probability)
    summary = {"status": "complete", "mode": mode, "seed": seed, "epochs": len(history_rows),
               "best_epoch": best_epoch, "dev": final, "initial_state_sha256": initial_hash,
               "best_checkpoint_sha256": sha256_file(output / "best_model.pt"),
               "best_model_state_sha256": model_digest(model.state_dict()),
               "zero_history_bridge_max_abs": bridge, "chunk_width_check_max_abs": chunk_difference,
               "stop_reason": "early_stopping" if stale >= patience else "epoch_limit",
               "test_evaluated": False, "holdout_evaluated": False,
               "seconds": time.monotonic() - started}
    write_json(output / "summary.json", summary)
    return {"summary": summary, "history": history_rows, "probability": probability}
