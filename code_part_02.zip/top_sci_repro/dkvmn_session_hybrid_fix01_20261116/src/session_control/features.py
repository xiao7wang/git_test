"""Build past-only global session boundaries and per-KC discounted counts."""
import math
import numpy as np

from count_time.features import construct


def build(arrays, development_users, threshold_hours=10.0, retention=0.5):
    if not math.isfinite(threshold_hours) or threshold_hours <= 0:
        raise ValueError("threshold must be positive and finite")
    if not math.isfinite(retention) or not 0 < retention <= 1:
        raise ValueError("retention must be in (0,1]")
    f = construct(arrays, development_users, fixed_discount=.8, half_life_hours=168.)
    u, kc, y, time, idx = (f[k] for k in ("student", "kc", "label", "timestamp", "record_idx"))
    n = len(u)
    user_first = np.r_[True, u[1:] != u[:-1]]
    adjacent = np.full(n, np.nan, dtype=np.float64)
    adjacent[1:] = (time[1:] - time[:-1]) / 3600.
    adjacent[user_first] = np.nan
    if (adjacent[~user_first] < 0).any():
        raise ValueError("student time decreases")
    starts_session = (~user_first) & (adjacent > threshold_hours)
    # A global cumulative counter is safe: differences are taken within the same student.
    session_index = np.cumsum(starts_session, dtype=np.int64)
    success, failure = np.empty(n), np.empty(n)
    crossings = np.zeros(n, dtype=np.int64)
    order = np.lexsort((idx, kc, u))
    last_key = None
    previous_session = 0
    a = b = 0.
    for i in order:
        key = (int(u[i]), int(kc[i]))
        if key != last_key:
            last_key, previous_session = key, int(session_index[i])
            a = b = 0.
        count = int(session_index[i]) - previous_session
        if count < 0:
            raise AssertionError("same-KC sessions out of order")
        crossings[i] = count
        discount = retention ** count
        a *= discount
        b *= discount
        success[i], failure[i] = a, b
        a += int(y[i])
        b += 1 - int(y[i])
        previous_session = int(session_index[i])
    f["session_states"] = (success, failure)
    f["session_crossings"] = crossings
    f["global_gap_hours"] = adjacent
    f["starts_session"] = starts_session
    return f
