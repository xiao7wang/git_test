"""Exploratory session boundary and elapsed-time controls."""
