"""Development-only replay and matched retraining with incremental snapshots."""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

import numpy as np
import torch

from count_time.common import model_digest, sha256_file, write_json
from count_time.features import check_legacy_counts, construct
from fixed_controls.references import validate_features
from dkvmn_ref.upstream import DKVMN
from overnight.model import CountHybrid
from overnight.package import package_results
from overnight.train import dense_history, evaluate, _write_predictions
from .analysis import analyze
from .features import gap_diagnostics, lag_states
from .train import fit_hybrid


def _check_free(path, min_free):
    free = shutil.disk_usage(path).free
    print(json.dumps({"phase": "free_space_check", "free_bytes": free, "minimum_free_bytes": min_free}), flush=True)
    if free < min_free:
        raise OSError(f"insufficient disk space: {free} bytes; require at least {min_free}")
    return free


def _load_checkpoint(data, checkpoint_path, summary, seed, device):
    checkpoint_path = Path(checkpoint_path)
    if sha256_file(checkpoint_path) != summary["best_checkpoint_sha256"]:
        raise ValueError(f"previous checkpoint file SHA-256 mismatch for seed {seed}")
    loaded = torch.load(checkpoint_path, map_location=device, weights_only=True)
    if (loaded.get("mode") != "time_168h" or loaded.get("seed") != seed or
            loaded.get("epoch") != summary["best_epoch"] or
            abs(float(loaded["dev_nll"]) - float(summary["dev"]["nll"])) > 1e-7):
        raise ValueError(f"previous checkpoint metadata differs for seed {seed}")
    dims = data.manifest["summary"]
    model = CountHybrid(DKVMN(num_c=int(dims["knowledges"]), dim_s=32, size_m=20, dropout=.2),
                        int(dims["students"]), int(dims["items"])).to(device)
    model.load_state_dict(loaded["model_state"], strict=True)
    if model_digest(model.state_dict()) != summary["best_model_state_sha256"]:
        raise ValueError(f"previous checkpoint model-state digest differs for seed {seed}")
    return model


def run_in_memory(data, development_users, output_dir, old, *, device="cpu", epochs=20,
                  patience=5, batch_size=8, chunk_size=50, repetitions=2000,
                  expected_population=None, run_metadata=None, min_free=0):
    output = Path(output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if not development_users or min(epochs, patience, batch_size, chunk_size, repetitions) < 1:
        raise ValueError("empty users or invalid execution size")
    output.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    status_path = output / "status.json"
    status = {"status": "running", "phase": "feature_construction", "active_job": None, "epoch": None,
              "replay_completed_seeds": [], "retraining_completed_seeds": [],
              "test_evaluated": False, "holdout_evaluated": False}
    write_json(status_path, status)
    try:
        _check_free(output, min_free)
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        features = construct(data.arrays, development_users, fixed_discount=.8, half_life_hours=168.)
        legacy_check = check_legacy_counts(features)
        if not legacy_check["match"]:
            raise ValueError("independent undiscounted-count audit failed")
        identity = validate_features(features, old["events"])
        lag = lag_states(features)
        nprev = features["prior_kc_count"]
        warm = nprev <= 1
        for name, expected in zip(("success", "failure"), features["states"]["C_real_time"]):
            if not np.allclose(lag[name][warm], expected[warm], atol=1e-12, rtol=0):
                raise ValueError(f"warm-up history mismatch: {name}")
        dev = np.flatnonzero(features["split"] == 1)
        eligible = dev[nprev[dev] >= 2]
        observed_population = {"train": int(np.sum(features["split"] == 0)), "development": len(dev),
                               "development_students": int(len(np.unique(features["student"][dev]))),
                               "eligible": len(eligible),
                               "eligible_students": int(len(np.unique(features["student"][eligible])))}
        if expected_population is not None and observed_population != expected_population:
            raise ValueError(f"source population differs: {observed_population} != {expected_population}")
        events = old["events"]
        ids = events["record_idx"]
        users = np.asarray(sorted(development_users), dtype=np.int64)
        histories = {"true": dense_history(features, "C_real_time", len(data.arrays["student_idx"]))}
        modified = dict(features)
        modified["states"] = dict(features["states"])
        modified["states"]["lag_168h"] = (lag["success"], lag["failure"])
        histories["lag"] = dense_history(modified, "lag_168h", len(data.arrays["student_idx"]))
        (output / "events.csv.gz").write_bytes(old["events_bytes"])
        np.savez_compressed(output / "reference_predictions.npz", record_idx=ids,
                            **{f"{mode}_seed{seed}": old["predictions"][mode][seed]
                               for mode in ("fixed_08", "time_168h") for seed in (1, 2)})
        write_json(output / "gap_diagnostics.json", gap_diagnostics(features, lag))
        write_json(output / "old_provenance.json", {"jobs": old["jobs"], "histories": old["histories"],
                                                     "archive_sha256": old.get("archive_sha256"),
                                                     "checkpoint_files": {str(s): str(old["checkpoints"][s]) for s in (1, 2)}})
        config = {"protocol": "lagged_same_kc_interval_v1_exploratory", "half_life_hours": 168.,
                  "population": observed_population, "identity": identity, "undiscounted_audit": legacy_check,
                  "seeds": [1, 2], "epochs_max": epochs, "patience": patience, "batch_size": batch_size,
                  "chunk_size": chunk_size, "bootstrap_repetitions": repetitions, "bootstrap_seed": 20261116,
                  "feedback": "predict before row-immediate feedback; platform timing unverified",
                  "time": "event-time proxy; not evidence of causal forgetting",
                  "warmup": "first repeat uses real gap in both conditions; later use previous same-KC gap",
                  "scope": "reused development; exploratory; model selection uncertainty excluded",
                  "test_label_note": "data loader reads arrays including test labels; selected features and scoring exclude test rows",
                  "metadata": run_metadata or {}, "test_evaluated": False, "holdout_evaluated": False}
        write_json(output / "config.json", config)
        replay = {"true": {}, "lag": {}}
        bridge = {}
        for seed in (1, 2):
            status.update(phase="frozen_model_replay", active_job=f"seed{seed}", epoch=None)
            write_json(status_path, status)
            print(json.dumps({"phase": "frozen_model_replay_start", "seed": seed}), flush=True)
            summary = old["jobs"][f"time_168h_seed{seed}"]
            model = _load_checkpoint(data, old["checkpoints"][seed], summary, seed, device)
            true_p, true_metrics = evaluate(model, data, users, histories["true"], device, chunk_size, batch_size, ids)
            expected_p = np.asarray(old["predictions"]["time_168h"][seed], dtype=np.float64)
            if true_p.shape != expected_p.shape:
                raise ValueError(f"replay length differs for seed {seed}")
            p_diff = float(np.max(np.abs(true_p - expected_p), initial=0.))
            nll_diff = abs(float(true_metrics["nll"]) - float(summary["dev"]["nll"]))
            if p_diff > 1e-5 or nll_diff > 1e-6:
                raise ValueError(f"old-model replay failed for seed {seed}: probability={p_diff}, nll={nll_diff}")
            lag_p, _ = evaluate(model, data, users, histories["lag"], device, chunk_size, batch_size, ids)
            warm_dev = np.asarray(events["prior_kc_count"]) <= 1
            warm_difference = float(np.max(np.abs(true_p[warm_dev] - lag_p[warm_dev]), initial=0.))
            if warm_difference > 1e-6:
                raise ValueError(f"warm-up model predictions differ for seed {seed}: {warm_difference}")
            replay["true"][seed], replay["lag"][seed] = true_p, lag_p
            for condition, values in (("true", true_p), ("lag", lag_p)):
                _write_predictions(output / f"replay_{condition}_seed{seed}.csv.gz", ids, data, values)
            bridge[str(seed)] = {"checkpoint_sha256": summary["best_checkpoint_sha256"],
                                 "max_probability_abs_difference": p_diff, "nll_abs_difference": nll_diff,
                                 "warmup_max_abs_difference": warm_difference}
            status["replay_completed_seeds"].append(seed)
            write_json(status_path, status)
            del model
        write_json(output / "replay_bridge.json", bridge)
        replay_analysis = analyze(events, replay, {"true_minus_lag": ("true", "lag")}, repetitions=repetitions)
        write_json(output / "analysis_replay.json", replay_analysis)
        common = ["status.json", "config.json", "events.csv.gz", "reference_predictions.npz", "gap_diagnostics.json",
                  "old_provenance.json", "replay_bridge.json", "analysis_replay.json"]
        common += [f"replay_{condition}_seed{seed}.csv.gz" for condition in ("true", "lag") for seed in (1, 2)]
        status.update(phase="replay_completed", active_job=None, epoch=None)
        write_json(status_path, status)
        _check_free(output, min_free)
        partial = package_results(output, "partial_replay.zip", common)
        print(json.dumps({"phase": "replay_complete", "partial_archive": partial}, ensure_ascii=False), flush=True)
        lag_predictions, pairing = {}, {}
        for seed in (1, 2):
            _check_free(output, min_free)
            status.update(phase="lag_retraining_start", active_job=f"lag_168h_seed{seed}", epoch=0)
            write_json(status_path, status)
            name = f"lag_168h_seed{seed}"
            reference = f"time_168h_seed{seed}"
            job = fit_hybrid(data, development_users, ids, histories["lag"], "lag_168h", seed,
                             output / "jobs" / name, status, status_path, device=device, epochs=epochs,
                             patience=patience, batch_size=batch_size, chunk_size=chunk_size,
                             expected_initial_hash=old["jobs"][reference]["initial_state_sha256"],
                             expected_history=old["histories"][reference])
            common_epochs = min(len(old["histories"][reference]), len(job["history"]))
            if not common_epochs or any(old["histories"][reference][i]["train_order_sha256"] != job["history"][i]["train_order_sha256"]
                                        for i in range(common_epochs)):
                raise ValueError(f"training order differs from previous model for seed {seed}")
            pairing[str(seed)] = {"initial_state_matches": True, "matching_common_epochs": common_epochs,
                                  "previous_epochs": len(old["histories"][reference]), "lag_epochs": len(job["history"])}
            lag_predictions[seed] = job["probability"]
            status["retraining_completed_seeds"].append(seed)
            status.update(phase="lag_retraining_completed", active_job=None, epoch=None)
            write_json(status_path, status)
            write_json(output / "pairing.json", pairing)
            if seed == 1:
                files = common + ["pairing.json"] + [f"jobs/{name}/{f}" for f in
                                                       ("summary.json", "history.json", "dev_predictions.csv.gz")]
                snapshot = package_results(output, "partial_lag_168h_seed1.zip", files)
                print(json.dumps({"phase": "lag_seed_complete", "seed": seed, "partial_archive": snapshot}), flush=True)
        predictions = {"true_retrained": old["predictions"]["time_168h"],
                       "fixed_retrained": old["predictions"]["fixed_08"], "lag_retrained": lag_predictions}
        contrasts = {"true_minus_lag": ("true_retrained", "lag_retrained"),
                     "fixed_minus_lag": ("fixed_retrained", "lag_retrained"),
                     "true_minus_fixed": ("true_retrained", "fixed_retrained")}
        result = analyze(events, predictions, contrasts, repetitions=repetitions, seed=20261116)
        write_json(output / "analysis_retrained.json", result)
        write_json(output / "pairing.json", pairing)
        status.update(phase="packaging_final", active_job=None, epoch=None)
        write_json(status_path, status)
        files = common + ["analysis_retrained.json", "pairing.json"]
        files += [f"jobs/lag_168h_seed{seed}/{f}" for seed in (1, 2) for f in
                  ("summary.json", "history.json", "dev_predictions.csv.gz")]
        _check_free(output, min_free)
        archive = package_results(output, "lag_gap_results.zip", files)
        status.update(status="complete", phase="complete", seconds=time.monotonic()-started,
                      result_archive=archive)
        write_json(status_path, status)
        print(json.dumps({"phase": "complete", "archive": archive}, ensure_ascii=False), flush=True)
        return {"status": "complete", "archive": archive}
    except BaseException as exc:
        status.update(status="failed", error=repr(exc), seconds=time.monotonic()-started)
        write_json(status_path, status)
        raise
