"""Causal previous-gap count states on already selected chronological rows."""
from __future__ import annotations

import math
import numpy as np


def lag_states(features, half_life_hours=168.0):
    half_life_hours = float(half_life_hours)
    if not math.isfinite(half_life_hours) or half_life_hours <= 0:
        raise ValueError("invalid half-life")
    keys = ("record_idx", "student", "kc", "label", "prior_kc_count", "gap_hours")
    if any(k not in features for k in keys):
        raise ValueError("missing history arrays")
    record, users, kc, labels, prior, gap = (np.asarray(features[k]) for k in keys)
    n = len(record)
    if not n or any(a.ndim != 1 or len(a) != n for a in (record, users, kc, labels, prior, gap)):
        raise ValueError("history array dimensions differ")
    if len(np.unique(record)) != n or (np.diff(record) <= 0).any():
        raise ValueError("record indices must be strictly increasing")
    if (users < 0).any() or (kc < 0).any() or (prior < 0).any() or not np.isin(labels, [0, 1]).all():
        raise ValueError("invalid history identity, count or label")
    if not np.array_equal(np.isnan(gap), prior == 0):
        raise ValueError("first encounter and missing gap differ")
    if not np.isfinite(gap[prior > 0]).all() or (gap[prior > 0] < 0).any():
        raise ValueError("repeated gap must be finite and nonnegative")
    order = np.lexsort((record, kc, users))
    positive = np.empty(n, dtype=np.float64)
    negative = np.empty(n, dtype=np.float64)
    used = np.full(n, np.nan, dtype=np.float64)
    last_user = last_kc = -1
    pos = neg = 0.0
    seen = 0
    previous_gap = None
    for ix in order:
        user, concept = int(users[ix]), int(kc[ix])
        if (user, concept) != (last_user, last_kc):
            last_user, last_kc = user, concept
            pos = neg = 0.0
            seen = 0
            previous_gap = None
        if int(prior[ix]) != seen:
            raise ValueError("same-KC history count differs from selected record order")
        if seen:
            actual_gap = float(gap[ix])
            selected_gap = actual_gap if seen == 1 else previous_gap
            if selected_gap is None or not math.isfinite(selected_gap) or selected_gap < 0:
                raise ValueError("previous gap unavailable or invalid")
            used[ix] = selected_gap
            factor = math.exp(-math.log(2.0) * selected_gap / half_life_hours)
            pos *= factor
            neg *= factor
        positive[ix], negative[ix] = pos, neg
        # Current answer and actual current gap become history only after the row's features.
        pos += int(labels[ix])
        neg += 1 - int(labels[ix])
        if seen:
            previous_gap = actual_gap
        seen += 1
    return {"success": positive, "failure": negative, "gap_hours": used}


def gap_diagnostics(features, lag):
    result = {}
    for name, split in (("train", 0), ("development", 1)):
        mask = (features["split"] == split) & (features["prior_kc_count"] >= 2)
        real = np.asarray(features["gap_hours"])[mask].astype(np.float64)
        old = np.asarray(lag["gap_hours"])[mask].astype(np.float64)
        if not len(real):
            result[name] = {"n": 0}
            continue
        if not np.isfinite(real).all() or not np.isfinite(old).all():
            raise ValueError("nonfinite eligible gap")
        lr, lo = np.log1p(real), np.log1p(old)
        correlation = None
        if len(real) > 1 and np.std(lr) > 0 and np.std(lo) > 0:
            correlation = float(np.corrcoef(lr, lo)[0, 1])
        def describe(values):
            return {"quantiles_hours_10_50_90": np.quantile(values, [.1, .5, .9]).tolist(),
                    "zero_fraction": float(np.mean(values == 0)),
                    "over_168h_fraction": float(np.mean(values > 168))}
        result[name] = {"n": len(real), "students": int(len(np.unique(features["student"][mask]))),
                        "actual": describe(real), "lagged": describe(old),
                        "log1p_hours_wasserstein_1": float(np.mean(np.abs(np.sort(lr) - np.sort(lo)))),
                        "log1p_hours_pearson_r": correlation}
    return result
