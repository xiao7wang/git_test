"""Lagged-gap exploration, to be implemented against the frozen contracts."""
