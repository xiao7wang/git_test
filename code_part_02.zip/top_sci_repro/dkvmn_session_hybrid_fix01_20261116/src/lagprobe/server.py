"""Fail-closed production entry point; only reused development is scored."""
from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from .references import load_legacy
from .runner import run_in_memory

ROOT = Path(__file__).resolve().parents[2]
OLD_ARCHIVE_SHA = "115a3ddf9cda66d88a8e1aa66e1c41793d3ffa0bbc0349d7c3bb6198ae75745c"
CHECKPOINTS = {1: "e1ca9aaaf7e9ee13919c35c16ebf37b5d4a899fa8b2c3c54b2040e5fedf41bc6",
               2: "69f091b28524b24da35f72519df23b4069c8ad12834f3b90bf7551877ac46c24"}
POPULATION = {"train": 1847688, "development": 126854, "development_students": 10036,
              "eligible": 101427, "eligible_students": 9116}


def verify_release():
    manifest_path = ROOT / "release_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files = manifest.get("files")
    required = {"run_server.sh", "README.md", "contracts/protocol.json", "contracts/vendor_hashes.json",
                "checks/verify.py", "checks/guard.py", "checks/gpu_preflight.py", "contract_tests/fixture.py",
                "src/lagprobe/server.py", "src/lagprobe/runner.py", "src/lagprobe/features.py",
                "src/lagprobe/analysis.py", "src/lagprobe/references.py", "src/lagprobe/train.py",
                "src/overnight/train.py", "src/overnight/model.py", "vendor/pykt_LICENSE.txt"}
    if not isinstance(files, dict) or not required.issubset(files):
        raise ValueError("release manifest missing required files")
    for name, expected in files.items():
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or sha256_file(path) != expected:
            raise ValueError(f"release file missing, unsafe or modified: {name}")
    vendor = json.loads((ROOT / "contracts/vendor_hashes.json").read_text(encoding="utf-8"))
    for name, digest in vendor.items():
        if files.get(name) != digest:
            raise ValueError(f"previous implementation hash differs: {name}")
    previous = (ROOT / "src/overnight/train.py").read_text(encoding="utf-8")
    derived = previous.replace("from .model import CountHybrid", "from overnight.model import CountHybrid")
    derived = derived.replace('if mode not in ("fixed_08", "time_168h") or seed not in (1, 2):',
                              'if mode not in ("fixed_08", "time_168h", "lag_168h") or seed not in (1, 2):')
    if derived != (ROOT / "src/lagprobe/train.py").read_text(encoding="utf-8"):
        raise ValueError("lag trainer differs from the original beyond the two declared changes")
    return {"manifest_sha256": sha256_file(manifest_path), "file_count": len(files)}


def protocol():
    spec = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    if (spec["protocol"] != "lagged_same_kc_interval_v1_exploratory" or
            spec["data_fingerprint"] != DATA_FINGERPRINT or spec["old_results_sha256"] != OLD_ARCHIVE_SHA or
            spec["old_checkpoints"] != {str(k): v for k, v in CHECKPOINTS.items()} or
            spec["same_kc_half_life_hours"] != 168. or spec["expected_population"] != POPULATION or
            spec["seeds"] != [1, 2] or spec["max_epochs"] != 20 or spec["patience"] != 5 or
            spec["batch_size"] != 8 or spec["chunk_size"] != 50 or
            spec["bootstrap_repetitions"] != 2000 or spec["bootstrap_seed"] != 20261116 or
            spec["replay_probability_absolute_tolerance"] != 1e-5 or
            spec["replay_nll_absolute_tolerance"] != 1e-6 or spec["minimum_free_bytes"] != 1073741824 or
            spec["test_evaluated"] is not False or spec["holdout_evaluated"] is not False):
        raise ValueError("frozen protocol and implementation differ")
    return spec


def verify_previous_config(old):
    cfg = old["config"]
    metadata = cfg.get("metadata", {})
    if (cfg.get("epochs_max") != 20 or cfg.get("patience") != 5 or cfg.get("batch_size") != 8 or
            cfg.get("chunk_size") != 50 or cfg.get("hybrid_optimizer") != "Adam lr=.001, no weight decay, clip=5" or
            cfg.get("selection") != "development event NLL separately per job" or
            cfg.get("hybrid_modes") != {"fixed_08": "same-KC fixed event retention 0.8",
                                       "time_168h": "same-KC elapsed time half-life 168h"} or
            cfg.get("train_events") != 1847688 or cfg.get("development_events") != 126854 or
            cfg.get("development_students") != 10036 or
            not cfg.get("feedback", "").startswith("predict before row-immediate feedback") or
            metadata.get("release", {}).get("manifest_sha256") != "1e9617d9f1ba81970eb2cf357d499bb23035e67022fc5eefec94e1e5bb0b5dc4" or
            metadata.get("project_source_sha256") != SOURCE_HASHES):
        raise ValueError("previous training configuration or source fingerprints differ")
    if (str(torch.__version__) != metadata.get("torch") or np.__version__ != metadata.get("numpy") or
            pd.__version__ != metadata.get("pandas")):
        raise RuntimeError("PyTorch, NumPy or pandas version differs from prior run; cannot claim matched replay")
    for seed in (1, 2):
        if old["jobs"][f"time_168h_seed{seed}"]["best_checkpoint_sha256"] != CHECKPOINTS[seed]:
            raise ValueError(f"previous result checkpoint digest differs for seed {seed}")
    return {"torch": str(torch.__version__), "numpy": np.__version__, "pandas": pd.__version__}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    for name in ("project-dir", "data-dir", "old-output-dir", "output-dir"):
        parser.add_argument("--" + name)
    parser.add_argument("--ack-row-feedback", action="store_true")
    parser.add_argument("--ack-time-proxy", action="store_true")
    args = parser.parse_args(argv)
    release, spec = verify_release(), protocol()
    print(json.dumps({"phase": "release_verified", **release}), flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir, args.data_dir, args.old_output_dir, args.output_dir)):
        parser.error("all data, old output and new output directories are required")
    if not args.ack_row_feedback or not args.ack_time_proxy:
        parser.error("row feedback and event-time proxy assumptions must be acknowledged")
    output = Path(args.output_dir).resolve()
    allowed = (ROOT / "outputs").resolve()
    if not output.is_relative_to(allowed) or output == allowed or output.exists():
        raise ValueError("output must be a new subdirectory of this release's outputs directory")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; no automatic CPU fallback")
    free = shutil.disk_usage(allowed).free
    if free < spec["minimum_free_bytes"]:
        raise OSError(f"insufficient disk space: {free} bytes; require at least {spec['minimum_free_bytes']}")
    previous = Path(args.old_output_dir).resolve()
    old = load_legacy(previous / "overnight_results.zip", OLD_ARCHIVE_SHA)
    environment = verify_previous_config(old)
    old["checkpoints"] = {seed: previous / "jobs" / f"time_168h_seed{seed}" / "best_model.pt" for seed in (1, 2)}
    for seed, checkpoint in old["checkpoints"].items():
        if not checkpoint.is_file() or sha256_file(checkpoint) != CHECKPOINTS[seed]:
            raise ValueError(f"previous checkpoint missing or hash mismatch for seed {seed}: {checkpoint}")
    print(json.dumps({"phase": "previous_results_and_checkpoints_verified", "events": len(old["events"]["label"])}), flush=True)
    data = load_prepared(args.project_dir, args.data_dir)
    split, users = data.arrays["split"], data.arrays["student_idx"]
    selected = development_users(users[split == 1])
    metadata = {"release": release, "previous_archive_sha256": OLD_ARCHIVE_SHA, "environment": environment,
                "python": platform.python_version(), "gpu": torch.cuda.get_device_name(0),
                "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"), "data_fingerprint": data.fingerprint,
                "project_dir": str(Path(args.project_dir).resolve()), "data_dir": str(Path(args.data_dir).resolve()),
                "free_bytes_at_start": free}
    result = run_in_memory(data, selected, output, old, device="cuda", epochs=spec["max_epochs"],
                           patience=spec["patience"], batch_size=spec["batch_size"], chunk_size=spec["chunk_size"],
                           repetitions=spec["bootstrap_repetitions"], expected_population=spec["expected_population"],
                           run_metadata=metadata, min_free=spec["minimum_free_bytes"])
    print(json.dumps({"status": result["status"], "archive": result["archive"]}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
