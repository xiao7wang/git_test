"""Paired per-event loss contrasts with fixed-model student-cluster intervals."""
from __future__ import annotations

import numpy as np
from overnight.analysis import _group


def analyze(events, predictions, contrasts, *, repetitions=2000, seed=20261116):
    if repetitions < 1 or not contrasts or not predictions:
        raise ValueError("invalid contrasts or bootstrap repetitions")
    y = np.asarray(events["label"])
    prior = np.asarray(events["prior_kc_count"])
    gap = np.asarray(events["same_kc_gap_hours"])
    if y.ndim != 1 or not len(y) or prior.shape != y.shape or gap.shape != y.shape:
        raise ValueError("analysis arrays do not align")
    for name, by_seed in predictions.items():
        if set(by_seed) != {1, 2}:
            raise ValueError(f"exactly two seeds are required: {name}")
        for values in by_seed.values():
            p = np.asarray(values)
            if p.shape != y.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f"invalid probabilities: {name}")
    if any(a not in predictions or b not in predictions for a, b in contrasts.values()):
        raise ValueError("unknown contrast condition")
    eligible = prior >= 2
    if not np.any(eligible):
        raise ValueError("no rows have a previous same-KC gap")
    groups = {"zero_gap": eligible & (gap == 0),
              "gap_0_to_24h": eligible & (gap > 0) & (gap <= 24),
              "gap_24_to_168h": eligible & (gap > 24) & (gap <= 168),
              "gap_over_168h": eligible & (gap > 168),
              "warmup_prior_0_or_1": prior <= 1}
    return {"primary": _group(events, predictions, contrasts, eligible, repetitions, seed),
            "overall": _group(events, predictions, contrasts, np.ones(len(y), dtype=bool), repetitions, seed + 1),
            "groups": {name: _group(events, predictions, contrasts, mask, repetitions, seed + i + 2)
                       for i, (name, mask) in enumerate(groups.items())},
            "primary_outcome": "event-weighted mean of seed-paired NLL differences on prior_same_kc_count >= 2",
            "bootstrap": {"repetitions": repetitions, "seed": seed, "unit": "student",
                          "scope": "conditional on already selected fitted models; excludes training and selection uncertainty"},
            "scope": "reused development data; exploratory and not a causal forgetting estimate"}
