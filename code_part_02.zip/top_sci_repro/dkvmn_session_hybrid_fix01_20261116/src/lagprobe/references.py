"""Read and validate the pinned previous development-only experiment archive."""
from __future__ import annotations

import json
import numpy as np

from count_time.common import binary_losses
from fixed_controls.references import (_verified_members, _csv, _identity, _integer_column,
                                       _check_identity, _check_probabilities, DATA_FINGERPRINT)


def load_legacy(path, expected_hash):
    members = _verified_members(path, expected_hash)
    status = json.loads(members["status.json"])
    config = json.loads(members["config.json"])
    if (status.get("status") != "complete" or status.get("test_evaluated") is not False or
            status.get("holdout_evaluated") is not False or
            config.get("test_evaluated") is not False or config.get("holdout_evaluated") is not False or
            config.get("protocol") != "dkvmn_count_time_overnight_exploratory_v1" or
            config.get("hybrid_seeds") != [1, 2] or
            config.get("metadata", {}).get("data_fingerprint") != DATA_FINGERPRINT):
        raise ValueError("previous result protocol, completion or data identity differs")
    rows = _csv(members["events.csv.gz"])
    if not rows:
        raise ValueError("previous development event list is empty")
    events = _identity(rows)
    for key in ("kc_idx", "prior_kc_count", "prior_student_count_selected_history"):
        events[key] = _integer_column(rows, key)
    events["same_kc_gap_hours"] = np.asarray([
        float(row["same_kc_gap_hours"]) if row["same_kc_gap_hours"] else np.nan for row in rows], dtype=np.float64)
    previous, gap = events["prior_kc_count"], events["same_kc_gap_hours"]
    if (np.diff(events["record_idx"]) <= 0).any() or not np.isin(events["label"], [0, 1]).all():
        raise ValueError("previous event identity is invalid")
    if (previous < 0).any() or not np.array_equal(np.isnan(gap), previous == 0):
        raise ValueError("previous gap identity invalid")
    if not np.isfinite(gap[previous > 0]).all() or (gap[previous > 0] < 0).any():
        raise ValueError("previous repeated gaps invalid")
    predictions = {"fixed_08": {}, "time_168h": {}}
    jobs, histories = {}, {}
    for mode in predictions:
        for seed in (1, 2):
            name = f"{mode}_seed{seed}"
            prefix = f"jobs/{name}/"
            summary, history = (json.loads(members[prefix + fn]) for fn in ("summary.json", "history.json"))
            if (summary.get("status") != "complete" or summary.get("mode") != mode or
                    summary.get("seed") != seed or not history or
                    summary.get("test_evaluated") is not False or summary.get("holdout_evaluated") is not False):
                raise ValueError(f"previous job is inconsistent: {name}")
            pred_rows = _csv(members[prefix + "dev_predictions.csv.gz"])
            _check_identity(_identity(pred_rows), events)
            values = _check_probabilities(np.asarray([float(r["probability"]) for r in pred_rows], dtype=np.float32), len(rows))
            nll = float(binary_losses(events["label"], values)[0].mean())
            if abs(nll - float(summary["dev"]["nll"])) > 1e-6:
                raise ValueError(f"previous prediction NLL disagrees with summary: {name}")
            predictions[mode][seed], jobs[name], histories[name] = values, summary, history
    for seed in (1, 2):
        a, b = f"fixed_08_seed{seed}", f"time_168h_seed{seed}"
        if jobs[a]["initial_state_sha256"] != jobs[b]["initial_state_sha256"]:
            raise ValueError(f"previous paired initial model differs for seed {seed}")
        common = min(len(histories[a]), len(histories[b]))
        if not common or any(histories[a][i]["train_order_sha256"] != histories[b][i]["train_order_sha256"]
                             for i in range(common)):
            raise ValueError(f"previous paired training order differs for seed {seed}")
    return {"events": events, "events_bytes": members["events.csv.gz"], "predictions": predictions,
            "jobs": jobs, "histories": histories, "config": config, "archive_sha256": expected_hash}
