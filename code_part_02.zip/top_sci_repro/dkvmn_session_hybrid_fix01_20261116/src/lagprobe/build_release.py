"""Build a small, immutable release; previous data and weights remain on server."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def build(destination):
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".zip" or destination.exists():
        raise FileExistsError(f"release destination must be a new ZIP: {destination}")
    files = {}
    roots = ("src/count_time", "src/fixed_controls", "src/dkvmn_ref", "src/overnight", "src/lagprobe",
             "contract_tests", "checks", "contracts", "vendor")
    paths = [ROOT / "README.md", ROOT / "run_server.sh"]
    for name in roots:
        paths.extend(p for p in (ROOT / name).rglob("*") if p.is_file() and "__pycache__" not in p.parts
                     and p.suffix != ".pyc")
    for path in paths:
        name = path.relative_to(ROOT).as_posix()
        if name in files:
            raise ValueError(f"duplicate release member: {name}")
        payload = path.read_bytes()
        if name.endswith(".sh") and b"\r" in payload:
            raise ValueError(f"shell scripts require LF line endings: {name}")
        files[name] = payload
    vendor = json.loads(files["contracts/vendor_hashes.json"])
    for name, expected in vendor.items():
        if name not in files or hashlib.sha256(files[name]).hexdigest() != expected:
            raise ValueError(f"vendor file changed: {name}")
    manifest = {"format": 1, "files": {name: hashlib.sha256(value).hexdigest() for name, value in sorted(files.items())}}
    files["release_manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    pending = destination.with_suffix(destination.suffix + ".pending")
    if pending.exists():
        raise FileExistsError(f"preserving existing pending release: {pending}")
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in sorted(files.items()):
            bundle.writestr(name, data)
    with zipfile.ZipFile(pending) as bundle:
        if bundle.testzip() is not None or set(bundle.namelist()) != set(files):
            raise ValueError("release ZIP CRC or inventory failure")
        for name, data in files.items():
            if bundle.read(name) != data:
                raise ValueError(f"release member differs: {name}")
    pending.replace(destination)
    return {"path": str(destination), "bytes": destination.stat().st_size,
            "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "members": len(files)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output), ensure_ascii=False, indent=2))
