"""Pinned digest must agree with both protocol and the actual bundled archives."""
import json
import unittest
from pathlib import Path
from count_time.common import sha256_file
from sessionhybrid import server

ROOT=Path(__file__).resolve().parents[1]


class ReleaseContracts(unittest.TestCase):
    def test_reference_constants_protocol_and_actual_archives(self):
        spec=json.loads((ROOT/"contracts/protocol.json").read_text(encoding="utf-8"))
        for constant,key,name in ((server.OLD_SHA,"previous_hybrid_result_sha256","overnight_results.zip"),
                                  (server.SESSION_SHA,"previous_session_result_sha256","calibrated_session_results.zip")):
            self.assertEqual(len(constant),64)
            self.assertEqual(constant,spec[key])
            self.assertEqual(constant,sha256_file(ROOT/"references"/name))
        self.assertEqual(server.protocol()["protocol"],"dkvmn_session_boundary_05_exploratory_v1")
