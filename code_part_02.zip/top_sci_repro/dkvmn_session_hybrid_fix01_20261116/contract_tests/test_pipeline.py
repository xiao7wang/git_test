import copy
import csv
import gzip
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
import numpy as np
from fixture import make_fixture
from session_control.features import build
from sessionhybrid.runner import run_in_memory, validate_session_events


def session_fixture(data,users):
    f=build(data.arrays,users,threshold_hours=10.,retention=.5)
    dev=np.flatnonzero(f["split"]==1)
    cols={"record_idx":f["record_idx"][dev],"student_idx":f["student"][dev],"label":f["label"][dev].astype(int),
          "kc_idx":f["kc"][dev],"prior_kc_count":f["prior_kc_count"][dev],
          "same_kc_gap_hours":f["gap_hours"][dev],"previous_global_event_gap_hours":f["global_gap_hours"][dev],
          "starts_session":f["starts_session"][dev].astype(int),"same_kc_session_crossings":f["session_crossings"][dev]}
    stream=io.StringIO(newline="");w=csv.writer(stream);w.writerow(cols)
    for i in range(len(dev)):
        w.writerow(["" if isinstance(cols[k][i],(float,np.floating)) and np.isnan(cols[k][i]) else cols[k][i] for k in cols])
    return {"events":cols,"events_bytes":gzip.compress(stream.getvalue().encode()),"sha256":"synthetic"}


def exercise_full_run(root,device="cpu"):
    data,users,old=make_fixture(root,device)
    ref=session_fixture(data,users)
    out=root/"new_session"
    result=run_in_memory(data,users,out,old,ref,device=device,epochs=1,patience=1,
                         batch_size=3,chunk_size=5,repetitions=20,expected_population=None,min_free=0)
    assert result["status"]=="complete"
    status=json.loads((out/"status.json").read_text(encoding="utf-8"))
    assert status["status"]=="complete" and status["test_evaluated"] is False and status["holdout_evaluated"] is False
    assert (out/"partial_session_seed1.zip").is_file()
    with zipfile.ZipFile(out/"dkvmn_session_results.zip") as z:
        assert z.testzip() is None and "analysis.json" in z.namelist()
        assert not any(n.endswith(".pt") for n in z.namelist())
        result_json=json.loads(z.read("analysis.json"))
        assert result_json["overall"]["n"]==24
    for seed in (1,2):
        a=json.loads((out/"jobs"/f"session_05_seed{seed}"/"summary.json").read_text(encoding="utf-8"))
        assert a["mode"]=="session_05" and a["initial_state_sha256"]==old["jobs"][f"time_168h_seed{seed}"]["initial_state_sha256"]
    try:
        run_in_memory(data,users,out,old,ref,device=device,epochs=1,patience=1,batch_size=3,chunk_size=5,repetitions=20)
        raise AssertionError("existing result was overwritten")
    except FileExistsError:
        pass
    corrupted=copy.deepcopy(ref);corrupted["events"]["same_kc_session_crossings"]=ref["events"]["same_kc_session_crossings"].copy()
    corrupted["events"]["same_kc_session_crossings"][0]+=1
    bad=root/"wrong_session_identity"
    try:
        run_in_memory(data,users,bad,old,corrupted,device=device,epochs=1,patience=1,batch_size=3,chunk_size=5,repetitions=20)
        raise AssertionError("invalid session event identity passed")
    except ValueError:
        assert not (bad/"dkvmn_session_results.zip").exists()
        assert json.loads((bad/"status.json").read_text(encoding="utf-8"))["status"]=="failed"
    return out


class PipelineContracts(unittest.TestCase):
    def test_full_synthetic_pipeline(self):
        with tempfile.TemporaryDirectory(prefix="session_hybrid_cpu_") as temp:
            exercise_full_run(Path(temp),"cpu")

    def test_boundaries_and_no_current_label_or_test_row(self):
        arrays={"student_idx":np.array([0,0,0,0,0]),"item_idx":np.array([0,1,1,0,0]),
                "label":np.array([1,0,1,0,1]),"split":np.array([0,0,0,1,2]),
                "timestamp":np.array([0.,36000.,72001.,108002.,200000.]),"item_q":np.eye(2,dtype=int)}
        f=build(arrays,{0},threshold_hours=10.,retention=.5)
        self.assertFalse(f["starts_session"][1]);self.assertEqual(f["session_crossings"][3],2)
        self.assertAlmostEqual(f["session_states"][0][3],.25)
        self.assertFalse(np.any(arrays["split"][f["record_idx"]]==2))
        changed={k:v.copy() for k,v in arrays.items()};changed["label"][3]=1-changed["label"][3];changed["label"][4]=0
        g=build(changed,{0},threshold_hours=10.,retention=.5)
        np.testing.assert_allclose(f["session_states"][0][:4],g["session_states"][0][:4],atol=0,rtol=0)
        np.testing.assert_allclose(f["session_states"][1][:4],g["session_states"][1][:4],atol=0,rtol=0)
