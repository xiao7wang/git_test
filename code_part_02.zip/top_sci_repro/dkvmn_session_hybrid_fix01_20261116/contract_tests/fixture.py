"""Synthetic full run with real model training; no real dataset is touched."""
import copy
import csv
import gzip
import hashlib
import io
import json
import zipfile
from pathlib import Path

import numpy as np

from count_time.common import write_json
from count_time.features import construct
from overnight.train import dense_history, fit_hybrid
from overnight.package import package_results
from helpers import FakeData


def make_fixture(root, device):
    data, users = FakeData(), set(range(6))
    features = construct(data.arrays, users)
    dev = np.flatnonzero(features["split"] == 1)
    students = features["student"]
    starts = np.r_[True, students[1:] != students[:-1]]
    begin = np.maximum.accumulate(np.where(starts, np.arange(len(students)), 0))
    events = {"record_idx": features["record_idx"][dev], "student_idx": students[dev],
              "label": features["label"][dev].astype(np.int64), "kc_idx": features["kc"][dev],
              "prior_kc_count": features["prior_kc_count"][dev],
              "prior_student_count_selected_history": (np.arange(len(students)) - begin)[dev],
              "same_kc_gap_hours": features["gap_hours"][dev]}
    buf = io.StringIO(newline="")
    writer = csv.writer(buf)
    writer.writerow(events)
    for i in range(len(dev)):
        writer.writerow([events[key][i] for key in events])
    old = {"events": events, "events_bytes": gzip.compress(buf.getvalue().encode()),
           "predictions": {"fixed_08": {}, "time_168h": {}}, "jobs": {}, "histories": {},
           "checkpoints": {}}
    old_root = root / "previous"
    old_root.mkdir(parents=True)
    state_file = old_root / "status.json"
    write_json(state_file, {"status": "running"})
    for seed in (1, 2):
        for mode, source in (("fixed_08", "B_fixed"), ("time_168h", "C_real_time")):
            history = dense_history(features, source, len(data.arrays["student_idx"]))
            jobname = f"{mode}_seed{seed}"
            job = fit_hybrid(data, users, events["record_idx"], history, mode, seed,
                             old_root / "jobs" / jobname, {}, state_file, device=device, epochs=1,
                             patience=1, batch_size=3, chunk_size=5)
            old["jobs"][jobname] = job["summary"]
            old["histories"][jobname] = job["history"]
            old["predictions"][mode][seed] = job["probability"]
            if mode == "time_168h":
                old["checkpoints"][seed] = old_root / "jobs" / jobname / "best_model.pt"
    (old_root / "events.csv.gz").write_bytes(old["events_bytes"])
    write_json(state_file, {"status": "complete", "test_evaluated": False, "holdout_evaluated": False})
    config = {"protocol": "dkvmn_count_time_overnight_exploratory_v1", "hybrid_seeds": [1, 2],
              "test_evaluated": False, "holdout_evaluated": False,
              "metadata": {"data_fingerprint": "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e"}}
    write_json(old_root / "config.json", config)
    names = ["status.json", "config.json", "events.csv.gz"]
    names += [f"jobs/{mode}_seed{seed}/{name}" for seed in (1, 2) for mode in ("fixed_08", "time_168h")
              for name in ("summary.json", "history.json", "dev_predictions.csv.gz")]
    archive = package_results(old_root, "old_results.zip", names)
    from lagprobe.references import load_legacy
    decoded = load_legacy(Path(archive["path"]), archive["sha256"])
    decoded["checkpoints"] = old["checkpoints"]
    try:
        load_legacy(Path(archive["path"]), "0" * 64)
        raise AssertionError("wrong archive hash unexpectedly passed")
    except ValueError:
        pass
    old = decoded
    return data, users, old


def exercise_full_run(root, device="cpu"):
    from lagprobe.runner import run_in_memory
    data, users, old = make_fixture(root, device)
    out = root / "new_run"
    result = run_in_memory(data, users, out, old, device=device, epochs=1, patience=1,
                           batch_size=3, chunk_size=5, repetitions=20, expected_population=None)
    assert result["status"] == "complete"
    status = json.loads((out / "status.json").read_text(encoding="utf-8"))
    assert status["status"] == "complete" and not status["test_evaluated"] and not status["holdout_evaluated"]
    assert (out / "partial_replay.zip").is_file()
    assert (out / "partial_lag_168h_seed1.zip").is_file()
    for seed in (1, 2):
        job = json.loads((out / "jobs" / f"lag_168h_seed{seed}" / "summary.json").read_text(encoding="utf-8"))
        assert job["mode"] == "lag_168h"
        assert job["initial_state_sha256"] == old["jobs"][f"time_168h_seed{seed}"]["initial_state_sha256"]
    with zipfile.ZipFile(out / "partial_replay.zip") as z:
        assert z.testzip() is None and "analysis_replay.json" in z.namelist()
    try:
        run_in_memory(data, users, out, old, device=device, epochs=1, patience=1,
                      batch_size=3, chunk_size=5, repetitions=20, expected_population=None)
        raise AssertionError("existing run directory was overwritten")
    except FileExistsError:
        pass
    altered = copy.deepcopy(old)
    altered["predictions"]["time_168h"][1] = old["predictions"]["time_168h"][1].copy()
    altered["predictions"]["time_168h"][1][0] = 0.001
    bad_out = root / "wrong_reference"
    try:
        run_in_memory(data, users, bad_out, altered, device=device, epochs=1, patience=1,
                      batch_size=3, chunk_size=5, repetitions=20, expected_population=None)
        raise AssertionError("mismatched replay unexpectedly passed")
    except ValueError:
        assert not (bad_out / "partial_replay.zip").exists()
        assert json.loads((bad_out / "status.json").read_text(encoding="utf-8"))["status"] == "failed"
    return out
