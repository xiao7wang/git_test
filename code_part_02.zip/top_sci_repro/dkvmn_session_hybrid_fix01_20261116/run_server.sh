#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_name="${1:-server_session_hybrid_01}"
if [[ ! "$task_name" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid run name' >&2; exit 2; fi
task_base=/home/wangxiao/QCCDM/top_sci_repro
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_project="$task_base/uctp_cd_time_factorial_v1"
task_data="$task_base/uctp_cd_clean_research/data/assist_full"
task_out="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
mkdir -p "$task_root/outputs"
if [[ -e "$task_out" || -e "$task_log" ]]; then echo 'Output or launch log exists; refusing overwrite.' >&2; exit 2; fi
( set -o noclobber; : > "$task_log" ) || exit 2
exec > >(tee -a "$task_log") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$task_root/src${PYTHONPATH:+:$PYTHONPATH}"
cd "$task_root"
printf 'Starting %s at %s\n' "$task_name" "$(date --iso-8601=seconds)"
echo 'Stage 1/4: verify release, protected source and disk space'
"$task_python" -B -m sessionhybrid.server --verify-only
"$task_python" -B checks/guard.py
"$task_python" -B -c 'import shutil,sys; f=shutil.disk_usage(sys.argv[1]).free; print("Free bytes:",f,"Required:",1073741824,flush=True);sys.exit(f<1073741824)' "$task_root/outputs"
echo 'Stage 2/4: synthetic CPU contracts'
"$task_python" -B checks/verify.py --strict
echo 'Stage 3/4: synthetic GPU contract'
"$task_python" -B checks/gpu_preflight.py
echo 'Stage 4/4: matched two-seed DKVMN session training and development comparisons'
"$task_python" -B -m sessionhybrid.server --project-dir "$task_project" --data-dir "$task_data" --output-dir "$task_out" --ack-row-feedback --ack-time-proxy
printf 'SUCCESS: %s/dkvmn_session_results.zip\n' "$task_out"
