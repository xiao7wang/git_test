# DKVMN plus session-boundary counts: exploratory matched comparison

This experiment asks whether the fixed session-boundary count rule that performed well in the project's simple count model also performs well in the existing bias-DKVMN plus count-readout architecture. It is a paired retraining comparison on previously reused ASSIST development students, not a new independent validation or an LPKT implementation.

## Compared conditions

* `session_05`: train two new models, seeds 1 and 2; a global student session boundary occurs when adjacent event timestamps differ by more than 10 hours, and historical per-KC success/failure counts are multiplied by 0.5 per session boundary crossed.
* `time_168h`: reuse the two pinned earlier hybrid predictions whose same-KC count retention has a 168-hour half-life.
* `fixed_08`: reuse the two pinned earlier hybrid predictions with 0.8 retention per repeated same-KC event.

The models have the same network architecture, trainable parameters, sources and overall optimizer schedule. For each seed, the new model must reproduce the previous initial-state hash and the previous training-order hash in every common epoch. The `session_05` candidate was chosen after examining development results and its 0.5 is not a validated optimum. Global session boundaries are inferred from event timestamps; they are not verified platform sessions, question bundles or feedback times. The fixed 0.5 and 168-hour curves do not have matched retention distributions or cumulative strengths.

The primary outcome is the **session minus time event NLL** on all development events, averaged across the two paired seeds; lower is better. Report student-macro NLL, AUC, Brier, per-seed results, both prior baselines, and predefined first/repeat and session-crossing groups. Student-cluster bootstrap intervals condition on these fitted models and exclude training, model selection and repeated exploration uncertainty. Results compare model predictions, not causal effects of waiting on a student.

## Integrity and execution

`bash run_server.sh server_session_hybrid_01` validates the complete release, the previous project code and data fingerprint, and both old result archives. Previous development events, session fields, original hyperparameters, initial states and epoch ordering must align. The new training code is exactly the previously verified trainer plus the declared import and allowed-mode changes. CPU and CUDA synthetic contracts must pass before real-data training. A mismatch, missing file, insufficient disk (<1 GiB) or absent CUDA fails closed; there is no automatic deletion, retry, overwrite, package installation or CPU fallback.

The prepared-data loader reads stored arrays including test labels; the feature construction, training selection and scoring exclude test and holdout rows. The analysis assumes row-immediate feedback and uses event timestamps as a proxy. Prior results were selected on the same development data and are not independent. The code does not access the previous model checkpoints: it compares the verified saved development predictions, histories and summaries from the pinned old ZIP.

The result is `outputs/server_session_hybrid_01/dkvmn_session_results.zip`. After seed 1, `partial_session_seed1.zip` is created so that a complete seed can be reviewed if the second does not finish. Archives contain pseudonymous development event/student identifiers, labels and probabilities but not checkpoints; share within the research context. `status.json` inside an archive is the snapshot when packaging started, whereas the external status and SUCCESS line signal full completion.

On the same server, the previous `time_168h` hybrid jobs reported 8,946 and 9,810 seconds respectively (about 2.5–2.7 hours each, including their own final checks). The two new jobs are expected to take roughly 5–6 hours plus startup and packaging, potentially much longer with load or a different stopping epoch; this is an estimate, not a measurement of this release.
