# UCTP-CD Clean Research：第一阶段

这是独立开发版本，不修改旁边的 `uctp_cd_v1_working`。当前只实现 clean baseline 和数据／测试基础设施，尚未加入任何新的论文模块。

服务器操作请先阅读本目录 `SERVER_TEST_GUIDE.md`；实际实现与本地验证结果见 `STAGE1_IMPLEMENTATION_REPORT.md`。

## 三个可以独立运行的对照

| variant | 状态更新 | 定位 |
|---|---|---|
| static | 不更新动态状态 | 原项目风格的静态诊断头；不是官方 NeuralCD 完整复现 |
| dynamic_only | 题目难度条件的正负证据写入 | 从早期 dynamic_only 提取，未加可靠性门 |
| unit_write | 正确加一个正证据、错误加一个负证据 | 固定单位写入的解释性对照 |

单个概念状态仅有 P、N。掌握动态分量为 `(1+P)/(2+P+N)`，叠加原学生静态先验后进入同一单调诊断头。`uncertainty` 是旧式 `2/(2+P+N)` 证据量指标，不是真实可靠概率。

没有 RT 编码器、rho、surprise、双时间尺度、选择性巩固、证据时效、额外辅助损失。保存时间与 RT 不代表模型使用它们。`dynamic_only` 也不等于固定加 1，后者是 `unit_write`。

## 文件与数据流

- `prepare_data.py` 与 `src/data.py`：共用的 ASSIST/EDNet 适配器，不为两个数据集重复实现读取逻辑。
- `src/model.py`：`predict` 与 `observe` 分离。预测接口没有 y 或 RT 参数。
- `src/engine.py`：分块训练、无梯度流式评测；只为当前块构造 Q。
- `train.py`：BCE、AdamW、验证选优，记录数据／代码指纹与运行配置。
- `evaluate.py`：只加载已有数据包和 checkpoint，不重新拟合映射，不覆盖旧输出。
- `tests/fixtures/legacy_model.py`：早期源文件的测试专用副本；生产训练从不导入它。
- `scripts/`：环境检查、测试、顺序多种子运行、独立评测对账、结果汇总与打包。

流程：原始统一时间划分＋题目 Q → 不可覆盖的 `data/...` 数据包 → 历史状态预测 → 反馈后写入 → 后续预测。

每个数据包只有 `records.npz`、`vocabulary.json`、`manifest.json`，不使用 pickle 数据缓存，不加载已有 EDNet prior。缺失／零／非有限 RT 保留原值并标记 `rt_valid=False`；答案、ID、时间戳或 Q 不合法时直接报错，不静默删除。

映射在所选 train/valid/test 的无标签 ID 并集上建立，属于传导式词表设定。当前没有拟合 RT residual，也没有使用整个训练期学生 RT 中位数。诊断用 gap 保留小时单位，multi-KC 标量 gap 取均值；本阶段模型不读取这些 gap。

## 协议限制必须保留

提供的日志无法恢复真实反馈组。当前明确使用“每行完成后立即获得答案”的研究假设，所以训练和评测必须显式加 `--ack-row-feedback`。这个参数只是确认假设，不会自动恢复题组或消除真实题组泄漏。不要把本阶段结果写成已验证的真实部署因果协议。

train 只看 train；valid 重放 train+valid；test 重放 train+valid+test。目标反馈允许更新时，只能影响之后的预测。`--update-targets 0` 禁止目标写入，但仍重放较早 train/valid 反馈，并非只用 train 的完全冻结评测。

## 复现与保护

所有输出必须是本独立项目内的新子目录，没有 `--force`。已有数据包和 run 目录一律拒绝覆盖。模型 checkpoint 绑定数据包指纹；独立评测拒绝不同数据包和不同核心源文件。

相同共享权重下，新旧 dynamic_only 的输出、状态、梯度有回归测试。训练初始化的随机数消耗和 batch shuffle 与旧项目不同，因此这不是旧 checkpoint／旧 seed 成绩的逐位复刻，也不直接兼容旧 `.pt`。不拿小样本结果和旧全量结果比较。

当前训练保存最佳模型、优化器与部分 RNG 状态，但没有实现训练中断续跑入口；失败后使用新的 run 名重新跑指定种子。其他成功 run 保留。

优先使用服务器现有 `yydw`。不要为本项目重装已有 CUDA/PyTorch。`requirements.txt` 是兼容范围，不是远程环境锁文件。本地 `.venv` 仅供 CPU 测试，不上传服务器。
