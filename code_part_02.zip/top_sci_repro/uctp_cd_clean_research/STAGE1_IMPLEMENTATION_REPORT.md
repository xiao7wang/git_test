# 第一阶段修改报告：Clean Baseline 与数据接入

完成日期：2026-09-13。独立版本：`uctp_cd_clean_research`。

## 1. 本轮交付结论

已经建立可独立运行、可单独比较的 clean baseline，完成 ASSIST 与 EDNet 数据接入、38 项测试、两数据集共 6 个小样本训练作业，以及独立评测一致性检查。

**尚未加入证据时效、可靠性、RT 归一化网络或巩固模块；没有进行全量模型训练，也没有在远程 GPU 上运行。** 下一步由用户在服务器 yydw 环境执行本目录 `SERVER_TEST_GUIDE.md`。本轮的重点是建立可信的比较起点，不是证明新方法提升。

## 2. 文件安全与环境

- 新代码位于旧项目旁边的独立目录，未修改、删除或覆盖旧源码、旧 CSV、V1–V7 或实验结果。
- 输入文件只读。全量与 smoke 预处理结果写入新目录的 `data/`，本地试验写入新目录的 `outputs/`。
- 输出目录必须在本独立项目内且从未存在，不提供 force 覆盖模式。
- 本地安装了独立 `.venv` 的 CPU PyTorch，用于实际运行测试；未修改远程 yydw，也未修改随附分析运行时的包。该 venv 继承本地分析包，只用于开发测试，不作为可搬迁的服务器环境。
- 交付 ZIP 不包含本地 venv、数据包、checkpoint、输出日志或用户原始数据。

本地实际环境：Python 3.12.14、PyTorch 2.11.0+cpu、NumPy 2.3.5、pandas 3.0.1。用户远程预期为 Python 3.11.15、PyTorch 2.11.0+cu128、NumPy 1.26.4、pandas 3.0.3。服务器还需要自行完成同一组 CPU/GPU 测试，不承诺跨环境逐位相同。

## 3. 模型如何简化

`src/model.py` 共 127 行，生产模型没有导入旧 V 系列代码。提取保留了早期 dynamic_only 的以下逻辑：

1. 学生静态掌握 embedding；题目难度、区分度、偏置。
2. 单调 NeuralCD 风格预测头与直接单调路径。
3. 动态正负证据 P、N，形成 `(1+P)/(2+P+N)`，再与静态掌握先验融合。
4. 根据题目难度生成正／负 evidence strength；为与旧权重对应，保留四维 strength 输入形状，其余三维在本基线中固定为零。
5. 先 `predict`，再在收到真实答案后 `observe`。

旧实现中关闭 dual 后数值相同的 short/long 两套 P/N 被合并为一套 P/N。生产代码不包含 reliability encoder、timescale gate、time decay、surprise、V3–V7、selective consolidation、uncertainty update 或辅助损失。

### 三种对照

| variant | 预测头 | 写入量 | 状态 |
|---|---|---|---|
| static | 与动态版相同的静态诊断基础 | 不写入 | 始终为初始状态 |
| dynamic_only | 加上原动态证据分量 | 题目难度条件的 strength | 单套 P/N |
| unit_write | 与 dynamic_only 相同 | 正确加 1 个正证据，错误加 1 个负证据 | 单套 P/N |

`dynamic_only` 没有显式可靠性门，但不是完全等权更新。`static` 是本项目风格对照，不声称严格复现官方 NeuralCD。静态／单位写入版仍实例化相同的小型 strength 层以保持三个新分支的共享初始化顺序；相应分支不使用它们，也不将它们视作新方法容量。

测试专用 `tests/fixtures/legacy_model.py` 是早期 `model.py.bak_before_surprise_v2` 的副本。排除换行格式后内容一致；只用于回归测试，训练器不导入它。

## 4. 数据接入改了什么

### 4.1 共用适配器

使用 `prepare_data.py`＋`src/data.py`＋两个 JSON 配置，不另建重复的 ASSIST/EDNet 转换代码。支持显式指定服务器 split-dir、meta-dir，避免硬编码本地 Windows 路径。

EDNet 输入链：

```text
ednet_splits 的五列时间表
  → exercise_id 查 item_mapping.json
  → 对应 q_matrix.npy 行的非零概念列
  → 统一且保存的 student/item/KC 词表
  → records.npz + vocabulary.json + manifest.json
```

只从 EDNet meta-dir 读取 item_mapping.json、q_matrix.npy；不读取该目录的三列 train/valid/test，也不读取 student_concept_prior_tau10.npz。因此没有把两套 EDNet 划分或 prior 混入新实验。

### 4.2 样本与时间规则

- RT 不可用时保留答案和原 RT 值，设置 rt_valid=False，不自动插补，也不删整条 interaction。
- timestamp/RT 单位显式配置。本次两数据集都按秒输入，gap 输出小时。
- datetime 转换改用相对 Unix epoch 的 timedelta 秒值，不再假定底层 int64 单位是 ns；NaT 保留缺失，非法时间戳报错。
- 非二元标签、空 ID、缺少 KC、无 Q 映射或同题 Q 冲突直接失败，不静默吞掉。
- 同学生 split 时间交错会失败；同时间跨 split 的事件计数写入 manifest，不假装已修复反馈语义。
- 词表按所选 train/valid/test 的 ID 并集建立并保存，属于无标签传导式词表设定，不是纯归纳冷启动设定。
- 不拟合 RT residual，不使用完整训练期学生 RT 中位数。时间与历史次数目前只作诊断输出，不影响模型。

### 4.3 已实际完成的全量预处理

| 数据 | train | valid | test | 总计 | 学生 | 题目 | KC | RT 不可用 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ASSIST | 1,847,688 | 255,916 | 549,250 | 2,652,854 | 20,256 | 52,681 | 217 | 0 |
| EDNet | 1,479,693 | 209,028 | 430,263 | 2,118,984 | 9,999 | 12,196 | 140 | 4,736 |

删除行数均为 0。EDNet 原 Q 有 141 列，其中第 0 列为空，模型实际词表为 140 个概念。

此次完整序列统计：ASSIST 最大 2,089，EDNet 最大 15,781。此前审计中的 ASSIST 1,462 是训练段最大长度，不能作为全 train+valid+test 评测序列的最大长度；以本次 manifest 的完整序列统计为准。

### 4.4 预处理缓存与评测不再相互覆盖

数据包使用不含对象数组的 NPZ（allow_pickle=False）、JSON 词表和 manifest。manifest 保存输入哈希、统计量、样本选择、单位、协议及处理代码指纹。

训练只加载该数据包，评测复用相同数据包，均不重新拟合词表／RT 统计。每个 checkpoint 绑定 manifest 指纹，独立评测校验数据包和核心源码。变更后必须新建版本／run，不能无提示沿用旧 checkpoint。

## 5. 训练和评测改了什么

- 单一 BCE 损失，AdamW，保留 BPTT、梯度裁剪和种子设置。
- 默认 batch=8、训练 chunk=50、评测 chunk=100、NCD hidden=128。
- 训练每个 chunk 更新优化器、detach 状态；评测固定参数，在 chunk 间持续保留同一学生状态。
- 只为当前 batch 的当前 chunk 构造密集 Q，不一次把最长学生的完整 B×T×K 都搬到 GPU。
- 验证 AUC 选最佳模型；单类别验证集明确回退到负 NLL，不误用旧 best_model。
- 启动时即保存 run_config/status，每个 epoch 保存 history；中断或异常会记录 failed 状态。
- 最佳 checkpoint 使用同一新 run 内的临时文件替换；不覆盖其他 run。保存模型、优化器、epoch 和部分 RNG 状态，但当前没有恢复训练 CLI。
- 独立 evaluate 不调用 epochs=0 的训练包装器，不修改 checkpoint 或数据缓存。
- 预测导出含 record_idx、source_row、原 split code、student_idx/item_idx、时间、RT mask、概率与证据量；可用 vocabulary.json 对回原 ID。
- 指标含 AUC、NLL、Brier、ACC、F1、RMSE、ECE。AUC 处理同分 rank，无需 sklearn；空组或单类别 AUC 用 JSON null 而非伪造为 0。
- 多种子运行顺序执行并保存每个作业日志；汇总拒绝未完成作业、重复种子或不满足预期种子数的组。

没有把三种子标准差称为统计显著性，也没有在小样本训练中据 test 结果调整模型。

## 6. 实际验证结果

### 6.1 单元测试

最终结果：**38/38 通过，0 failures、0 errors、0 skipped**，CPU PyTorch 2.11.0。权威本地记录为 `outputs/local_tests_verified/test_results.json`。

其中新旧 dynamic_only 的对比是先把早期模型的共享参数加载到新模型，再比较 probability、uncertainty、evidence、最终 P/N 与共享参数梯度，均在给定数值容差内通过。这证明本轮状态提取的数学等价性；不证明随机初始化和旧训练作业逐位一致。

另有当前／未来标签扰动、RT 不进入基线、padding NaN 标签、停止目标写入仍重放上下文、分块与整段一致、Q 冲突、日期转换、输出保护等检查。

扩充测试时曾发现一个测试夹具试图原地修改 pandas 3 返回的只读数组，已改为替换测试副本并重新跑完整测试。该失败记录保留在较早测试目录，不是最终验证结果；没有为此改动生产模型或源数据。

### 6.2 六个 smoke 作业

两个数据集各固定抽样 32 名学生；seed0、1 epoch、BCE、默认 hidden=128。ASSIST 测试 737 条，EDNet 测试 1,243 条。

| 数据 | variant | test AUC | NLL | Brier |
|---|---|---:|---:|---:|
| ASSIST smoke | static | 0.537497 | 0.660733 | 0.233843 |
| ASSIST smoke | dynamic_only | 0.648156 | 0.649292 | 0.228194 |
| ASSIST smoke | unit_write | 0.660244 | 0.648511 | 0.227810 |
| EDNet smoke | static | 0.499474 | 0.677476 | 0.242192 |
| EDNet smoke | dynamic_only | 0.570428 | 0.673365 | 0.240172 |
| EDNet smoke | unit_write | 0.572016 | 0.672993 | 0.239991 |

六个作业均成功反向传播、验证选优、保存并重载 checkpoint、导出测试结果。**这些数字只是运行检查记录，不能据此宣称 unit_write 优于 dynamic_only 或新模型有效。** 抽样后训练中未见题很多，1 epoch 和单种子也不足以判断泛化。

### 6.3 独立评测一致性

用同一 EDNet dynamic_only checkpoint，把 eval chunk 从 100 改为 17。1,243 条测试记录按事件标识对齐，probability、uncertainty、evidence 的最大绝对差均为 **0.0**，AUC/NLL/Brier 同样一致。

这是同环境、同 checkpoint、同数据包的检查，不是不同 GPU／不同训练 batch 的逐位等价承诺。

## 7. 对创新方案做了什么修改

本轮只把研究起点实现为更简单、可区分的三种 baseline。取消了“先把旧 V7 搬过来再加模块”的路线，没有把老模块换名字当作新贡献。

原三个创新点与本轮状态：

| 方向 | 本轮状态 | 下一步条件 |
|---|---|---|
| Process-aware reliability | 未实现，rho 不存在于生产模型 | 先完成 clean baseline 对照，之后单独比较受约束写入 |
| Context-normalized temporal evidence | 保留原始时间与 RT mask；未拟合残差或加网络 | 原始 RT 含义／反馈时点明确后，再单独加入前缀标准化 |
| Temporal consolidation | 未实现，short/long 已从生产状态移除 | 优先检验简单证据时效假设，不强行恢复双记忆 |

后续首选研究问题仍是“降低旧证据有效量，是否必须同时让掌握估计回到先验”。该 m/c 候选尚未编码、训练或验证，也未宣称新颖性已获得文献确认。服务器 baseline 通过后，下一阶段只加入一个时间机制，并让旧式 P/N 衰减对照采用相同的预测前时序。

## 8. 已知边界与仍待处理事项

1. 两数据集日志的真实反馈可用时点尚未完整核实，EDNet 缺少 solving_id／提交组。当前是明确标注的逐行即时反馈假设；`--ack-row-feedback` 只是用户确认，不是技术修复。不能将真实题组内提前反馈风险说成已解决。
2. Q 元数据索引完整性已验证，原 tags→compact Q 的语义生成链仍未闭合。
3. 没有完成远程 GPU 测试；CUDA deterministic 算法、运行时和显存以服务器结果为准。
4. 没有跑全量训练或三种子正式对照；只做了全量预处理。
5. 新模型删减了未用模块，改变了随机数消耗；batch shuffle 与旧 DataLoader 也不同。不能拿相同 seed 要求复刻旧 AUC。
6. 数据解析兼容当前 pandas 3 的问题已测试；不能据此保证所有历史 pandas/PyTorch 版本都受支持。
7. 状态不确定性只是证据量函数，不是经外部验证的认知置信度；当前损失不校准它。
8. 新代码只实现学生状态在线更新，不涉及参数级持续学习／灾难性遗忘协议。

## 9. 用户下一步

请按 `SERVER_TEST_GUIDE.md` 先完成第 1–5 步，把环境 JSON、CPU/GPU 测试 JSON、两份 smoke manifest、history、metrics、run_config 和 chunk comparison 发回。先核查这些，再投入全量多种子训练更稳妥。

完整训练与结果汇总命令也已列出。所有 run 可独立运行；失败改新目录重跑，保留旧结果，不提供破坏性清理命令。

## 附：旧文件不变的抽查指纹

```text
旧 train_v1.py
2583B2BFDA4DE8F60C8BE3D6F958B42F87D73376397C09CEEF81C7A08D4DCECA
旧 src/uctp_v1/model.py
206EEB75E0E85AAF60CC56A68F8137143DB67CB8FEB557EA639E16BDBA9B6887
旧 src/uctp_v1/data.py
F09C6B16780082C615D874782780B9357ADA35B34EDFC5BAE3FEB785DA5C21DA
早期参考模型原文件
9590031F7986894F98ED1DC156D226C1FBA97A4751FAFB6B408622D986D0195D
```

这些指纹与代码审计时一致。交付包另附 package_manifest.json，用于核查新版本源码清单。
