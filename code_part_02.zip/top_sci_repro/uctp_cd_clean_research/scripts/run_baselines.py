"""Sequential jobs with fresh directories and captured stdout/stderr, no background service."""
import argparse
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, new_output_dir, write_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-root", required=True)
    p.add_argument("--variants", nargs="+", choices=("static", "dynamic_only", "unit_write"), default=["dynamic_only"])
    p.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=50)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--ack-row-feedback", action="store_true")
    a = p.parse_args()
    if not a.ack_row_feedback:
        p.error("--ack-row-feedback required")
    if len(set(a.variants)) != len(a.variants) or len(set(a.seeds)) != len(a.seeds):
        p.error("Duplicate variants/seeds")
    data_dir = str(Path(a.data_dir).resolve())
    out = new_output_dir(a.output_root)
    plan = []
    for variant in a.variants:
        for seed in a.seeds:
            name = f"{variant}_seed{seed}"
            command = [sys.executable, "-u", str(ROOT / "train.py"), "--data-dir", data_dir,
                       "--output-dir", str(out / name), "--variant", variant, "--seed", str(seed),
                       "--epochs", str(a.epochs), "--batch-size", str(a.batch_size),
                       "--chunk-size", str(a.chunk_size), "--device", a.device, "--ack-row-feedback"]
            plan.append({"name": name, "command": command})
    write_json(out / "plan.json", plan)
    completed = []
    for job in plan:
        print(f"Starting {job['name']}; progress log: {out / (job['name'] + '.log')}", flush=True)
        with open(out / (job["name"] + ".log"), "x", encoding="utf-8") as log:
            process = subprocess.run(job["command"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        completed.append({"name": job["name"], "returncode": process.returncode})
        write_json(out / "jobs.json", completed)
        if process.returncode:
            raise SystemExit(f"Stopped on {job['name']}; read its log. Existing successful jobs are preserved.")
        print(f"Completed {job['name']}", flush=True)


if __name__ == "__main__":
    main()
