# 服务器测试指南：先验证流程，再跑正式 baseline

本轮先验证干净起点。不要加入新模块，也不要同时修改学习率、预测头、写入规则和切分。所有命令在新的 `uctp_cd_clean_research` 目录执行。下面没有删除旧文件、覆盖旧 run 或修改 `yydw` 的命令。

## 0. 上传到哪里

把交付 ZIP 上传至：

```text
/home/wangxiao/QCCDM/top_sci_repro/UCTP-CD-V1/
```

ZIP 自带顶层 `uctp_cd_clean_research/`，解压后应与旧 `uctp_cd_v1_working/` 并列。首次上传时可在 VS Code 文件界面确认不存在同名新目录，再解压。若已经存在该目录，不要覆盖其中的代码／运行记录；先与我确认版本安排。

不需要上传本地 `.venv`、`data`、`outputs`。ZIP 只包含源码、配置、测试和说明；服务器上重新准备数据即可。

```bash
conda activate yydw
cd /home/wangxiao/QCCDM/top_sci_repro/UCTP-CD-V1/uctp_cd_clean_research
pwd
python --version
```

应看到新目录，Python 预期为你已确认的 3.11.15。如果路径不同，后续命令统一在实际新目录执行；不要进入旧目录运行新训练。

## 1. 先检查 GPU 环境

```bash
python scripts/check_environment.py --device cuda --output-dir outputs/server_env_01
```

成功时应有 `forward_backward_ok: true`、`cuda_available: true`，GPU 为 RTX 5090，torch 预期 `2.11.0+cu128`，CUDA build 预期 `12.8`。结果保存在 `outputs/server_env_01/environment.json`。

若失败，先发完整报错和 `python --version`，不要先升级／降级环境。`No module named torch` 通常需要检查是否激活正确 conda 环境；CUDA unavailable 不能靠改成 CPU 后声称 GPU 检查通过。

已有同名输出时改成 `_02`，不要删除 `_01`。

## 2. 运行单元测试：CPU 后 GPU

```bash
python scripts/run_tests.py --device cpu --output-dir outputs/server_tests_cpu_01
python scripts/run_tests.py --device cuda --output-dir outputs/server_tests_cuda_01
```

预期：**38 tests，OK，success=true，failures/errors/skipped 均为空**。每次生成 `test_results.json`。

这些测试包括：

- 相同共享权重的新旧 dynamic_only 预测、状态、梯度等价。
- 改当前答案不改变当前预测，改未来答案不改变过去预测。
- RT 不进入当前 baseline；缺失 RT 作答保留。
- padding、禁止写入、静态状态、单位写入量与 KC 选择正确。
- 训练／验证／测试历史视图、分块重放一致性。
- 日期转换精度与缺失、Q 错配、划分交错和输出保护。

测试没有证明真实 EDNet 题组反馈已经恢复。若有失败，不继续正式训练；先发 CPU/GPU 两份测试 JSON 和终端 traceback。GPU 浮点容差问题也应先核查，不直接放宽容差。

## 3. 准备小样本数据

### 3.1 ASSIST

默认读取旁边旧项目已加工的完整 ASSIST 表，再以固定 seed 2026 抽取 32 名学生，保留这些学生的全部 train/valid/test 记录。

```bash
python prepare_data.py --config configs/assist.json --output-dir data/assist_smoke --max-students 32
```

若旧项目相对路径不一致：

```bash
python prepare_data.py --config configs/assist.json --split-dir /home/wangxiao/QCCDM/top_sci_repro/UCTP-CD-V1/uctp_cd_v1_working/data/assistments_time --output-dir data/assist_smoke --max-students 32
```

上面两条是替代关系，只需成功执行其中一条。

### 3.2 EDNet

如果服务器也有并列的 `work_support_20260912`：

```bash
python prepare_data.py --config configs/ednet.json --output-dir data/ednet_smoke --max-students 32
```

如果服务器保留的是原始远程路径，用这条替代：

```bash
python prepare_data.py --config configs/ednet.json --split-dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/splits/ednet --meta-dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data/ednet --output-dir data/ednet_smoke --max-students 32
```

**split-dir 必须是保留五列和时间顺序的 splits/ednet。meta-dir 只读取 item_mapping.json、q_matrix.npy，不读取它的三列 train 或 prior。**

使用与本地相同输入文件和抽样 seed 时，应得到：

| small dataset | 学生 | train | valid | test | 总记录 | 实际 KC |
|---|---:|---:|---:|---:|---:|---:|
| assist_smoke | 32 | 2,457 | 338 | 737 | 3,532 | 121 |
| ednet_smoke | 32 | 4,269 | 601 | 1,243 | 6,113 | 136 |

若数量不同，先比较 `manifest.json` 的 sources 哈希和 sample_seed；不要为了对齐数字手工删行。每个数据目录含 `records.npz`、`vocabulary.json`、`manifest.json`，三者需一起保留。这里不同于旧项目原先 256 人的 ASSIST smoke。

## 4. 各跑一个最小训练

```bash
python -u train.py --data-dir data/assist_smoke --output-dir outputs/server_assist_smoke_seed0 --variant dynamic_only --epochs 1 --seed 0 --device cuda --ack-row-feedback
python -u train.py --data-dir data/ednet_smoke --output-dir outputs/server_ednet_smoke_seed0 --variant dynamic_only --epochs 1 --seed 0 --device cuda --ack-row-feedback
```

`--ack-row-feedback` 的含义：确认当前采用逐行即时反馈假设；它不是“修复题组泄漏”的开关。真实反馈组尚未提供，正式论文必须说明或后续补齐。

成功条件：

1. 出现 epoch=1，训练 BCE、验证 NLL 均为有限数值。
2. `status.json` 为 `complete`，best_epoch=1。
3. 有 `best_model.pt`、`history.json`、`run_config.json`、`test_metrics.json`、`test_predictions.csv`。
4. ASSIST 的 test n=737，EDNet 的 test n=1,243；不是零行，概率均在 [0,1]。

**不要要求 GPU 分数逐位等于本地 CPU。** 小样本中大量题目在训练未出现，AUC 不高不代表流程失败；这里检验连通性、有限值和协议，不判断创新有效性。

如果想同时验证另外两个分支：

```bash
python scripts/run_baselines.py --data-dir data/ednet_smoke --output-root outputs/server_ednet_smoke_controls --variants static unit_write --seeds 0 --epochs 1 --device cuda --ack-row-feedback
```

这是顺序执行两个作业，不会同时占满 GPU。每个作业日志在 output-root 下的对应 `.log`。

## 5. 独立评测与分块一致性检查

对步骤 4 的同一个 EDNet checkpoint 换一个评测 chunk size，不训练、不重新预处理：

```bash
python evaluate.py --checkpoint outputs/server_ednet_smoke_seed0/best_model.pt --data-dir data/ednet_smoke --output-dir outputs/server_ednet_recheck_chunk17 --chunk-size 17 --device cuda --ack-row-feedback
python scripts/compare_predictions.py --left outputs/server_ednet_smoke_seed0/test_predictions.csv --right outputs/server_ednet_recheck_chunk17/predictions.csv --output-dir outputs/server_ednet_chunk_check
```

应看到 success=true，比较记录数 1,243，probability/uncertainty/evidence 的最大绝对差≤1e-6。本地 CPU 此检查为 0；服务器若超过阈值，先发 `comparison.json`，不要直接继续跑大实验。

若出现 data fingerprint 或 code differs 报错，说明数据包或核心代码不再与训练一致。请找到原包／原代码，不要删除验证逻辑绕过检查。

到这里可以先把小样本结果发给我。确认后再运行下面全量流程，会更省 GPU 时间。

## 6. 准备全量输入，只需要做一次

```bash
python prepare_data.py --config configs/assist.json --output-dir data/assist_full
python prepare_data.py --config configs/ednet.json --split-dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/splits/ednet --meta-dir /home/wangxiao/QCCDM/top_sci_repro/unified_experiments/trace_cd_data/ednet --output-dir data/ednet_full
```

EDNet 如果使用 work_support 目录，第二条可省略 split-dir/meta-dir，和步骤 3 的规则一致。

全量预期：

| 数据 | train | valid | test | 学生 | 题目 | KC | 不可用 RT | 删除行 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| ASSIST | 1,847,688 | 255,916 | 549,250 | 20,256 | 52,681 | 217 | 0 | 0 |
| EDNet | 1,479,693 | 209,028 | 430,263 | 9,999 | 12,196 | 140 | 4,736 | 0 |

EDNet 不是旧清洗后 test=429,387，也不是三列 CD 表的 test=211,899。数目不符时不要混用版本。

当前保留已提供 ASSIST 表的 1 条历史 RT 插补，不在新代码里补写任何值。日期解析已修复；timestamp/RT 显式配置为秒。

## 7. 正式 baseline：先 dynamic_only，再完整对照

先各跑 5 epochs 的 seed0，查看耗时和显存；它们属于基线复现，不是新方法：

```bash
python -u train.py --data-dir data/assist_full --output-dir outputs/server_assist_full_dynamic_seed0_check --variant dynamic_only --epochs 5 --seed 0 --device cuda --ack-row-feedback
python -u train.py --data-dir data/ednet_full --output-dir outputs/server_ednet_full_dynamic_seed0_check --variant dynamic_only --epochs 5 --seed 0 --device cuda --ack-row-feedback
```

不要将上述诊断作业混入下面同名 seed 的汇总，避免重复计数。

需要完整的三种子基线表时，运行两组，每组 3 variants×3 seeds=9 个作业，共 18 个。按顺序执行，不启动隐藏后台任务：

```bash
python -u scripts/run_baselines.py --data-dir data/assist_full --output-root outputs/server_assist_baselines_v1 --variants static dynamic_only unit_write --seeds 0 1 2 --epochs 5 --device cuda --ack-row-feedback
python -u scripts/run_baselines.py --data-dir data/ednet_full --output-root outputs/server_ednet_baselines_v1 --variants static dynamic_only unit_write --seeds 0 1 2 --epochs 5 --device cuda --ack-row-feedback
```

进度日志示例：

```bash
tail -n 40 outputs/server_ednet_baselines_v1/dynamic_only_seed0.log
```

默认训练 batch=8、BPTT chunk=50、评测 chunk=100、NCD hidden=128、lr=0.001、weight decay=1e-5、BCE 唯一损失。以验证 AUC 选 checkpoint；若验证标签只有一类则回退验证 NLL，正常全量数据不应触发。

这 5 epochs 是先建立可比较起点的预算，不预先保证已收敛。之后根据验证曲线决定是否对所有方法统一延长；不依据 test 最优次数挑预算。运行时间应以服务器实际日志为准。

若 OOM，不直接同时改多个参数。先发报错、batch/chunk、环境信息。评测已经流式分块；降低训练 chunk 会改变 BPTT，应在全部对照中统一并重新跑，不能只为某个方法改。

终端断开会中断前台作业；可在你习惯的已有 tmux 会话中执行。当前没有 resume 功能。单个种子失败后，其余成功结果保留；重跑用新的目录名，并告诉我哪些是替代作业。

## 8. 汇总结果

两组各 9 个作业全部完成后：

```bash
python scripts/summarize_runs.py --run-root outputs/server_assist_baselines_v1 --output-dir outputs/server_assist_summary_v1
python scripts/summarize_runs.py --run-root outputs/server_ednet_baselines_v1 --output-dir outputs/server_ednet_summary_v1
```

结果为各 variant 的 AUC/NLL/Brier/ACC/ECE 均值和样本标准差，同时保留每个种子的值。它不是显著性检验，也不是学生聚类置信区间。缺失、失败、重复种子或不同数据／核心代码会阻止正常合并。

若只是汇总一个种子的 smoke 控制组，显式加 `--expected-seeds 1`，不要把单种子标准差写成 0。

## 9. 跑完发哪些文件给我

### 第一批：建议先发，不必等全量

- `outputs/server_env_01/environment.json`。
- CPU、GPU 两个测试目录的 `test_results.json`。
- `data/assist_smoke/manifest.json`、`data/ednet_smoke/manifest.json`。
- 两个 smoke run 的 `status.json`、`history.json`、`run_config.json`、`test_metrics.json`。
- `outputs/server_ednet_chunk_check/comparison.json`。
- 如有错误，完整 traceback 与出错命令；不要只截最后一行。

### 第二批：正式 baseline 跑完后

- 两份 full 数据 `manifest.json`。
- 两份 summary 目录里的 `summary.json`。
- 每个 run 的 `status.json`、`history.json`、`run_config.json`、`test_metrics.json`、`subgroup_metrics.json`。
- 各组 `plan.json`、`jobs.json` 和训练 `.log`，用于核对失败或提前停止。

初次不用上传所有 `.pt` 或全部预测 CSV。先发上述小文件，我会检查数据协议、收敛、种子波动，再决定取哪些 `test_predictions.csv` 做配对分析；这些 CSV 的 record_idx 与 source_row 能精确回到原数据。

## 10. 这轮结果应该回答什么

先回答：新基线是否可复现、单位写入与题目条件写入有什么差异、两个数据集是否同一协议、概率质量是否正常。

还不能回答：可靠性是否有效、证据时效是否优于真实遗忘、是否达到 SCI 投稿要求。本轮这三个新模块均未加入。基线测试通过后，再只改一个机制并与同协议对照配对训练。
