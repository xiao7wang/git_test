"""Synthetic unit/integration tests; no model training and no server data needed."""
import argparse
import contextlib
import io
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import torch
from run_diagnostic import import_project, check_reference, parser, save, ROOT
from mechanism_core import (MODES, interventions, plan_windows, snapshot_model_class,
    replay_reference, branch_predictions, check_invariants, parameter_digest, bootstrap_pairs)

PROJECT = None
DEVICE = torch.device("cpu")


def fixture():
    # student, item, label, elapsed hours, split (test deliberately included).
    rows = [(0,0,1,0,0),(0,0,1,1,0),(0,1,0,2,0),
            (0,0,0,200,1),(0,1,1,201,1),(0,2,1,202,1),
            (0,0,0,203,1),(0,2,1,204,1),(0,0,1,205,1),(0,2,1,206,1),(0,0,0,300,2),
            (1,1,1,0,0),(1,1,0,1,0),(1,1,1,400,1),(1,1,0,400,1),(1,1,1,401,1),(1,1,0,600,2)]
    a = np.asarray(rows)
    x = {"student_idx": a[:,0].astype(np.int32), "item_idx": a[:,1].astype(np.int32),
         "label": a[:,2].astype(np.float32), "timestamp": (1700000000+a[:,3]*3600).astype(np.float64),
         "split": a[:,4].astype(np.int32), "user_offsets": np.array([0,11,17]),
         "item_q": np.array([[1,0],[0,1],[1,0]], bool)}
    for k in ("delta_t_hours", "delta_t_k_hours", "kc_count_before", "student_count_before"):
        x[k] = np.zeros(len(a), np.float32)
    x.update(source_row=np.arange(len(a)), response_time=np.ones(len(a)), rt_valid=np.ones(len(a), bool))
    return x


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.Data, self.Temporal, self.metrics, set_seed, _ = import_project(PROJECT)
        set_seed(9)
        self.data = self.Data.__new__(self.Data)
        self.data.arrays = fixture()
        self.users = np.array([0,1])
        self.plan = plan_windows(self.data.arrays, self.users)

    def make_model(self, variant="unit_write"):
        m = snapshot_model_class(self.Temporal)(2,3,2, variant=variant, ncd_hidden_dim=8,
                                               time_mode="none", decay_rate_per_hour=0).to(DEVICE)
        m.eval().requires_grad_(False)
        return m

    def run_fixture(self, variant="unit_write", batch=2, chunk=100):
        m = self.make_model(variant)
        ref, ab = replay_reference(m, self.data, self.users, self.plan, DEVICE, batch, chunk)
        frame = branch_predictions(m, self.data.arrays, self.plan, ab, DEVICE)
        return m, ref, ab, frame

    def test_hand_calculated_four_interventions_and_scales(self):
        values, scales = interventions(np.array([[9.,1.]]), np.array([2.]), 1.)
        np.testing.assert_allclose(values[0,:4], [[9,1],[3.6,.4],[7.5,2.5],[3,1]])
        np.testing.assert_allclose(scales[0], [1,1,1,1,2.5,2.5])

    def test_zero_gap_identity(self):
        ab = np.array([[9.,1.],[2.,4.]])
        values, scales = interventions(ab, np.zeros(2), 168)
        for j in range(len(MODES)):
            np.testing.assert_allclose(values[:,j], ab)
        np.testing.assert_array_equal(scales, 1.)

    def test_large_gap_mass_not_clamped(self):
        values, _ = interventions(np.array([[999.,1.]]), np.array([1e9]), 168)
        self.assertAlmostEqual(values[0,1].sum(), 2)
        self.assertLess(values[0,1,1], 1)
        self.assertAlmostEqual(values[0,1,0]/values[0,1].sum(), .999)

    def test_invalid_intervention_inputs(self):
        for rate in (0,-1,float("inf"),float("nan")):
            with self.assertRaises(ValueError):
                interventions(np.array([[2.,1.]]), np.array([200.]), rate)
        with self.assertRaises(ValueError):
            interventions(np.array([[2.,1.]]), np.array([-1.]), 168.)

    def test_anchor_ids_real_kc_history(self):
        np.testing.assert_array_equal(self.plan["anchor"], [3,4,13])
        np.testing.assert_allclose(self.plan["gap_hours"], [199,199,399])
        np.testing.assert_array_equal(self.plan["prior_count"], [2,1,2])

    def test_same_kc_paths_skip_other_kcs_not_feedback(self):
        np.testing.assert_array_equal(self.plan["paths"][0], [3,5,6,7,8,9])

    def test_tied_next_kc_stops_window_not_skipped(self):
        np.testing.assert_array_equal(self.plan["paths"][2], [13,-1,-1,-1,-1,-1])
        self.assertTrue(self.plan["anchor_tied"][2])

    def test_first_kc_is_not_a_long_gap(self):
        x = fixture()
        x["timestamp"][2] = x["timestamp"][0]+180*3600
        plan = plan_windows(x, self.users)
        self.assertNotIn(2, plan["anchor"])
        self.assertNotIn(4, plan["anchor"])

    def test_exact_gap_boundary_not_eligible(self):
        x = fixture()
        x["timestamp"][3] = x["timestamp"][1]+168*3600
        self.assertNotIn(3, plan_windows(x, self.users)["anchor"])

    def test_multi_kc_rejected(self):
        x = fixture()
        x["item_q"][0] = True
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)

    def test_float32_and_backward_time_rejected(self):
        x = fixture()
        x["timestamp"] = x["timestamp"].astype(np.float32)
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)
        x = fixture()
        x["timestamp"][1] = x["timestamp"][0]-1
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)

    def test_test_events_not_used_even_when_poisoned(self):
        x = fixture()
        test = x["split"] == 2
        x["timestamp"][test] = np.nan
        x["label"][test] = np.nan
        plan = plan_windows(x, self.users)
        np.testing.assert_array_equal(plan["paths"], self.plan["paths"])
        self.data.arrays = x
        self.run_fixture()

    def test_original_forward_predictions_not_changed(self):
        from src.engine import evaluate
        m, ref, _, _ = self.run_fixture("dynamic_only")
        original = self.Temporal(2,3,2,variant="dynamic_only",ncd_hidden_dim=8,time_mode="none").to(DEVICE)
        original.load_state_dict(m.state_dict())
        _, expected, _ = evaluate(original,self.data,DEVICE,"valid",2,100,True)
        for key in ("record_idx", "probability", "uncertainty", "evidence"):
            np.testing.assert_array_equal(ref[key], expected[key])

    def test_snapshot_and_branch_none_match_both_writing_rules(self):
        for variant in ("dynamic_only", "unit_write"):
            with self.subTest(variant=variant):
                _, ref, _, frame = self.run_fixture(variant)
                report = check_invariants(frame, ref)
                self.assertTrue(report["success"], report)

    def test_chunk_size_does_not_change_snapshots_or_predictions(self):
        m = self.make_model("dynamic_only")
        a, ab1 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,1)
        b, ab2 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,17)
        pd.testing.assert_frame_equal(a,b)
        np.testing.assert_array_equal(ab1,ab2)

    def test_student_batch_size_invariant(self):
        m = self.make_model("dynamic_only")
        a, ab1 = replay_reference(m,self.data,self.users,self.plan,DEVICE,1,17)
        b, ab2 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,17)
        np.testing.assert_allclose(a.probability,b.probability,rtol=0,atol=1e-6)
        np.testing.assert_allclose(ab1,ab2,rtol=0,atol=1e-6)

    def test_branch_batch_size_invariant(self):
        m, _, ab, a = self.run_fixture("dynamic_only")
        b = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,batch_size=1)
        for mode in MODES:
            np.testing.assert_allclose(a[f"{mode}_probability"],b[f"{mode}_probability"],rtol=0,atol=1e-6)

    def test_selected_users_keep_original_batch_but_exclude_companion_outputs(self):
        m, full, _, _ = self.run_fixture("dynamic_only")
        users = np.array([0])
        plan = plan_windows(self.data.arrays,users)
        selected, _ = replay_reference(m,self.data,users,plan,DEVICE,2,100)
        expected = full.loc[full.record_idx < 11].reset_index(drop=True)
        pd.testing.assert_frame_equal(selected,expected)

    def test_current_response_does_not_enter_current_prediction(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        self.data.arrays["label"][3] = 1-self.data.arrays["label"][3]
        new = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        ix = (old.anchor_record_idx == 3) & (old.horizon == 0)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[ix,f"{mode}_probability"],new.loc[ix,f"{mode}_probability"])
        self.assertNotEqual(float(old.loc[ix,"mass_mean_after"].iloc[0]),float(new.loc[ix,"mass_mean_after"].iloc[0]))

    def test_future_response_does_not_enter_earlier_predictions(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        self.data.arrays["label"][7] = 1-self.data.arrays["label"][7]
        new = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        ix = (old.anchor_record_idx == 3) & (old.horizon <= 3)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[ix,f"{mode}_probability"],new.loc[ix,f"{mode}_probability"])

    def test_future_window_change_does_not_change_anchor_forecast(self):
        m, _, ab, old = self.run_fixture()
        plan = {k: v.copy() for k,v in self.plan.items()}
        plan["paths"][:,1:] = -1
        new = branch_predictions(m,self.data.arrays,plan,ab,DEVICE)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[old.horizon==0,f"{mode}_probability"],new[f"{mode}_probability"])

    def test_parameters_and_snapshot_inputs_immutable(self):
        m = self.make_model("dynamic_only")
        before = parameter_digest(m)
        _, ab = replay_reference(m,self.data,self.users,self.plan,DEVICE)
        original = ab.copy()
        branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        np.testing.assert_array_equal(ab,original)
        self.assertEqual(before,parameter_digest(m))
        self.assertTrue(all(p.grad is None and not p.requires_grad for p in m.parameters()))

    def test_independent_anchors_not_contaminated_by_other_branches(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        take = np.array([1,2])
        plan = {k: (v[take] if k != "validation_records" else v) for k,v in self.plan.items()}
        new = branch_predictions(m,self.data.arrays,plan,ab[take],DEVICE)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[old.anchor_record_idx!=3,f"{mode}_probability"],new[f"{mode}_probability"])

    def test_invariants_detect_probability_corruption(self):
        _, ref, _, f = self.run_fixture()
        f.loc[0,"write_rescale_probability"] = np.float32(float(f.loc[0,"write_rescale_probability"]) + 0.01)
        self.assertFalse(check_invariants(f,ref)["success"])

    def test_reference_identity_guard(self):
        _, ref, _, _ = self.run_fixture()
        ids = ref.record_idx.to_numpy()
        old = ref.copy()
        for k in ("student_idx","item_idx","label","split","timestamp"):
            old[k] = self.data.arrays[k][ids]
        self.assertTrue(check_reference(ref,old,self.data.arrays,ids,1e-6)["success"])
        old.loc[0,"label"] = 1-old.loc[0,"label"]
        with self.assertRaises(AssertionError):
            check_reference(ref,old,self.data.arrays,ids,1e-6)

    def test_bootstrap_identical_predictions_zero(self):
        _, _, _, f = self.run_fixture()
        for mode in MODES:
            f[f"{mode}_probability"] = .5
        for result in bootstrap_pairs(f,100):
            self.assertEqual(result["delta_nll"],0)
            self.assertEqual(result["ci95"],[0,0])

    def test_csv_short_decimal_roundtrip_is_compared_in_original_precision(self):
        _, ref, _, _ = self.run_fixture()
        ids = ref.record_idx.to_numpy()
        ref["evidence"] = np.float32(12345.678)
        old = pd.read_csv(io.StringIO(ref.to_csv(index=False)))
        for k in ("student_idx","item_idx","label","split","timestamp"):
            old[k] = self.data.arrays[k][ids]
        report = check_reference(ref,old,self.data.arrays,ids,1e-6)
        self.assertTrue(report["success"])
        self.assertGreater(report["raw_float64_vs_csv_decimal_difference"]["evidence"],1e-6)

    def test_no_test_view_option(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            parser().parse_args(["--project-dir","x","--checkpoint","x","--data-dir","x","--output-dir","x","--view","test"])

    def test_empty_anchor_subset_supported(self):
        self.data.arrays["timestamp"] = 1700000000 + np.arange(len(self.data.arrays["label"]),dtype=np.float64)
        plan = plan_windows(self.data.arrays,self.users)
        self.assertEqual(len(plan["anchor"]),0)
        m = self.make_model()
        ref, ab = replay_reference(m,self.data,self.users,plan,DEVICE)
        f = branch_predictions(m,self.data.arrays,plan,ab,DEVICE)
        self.assertTrue(f.empty)
        self.assertTrue(check_invariants(f,ref)["success"])


def main():
    global PROJECT, DEVICE
    p = argparse.ArgumentParser()
    p.add_argument("--project-dir", required=True)
    p.add_argument("--device", choices=("cpu","cuda"), default="cpu")
    p.add_argument("--report", required=True)
    a = p.parse_args()
    PROJECT, DEVICE = a.project_dir, torch.device(a.device)
    if DEVICE.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    report = Path(a.report).resolve()
    if not report.is_relative_to(ROOT/"outputs") or report.exists():
        raise ValueError("Report must be a NEW file inside package outputs")
    import os
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(4)
    report.parent.mkdir(parents=True, exist_ok=True)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DiagnosticTests))
    summary = {"success":result.wasSuccessful(),"tests_run":result.testsRun,"device":str(DEVICE),"torch":str(torch.__version__),
               "failures":[(str(t),e) for t,e in result.failures],"errors":[(str(t),e) for t,e in result.errors],"skipped":result.skipped}
    save(report,summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ("failures","errors")}),flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
