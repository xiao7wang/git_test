# 本轮交付说明（2026-09-28）

## 完成的内容

独立目录 uctp_mechanism_diagnostic_v1，未编辑 uctp_cd_temporal_v1 或 uctp_cd_clean_research 的源码、配置、模型、旧结果。

| 文件 | 用途 |
|---|---|
| mechanism_core.py | 因果起点选择、原模型状态旁观捕获、六分支一次性干预、窗口指标与学生整群 bootstrap |
| run_diagnostic.py | 单 checkpoint 诊断、源码及数据/模型指纹校验、旧预测桥接、防覆盖、状态与参数不变检查 |
| test_diagnostic.py | 29 项无训练测试，CPU / CUDA 可独立运行 |
| run_suite.py | 顺序执行测试、预检、chunk17 检查，工程检查通过后可做两个全验证诊断并打包结果 |
| show_results.py | 只读查看进度与核心结果 |
| expected_project_sources.json | 固定已审核的 8 个原项目源码哈希，禁止绕过版本不一致 |
| README.md | 数学等价关系、诊断定义、统计限制和研究意义边界 |
| SERVER_GUIDE.md | 上传、tmux、准确服务器命令、结果返回方式 |

没有新增训练模型、学习参数、损失、优化器或真实反馈分组逻辑。

## 已完成的本地验证

- 环境：项目现有 Python 虚拟环境，PyTorch 2.11.0+cpu；未安装新依赖。
- 最终 29 项测试全部通过，无 skipped。
- 实际 ASSIST / EDNet smoke 的 dynamic_only_none、unit_write_none checkpoint 均完成独立诊断。
- 原 probability、uncertainty、evidence 按原 float32 输出精度恢复 CSV 后，最大差值均为 0。
- 分支 none 与旧后续预测、两个等价性控制的最大概率差值不超过 5.960464477539063e-08。
- 本地完整 suite 流程通过，包含 chunk17 和自动结果打包；该流程使用的是 smoke 数据。目录中作业名的 full 表示“所提供数据的全部学生”，不代表本地完成了服务器 full checkpoint 的诊断。
- 本地还对两套实际 full 数据重建了全部窗口，但没有使用 full checkpoint 预测：ASSIST 为 255,916 条验证 / 34,515 起点 / 15,618 个 h1 / 3,615 个 h5；EDNet 为 209,028 / 27,137 / 9,702 / 843，与上一轮独立分析完全相同。
- 未执行服务器 CUDA 测试、服务器 full checkpoint 诊断；这些由服务器指南完成。

开发过程曾发现 CSV 最短十进制表示与内存 float32 比较时，较大 evidence 数值出现假差异。已修正为恢复原 float32 精度，同时记录原始十进制差值，并新增回归测试；没有放宽容差。早期失败输出保留在本地独立 outputs，没有覆盖原结果，不随交付代码包发送。

## 对创新判断的实质变化

当前单次 mass 干预，在均值读出且写入函数不依赖分支状态的条件下，与窗口内固定比例的写入放大具有相同预测轨迹；代码和实际 smoke 也验证了该代数关系。不能把 mass 与这种步长调整称为两种不同的核心创新。

本次全验证诊断的目的不是证明已经知道的等价关系，而是判断：共同状态下，当前均值调整和后续更新增益分别带来什么收益/损失，是否有足够稳定、足够具体的问题值得继续做方法研究。

若差异可以由简单更新增益解释，且没有独立的教育场景价值或稳健性证据，就不继续把 mass 包装为主创新。不自动启动多 seed、不自动选半衰期、不查看 test 选模型。

这是辅助识别机制的诊断工具，不是已经改进完成的论文模型。
