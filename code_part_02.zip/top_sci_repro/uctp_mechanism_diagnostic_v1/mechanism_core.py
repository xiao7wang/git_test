"""Frozen-checkpoint, ONE-TIME anchor intervention; not a new trained model.

Requires one-hot Q and the audited difficulty-only writing rule. Same-KC
windows are exact under these assumptions; other KCs cannot change this state.
Future records select evaluation outcomes, never anchor decisions/features.
"""
import hashlib
import math
import numpy as np
import pandas as pd
import torch

MODES = ("none", "mass", "mean", "joint", "write_rescale", "mean_write_rescale")


def parameter_digest(model):
    h = hashlib.sha256()
    for name, value in model.state_dict().items():
        h.update(name.encode())
        h.update(str((value.shape, value.dtype)).encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def plan_windows(arrays, users, gap_hours=168., window_hours=168., max_horizon=5):
    if not (np.isfinite(gap_hours) and gap_hours >= 0 and np.isfinite(window_hours) and window_hours > 0):
        raise ValueError("Invalid gap/window")
    q = arrays["item_q"]
    if q.ndim != 2 or not np.isin(q, [0, 1]).all() or not np.all(q.sum(1) == 1):
        raise ValueError("This diagnostic requires verified one-hot Q; do not average multi-KC clocks")
    if max_horizon < 1:
        raise ValueError("max_horizon must be positive")
    if arrays["timestamp"].dtype != np.float64:
        raise ValueError("float64 Unix-second timestamps required")
    item_kc = q.argmax(1)
    records, paths, gap_values, counts, tied_values = [], [], [], [], []
    offsets = arrays["user_offsets"]
    eligible_events = []
    for u in users:
        indices = np.arange(offsets[u], offsets[u+1])
        # Test events do not participate in windows, clocks, labels, or prediction.
        indices = indices[arrays["split"][indices] <= 1]
        if not len(indices):
            continue
        if not np.all(arrays["student_idx"][indices] == u):
            raise ValueError("Invalid student offsets")
        times = arrays["timestamp"][indices]
        if not np.isfinite(times).all() or (np.diff(times) < 0).any():
            raise ValueError("Invalid or backward time")
        if (np.diff(arrays["split"][indices]) < 0).any():
            raise ValueError("Interleaved train/validation")
        eligible_events.extend(indices[arrays["split"][indices] == 1].tolist())
        tied = np.zeros(len(indices), bool)
        tied[1:] |= np.diff(times) == 0
        tied[:-1] |= np.diff(times) == 0
        by_kc = {}
        for pos, idx in enumerate(indices):
            by_kc.setdefault(int(item_kc[arrays["item_idx"][idx]]), []).append((pos, int(idx)))
        for sequence in by_kc.values():
            for j, (pos, idx) in enumerate(sequence):
                if j == 0 or arrays["split"][idx] != 1:
                    continue
                gap = (arrays["timestamp"][idx] - arrays["timestamp"][sequence[j-1][1]]) / 3600.
                if gap <= gap_hours:
                    continue
                path = [idx]
                for h in range(1, max_horizon+1):
                    if j+h >= len(sequence):
                        break
                    nxt = sequence[j+h][1]
                    # Never skip a tied same-KC event and silently omit its feedback.
                    if arrays["split"][nxt] != 1 or arrays["timestamp"][nxt] <= arrays["timestamp"][path[-1]]:
                        break
                    if arrays["timestamp"][nxt] - arrays["timestamp"][idx] > window_hours * 3600:
                        break
                    path.append(nxt)
                records.append(idx)
                paths.append(path + [-1] * (max_horizon+1-len(path)))
                gap_values.append(gap)
                counts.append(j)
                tied_values.append(bool(tied[pos]))
    order = np.argsort(records)
    anchor = np.asarray(records, np.int64)[order]
    return {"anchor": anchor,
            "paths": np.asarray(paths, np.int64).reshape(-1, max_horizon+1)[order],
            "gap_hours": np.asarray(gap_values, np.float64)[order],
            "prior_count": np.asarray(counts, np.int64)[order],
            "anchor_tied": np.asarray(tied_values, bool)[order],
            "validation_records": np.asarray(sorted(eligible_events), np.int64)}


def snapshot_model_class(temporal_class):
    class SnapshotModel(temporal_class):
        """Only observes the state passed to the original prediction function."""
        def predict(self, state, student_idx, item_idx, q):
            idx = self.capture_indices[:, self.capture_column]
            self.capture_column += 1
            take = np.flatnonzero((idx >= 0) & self.capture_anchors[np.maximum(idx, 0)])
            if len(take):
                row = torch.as_tensor(take, device=q.device)
                kc = q[row].argmax(1)
                # Input checkpoint is strictly none: original P/N arithmetic.
                a = 1 + state.evidence.positive[row, kc].clamp_min(0)
                b = 1 + state.evidence.negative[row, kc].clamp_min(0)
                self.captured_values.append(torch.stack((a, b), 1).clone())
                self.captured_ids.append(idx[take].copy())
            return super().predict(state, student_idx, item_idx, q)
    return SnapshotModel


@torch.no_grad()
def replay_reference(model, data, users, plan, device, batch_size=8, chunk_size=100, progress=None):
    anchor_mask = np.zeros(len(data.arrays["label"]), bool)
    anchor_mask[plan["anchor"]] = True
    model.capture_anchors = anchor_mask
    captures, capture_ids, predictions = [], [], []
    wanted = set(map(int, users))
    # Preserve the original student batches (including companion rows) so a
    # 32-user preflight does not change GEMM shapes/numerics relative to full
    # checkpoint evaluation. Only selected users contribute records/anchors.
    batches = [(chosen, sequences) for chosen, sequences in data.batches("valid", batch_size)
               if any(int(u) in wanted for u in chosen)]
    for bno, (chosen, sequences) in enumerate(batches, 1):
        selected_rows = np.array([int(u) in wanted for u in chosen])
        state = model.init_state(len(chosen), device)
        for batch, indices in data.chunks(chosen, sequences, "valid", chunk_size, device):
            model.capture_indices, model.capture_column = indices, 0
            model.captured_values, model.captured_ids = [], []
            outputs, state = model.forward_chunk(
                state, batch["student_idx"], batch["item_idx"], batch["q"], batch["label"],
                batch["active_mask"], timestamp=batch["timestamp"])
            if model.captured_values:
                captures.append(torch.cat(model.captured_values).cpu().numpy())
                capture_ids.append(np.concatenate(model.captured_ids))
            mask = batch["target_mask"].cpu().numpy() & selected_rows[:, None]
            if mask.any():
                rows = {"record_idx": indices[mask]}
                for key in ("probability", "uncertainty", "evidence"):
                    rows[key] = outputs[key].cpu().numpy()[mask]
                predictions.append(pd.DataFrame(rows))
        if progress and (bno == 1 or bno % 25 == 0 or bno == len(batches)):
            progress({"phase": "reference_replay", "batches": bno, "total_batches": len(batches)})
    if not predictions:
        raise ValueError("No validation records")
    frame = pd.concat(predictions, ignore_index=True).sort_values("record_idx").reset_index(drop=True)
    np.testing.assert_array_equal(frame.record_idx, plan["validation_records"])
    if captures:
        order = np.argsort(np.concatenate(capture_ids))
        np.testing.assert_array_equal(np.concatenate(capture_ids)[order], plan["anchor"])
        ab = np.concatenate(captures)[order]
    else:
        ab = np.empty((0, 2), np.float32)
    return frame, ab


def interventions(ab, gap, half_life_hours):
    if not np.isfinite(half_life_hours) or half_life_hours <= 0:
        raise ValueError("Invalid half life")
    if not np.isfinite(ab).all() or (ab <= 0).any() or (ab.sum(1) < 2-1e-6).any():
        raise ValueError("Invalid common Beta state")
    if not np.isfinite(gap).all() or (gap < 0).any():
        raise ValueError("Invalid elapsed time")
    ab = ab.astype(np.float64)
    total = ab.sum(1)
    d = np.exp(-math.log(2) * gap / half_life_hours)
    next_total = 2 + (total-2) * d
    joint = 1 + (ab-1) * d[:, None]
    mass = ab * (next_total/total)[:, None]
    mean = joint * (total/next_total)[:, None]
    values = np.stack((ab, mass, mean, joint, ab, mean), 1)
    scales = np.ones((len(ab), len(MODES)), np.float64)
    scales[:, 4:] = (total/next_total)[:, None]
    return values, scales


@torch.no_grad()
def branch_predictions(model, arrays, plan, ab, device, half_life_hours=168., batch_size=128):
    """Intervene once at h=0; ordinary observations thereafter, no extra decay."""
    state, scales = interventions(ab, plan["gap_hours"], half_life_hours)
    output = []
    keys = ("probability", "mean_before", "support_before", "mean_after", "support_after", "write_gain")
    users = arrays["student_idx"][plan["anchor"]]
    paths = plan["paths"]
    for start in range(0, len(ab), batch_size):
        end = min(start+batch_size, len(ab))
        for h in range(paths.shape[1]):
            local = np.flatnonzero(paths[start:end, h] >= 0)
            if not len(local):
                continue
            ix = local+start
            record = paths[ix, h]
            item = arrays["item_idx"][record]
            student = torch.as_tensor(users[ix], dtype=torch.long, device=device)
            items = torch.as_tensor(item, dtype=torch.long, device=device)
            q = torch.as_tensor(arrays["item_q"][item].astype(np.float32), device=device)
            # Same difficulty-only write strength for every branch, with no label used in readout.
            difficulty = (torch.sigmoid(model.item_difficulty_logit(items)) * q).sum(-1)
            results = {}
            for j, mode in enumerate(MODES):
                pair = state[ix, j]
                alpha = torch.where(q > 0, torch.as_tensor(pair[:, 0], dtype=q.dtype, device=device)[:, None], torch.ones_like(q))
                beta = torch.where(q > 0, torch.as_tensor(pair[:, 1], dtype=q.dtype, device=device)[:, None], torch.ones_like(q))
                # Do not clamp alpha/beta to >=1. This preserves mean in the mass branch.
                p = model.predict_from_beta(alpha, beta, student, items, q)["probability"].cpu().numpy()
                results[mode] = {"probability": p, "mean_before": pair[:, 0]/pair.sum(1),
                                 "support_before": pair.sum(1)}
            # All predictions above have been made before observing current labels.
            y = torch.as_tensor(arrays["label"][record], dtype=q.dtype, device=device)
            inc = model.evidence_increment(q, y, difficulty, torch.ones(len(ix), dtype=torch.bool, device=device))
            weight = torch.stack((inc.positive.sum(1), inc.negative.sum(1)), 1).cpu().numpy().astype(np.float64)
            for j, mode in enumerate(MODES):
                delta = weight * scales[ix, j, None]
                prior_total = state[ix, j].sum(1)
                state[ix, j] += delta
                total = state[ix, j].sum(1)
                results[mode].update(mean_after=state[ix, j, 0]/total, support_after=total,
                                     write_gain=delta.sum(1)/(prior_total+delta.sum(1)))
            rows = {"anchor_record_idx": plan["anchor"][ix], "record_idx": record,
                    "student_idx": users[ix], "item_idx": item, "horizon": h,
                    "label": arrays["label"][record], "gap_hours": plan["gap_hours"][ix],
                    "prior_count": plan["prior_count"][ix], "anchor_tied": plan["anchor_tied"][ix],
                    "available_horizon": (paths[ix] >= 0).sum(1)-1}
            for mode in MODES:
                for key in keys:
                    rows[f"{mode}_{key}"] = results[mode][key]
            output.append(pd.DataFrame(rows))
    columns = ["anchor_record_idx", "horizon", "record_idx"]
    return pd.concat(output, ignore_index=True).sort_values(columns).reset_index(drop=True) if output else pd.DataFrame(columns=columns)


def bootstrap_pairs(frame, repetitions=1000, seed=20260928):
    if not len(frame):
        return []
    students, inverse = np.unique(frame.student_idx.to_numpy(), return_inverse=True)
    y = frame.label.to_numpy(dtype=float)
    pairs = [(mode, "none") for mode in ("mass", "mean", "joint")]
    pairs += [("joint", "mean"), ("joint", "mass")]
    sums = []
    for left, right in pairs:
        lp = frame[f"{left}_probability"].to_numpy(dtype=float).clip(1e-7, 1-1e-7)
        rp = frame[f"{right}_probability"].to_numpy(dtype=float).clip(1e-7, 1-1e-7)
        d = -(y*np.log(lp)+(1-y)*np.log1p(-lp)) + (y*np.log(rp)+(1-y)*np.log1p(-rp))
        sums.append(np.bincount(inverse, weights=d, minlength=len(students)))
    sums = np.array(sums).T
    counts = np.bincount(inverse, minlength=len(students))
    draws = []
    rng = np.random.default_rng(seed)
    for start in range(0, repetitions, 32):
        ix = rng.integers(0, len(students), size=(min(32, repetitions-start), len(students)))
        draws.append(sums[ix].sum(1)/counts[ix].sum(1)[:, None])
    draws = np.concatenate(draws)
    return [{"candidate": left, "reference": right,
             "delta_nll": float(sums[:, j].sum()/counts.sum()),
             "ci95": np.quantile(draws[:, j], [.025, .975]).tolist(),
             "student_macro_delta_nll": float((sums[:, j]/counts).mean()),
             "students": len(students)} for j, (left, right) in enumerate(pairs)]


def summarize(frame, metric_function, repetitions=1000):
    if frame.empty:
        return {"groups": {}, "note": "No eligible anchors; smoke may still pass engineering checks."}
    groups = {"all_anchors_h0": frame.horizon == 0,
              "untied_anchors_h0": (frame.horizon == 0) & ~frame.anchor_tied,
              "matched_next1_h0": (frame.horizon == 0) & (frame.available_horizon >= 1),
              "matched_next1_h1": frame.horizon == 1}
    for h in (0, 1, 3, 5):
        groups[f"matched_next5_h{h}"] = (frame.horizon == h) & (frame.available_horizon >= 5)
    report = {"groups": {}, "bootstrap": {"repetitions": repetitions, "seed": 20260928,
              "unit": "student cluster", "limits": "Pointwise exploratory intervals conditional on one frozen checkpoint; no multiplicity correction, no training-seed uncertainty."}}
    for group, mask in groups.items():
        f = frame.loc[mask]
        report["groups"][group] = {"n": len(f), "students": int(f.student_idx.nunique()),
            "observed_rate": float(f.label.mean()) if len(f) else None,
            "models": {mode: metric_function(f.label.to_numpy(), f[f"{mode}_probability"].to_numpy()) for mode in MODES},
            "paired_nll": bootstrap_pairs(f, repetitions)}
    return report


def check_invariants(frame, reference, atol=1e-6):
    if frame.empty:
        return {"success": True, "n": 0, "note": "No anchor invariant exercised"}
    expected = reference.set_index("record_idx").loc[frame.record_idx, "probability"].to_numpy()
    h0 = frame.horizon.to_numpy() == 0
    differences = {"none_matches_original_window": float(np.max(np.abs(frame.none_probability-expected)))}
    for left, right, mask, name in (
        ("mass", "none", h0, "anchor_mass_equals_none"),
        ("joint", "mean", h0, "anchor_joint_equals_mean"),
        ("mass", "write_rescale", np.ones(len(frame), bool), "mass_equals_rescaled_writes_all_horizons"),
        ("joint", "mean_write_rescale", np.ones(len(frame), bool), "joint_equals_mean_and_rescaled_writes_all_horizons")):
        d = frame[f"{left}_probability"].to_numpy()-frame[f"{right}_probability"].to_numpy()
        differences[name] = float(np.max(np.abs(d[mask])))
    return {"success": all(np.isfinite(x) and x <= atol for x in differences.values()),
            "n": len(frame), "atol": atol, "max_absolute_difference": differences,
            "interpretation": "Algebra/implementation checks, NOT evidence that a treatment improves real learning."}
