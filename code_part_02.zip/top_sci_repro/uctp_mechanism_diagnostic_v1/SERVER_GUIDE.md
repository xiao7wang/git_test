# 服务器操作指南：免重训机制诊断

请只复制命令，不复制 (base)/(yydw) 提示符。全部使用 yydw 的绝对 Python 路径，不需要在 base 安装包。

这一次最多做两个全量验证历史重放，不是重跑 12 个模型，也没有训练 epoch。先运行小检查，失败自动停止；成功后才进入 full。不要同时启动多套。

## 1. 上传独立包

将桌面的 uctp_mechanism_diagnostic_v1.zip 上传到服务器：

    /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1.zip

不覆盖 uctp_cd_temporal_v1，也不覆盖 uctp_cd_clean_research。

## 2. 解压（目录已存在就停止，不覆盖）

    cd /home/wangxiao/QCCDM/top_sci_repro
    if [ -e /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1 ]; then
      printf '%s\n' '目录已存在，请停止，不要覆盖。把终端输出发给我。'
    else
      /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e \
        /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1.zip \
        /home/wangxiao/QCCDM/top_sci_repro
    fi

确认入口文件存在：

    ls -l /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/run_suite.py

若不存在，不继续。ZIP 是压缩包，在 VS Code 中提示二进制文件正常，不要把 ZIP 当源码打开编辑。

## 3. 新建 tmux 会话

在一个普通 SSH 终端中执行（不要在已处于 tmux 的分屏里再套一层）：

    tmux new-session -s mechanism_diag_0928

若提示会话已存在，先连接检查，不要重复开作业：

    tmux attach-session -t mechanism_diag_0928

## 4. 在 tmux 内执行这一条完整命令

    CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 \
    /home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/run_suite.py \
      --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1 \
      --data-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/outputs/server_01 \
      --device cuda \
      --full \
      --ack-row-feedback \
      --ack-time-proxy

运行器默认读取已经完成的这两个旧 checkpoint：

    uctp_cd_temporal_v1/outputs/server_assist_full_pilot_e20_p5_seed0_01/runs/dynamic_only_none_seed0/best_model.pt
    uctp_cd_temporal_v1/outputs/server_ednet_full_pilot_e20_p5_seed0_01/runs/dynamic_only_none_seed0/best_model.pt

也需要各自同目录的 status.json、run_config.json、validation_predictions.csv。原完整数据目录需要 manifest.json、records.npz、vocabulary.json。

如果这些路径与实际目录不同，先发完整缺失提示，不要随便换成旧 clean baseline 或其他模式的 checkpoint。脚本也会检查指纹，不能绕过。

执行顺序：

1. 29 项 CPU 测试。
2. 29 项 GPU 测试。
3. ASSIST / EDNet 各随机 32 名目标学生预检，使用 full checkpoint + full data，不是重建 smoke data。
4. 同样目标学生，chunk-size=17 重检；跨 chunk 输出对齐后显示 CHUNK_COMPARISON_PASSED。
5. ASSIST 全验证集机制诊断。
6. EDNet 全验证集机制诊断。
7. 自动打包 diagnostic_results.zip，显示 ALL_DIAGNOSTICS_COMPLETED。

源代码验证、旧预测重现、数学等价性检查任何一项失败都会停止。不会因为某个方案的分数差就停止，也不会据此自动调参。

如果只想先预检，在第一次执行前去掉 --full。之后要跑 full 必须换全新的 output-root，例如 server_02；不要覆盖 server_01。默认建议按上面的完整命令一次完成。

开始后需要离开：按 Ctrl+B，松开，再按 D。不要按 Ctrl+C，Ctrl+C 会中断前台作业。复制终端文本优先用鼠标右键菜单。

## 5. 看进度

在另一个 SSH 终端读取：

    /home/wangxiao/miniconda3/envs/yydw/bin/python -B \
      /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/show_results.py \
      --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/outputs/server_01

看当前作业日志，例如 EDNet full：

    tail -n 40 /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/outputs/server_01/ednet_full.log

实际存活进程：

    pgrep -a -u wangxiao -f 'uctp_mechanism_diagnostic_v1/(run_suite[.]py|run_diagnostic[.]py|test_diagnostic[.]py)'

日志每 25 个原学生 batch 输出一次 reference_replay 进度。suite_status.json 的 running 只是保存状态，不证明进程还在运行。

耗时不能用本地 CPU 小数据秒数推算服务器 full。工作量是两个冻结模型的历史重放和少量分支推断，远少于原先的多模型、多 epoch 训练；准确时间看服务器日志。当前未在服务器跑过，不承诺固定小时数。

## 6. 完成后给我什么

把这个文件下载到本地发给我：

    /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1/outputs/server_01/diagnostic_results.zip

无需再次上传 checkpoint 或全部数据。包中包含原预测桥接、参数不变检查、分支结果、汇总、日志和所用配置。

正常 full 数量预计与已审核数据一致：

| 数据集 | 验证记录 | 严格长间隔起点 | 有下一次窗口 | 有后续 5 次窗口 |
|---|---:|---:|---:|---:|
| ASSIST | 255,916 | 34,515 | 15,618 | 3,615 |
| EDNet | 209,028 | 27,137 | 9,702 | 843 |

数量不同先检查数据和分组，不先解释性能差异。三种等价性检查应该在浮点容差内相同，这不是方法效果好坏。真正要看的是当前调整与后续反馈更新各自带来的损失变化，以及是否值得继续研究。

## 7. 遇到报错

- 输出目录已存在：保护旧结果，不删除、不覆盖；确认没有活跃作业后再决定新编号。
- 指纹不同：停止，给我报错，不增加“忽略检查”参数。
- CPU/GPU 测试失败：发送相应 tests_cpu.log / tests_cuda.log；不要继续 full。
- reference_bridge 失败：发送 reference_bridge.json 及该作业日志，不调整容差来强行通过。
- invariants 失败：发送 invariants.json；不得把不一致当成发现新机制。
- 缺文件：发送提示的具体路径。不要改用别的 checkpoint 冒充。
- 脚本不修改原模型；失败结果保存在独立目录。没有自动续跑，从头重试需要新的目录。

仍使用逐行即时反馈假设与时间戳代理；真实 EDNet 反馈边界未核实。本次不是反馈协议修复实验，也不是新模型的最终泛化测试。
