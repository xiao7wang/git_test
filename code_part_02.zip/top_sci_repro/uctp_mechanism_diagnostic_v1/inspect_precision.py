"""Read-only replay of an existing small diagnostic; never trains or writes files.

Prints float64 state ratios, actual float32 readout inputs, and a float64
copy-of-head comparison. This diagnoses failures; it does NOT waive invariants.
"""
import sys
sys.dont_write_bytecode = True

import argparse
import copy
import json
import os
from pathlib import Path

from run_diagnostic import import_project, read_json, sha256, check_reference


def emit(value):
    print(json.dumps(value, ensure_ascii=False, allow_nan=False), flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run-dir", required=True,
                   help="Existing small preflight directory containing diagnostic_config.json")
    args = p.parse_args()
    folder = Path(args.run_dir).resolve()
    meta_path = folder / "diagnostic_config.json"
    meta_hash = sha256(meta_path)
    meta = read_json(meta_path)
    a = meta["args"]
    users = meta["selected_students"]
    if not users or len(users) > 32 or a.get("max_students") is None:
        raise ValueError("Only an existing preflight of at most 32 target students is allowed")
    if not a.get("ack_row_feedback") or not a.get("ack_time_proxy"):
        raise ValueError("Existing run must acknowledge the unchanged feedback/time assumptions")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    Data, Temporal, _, set_seed, choose_device = import_project(a["project_dir"])
    import numpy as np
    import pandas as pd
    import torch
    from mechanism_core import (MODES, parameter_digest, snapshot_model_class,
                                plan_windows, replay_reference, branch_predictions,
                                check_invariants)
    torch.set_num_threads(a["threads"])
    set_seed(0)
    device = choose_device(a["device"])
    checkpoint = Path(a["checkpoint"])
    original_path = checkpoint.parent / "validation_predictions.csv"
    if sha256(checkpoint) != meta["checkpoint_sha256"]:
        raise ValueError("Checkpoint changed since failed/preflight run")
    if sha256(original_path) != meta["reference_sha256"]:
        raise ValueError("Original validation predictions changed")
    ckpt = torch.load(checkpoint, map_location="cpu", weights_only=True)
    cfg = ckpt["model_config"]
    if cfg != meta["model_config"] or cfg["time_mode"] != "none" or cfg["decay_rate_per_hour"] != 0:
        raise ValueError("Expected the exact original none checkpoint")
    data = Data(a["data_dir"])
    if data.fingerprint != meta["data_fingerprint"] or data.fingerprint != ckpt["data_fingerprint"]:
        raise ValueError("Prepared data fingerprint changed")
    model = snapshot_model_class(Temporal)(**cfg).to(device)
    model.load_state_dict(ckpt["model_state"], strict=True)
    del ckpt
    model.eval().requires_grad_(False)
    before = parameter_digest(model)
    if before != meta["parameter_sha256_before"]:
        raise ValueError("Parameter digest does not match original preflight")
    plan = plan_windows(data.arrays, np.asarray(users))
    emit({"phase": "precision_probe", "read_only": True, "students": len(users),
          "validation_records": len(plan["validation_records"]), "anchors": len(plan["anchor"]),
          "device": str(device), "numpy": np.__version__, "pandas": pd.__version__,
          "torch": str(torch.__version__)})
    reference, ab = replay_reference(model, data, users, plan, device,
                                    a["batch_size"], a["chunk_size"], emit)
    columns = ["record_idx", "student_idx", "item_idx", "label", "split", "timestamp",
               "probability", "uncertainty", "evidence"]
    old = pd.read_csv(original_path, usecols=columns)
    bridge = check_reference(reference, old, data.arrays, plan["validation_records"], a["atol"])
    emit({"phase": "reference_bridge", **bridge})
    if not bridge["success"]:
        raise AssertionError("Reference bridge failed; do not interpret precision comparisons")

    # Match each unmodified branch call to its anchor IDs and horizon.
    contexts = []
    batch_size = a["branch_batch_size"]
    paths = plan["paths"]
    for start in range(0, len(ab), batch_size):
        end = min(start + batch_size, len(ab))
        for horizon in range(paths.shape[1]):
            ix = np.flatnonzero(paths[start:end, horizon] >= 0) + start
            if len(ix):
                for mode in MODES:
                    contexts.append((ix, horizon, mode))
    captures = {}
    call_count = 0
    original_predict = model.predict_from_beta

    def tapped_predict(alpha, beta, student, item, q):
        nonlocal call_count
        result = original_predict(alpha, beta, student, item, q)
        ix, horizon, mode = contexts[call_count]
        call_count += 1
        record = paths[ix, horizon]
        np.testing.assert_array_equal(student.cpu().numpy(), data.arrays["student_idx"][record])
        np.testing.assert_array_equal(item.cpu().numpy(), data.arrays["item_idx"][record])
        row = torch.arange(len(ix), device=device)
        kc = q.argmax(1)
        aa, bb = alpha[row, kc], beta[row, kc]
        packed = torch.stack((aa, bb, aa / (aa + bb), result["probability"]), 1).cpu().numpy()
        for index, values in zip(ix, packed):
            captures[(int(plan["anchor"][index]), horizon, mode)] = values
        return result

    model.predict_from_beta = tapped_predict
    try:
        frame = branch_predictions(model, data.arrays, plan, ab, device,
                                   a["half_life_hours"], batch_size)
    finally:
        del model.predict_from_beta
    if call_count != len(contexts):
        raise AssertionError("Capture did not match original branch call order")
    invariant = check_invariants(frame, reference, a["atol"])
    emit({"phase": "original_invariants_not_waived", **invariant})
    if not len(frame):
        raise ValueError("No anchors to inspect")

    comparisons = [("mass", "write_rescale"), ("joint", "mean_write_rescale")]
    # This copy is ONLY a numerical reference. Original model stays float32 and unchanged.
    precise = copy.deepcopy(model).cpu().double().eval().requires_grad_(False)
    with torch.no_grad():
        for left, right in comparisons:
            delta = np.abs(frame[f"{left}_probability"] - frame[f"{right}_probability"]).to_numpy()
            worst = frame.iloc[int(delta.argmax())]
            key = (int(worst.anchor_record_idx), int(worst.horizon))
            values = [captures[(*key, mode)] for mode in (left, right)]
            for mode, captured in zip((left, right), values):
                if float(captured[3]) != float(worst[f"{mode}_probability"]):
                    raise AssertionError("Captured probability does not equal unmodified branch output")
            means64 = [float(worst[f"{mode}_mean_before"]) for mode in (left, right)]
            student = torch.tensor([int(worst.student_idx)] * 2, dtype=torch.long)
            item = torch.tensor([int(worst.item_idx)] * 2, dtype=torch.long)
            q = torch.tensor(data.arrays["item_q"][[int(worst.item_idx)] * 2], dtype=torch.float64)
            ratio = torch.tensor(means64, dtype=torch.float64)[:, None]
            alpha = torch.where(q > 0, ratio, torch.ones_like(q))
            beta = torch.where(q > 0, 1 - ratio, torch.ones_like(q))
            p64 = precise.predict_from_beta(alpha, beta, student, item, q)["probability"].numpy()
            # Isolate the error already present in the float32 alpha/beta operands.
            aa = torch.tensor([float(v[0]) for v in values], dtype=torch.float64)[:, None]
            bb = torch.tensor([float(v[1]) for v in values], dtype=torch.float64)[:, None]
            pa = torch.where(q > 0, aa, torch.ones_like(q))
            pb = torch.where(q > 0, bb, torch.ones_like(q))
            rounded64 = precise.predict_from_beta(pa, pb, student, item, q)["probability"].numpy()
            emit({"phase": "worst_pair", "pair": [left, right],
                  "anchor_record_idx": key[0], "horizon": key[1], "record_idx": int(worst.record_idx),
                  "probability32": [float(v[3]) for v in values],
                  "max_probability_difference32": float(delta.max()),
                  "rows_exceeding_original_atol": int((delta > a["atol"]).sum()),
                  "state_mean64_at_worst": means64,
                  "state_mean64_max_difference_all_rows": float(np.abs(frame[f"{left}_mean_before"] - frame[f"{right}_mean_before"]).max()),
                  "state_mean64_max_difference_after_updates": float(np.abs(frame[f"{left}_mean_after"] - frame[f"{right}_mean_after"]).max()),
                  "actual_alpha_beta32": [[float(v[0]), float(v[1])] for v in values],
                  "actual_readout_mean32": [float(v[2]) for v in values],
                  "support64_at_worst": [float(worst[f"{mode}_support_before"]) for mode in (left, right)],
                  "float64_head_from_state_means": p64.tolist(),
                  "float64_head_from_state_means_difference": float(abs(p64[0] - p64[1])),
                  "float64_head_from_rounded_alpha_beta": rounded64.tolist(),
                  "float64_head_from_rounded_alpha_beta_difference": float(abs(rounded64[0] - rounded64[1]))})
    if parameter_digest(model) != before:
        raise AssertionError("Original model parameters changed")
    if sha256(checkpoint) != meta["checkpoint_sha256"] or sha256(original_path) != meta["reference_sha256"]:
        raise AssertionError("Original input changed")
    if sha256(meta_path) != meta_hash or sha256(data.path / "manifest.json") != data.fingerprint:
        raise AssertionError("Configuration/data manifest changed")
    import_project(a["project_dir"])
    emit({"phase": "precision_probe_complete", "original_parameters_unchanged": True,
          "files_written": False, "trained": False, "test_evaluated": False,
          "original_invariants_passed": invariant["success"],
          "note": "Diagnostic only: no tolerance changed, no failed check bypassed, no full run started."})


if __name__ == "__main__":
    main()
