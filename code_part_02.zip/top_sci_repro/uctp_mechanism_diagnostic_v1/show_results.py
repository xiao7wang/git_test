"""Read saved status/results; never launches or changes an experiment."""
import argparse
from pathlib import Path
from run_diagnostic import read_json

p = argparse.ArgumentParser()
p.add_argument("--output-root",required=True)
a = p.parse_args()
root = Path(a.output_root)
status = read_json(root/"suite_status.json")
print(f"Suite status: {status['status']}; active_job={status.get('active_job','-')}")
print("A saved running status is not proof of a live process.")
for job in status["jobs"]:
    print(f"{job['name']:<22} returncode={job['returncode']} seconds={job['seconds']:.1f}")
for ds in ("assist","ednet"):
    folder = root/f"{ds}_full"
    if not (folder/"summary.json").is_file():
        continue
    s = read_json(folder/"status.json")
    if s["status"] != "complete":
        continue
    r = read_json(folder/"summary.json")
    print(f"\n{ds.upper()} anchors={s['anchors']} valid_records={s['validation_records']}")
    print(f"Reference bridge: {read_json(folder/'reference_bridge.json')['success']}; invariants: {read_json(folder/'invariants.json')['success']}")
    for group in ("all_anchors_h0","matched_next1_h0","matched_next1_h1","matched_next5_h5"):
        g = r.get("groups",{}).get(group)
        if not g:
            continue
        print(f"{group}: n={g['n']} students={g['students']}")
        for mode in ("none","mass","mean","joint"):
            m = g["models"][mode]
            auc = "NA" if m["auc"] is None else f"{m['auc']:.6f}"
            nll = "NA" if m["nll"] is None else f"{m['nll']:.6f}"
            print(f"  {mode:<6} AUC={auc} NLL={nll}")
print(f"\nUpload after completion: {root/'diagnostic_results.zip'}")
