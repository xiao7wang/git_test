import csv
import json
from pathlib import Path
from collections import defaultdict

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")

DATASETS = {
    "assistments_time": {
        "split_dir": ROOT / "unified_experiments/splits/assistments_time",
        "q_path": ROOT / "unified_experiments/data/assistments_time/q.csv",
        "config_path": ROOT / "unified_experiments/data/assistments_time/config.json",
        "out_dir": ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time",
    },
    "ednet": {
        "split_dir": ROOT / "unified_experiments/splits/ednet",
        "q_path": ROOT / "unified_experiments/data/ednet/q.csv",
        "config_path": ROOT / "unified_experiments/data/ednet/config.json",
        "out_dir": ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/ednet",
    },
}

def read_q_skill_map(q_path):
    skill_map = {}
    with open(q_path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.reader(f)
        for row_idx, row in enumerate(reader):
            skills = []
            for col_idx, x in enumerate(row):
                try:
                    v = float(x)
                except Exception:
                    v = 0.0
                if v != 0:
                    # NeuralCDM 原始数据 knowledge_code 使用 1-based 编号
                    skills.append(col_idx + 1)
            skill_map[row_idx] = skills
    return skill_map

def get_skills(skill_map, exer_id):
    eid = int(float(exer_id))

    # 当前 HyperCDM/统一数据的 exercise_id 通常可直接作为 q.csv 行索引；
    # 如果该行为空，则回退到 eid-1，兼容 0-based 数据。
    skills = skill_map.get(eid, [])
    if not skills:
        skills = skill_map.get(eid - 1, [])
    if not skills:
        skills = [1]
    return skills

def read_config(config_path):
    cfg = json.loads(config_path.read_text(encoding="utf-8"))
    return {
        "student_n": int(cfg["student_num"]),
        "exer_n": int(cfg["exercise_num"]),
        "knowledge_n": int(cfg["knowledge_num"]),
    }

def convert_train(csv_path, skill_map):
    rows = []
    with open(csv_path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append({
                "user_id": int(float(r["student_id"])),
                "exer_id": int(float(r["exercise_id"])),
                "knowledge_code": get_skills(skill_map, r["exercise_id"]),
                "score": int(float(r["score"])),
                "response_time": float(r["response_time"]),
                "timestamp": int(float(r["timestamp"])),
            })
    return rows

def convert_grouped(csv_path, skill_map):
    groups = defaultdict(list)
    with open(csv_path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        for r in reader:
            sid = int(float(r["student_id"]))
            log = {
                "exer_id": int(float(r["exercise_id"])),
                "score": int(float(r["score"])),
                "knowledge_code": get_skills(skill_map, r["exercise_id"]),
                "response_time": float(r["response_time"]),
                "timestamp": int(float(r["timestamp"])),
            }
            groups[sid].append(log)

    out = []
    for sid in sorted(groups.keys()):
        logs = sorted(groups[sid], key=lambda x: x["timestamp"])
        out.append({
            "user_id": sid,
            "log_num": len(logs),
            "logs": logs,
        })
    return out

for name, info in DATASETS.items():
    print("\n" + "=" * 80)
    print("Preparing NeuralCDM unified data:", name)

    out_dir = info["out_dir"]
    out_dir.mkdir(parents=True, exist_ok=True)

    cfg = read_config(info["config_path"])
    skill_map = read_q_skill_map(info["q_path"])

    train_csv = info["split_dir"] / "train.csv"
    valid_csv = info["split_dir"] / "valid.csv"
    test_csv = info["split_dir"] / "test.csv"

    print("train_csv:", train_csv)
    print("valid_csv:", valid_csv)
    print("test_csv:", test_csv)
    print("out_dir:", out_dir)
    print("config:", cfg)

    train_set = convert_train(train_csv, skill_map)
    val_set = convert_grouped(valid_csv, skill_map)
    test_set = convert_grouped(test_csv, skill_map)

    (out_dir / "train_set.json").write_text(json.dumps(train_set, ensure_ascii=False), encoding="utf-8")
    (out_dir / "val_set.json").write_text(json.dumps(val_set, ensure_ascii=False), encoding="utf-8")
    (out_dir / "test_set.json").write_text(json.dumps(test_set, ensure_ascii=False), encoding="utf-8")

    config_text = "student_n,exer_n,knowledge_n\n{},{},{}\n".format(
        cfg["student_n"], cfg["exer_n"], cfg["knowledge_n"]
    )
    (out_dir / "config.txt").write_text(config_text, encoding="utf-8")

    summary = {
        "dataset": name,
        "train_samples": len(train_set),
        "valid_users": len(val_set),
        "valid_logs": sum(x["log_num"] for x in val_set),
        "test_users": len(test_set),
        "test_logs": sum(x["log_num"] for x in test_set),
        "config": cfg,
        "first_train": train_set[0] if train_set else None,
        "first_valid": val_set[0] if val_set else None,
        "first_test": test_set[0] if test_set else None,
    }
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(summary, ensure_ascii=False, indent=2)[:3000])
    print("saved:", out_dir)

print("\nDone.")
