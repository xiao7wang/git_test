import json
from pathlib import Path
from pprint import pprint

files = [
    "/home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis/data/assist2009/train_0.json",
    "/home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis/data/assistments_time_dynamiccd/train_0.json",
    "/home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis/data/ednet_kt1_time_dynamiccd/train_0.json",
]

for fp in files:
    path = Path(fp)
    print("=" * 120)
    print(path)

    if not path.exists():
        print("MISSING")
        continue

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    print("top type:", type(data))
    print("top len:", len(data))

    if len(data) > 0:
        r = data[0]
        print("record0 type:", type(r))
        try:
            print("record0 len:", len(r))
        except Exception as e:
            print("record0 len error:", e)

        print("record0 full:")
        pprint(r, width=160)

    if len(data) > 1:
        r = data[1]
        print("record1 type:", type(r))
        try:
            print("record1 len:", len(r))
        except Exception as e:
            print("record1 len error:", e)

        print("record1 full:")
        pprint(r, width=160)
