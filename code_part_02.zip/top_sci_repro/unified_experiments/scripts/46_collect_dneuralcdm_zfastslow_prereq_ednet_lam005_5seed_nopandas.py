from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["EDNet", "dNeuralCDM-zfastslow+prereq", 0, 2, 0.7394081040326291, 0.7165355837495455, 0.43195385480830173, 0.7408886495880656, 0.7138773261935142, 0.43298935969376906],
    ["EDNet", "dNeuralCDM-zfastslow+prereq", 1, 2, 0.7371177854685487, 0.7140813670895765, 0.43288292531825323, 0.7384448335803600, 0.7119134110997227, 0.43430323112923114],
    ["EDNet", "dNeuralCDM-zfastslow+prereq", 2, 2, 0.7401437187744675, 0.7155548538951719, 0.43222527951406910, 0.7404693239744338, 0.7123968363535791, 0.43407737229704724],
    ["EDNet", "dNeuralCDM-zfastslow+prereq", 3, 2, 0.7391967679575316, 0.7144688749832558, 0.43250895354141220, 0.7402491503026131, 0.7131475399929811, 0.43328649326463330],
    ["EDNet", "dNeuralCDM-zfastslow+prereq", 4, 2, 0.7392956298914577, 0.7151147214727214, 0.43179596949831356, 0.7398242872586669, 0.7138819745132629, 0.43314759075071835],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_zfastslow_prereq_ednet_lam005_5seed.csv"
summary_path = out_dir / "dneuralcdm_zfastslow_prereq_ednet_lam005_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_zfastslow_prereq_ednet_lam005_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

baseline = {
    "auc": 0.717341,
    "acc": 0.704319,
    "rmse": 0.440954,
    "auc_std": 0.001139,
    "acc_std": 0.001870,
    "rmse_std": 0.000606,
}

zfast = {
    "auc": 0.739367,
    "acc": 0.713123,
    "rmse": 0.433629,
    "auc_std": 0.000371,
    "acc_std": 0.000131,
    "rmse_std": 0.000158,
}

auc, auc_std = summary["test_AUC"]
acc, acc_std = summary["test_ACC"]
rmse, rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-zfastslow+prereq on EDNet, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 2.\n")
    f.write("Prereq lambda = 0.005\n\n")

    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified:\n")
    f.write(f"AUC gain: {auc - baseline['auc']:+.6f}\n")
    f.write(f"ACC gain: {acc - baseline['acc']:+.6f}\n")
    f.write(f"RMSE gain: {rmse - baseline['rmse']:+.6f}\n")

    f.write("\nCompared with dNeuralCDM-zfastslow:\n")
    f.write(f"AUC difference: {auc - zfast['auc']:+.6f}\n")
    f.write(f"ACC difference: {acc - zfast['acc']:+.6f}\n")
    f.write(f"RMSE difference: {rmse - zfast['rmse']:+.6f}\n")

    f.write("\nConclusion: zfastslow+prereq slightly improves AUC and RMSE over zfastslow on EDNet, while ACC is nearly unchanged but marginally lower.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-zfastslow+prereq on EDNet\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write(f"| EDNet | dNeuralCDM-unified | {baseline['auc']:.6f} ± {baseline['auc_std']:.6f} | {baseline['acc']:.6f} ± {baseline['acc_std']:.6f} | {baseline['rmse']:.6f} ± {baseline['rmse_std']:.6f} |\n")
    f.write(f"| EDNet | dNeuralCDM-zfastslow | {zfast['auc']:.6f} ± {zfast['auc_std']:.6f} | **{zfast['acc']:.6f} ± {zfast['acc_std']:.6f}** | {zfast['rmse']:.6f} ± {zfast['rmse_std']:.6f} |\n")
    f.write(f"| EDNet | dNeuralCDM-zfastslow+prereq | **{auc:.6f} ± {auc_std:.6f}** | {acc:.6f} ± {acc_std:.6f} | **{rmse:.6f} ± {rmse_std:.6f}** |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
