import re
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
RES = ROOT / "unified_experiments/results/ours_trg_current_rt"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

pat = re.compile(
    r"\[best\] epoch=(\d+) valid_auc=([0-9.eE+-]+) "
    r"test_auc=([0-9.eE+-]+) test_acc=([0-9.eE+-]+) "
    r"test_rmse=([0-9.eE+-]+) test_precision=([0-9.eE+-]+) "
    r"test_recall=([0-9.eE+-]+) test_f1=([0-9.eE+-]+)"
)

def parse(path):
    text = Path(path).read_text(encoding="utf-8")
    ms = pat.findall(text)
    if not ms:
        raise RuntimeError(f"No [best] line in {path}")
    epoch, valid_auc, auc, acc, rmse, precision, recall, f1 = ms[-1]
    return {
        "best_epoch": int(epoch),
        "valid_AUC": float(valid_auc),
        "AUC": float(auc),
        "ACC": float(acc),
        "RMSE": float(rmse),
        "Precision": float(precision),
        "Recall": float(recall),
        "F1": float(f1),
    }

def collect(dataset_key, tag):
    rows = []
    for seed in range(5):
        if dataset_key == "ednet":
            path = RES / f"ednet_seed{seed}_{tag}_ep8.log"
        elif dataset_key == "assist":
            path = RES / f"assist_seed{seed}_{tag}_ep8.log"
        else:
            raise RuntimeError(f"unknown dataset_key={dataset_key}")
        rows.append(parse(path))
    return rows

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

def stat(rows):
    metrics = ["AUC", "ACC", "RMSE", "Precision", "Recall", "F1"]
    return {m: (mean([r[m] for r in rows]), std([r[m] for r in rows])) for m in metrics}

groups = [
    ("EDNet", "ednet", "Official-style NeuralCDM", "beta0"),
    ("EDNet", "ednet", "Ours-v1 current-rt", "beta005"),
    ("EDNet", "ednet", "Ours-v2 fast-slow", "fastslow_beta005"),
    ("EDNet", "ednet", "Ours-v3 current-rt + prereq", "prereq_lam0p001"),

    ("ASSISTments_time", "assist", "Official-style NeuralCDM", "beta0"),
    ("ASSISTments_time", "assist", "Ours-v1 current-rt", "beta005"),
    ("ASSISTments_time", "assist", "Ours-v2 fast-slow", "fastslow_beta005"),
    ("ASSISTments_time", "assist", "Ours-v3 current-rt + prereq", "prereq_lam0p001"),
]

summary_path = OUT / "final_time_structure_table.md"

stats = {}
with open(summary_path, "w", encoding="utf-8") as f:
    f.write("# Final time-structure enhanced NeuralCDM results\n\n")
    f.write("Protocol: unified student split, 8 epochs, 5 seeds, best epoch selected by validation AUC.\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE | Precision | Recall | F1 |\n")
    f.write("|---|---|---:|---:|---:|---:|---:|---:|\n")

    for dataset_name, dataset_key, model, tag in groups:
        s = stat(collect(dataset_key, tag))
        stats[(dataset_name, model)] = s
        f.write(
            f"| {dataset_name} | {model} | "
            f"{s['AUC'][0]:.6f} ± {s['AUC'][1]:.6f} | "
            f"{s['ACC'][0]:.6f} ± {s['ACC'][1]:.6f} | "
            f"{s['RMSE'][0]:.6f} ± {s['RMSE'][1]:.6f} | "
            f"{s['Precision'][0]:.6f} ± {s['Precision'][1]:.6f} | "
            f"{s['Recall'][0]:.6f} ± {s['Recall'][1]:.6f} | "
            f"{s['F1'][0]:.6f} ± {s['F1'][1]:.6f} |\n"
        )

    f.write("\n## Improvements over Official-style NeuralCDM\n\n")
    f.write("| Dataset | Model | ΔAUC | ΔACC | ΔRMSE | ΔPrecision | ΔRecall | ΔF1 |\n")
    f.write("|---|---|---:|---:|---:|---:|---:|---:|\n")

    for dataset_name in ["EDNet", "ASSISTments_time"]:
        base = stats[(dataset_name, "Official-style NeuralCDM")]
        for model in ["Ours-v1 current-rt", "Ours-v2 fast-slow", "Ours-v3 current-rt + prereq"]:
            cur = stats[(dataset_name, model)]
            f.write(
                f"| {dataset_name} | {model} | "
                f"{cur['AUC'][0] - base['AUC'][0]:+.6f} | "
                f"{cur['ACC'][0] - base['ACC'][0]:+.6f} | "
                f"{cur['RMSE'][0] - base['RMSE'][0]:+.6f} | "
                f"{cur['Precision'][0] - base['Precision'][0]:+.6f} | "
                f"{cur['Recall'][0] - base['Recall'][0]:+.6f} | "
                f"{cur['F1'][0] - base['F1'][0]:+.6f} |\n"
            )

print(summary_path)
print(summary_path.read_text(encoding="utf-8"))
