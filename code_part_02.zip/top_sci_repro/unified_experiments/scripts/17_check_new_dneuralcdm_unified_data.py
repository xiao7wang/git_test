import json
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis/data")

for ds in ["assistments_time_unified_dynamiccd", "ednet_unified_dynamiccd"]:
    print("=" * 100)
    print(ds)
    ds_dir = ROOT / ds
    print((ds_dir / "data_config.txt").read_text(encoding="utf-8"))

    for fn in ["train_0.json", "val_0.json", "test.json"]:
        path = ds_dir / fn
        data = json.load(open(path, encoding="utf-8"))

        seq_n = len(data)
        json_rows = sum(x[1] for x in data)
        pred_rows = sum(x[1] - 1 for x in data)

        min_len = min(x[1] for x in data) if data else 0
        max_len = max(x[1] for x in data) if data else 0

        print(f"{fn}: seq_n={seq_n}, json_rows={json_rows}, pred_rows={pred_rows}, min_len={min_len}, max_len={max_len}")
        if data:
            print("first_student:", data[0][0])
            print("first_log_len:", data[0][1])
            print("first_log:", data[0][2][0])
            print("second_log:", data[0][2][1] if data[0][1] > 1 else None)
