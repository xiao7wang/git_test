from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["EDNet", "dNeuralCDM-fastslow", 0, 2, 0.7383009903512949, 0.7157366477218363, 0.4321577486401612, 0.7392220070059620, 0.7134427082970183, 0.43340311276825344],
    ["EDNet", "dNeuralCDM-fastslow", 1, 2, 0.7384077402846023, 0.7158945213081501, 0.4321350338520548, 0.7395271601151695, 0.7132846654255653, 0.43357821508985870],
    ["EDNet", "dNeuralCDM-fastslow", 2, 2, 0.7386029876790952, 0.7163824942113018, 0.43214517845079914, 0.7388675363803484, 0.7132312097484562, 0.43378228949122400],
    ["EDNet", "dNeuralCDM-fastslow", 3, 2, 0.7389643720114495, 0.7166360487590180, 0.4318015935844365, 0.7389192283555418, 0.7129616072030363, 0.43342943012810080],
    ["EDNet", "dNeuralCDM-fastslow", 4, 2, 0.7388139340550761, 0.7141148554260673, 0.43288133728216255, 0.7390461913421239, 0.7129709038425335, 0.43387447328298456],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_fastslow_ednet_5seed.csv"
summary_path = out_dir / "dneuralcdm_fastslow_ednet_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_fastslow_ednet_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

baseline_auc = 0.717341
baseline_acc = 0.704319
baseline_rmse = 0.440954
baseline_auc_std = 0.001139
baseline_acc_std = 0.001870
baseline_rmse_std = 0.000606

fast_auc, fast_auc_std = summary["test_AUC"]
fast_acc, fast_acc_std = summary["test_ACC"]
fast_rmse, fast_rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-fastslow on EDNet, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 2.\n\n")
    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified on EDNet:\n")
    f.write(f"Baseline test_AUC: {baseline_auc:.6f} ± {baseline_auc_std:.6f}\n")
    f.write(f"Fastslow test_AUC: {fast_auc:.6f} ± {fast_auc_std:.6f}\n")
    f.write(f"AUC gain: {fast_auc - baseline_auc:+.6f}\n\n")

    f.write(f"Baseline test_ACC: {baseline_acc:.6f} ± {baseline_acc_std:.6f}\n")
    f.write(f"Fastslow test_ACC: {fast_acc:.6f} ± {fast_acc_std:.6f}\n")
    f.write(f"ACC gain: {fast_acc - baseline_acc:+.6f}\n\n")

    f.write(f"Baseline test_RMSE: {baseline_rmse:.6f} ± {baseline_rmse_std:.6f}\n")
    f.write(f"Fastslow test_RMSE: {fast_rmse:.6f} ± {fast_rmse_std:.6f}\n")
    f.write(f"RMSE gain: {fast_rmse - baseline_rmse:+.6f}\n\n")

    f.write("Conclusion: dNeuralCDM-fastslow substantially improves over dNeuralCDM-unified on EDNet.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-fastslow on EDNet\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write(f"| EDNet | dNeuralCDM-unified | {baseline_auc:.6f} ± {baseline_auc_std:.6f} | {baseline_acc:.6f} ± {baseline_acc_std:.6f} | {baseline_rmse:.6f} ± {baseline_rmse_std:.6f} |\n")
    f.write(f"| EDNet | dNeuralCDM-fastslow | **{fast_auc:.6f} ± {fast_auc_std:.6f}** | **{fast_acc:.6f} ± {fast_acc_std:.6f}** | **{fast_rmse:.6f} ± {fast_rmse_std:.6f}** |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
