#!/usr/bin/env bash
set -euo pipefail

source /home/wangxiao/miniconda3/etc/profile.d/conda.sh
conda activate cd5090

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD

export NEURALCD_DATA_DIR=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time
export NEURALCD_CONFIG=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time/config.txt
export NEURALCD_MODEL_DIR=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/model_unified/assistments_time_seed0_smoke

mkdir -p "$NEURALCD_MODEL_DIR" logs/unified result model

echo "DATA_DIR=$NEURALCD_DATA_DIR"
echo "CONFIG=$NEURALCD_CONFIG"
echo "MODEL_DIR=$NEURALCD_MODEL_DIR"

python train_original_seed.py cuda:0 2 0 2>&1 | tee logs/unified/assistments_time_seed0_epoch2_train.log
python predict_original_seed.py 2 0 2>&1 | tee logs/unified/assistments_time_seed0_epoch2_test.log
