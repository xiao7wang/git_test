import pandas as pd
from pathlib import Path

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    {
        "Model": "NeuralCDM-unified",
        "ASSISTments_time AUC": "0.684499 ± 0.000072",
        "ASSISTments_time ACC": "0.669128 ± 0.000963",
        "ASSISTments_time RMSE": "0.454681 ± 0.000132",
        "ASSISTments_time F1": "TODO",
        "EDNet AUC": "0.714012 ± 0.000470",
        "EDNet ACC": "0.696100 ± 0.000888",
        "EDNet RMSE": "0.445690 ± 0.000466",
        "EDNet F1": "TODO",
        "Protocol": "Unified student-time 7:1:2 split, 5 seeds",
    }
]

df = pd.DataFrame(rows)

csv_path = out_dir / "current_main_table_unified.csv"
md_path = out_dir / "current_main_table_unified.md"

df.to_csv(csv_path, index=False)
df.to_markdown(md_path, index=False)

print(f"Saved: {csv_path}")
print(f"Saved: {md_path}")
print(df.to_markdown(index=False))
