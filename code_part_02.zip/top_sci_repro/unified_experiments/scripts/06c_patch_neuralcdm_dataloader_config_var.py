from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
P = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_loader.py"

text = P.read_text(encoding="utf-8", errors="ignore")

bak = P.with_suffix(P.suffix + ".bak_config_var_fix")
if not bak.exists():
    bak.write_text(text, encoding="utf-8")

if "import os" not in text:
    text = "import os\n" + text

text = text.replace(
    "config_file = 'config.txt'",
    'config_file = os.environ.get("NEURALCD_CONFIG", "config.txt")'
)

text = text.replace(
    'config_file = "config.txt"',
    'config_file = os.environ.get("NEURALCD_CONFIG", "config.txt")'
)

P.write_text(text, encoding="utf-8")

print("patched:", P)
print("===== check lines =====")
for i, line in enumerate(text.splitlines(), 1):
    if "config_file" in line or "NEURALCD_CONFIG" in line or "knowledge_n" in line:
        print(f"{i}: {line}")
