import csv
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")

TARGETS = {
    "NeuralCDM": ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD",
    "dNeuralCDM": ROOT / "repos/Dynamic-Cognitive-Diagnosis",
    "CausalCDF": ROOT / "repos/CausalCDF/CasualCDF",
    "ORCDF": ROOT / "repos/ORCDF",
    "HyperCDM": ROOT / "repos/HyperCDM",
    "DisenGCD": ROOT / "repos/Intelligent-Education/DisenGCD/DisenGCD",
}

OUT_MD = ROOT / "unified_experiments/results/main/latest_model_format_inspection_compact.md"
OUT_CSV = ROOT / "unified_experiments/results/main/latest_model_format_inspection_compact.csv"
OUT_MD.parent.mkdir(parents=True, exist_ok=True)

def size_mb(p):
    try:
        return p.stat().st_size / 1024 / 1024
    except Exception:
        return -1

def csv_header(p):
    try:
        with open(p, "r", encoding="utf-8", errors="ignore", newline="") as f:
            return next(csv.reader(f), [])
    except Exception as e:
        return [f"READ_ERROR: {e}"]

rows = []
md = ["# Compact Latest Model Format Inspection\n"]

for name, repo in TARGETS.items():
    md.append(f"\n## {name}\n")
    md.append(f"- repo: `{repo}`")
    md.append(f"- exists: {repo.exists()}")
    if not repo.exists():
        continue

    candidates = []
    for ext in ["*.csv", "*.json", "*.txt", "*.pkl", "*.npy"]:
        candidates.extend(repo.rglob(ext))

    filtered = []
    for p in candidates:
        s = str(p).lower()
        if any(x in s for x in ["__pycache__", "log", "result", "checkpoint", ".git"]):
            continue
        if any(x in s for x in ["data", "dataset", "datasets", "config", "q.csv", "q_matrix", "train", "valid", "test"]):
            filtered.append(p)

    filtered = sorted(filtered, key=lambda p: (size_mb(p), str(p)))[:80]

    md.append("| file | size_MB | csv_header_if_any |")
    md.append("|---|---:|---|")

    for p in filtered:
        rel = str(p.relative_to(ROOT))
        sz = size_mb(p)
        header = ""
        if p.suffix.lower() == ".csv":
            header = str(csv_header(p))
        md.append(f"| `{rel}` | {sz:.3f} | `{header}` |")
        rows.append({
            "model": name,
            "file": rel,
            "size_MB": f"{sz:.3f}",
            "suffix": p.suffix,
            "csv_header": header,
        })

with open(OUT_CSV, "w", encoding="utf-8", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=["model", "file", "size_MB", "suffix", "csv_header"])
    writer.writeheader()
    writer.writerows(rows)

OUT_MD.write_text("\n".join(md) + "\n", encoding="utf-8")

print("saved:", OUT_MD)
print("saved:", OUT_CSV)
