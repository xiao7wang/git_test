import csv
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
z_csv = ROOT / "unified_experiments/results/main/dneuralcdm_zfastslow_unified_ednet_5seed.csv"
f_csv = ROOT / "unified_experiments/results/main/dneuralcdm_fastslow_unified_ednet_5seed.csv"

def read_rows(path):
    with open(path, encoding="utf-8") as f:
        return sorted(list(csv.DictReader(f)), key=lambda r: int(r["seed"]))

z = read_rows(z_csv)
f = read_rows(f_csv)

assert [r["seed"] for r in z] == [r["seed"] for r in f]

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

print("Paired comparison: dNeuralCDM-zfastslow EDNet vs dNeuralCDM-fastslow EDNet")
print("Pairing is by seed id.\n")

for m in ["test_AUC", "test_ACC", "test_RMSE"]:
    zvals = [float(r[m]) for r in z]
    fvals = [float(r[m]) for r in f]
    diffs = [a - b for a, b in zip(zvals, fvals)]

    print("=" * 80)
    print(m)
    print("zfastslow:", ", ".join(f"{x:.6f}" for x in zvals))
    print("fastslow :", ", ".join(f"{x:.6f}" for x in fvals))
    print("diff     :", ", ".join(f"{x:+.6f}" for x in diffs))
    print(f"mean diff: {mean(diffs):+.6f} ± {std(diffs):.6f}")

    sd = std(diffs)
    t = mean(diffs) / (sd / math.sqrt(len(diffs))) if sd > 0 else float("inf")
    print(f"paired t statistic: {t:.6f}")

    try:
        from scipy import stats
        tres = stats.ttest_rel(zvals, fvals)
        wres = stats.wilcoxon(diffs, zero_method="wilcox", alternative="two-sided")
        print(f"paired t-test p-value: {tres.pvalue:.8f}")
        print(f"wilcoxon p-value: {wres.pvalue:.8f}")
    except Exception as e:
        print("scipy significance tests skipped:", repr(e))

print("=" * 80)
print("Interpretation:")
print("For AUC and ACC, positive diff means zfastslow is better.")
print("For RMSE, negative diff means zfastslow is better.")
