import json
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
DATA_DIR = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time"
CONFIG = DATA_DIR / "config.txt"

lines = CONFIG.read_text(encoding="utf-8").strip().splitlines()
student_n, exer_n, knowledge_n = map(int, lines[1].split(","))
print("knowledge_n =", knowledge_n)

def fix_codes(codes):
    fixed = []
    bad = []
    for c in codes:
        try:
            x = int(c)
        except Exception:
            bad.append(c)
            continue
        if 1 <= x <= knowledge_n:
            fixed.append(x)
        else:
            bad.append(x)
    if not fixed:
        fixed = [1]
    return sorted(set(fixed)), bad

def scan_and_fix_train(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    bad_count = 0
    max_code = -1
    examples = []

    for row in data:
        codes = row.get("knowledge_code", [])
        for c in codes:
            try:
                max_code = max(max_code, int(c))
            except Exception:
                pass
        fixed, bad = fix_codes(codes)
        if bad:
            bad_count += 1
            if len(examples) < 10:
                examples.append({"before": codes, "bad": bad, "after": fixed, "exer_id": row.get("exer_id")})
        row["knowledge_code"] = fixed

    backup = path.with_suffix(path.suffix + ".bak_before_skill_fix")
    if not backup.exists():
        backup.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return {"file": str(path), "records": len(data), "bad_records": bad_count, "max_code_before": max_code, "examples": examples}

def scan_and_fix_grouped(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    bad_count = 0
    max_code = -1
    examples = []

    for stu in data:
        for log in stu.get("logs", []):
            codes = log.get("knowledge_code", [])
            for c in codes:
                try:
                    max_code = max(max_code, int(c))
                except Exception:
                    pass
            fixed, bad = fix_codes(codes)
            if bad:
                bad_count += 1
                if len(examples) < 10:
                    examples.append({"before": codes, "bad": bad, "after": fixed, "exer_id": log.get("exer_id")})
            log["knowledge_code"] = fixed

    backup = path.with_suffix(path.suffix + ".bak_before_skill_fix")
    if not backup.exists():
        backup.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    return {"file": str(path), "students": len(data), "bad_logs": bad_count, "max_code_before": max_code, "examples": examples}

reports = []
reports.append(scan_and_fix_train(DATA_DIR / "train_set.json"))
reports.append(scan_and_fix_grouped(DATA_DIR / "val_set.json"))
reports.append(scan_and_fix_grouped(DATA_DIR / "test_set.json"))

out = DATA_DIR / "skill_range_fix_report.json"
out.write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")

print(json.dumps(reports, ensure_ascii=False, indent=2)[:5000])
print("saved:", out)
