import pandas as pd
from pathlib import Path

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    {
        "dataset": "ASSISTments_time",
        "model": "NeuralCDM-unified",
        "seed": 0,
        "best_epoch": 3,
        "valid_AUC": 0.705289,
        "valid_ACC": 0.683123,
        "valid_RMSE": 0.446550,
        "test_AUC": 0.684487,
        "test_ACC": 0.667596,
        "test_RMSE": 0.454652,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "NeuralCDM-unified",
        "seed": 1,
        "best_epoch": 3,
        "valid_AUC": 0.705561,
        "valid_ACC": 0.684049,
        "valid_RMSE": 0.446376,
        "test_AUC": 0.684619,
        "test_ACC": 0.669349,
        "test_RMSE": 0.454513,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "NeuralCDM-unified",
        "seed": 2,
        "best_epoch": 3,
        "valid_AUC": 0.705270,
        "valid_ACC": 0.683506,
        "valid_RMSE": 0.446846,
        "test_AUC": 0.684495,
        "test_ACC": 0.669804,
        "test_RMSE": 0.454835,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "NeuralCDM-unified",
        "seed": 3,
        "best_epoch": 3,
        "valid_AUC": 0.705288,
        "valid_ACC": 0.683783,
        "valid_RMSE": 0.446572,
        "test_AUC": 0.684458,
        "test_ACC": 0.668874,
        "test_RMSE": 0.454614,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "NeuralCDM-unified",
        "seed": 4,
        "best_epoch": 3,
        "valid_AUC": 0.705286,
        "valid_ACC": 0.683595,
        "valid_RMSE": 0.446747,
        "test_AUC": 0.684434,
        "test_ACC": 0.670019,
        "test_RMSE": 0.454792,
    },
]

df = pd.DataFrame(rows)

csv_path = out_dir / "neuralcdm_unified_assistments_time_5seed.csv"
summary_path = out_dir / "neuralcdm_unified_assistments_time_5seed_summary.txt"

df.to_csv(csv_path, index=False)

metrics = [
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE",
]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("NeuralCDM-unified on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by valid AUC. All best_epoch = 3.\n\n")
    for m in metrics:
        mean = df[m].mean()
        std = df[m].std(ddof=1)
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(df)

for m in metrics:
    print(f"{m}: {df[m].mean():.6f} ± {df[m].std(ddof=1):.6f}")
