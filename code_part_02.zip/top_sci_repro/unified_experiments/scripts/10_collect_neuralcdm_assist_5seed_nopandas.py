import csv
import math
from pathlib import Path

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["ASSISTments_time", "NeuralCDM-unified", 0, 3, 0.705289, 0.683123, 0.446550, 0.684487, 0.667596, 0.454652],
    ["ASSISTments_time", "NeuralCDM-unified", 1, 3, 0.705561, 0.684049, 0.446376, 0.684619, 0.669349, 0.454513],
    ["ASSISTments_time", "NeuralCDM-unified", 2, 3, 0.705270, 0.683506, 0.446846, 0.684495, 0.669804, 0.454835],
    ["ASSISTments_time", "NeuralCDM-unified", 3, 3, 0.705288, 0.683783, 0.446572, 0.684458, 0.668874, 0.454614],
    ["ASSISTments_time", "NeuralCDM-unified", 4, 3, 0.705286, 0.683595, 0.446747, 0.684434, 0.670019, 0.454792],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE",
]

csv_path = out_dir / "neuralcdm_unified_assistments_time_5seed.csv"
summary_path = out_dir / "neuralcdm_unified_assistments_time_5seed_summary.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

def mean(xs):
    return sum(xs) / len(xs)

def sample_std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

metric_indices = {
    "valid_AUC": 4,
    "valid_ACC": 5,
    "valid_RMSE": 6,
    "test_AUC": 7,
    "test_ACC": 8,
    "test_RMSE": 9,
}

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("NeuralCDM-unified on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by valid AUC. All best_epoch = 3.\n\n")
    for name, idx in metric_indices.items():
        vals = [r[idx] for r in rows]
        f.write(f"{name}: {mean(vals):.6f} ± {sample_std(vals):.6f}\n")

print("Saved:", csv_path)
print("Saved:", summary_path)

for name, idx in metric_indices.items():
    vals = [r[idx] for r in rows]
    print(f"{name}: {mean(vals):.6f} ± {sample_std(vals):.6f}")
