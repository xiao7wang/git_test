import csv
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
fast_csv = ROOT / "unified_experiments/results/main/dneuralcdm_fastslow_unified_ednet_5seed.csv"
base_csv = ROOT / "unified_experiments/results/main/dneuralcdm_unified_ednet_attr4_matched_5seed.csv"

def read_rows(path):
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))

fast = sorted(read_rows(fast_csv), key=lambda r: int(r["seed"]))
base = sorted(read_rows(base_csv), key=lambda r: int(r["seed"]))

assert [r["seed"] for r in fast] == [r["seed"] for r in base]

metrics = ["test_AUC", "test_ACC", "test_RMSE"]

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

print("Paired comparison: dNeuralCDM-fastslow EDNet vs dNeuralCDM attr_idx=4 no-RT matched baseline")
print("Pairing is by seed id.\n")

for m in metrics:
    fvals = [float(r[m]) for r in fast]
    bvals = [float(r[m]) for r in base]
    diffs = [f - b for f, b in zip(fvals, bvals)]

    print("=" * 80)
    print(m)
    print("fastslow:", ", ".join(f"{x:.6f}" for x in fvals))
    print("attr4-noRT:", ", ".join(f"{x:.6f}" for x in bvals))
    print("diff:", ", ".join(f"{x:+.6f}" for x in diffs))
    print(f"mean diff: {mean(diffs):+.6f} ± {std(diffs):.6f}")

    # paired t statistic; p-value optional if scipy exists
    sd = std(diffs)
    t = mean(diffs) / (sd / math.sqrt(len(diffs))) if sd > 0 else float("inf")
    print(f"paired t statistic: {t:.6f}")

    try:
        from scipy import stats
        tres = stats.ttest_rel(fvals, bvals)
        wres = stats.wilcoxon(diffs, zero_method="wilcox", alternative="two-sided")
        print(f"paired t-test p-value: {tres.pvalue:.8f}")
        print(f"wilcoxon p-value: {wres.pvalue:.8f}")
    except Exception as e:
        print("scipy significance tests skipped:", repr(e))

print("=" * 80)
print("Interpretation note:")
print("For AUC and ACC, positive diff means fastslow is better.")
print("For RMSE, negative diff means fastslow is better.")
