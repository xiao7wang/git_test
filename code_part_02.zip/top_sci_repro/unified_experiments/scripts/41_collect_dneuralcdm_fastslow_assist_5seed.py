import pandas as pd
from pathlib import Path

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    {
        "dataset": "ASSISTments_time",
        "model": "dNeuralCDM-fastslow",
        "seed": 0,
        "best_epoch": 1,
        "valid_AUC": 0.7146797853698095,
        "valid_ACC": 0.7156254395973679,
        "valid_RMSE": 0.436463290843726,
        "test_AUC": 0.7087253802370245,
        "test_ACC": 0.7076941283568503,
        "test_RMSE": 0.4399578403694744,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "dNeuralCDM-fastslow",
        "seed": 1,
        "best_epoch": 1,
        "valid_AUC": 0.7150016597607589,
        "valid_ACC": 0.709924350177402,
        "valid_RMSE": 0.43817877829814295,
        "test_AUC": 0.7084664230030535,
        "test_ACC": 0.6989239872553482,
        "test_RMSE": 0.4438747976172694,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "dNeuralCDM-fastslow",
        "seed": 2,
        "best_epoch": 1,
        "valid_AUC": 0.7151699944950034,
        "valid_ACC": 0.7130855436940245,
        "valid_RMSE": 0.4372345155922651,
        "test_AUC": 0.7105885232959697,
        "test_ACC": 0.7055894401456532,
        "test_RMSE": 0.4402217615896465,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "dNeuralCDM-fastslow",
        "seed": 3,
        "best_epoch": 1,
        "valid_AUC": 0.7159488214933007,
        "valid_ACC": 0.7184505853483174,
        "valid_RMSE": 0.4347568441711574,
        "test_AUC": 0.7104931325224655,
        "test_ACC": 0.7125844333181611,
        "test_RMSE": 0.43720033500627226,
    },
    {
        "dataset": "ASSISTments_time",
        "model": "dNeuralCDM-fastslow",
        "seed": 4,
        "best_epoch": 1,
        "valid_AUC": 0.7174944520450457,
        "valid_ACC": 0.7154964910361212,
        "valid_RMSE": 0.4350186987177944,
        "test_AUC": 0.7120070408737321,
        "test_ACC": 0.7067583067819754,
        "test_RMSE": 0.439178790268277,
    },
]

baseline = {
    "model": "dNeuralCDM-unified",
    "test_AUC_mean": 0.706384,
    "test_AUC_std": 0.000717,
    "test_ACC_mean": 0.699302,
    "test_ACC_std": 0.002295,
    "test_RMSE_mean": 0.443269,
    "test_RMSE_std": 0.001233,
}

df = pd.DataFrame(rows)

csv_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed.csv"
summary_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed_table.md"

df.to_csv(csv_path, index=False)

metrics = [
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE",
]

summary = {}
for m in metrics:
    summary[m] = {
        "mean": df[m].mean(),
        "std": df[m].std(ddof=1),
    }

auc_gain = summary["test_AUC"]["mean"] - baseline["test_AUC_mean"]
acc_gain = summary["test_ACC"]["mean"] - baseline["test_ACC_mean"]
rmse_gain = summary["test_RMSE"]["mean"] - baseline["test_RMSE_mean"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-fastslow on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 1.\n\n")

    for m in metrics:
        f.write(f"{m}: {summary[m]['mean']:.6f} ± {summary[m]['std']:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified on ASSISTments_time:\n")
    f.write(f"Baseline test_AUC: {baseline['test_AUC_mean']:.6f} ± {baseline['test_AUC_std']:.6f}\n")
    f.write(f"Fastslow test_AUC: {summary['test_AUC']['mean']:.6f} ± {summary['test_AUC']['std']:.6f}\n")
    f.write(f"AUC gain: {auc_gain:+.6f}\n\n")

    f.write(f"Baseline test_ACC: {baseline['test_ACC_mean']:.6f} ± {baseline['test_ACC_std']:.6f}\n")
    f.write(f"Fastslow test_ACC: {summary['test_ACC']['mean']:.6f} ± {summary['test_ACC']['std']:.6f}\n")
    f.write(f"ACC gain: {acc_gain:+.6f}\n\n")

    f.write(f"Baseline test_RMSE: {baseline['test_RMSE_mean']:.6f} ± {baseline['test_RMSE_std']:.6f}\n")
    f.write(f"Fastslow test_RMSE: {summary['test_RMSE']['mean']:.6f} ± {summary['test_RMSE']['std']:.6f}\n")
    f.write(f"RMSE gain: {rmse_gain:+.6f}\n\n")

    if summary["test_AUC"]["mean"] > baseline["test_AUC_mean"]:
        f.write("Conclusion: dNeuralCDM-fastslow improves over the strong dNeuralCDM-unified baseline on ASSISTments_time.\n")
    else:
        f.write("Conclusion: dNeuralCDM-fastslow does not improve over the strong dNeuralCDM-unified baseline on ASSISTments_time.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-fastslow on ASSISTments_time\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write(
        f"| ASSISTments_time | dNeuralCDM-unified | "
        f"{baseline['test_AUC_mean']:.6f} ± {baseline['test_AUC_std']:.6f} | "
        f"{baseline['test_ACC_mean']:.6f} ± {baseline['test_ACC_std']:.6f} | "
        f"{baseline['test_RMSE_mean']:.6f} ± {baseline['test_RMSE_std']:.6f} |\n"
    )
    f.write(
        f"| ASSISTments_time | dNeuralCDM-fastslow | "
        f"**{summary['test_AUC']['mean']:.6f} ± {summary['test_AUC']['std']:.6f}** | "
        f"**{summary['test_ACC']['mean']:.6f} ± {summary['test_ACC']['std']:.6f}** | "
        f"**{summary['test_RMSE']['mean']:.6f} ± {summary['test_RMSE']['std']:.6f}** |\n"
    )

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(df)
print()
print(open(summary_path, encoding="utf-8").read())
