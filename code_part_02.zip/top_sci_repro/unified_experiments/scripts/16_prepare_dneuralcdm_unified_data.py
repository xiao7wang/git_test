import csv
import json
from pathlib import Path
from collections import defaultdict

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
OUT_ROOT = ROOT / "repos/Dynamic-Cognitive-Diagnosis/data"

DATASETS = {
    "assistments_time": {
        "out_name": "assistments_time_unified_dynamiccd",
        "student_n": 20257,
        "exer_n": 52690,
        "knowledge_n": 218,
    },
    "ednet": {
        "out_name": "ednet_unified_dynamiccd",
        "student_n": 10000,
        "exer_n": 12198,
        "knowledge_n": 141,
    },
}

MAX_LOG = 200
MIN_LOG = 2


def is_number(x):
    try:
        float(x)
        return True
    except Exception:
        return False


def load_q_matrix(q_path, knowledge_n):
    rows = []
    with open(q_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            if not all(is_number(x) for x in row):
                continue
            rows.append(row)

    q_map = {}

    for idx, row in enumerate(rows):
        vals = [float(x) for x in row]

        # Case 1: pure Q matrix, row index is exercise_id.
        if len(vals) == knowledge_n:
            exer_zero = idx
            skill_vals = vals

        # Case 2: first column is exercise_id, followed by Q vector.
        elif len(vals) == knowledge_n + 1:
            exer_zero = int(vals[0])
            skill_vals = vals[1:]
        else:
            raise ValueError(f"Unexpected q row length={len(vals)}, knowledge_n={knowledge_n}, q_path={q_path}")

        skills = [i + 1 for i, v in enumerate(skill_vals) if v > 0]
        if not skills:
            # Extremely rare safeguard. The actual converted data should not hit this.
            skills = [1]
        q_map[exer_zero] = skills

    return q_map


def load_split_csv(path):
    with open(path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    required = ["student_id", "exercise_id", "score"]
    for c in required:
        if c not in reader.fieldnames:
            raise ValueError(f"{path} missing column: {c}. columns={reader.fieldnames}")

    # timestamp may be named timestamp. If absent, keep original order.
    has_ts = "timestamp" in reader.fieldnames

    parsed = []
    for idx, r in enumerate(rows):
        stu = int(float(r["student_id"]))
        exer = int(float(r["exercise_id"]))
        score = int(float(r["score"]))
        ts = float(r["timestamp"]) if has_ts and r["timestamp"] not in ("", None) else idx
        parsed.append({
            "student_id": stu,
            "exercise_id": exer,
            "score": score,
            "timestamp": ts,
            "_row_idx": idx,
        })

    return parsed


def infer_offset(values, expected_n, name):
    mn = min(values)
    mx = max(values)
    if mn == 0 and mx <= expected_n - 1:
        return 1
    if mn >= 1 and mx <= expected_n:
        return 0
    raise ValueError(f"Cannot infer {name} id offset: min={mn}, max={mx}, expected_n={expected_n}")


def build_logs(rows, stu_offset, exer_offset, q_map, skill_comb_to_id):
    out = []
    for order_id, r in enumerate(rows, start=1):
        exer_zero = r["exercise_id"] if exer_offset == 1 else r["exercise_id"] - 1
        skills = q_map.get(exer_zero)
        if skills is None:
            raise KeyError(f"exercise_id={r['exercise_id']} maps to q row={exer_zero}, but q row not found")

        key = "_".join(map(str, skills))
        if key not in skill_comb_to_id:
            skill_comb_to_id[key] = len(skill_comb_to_id) + 1
        skill_comb = skill_comb_to_id[key]

        out.append([
            order_id,
            r["exercise_id"] + exer_offset,
            int(r["score"]),
            skills,
            skill_comb,
        ])
    return out


def chunk_train_student(stu_out_id, rows, stu_offset, exer_offset, q_map, skill_comb_to_id):
    """
    Training chunks:
    - first chunk: first MAX_LOG train rows, predicts from t=2..T, so first row is context-only.
    - subsequent chunks: previous row as context + next MAX_LOG-1 target rows.
    """
    seqs = []
    n = len(rows)
    if n < MIN_LOG:
        return seqs

    start = 0
    first = True
    while start < n:
        if first:
            chunk_rows = rows[start:start + MAX_LOG]
            start += MAX_LOG
            first = False
        else:
            ctx = rows[start - 1]
            target_rows = rows[start:start + MAX_LOG - 1]
            chunk_rows = [ctx] + target_rows
            start += MAX_LOG - 1

        if len(chunk_rows) >= MIN_LOG:
            logs = build_logs(chunk_rows, stu_offset, exer_offset, q_map, skill_comb_to_id)
            seqs.append([stu_out_id, len(logs), logs])

    return seqs


def chunk_eval_student(stu_out_id, context_row, target_rows, stu_offset, exer_offset, q_map, skill_comb_to_id):
    """
    Validation/test chunks:
    - prepend one context interaction from previous split.
    - all predictions t=2..T correspond exactly to target rows.
    """
    seqs = []
    if not target_rows:
        return seqs

    start = 0
    while start < len(target_rows):
        targets = target_rows[start:start + MAX_LOG - 1]
        start += MAX_LOG - 1

        if context_row is not None:
            chunk_rows = [context_row] + targets
        else:
            chunk_rows = targets

        if len(chunk_rows) >= MIN_LOG:
            logs = build_logs(chunk_rows, stu_offset, exer_offset, q_map, skill_comb_to_id)
            seqs.append([stu_out_id, len(logs), logs])

        # For next chunk, use the last target of previous chunk as context.
        if targets:
            context_row = targets[-1]

    return seqs


def group_by_student(rows):
    g = defaultdict(list)
    for r in rows:
        g[r["student_id"]].append(r)
    for stu in g:
        g[stu].sort(key=lambda x: (x["timestamp"], x["_row_idx"]))
    return g


def convert_dataset(ds_name, meta):
    print("=" * 100)
    print("Converting", ds_name)

    split_dir = ROOT / "unified_experiments/splits" / ds_name
    data_dir = ROOT / "unified_experiments/data" / ds_name
    out_dir = OUT_ROOT / meta["out_name"]
    out_dir.mkdir(parents=True, exist_ok=True)

    q_map = load_q_matrix(data_dir / "q.csv", meta["knowledge_n"])

    train_rows = load_split_csv(split_dir / "train.csv")
    valid_rows = load_split_csv(split_dir / "valid.csv")
    test_rows = load_split_csv(split_dir / "test.csv")

    all_rows = train_rows + valid_rows + test_rows
    stu_offset = infer_offset([r["student_id"] for r in all_rows], meta["student_n"], "student")
    exer_offset = infer_offset([r["exercise_id"] for r in all_rows], meta["exer_n"], "exercise")

    print(f"student_id offset for output: +{stu_offset}")
    print(f"exercise_id offset for output: +{exer_offset}")

    train_g = group_by_student(train_rows)
    valid_g = group_by_student(valid_rows)
    test_g = group_by_student(test_rows)

    all_students = sorted(set(train_g) | set(valid_g) | set(test_g))

    skill_comb_to_id = {}

    train_data = []
    valid_data = []
    test_data = []

    raw_counts = {
        "train": len(train_rows),
        "valid": len(valid_rows),
        "test": len(test_rows),
    }

    for stu in all_students:
        stu_out_id = stu + stu_offset

        tr = train_g.get(stu, [])
        va = valid_g.get(stu, [])
        te = test_g.get(stu, [])

        train_data.extend(chunk_train_student(
            stu_out_id, tr, stu_offset, exer_offset, q_map, skill_comb_to_id
        ))

        valid_context = tr[-1] if tr else None
        valid_data.extend(chunk_eval_student(
            stu_out_id, valid_context, va, stu_offset, exer_offset, q_map, skill_comb_to_id
        ))

        test_context = va[-1] if va else (tr[-1] if tr else None)
        test_data.extend(chunk_eval_student(
            stu_out_id, test_context, te, stu_offset, exer_offset, q_map, skill_comb_to_id
        ))

    def pred_count(data):
        return sum(stu[1] - 1 for stu in data)

    def row_count(data):
        return sum(stu[1] for stu in data)

    with open(out_dir / "train_0.json", "w", encoding="utf-8") as f:
        json.dump(train_data, f, ensure_ascii=False)

    with open(out_dir / "val_0.json", "w", encoding="utf-8") as f:
        json.dump(valid_data, f, ensure_ascii=False)

    with open(out_dir / "test.json", "w", encoding="utf-8") as f:
        json.dump(test_data, f, ensure_ascii=False)

    with open(out_dir / "skill_comb_map.json", "w", encoding="utf-8") as f:
        json.dump(skill_comb_to_id, f, ensure_ascii=False, indent=2)

    data_config = {
        "student_n": meta["student_n"],
        "exer_n": meta["exer_n"],
        "knowledge_n": meta["knowledge_n"],
        "skill_comb_n": len(skill_comb_to_id),
        "min_log": MIN_LOG,
        "max_log": MAX_LOG,
        "stu_cnt_train": len(train_data),
        "raw_train_rows": raw_counts["train"],
        "raw_valid_rows": raw_counts["valid"],
        "raw_test_rows": raw_counts["test"],
        "train_seq_n": len(train_data),
        "valid_seq_n": len(valid_data),
        "test_seq_n": len(test_data),
        "train_pred_count": pred_count(train_data),
        "valid_pred_count": pred_count(valid_data),
        "test_pred_count": pred_count(test_data),
    }

    with open(out_dir / "data_config.txt", "w", encoding="utf-8") as f:
        f.write(str(data_config))

    print("out_dir:", out_dir)
    print("raw_counts:", raw_counts)
    print("seq_counts:", {
        "train": len(train_data),
        "valid": len(valid_data),
        "test": len(test_data),
    })
    print("json_row_counts_with_context:", {
        "train": row_count(train_data),
        "valid": row_count(valid_data),
        "test": row_count(test_data),
    })
    print("prediction_counts:", {
        "train": pred_count(train_data),
        "valid": pred_count(valid_data),
        "test": pred_count(test_data),
    })
    print("data_config:", data_config)

    # sanity checks for validation/test: with context, prediction count should equal raw target rows.
    if pred_count(valid_data) != raw_counts["valid"]:
        print("[WARN] valid_pred_count != raw_valid_rows")
    if pred_count(test_data) != raw_counts["test"]:
        print("[WARN] test_pred_count != raw_test_rows")


def main():
    for ds_name, meta in DATASETS.items():
        convert_dataset(ds_name, meta)


if __name__ == "__main__":
    main()
