import json
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
REPO = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD"

print("===== config.txt =====")
config_path = REPO / "config.txt"
if config_path.exists():
    print(config_path.read_text(encoding="utf-8", errors="ignore"))
else:
    print("config.txt not found")

for name in ["train_set.json", "val_set.json", "test_set.json"]:
    p = REPO / "data" / name
    print("\n" + "=" * 80)
    print(name, p, "exists:", p.exists(), "size_MB:", p.stat().st_size / 1024 / 1024 if p.exists() else None)

    if not p.exists():
        continue

    data = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
    print("top_type:", type(data))
    print("top_len:", len(data) if hasattr(data, "__len__") else None)

    if isinstance(data, list) and len(data) > 0:
        print("first_type:", type(data[0]))
        print("first:", data[0])
        if isinstance(data[0], dict):
            print("first_keys:", list(data[0].keys()))
        if isinstance(data[0], list):
            print("first_list_len:", len(data[0]))
            for i, x in enumerate(data[0][:5]):
                print(f"first[{i}] =", x)

print("\n===== python data read/search locations =====")
for py in REPO.rglob("*.py"):
    text = py.read_text(encoding="utf-8", errors="ignore")
    hits = []
    for key in ["train_set", "val_set", "test_set", "config.txt", "json.load", "json.loads", "knowledge_code", "user_id", "exer_id", "item_id"]:
        if key in text:
            hits.append(key)
    if hits:
        print(py.relative_to(REPO), "HITS:", hits)
