import json
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
DATA_DIR = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time"
CONFIG = DATA_DIR / "config.txt"

knowledge_n = int(CONFIG.read_text(encoding="utf-8").strip().splitlines()[1].split(",")[2])
print("knowledge_n =", knowledge_n)

def check_train(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    max_code = -1
    bad = 0
    empty = 0
    for row in data:
        codes = row.get("knowledge_code", [])
        if not codes:
            empty += 1
        for c in codes:
            c = int(c)
            max_code = max(max_code, c)
            if c < 1 or c > knowledge_n:
                bad += 1
    print(path.name, "records", len(data), "max_code", max_code, "bad", bad, "empty", empty)

def check_grouped(path):
    data = json.loads(path.read_text(encoding="utf-8"))
    max_code = -1
    bad = 0
    empty = 0
    logs = 0
    for stu in data:
        for log in stu.get("logs", []):
            logs += 1
            codes = log.get("knowledge_code", [])
            if not codes:
                empty += 1
            for c in codes:
                c = int(c)
                max_code = max(max_code, c)
                if c < 1 or c > knowledge_n:
                    bad += 1
    print(path.name, "students", len(data), "logs", logs, "max_code", max_code, "bad", bad, "empty", empty)

check_train(DATA_DIR / "train_set.json")
check_grouped(DATA_DIR / "val_set.json")
check_grouped(DATA_DIR / "test_set.json")
