from pathlib import Path
import re

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
REPO = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD"

def backup(p):
    bak = p.with_suffix(p.suffix + ".bak_unified")
    if not bak.exists():
        bak.write_text(p.read_text(encoding="utf-8", errors="ignore"), encoding="utf-8")
    return bak

def ensure_import_os(text):
    if "import os" not in text:
        text = "import os\n" + text
    return text

# patch data_loader.py
p = REPO / "data_loader.py"
text = p.read_text(encoding="utf-8", errors="ignore")
backup(p)
text = ensure_import_os(text)

text = re.sub(
    r"data_file\s*=\s*['\"]data/train_set\.json['\"]",
    'data_file = os.path.join(os.environ.get("NEURALCD_DATA_DIR", "data"), "train_set.json")',
    text
)
text = re.sub(
    r"data_file\s*=\s*['\"]data/val_set\.json['\"]",
    'data_file = os.path.join(os.environ.get("NEURALCD_DATA_DIR", "data"), "val_set.json")',
    text
)
text = re.sub(
    r"data_file\s*=\s*['\"]data/test_set\.json['\"]",
    'data_file = os.path.join(os.environ.get("NEURALCD_DATA_DIR", "data"), "test_set.json")',
    text
)
text = re.sub(
    r"open\(['\"]config\.txt['\"]\)",
    'open(os.environ.get("NEURALCD_CONFIG", "config.txt"))',
    text
)
p.write_text(text, encoding="utf-8")
print("patched", p)

# patch train_original_seed.py / predict_original_seed.py / train.py / predict.py
for fname in ["train_original_seed.py", "predict_original_seed.py", "train.py", "predict.py"]:
    p = REPO / fname
    text = p.read_text(encoding="utf-8", errors="ignore")
    backup(p)
    text = ensure_import_os(text)
    text = re.sub(
        r"open\(['\"]config\.txt['\"]\)",
        'open(os.environ.get("NEURALCD_CONFIG", "config.txt"))',
        text
    )
    text = re.sub(
        r"with open\(['\"]config\.txt['\"]\) as ([a-zA-Z_][a-zA-Z0-9_]*)",
        r'with open(os.environ.get("NEURALCD_CONFIG", "config.txt")) as \1',
        text
    )
    text = text.replace(
        'torch.save(net.state_dict(), f"model/model_original_seed{seed}_epoch{epoch + 1}")',
        'os.makedirs(os.environ.get("NEURALCD_MODEL_DIR", "model"), exist_ok=True)\n        torch.save(net.state_dict(), os.path.join(os.environ.get("NEURALCD_MODEL_DIR", "model"), f"model_original_seed{seed}_epoch{epoch + 1}"))'
    )
    text = text.replace(
        'model_path = f"model/model_original_seed{seed}_epoch{epoch}"',
        'model_path = os.path.join(os.environ.get("NEURALCD_MODEL_DIR", "model"), f"model_original_seed{seed}_epoch{epoch}")'
    )
    p.write_text(text, encoding="utf-8")
    print("patched", p)

print("done")
