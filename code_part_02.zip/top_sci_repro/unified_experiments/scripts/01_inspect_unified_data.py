import csv
import json
from pathlib import Path
from collections import Counter

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")

DATASETS = {
    "assistments_time": ROOT / "unified_experiments/data/assistments_time",
    "ednet": ROOT / "unified_experiments/data/ednet",
}

OUT_DIR = ROOT / "unified_experiments/results/main"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def detect_col(cols, candidates):
    lower = {c.lower(): c for c in cols}
    for x in candidates:
        if x.lower() in lower:
            return lower[x.lower()]
    return None

def inspect_csv(path, max_head=10):
    with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []

        user_col = detect_col(cols, ["user_id", "user", "stu_id", "student_id", "uid", "student"])
        item_col = detect_col(cols, ["item_id", "exer_id", "exercise_id", "problem_id", "question_id", "qid", "item"])
        score_col = detect_col(cols, ["score", "label", "correct", "is_correct", "answer", "response"])
        kc_col = detect_col(cols, ["knowledge_code", "knowledge", "skill_id", "concept_id", "kc", "kcs"])
        time_col = detect_col(cols, ["timestamp", "time", "order_id", "seq", "datetime", "submit_time"])
        rt_col = detect_col(cols, ["response_time", "rt", "elapsed_time", "cost_time", "answer_time", "duration"])

        n_rows = 0
        users = set()
        items = set()
        scores = Counter()
        score_sum = 0.0
        score_count = 0
        head = []

        for row in reader:
            n_rows += 1

            if n_rows <= max_head:
                head.append(row)

            if user_col:
                users.add(row.get(user_col, ""))
            if item_col:
                items.add(row.get(item_col, ""))
            if score_col:
                v = row.get(score_col, "")
                scores[v] += 1
                try:
                    score_sum += float(v)
                    score_count += 1
                except Exception:
                    pass

        score_mean = score_sum / score_count if score_count else None

    return {
        "columns": cols,
        "user_col": user_col,
        "item_col": item_col,
        "score_col": score_col,
        "knowledge_col": kc_col,
        "time_col": time_col,
        "response_time_col": rt_col,
        "rows": n_rows,
        "users": len(users) if user_col else None,
        "items": len(items) if item_col else None,
        "score_unique_count": len(scores) if score_col else None,
        "score_mean": score_mean,
        "score_dist": dict(scores.most_common(10)),
        "head": head,
    }

def inspect_q(path):
    if not path.exists():
        return None, None

    n_rows = 0
    n_cols = None
    nonzero = 0

    with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.reader(f)
        for row in reader:
            n_rows += 1
            if n_cols is None:
                n_cols = len(row)
            for x in row:
                try:
                    if float(x) != 0:
                        nonzero += 1
                except Exception:
                    if str(x).strip() not in ("", "0", "0.0"):
                        nonzero += 1

    return (n_rows, n_cols), nonzero

summary_rows = []
md_lines = ["# Unified Dataset Inspection\n"]

for name, d in DATASETS.items():
    data_path = d / "interactions_raw.csv"
    q_path = d / "q.csv"
    config_path = d / "config.json"

    print("\n" + "=" * 80)
    print("DATASET:", name)
    print("data:", data_path)
    print("q:", q_path)
    print("config:", config_path)

    if not data_path.exists():
        print("ERROR: data file not found")
        continue

    info = inspect_csv(data_path)
    q_shape, q_nonzero = inspect_q(q_path)

    config = {}
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
        except Exception as e:
            config = {"read_error": str(e)}

    print("rows:", info["rows"])
    print("columns:", info["columns"])
    print("detected user_col:", info["user_col"])
    print("detected item_col:", info["item_col"])
    print("detected score_col:", info["score_col"])
    print("detected knowledge_col:", info["knowledge_col"])
    print("detected time_col:", info["time_col"])
    print("detected response_time_col:", info["response_time_col"])
    print("users:", info["users"])
    print("items:", info["items"])
    print("score_unique_count:", info["score_unique_count"])
    print("score_mean:", info["score_mean"])
    print("score_dist:", info["score_dist"])
    print("q_shape:", q_shape)
    print("q_nonzero:", q_nonzero)
    print("config:", config)
    print("head:")
    for r in info["head"][:5]:
        print(r)

    md_lines.extend([
        f"\n## {name}\n",
        f"- data: `{data_path}`",
        f"- q: `{q_path}`",
        f"- config: `{config_path}`",
        f"- rows: {info['rows']}",
        f"- columns: {info['columns']}",
        f"- detected user_col: `{info['user_col']}`",
        f"- detected item_col: `{info['item_col']}`",
        f"- detected score_col: `{info['score_col']}`",
        f"- detected knowledge_col: `{info['knowledge_col']}`",
        f"- detected time_col: `{info['time_col']}`",
        f"- detected response_time_col: `{info['response_time_col']}`",
        f"- users: {info['users']}",
        f"- items: {info['items']}",
        f"- score_unique_count: {info['score_unique_count']}",
        f"- score_mean: {info['score_mean']}",
        f"- score_dist: `{info['score_dist']}`",
        f"- q_shape: {q_shape}",
        f"- q_nonzero: {q_nonzero}",
        f"- config: `{config}`",
        "\n### Head",
    ])

    for r in info["head"][:10]:
        md_lines.append(f"- `{r}`")

    summary_rows.append({
        "dataset": name,
        "rows": info["rows"],
        "users": info["users"],
        "items": info["items"],
        "score_col": info["score_col"],
        "score_mean": info["score_mean"],
        "user_col": info["user_col"],
        "item_col": info["item_col"],
        "knowledge_col": info["knowledge_col"],
        "time_col": info["time_col"],
        "response_time_col": info["response_time_col"],
        "q_shape": str(q_shape),
        "q_nonzero": q_nonzero,
    })

summary_csv = OUT_DIR / "unified_data_inspection_summary.csv"
with open(summary_csv, "w", encoding="utf-8", newline="") as f:
    fieldnames = [
        "dataset", "rows", "users", "items", "score_col", "score_mean",
        "user_col", "item_col", "knowledge_col", "time_col",
        "response_time_col", "q_shape", "q_nonzero"
    ]
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(summary_rows)

md_path = OUT_DIR / "unified_data_inspection.md"
md_path.write_text("\n".join(md_lines) + "\n", encoding="utf-8")

print("\n" + "=" * 80)
print("saved:", summary_csv)
print("saved:", md_path)
