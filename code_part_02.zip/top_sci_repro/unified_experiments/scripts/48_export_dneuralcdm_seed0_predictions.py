import os
import re
import csv
import math
import importlib.util
from pathlib import Path

import numpy as np
import torch
from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
REPO = ROOT / "repos/Dynamic-Cognitive-Diagnosis"
OUT_DIR = ROOT / "unified_experiments/results/analysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

os.chdir(REPO)

def load_module(module_path, name):
    module_path = str(REPO / module_path)
    spec = importlib.util.spec_from_file_location(name, module_path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def parse_best_epoch(ws):
    p = REPO / ws / "results.txt"
    if not p.exists():
        print(f"[WARN] no results.txt: {p}, fallback epoch=0")
        return 0

    best_epoch = None
    best_auc = -1.0
    pat = re.compile(r"\[validation\]\s+stage=1,\s+epoch=(\d+):\s+auc=([0-9.]+)")
    txt = p.read_text(encoding="utf-8", errors="ignore")

    for m in pat.finditer(txt):
        ep = int(m.group(1))
        auc = float(m.group(2))
        if auc > best_auc:
            best_auc = auc
            best_epoch = ep

    if best_epoch is None:
        print(f"[WARN] cannot parse best epoch from {p}, fallback epoch=0")
        return 0

    print(f"[BEST] {ws}: epoch={best_epoch}, valid_auc={best_auc:.6f}")
    return best_epoch

def to_numpy(x):
    if hasattr(x, "detach"):
        return x.detach().cpu().numpy()
    return np.asarray(x)

def make_export_val_test(mod, export_path):
    def export_val_test(ws, model, epoch_i, stage, dtype="validation"):
        ws_config_dict = mod.read_ws_config(ws)
        data_loader = mod.ValTestDataLoader(ws_config_dict, mod.cross_idx, dtype=dtype)

        device = next(model.parameters()).device
        model.train(0)

        rows = []
        pred_all = []
        label_all = []
        flat_idx = 0
        eval_batch_count = 0

        with torch.no_grad():
            while not data_loader.is_end():
                eval_batch_count += 1
                batch = data_loader.next_batch()
                if batch is None:
                    break

                if len(batch) == 6:
                    batch_len, stu_ids, log_lens, exer_ids, knowledge_relevancies, corrs = batch
                    rt_residuals = None
                elif len(batch) == 7:
                    batch_len, stu_ids, log_lens, exer_ids, knowledge_relevancies, corrs, rt_residuals = batch
                else:
                    raise RuntimeError(f"Unexpected next_batch length: {len(batch)}")

                exer_ids = exer_ids.to(device)
                knowledge_relevancies = knowledge_relevancies.to(device)
                corrs = corrs.to(device)

                model.init_hidden()

                if rt_residuals is None:
                    pred_out = model.forward(stu_ids, exer_ids, knowledge_relevancies, corrs, stage)
                else:
                    pred_out = model.forward(
                        stu_ids,
                        exer_ids,
                        knowledge_relevancies,
                        corrs,
                        stage,
                        rt_residuals=rt_residuals
                    )

                pred_np = pred_out.detach().cpu().numpy()
                corr_np = corrs.detach().cpu().numpy()
                exer_np = exer_ids.detach().cpu().numpy()
                sid_np = to_numpy(stu_ids)
                log_len_np = to_numpy(log_lens)

                if rt_residuals is not None:
                    rt_np = to_numpy(rt_residuals)
                else:
                    rt_np = None

                for stu_i in range(batch_len):
                    L = int(log_len_np[stu_i]) - 1
                    if L <= 0:
                        continue

                    for t in range(L):
                        pred = float(pred_np[stu_i, t, 1])
                        label = int(corr_np[stu_i, t + 1])
                        exer = int(exer_np[stu_i, t + 1])
                        sid = int(sid_np[stu_i])
                        rt_val = ""

                        if rt_np is not None:
                            rt_val = float(rt_np[stu_i, t + 1])

                        rows.append([
                            flat_idx,
                            sid,
                            t + 1,
                            exer,
                            label,
                            pred,
                            rt_val
                        ])

                        pred_all.append(pred)
                        label_all.append(label)
                        flat_idx += 1

                if eval_batch_count % 50 == 0:
                    print(f"[{dtype}] eval_batch={eval_batch_count}, collected={len(pred_all)}", flush=True)

        pred_all_np = np.asarray(pred_all, dtype=np.float64)
        label_all_np = np.asarray(label_all, dtype=np.int64)
        pred_binary = (pred_all_np >= 0.5).astype(np.int64)

        auc = roc_auc_score(label_all_np, pred_all_np)
        rmse = math.sqrt(float(np.mean((pred_all_np - label_all_np) ** 2)))
        acc = float(np.mean(pred_binary == label_all_np))
        precision = precision_score(label_all_np, pred_binary, zero_division=0)
        recall = recall_score(label_all_np, pred_binary, zero_division=0)
        f1 = f1_score(label_all_np, pred_binary, zero_division=0)

        export_path.parent.mkdir(parents=True, exist_ok=True)
        with open(export_path, "w", encoding="utf-8", newline="") as f:
            writer = csv.writer(f)
            writer.writerow([
                "flat_idx",
                "student_id",
                "step",
                "exercise_id",
                "label",
                "pred",
                "rt_residual"
            ])
            writer.writerows(rows)

        print(
            f"[EXPORT] {export_path}\n"
            f"         n={len(rows)}, auc={auc:.6f}, acc={acc:.6f}, rmse={rmse:.6f}, "
            f"precision={precision:.6f}, recall={recall:.6f}, f1={f1:.6f}",
            flush=True
        )

        with open(str(export_path) + ".metrics.txt", "w", encoding="utf-8") as f:
            f.write(f"n={len(rows)}\n")
            f.write(f"auc={auc:.9f}\n")
            f.write(f"acc={acc:.9f}\n")
            f.write(f"rmse={rmse:.9f}\n")
            f.write(f"precision={precision:.9f}\n")
            f.write(f"recall={recall:.9f}\n")
            f.write(f"f1={f1:.9f}\n")

    return export_val_test

def run_case(tag, module_file, ws, epoch=None):
    print("\n" + "=" * 90, flush=True)
    print(f"[CASE] {tag}", flush=True)
    print(f"[MODULE] {module_file}", flush=True)
    print(f"[WS] {ws}", flush=True)

    mod = load_module(module_file, f"mod_{tag}")
    mod.cross_idx = 0

    if epoch is None:
        epoch = parse_best_epoch(ws)

    export_path = OUT_DIR / f"{tag}_test_predictions.csv"
    mod.val_test = make_export_val_test(mod, export_path)
    mod.test(ws=ws, epoch_model=epoch, stage=1, device="cuda:0")

cases = [
    {
        "tag": "assist_baseline_seed0",
        "module_file": "original_assistments_time_unified_seed0.py",
        "ws": "ws/dneuralcdm/assistments_time_unified_dynamiccd_original_seed0_lr001",
        "epoch": None,
    },
    {
        "tag": "assist_pbts_seed0",
        "module_file": "dneuralcdm_zfastslow_prereq_assistments_unified_seed0.py",
        "ws": "ws/dneuralcdm/assistments_time_dynamiccd_zfastslow_lr001",
        "epoch": None,
    },
    {
        "tag": "ednet_baseline_seed0",
        "module_file": "original_ednet_unified_seed0.py",
        "ws": "ws/dneuralcdm/ednet_unified_dynamiccd_trg_original_seed0_lr001_matched_attr4_seed0",
        "epoch": None,
    },
    {
        "tag": "ednet_pbts_seed0",
        "module_file": "dneuralcdm_zfastslow_prereq_ednet_unified_seed0.py",
        "ws": "ws/dneuralcdm/ednet_kt1_time_dynamiccd_zfastslow_lr001_zfastslow_unified_seed0",
        "epoch": None,
    },
]

for c in cases:
    run_case(**c)

print("\n[DONE] prediction export finished", flush=True)
