from pathlib import Path
import csv
import math
import statistics as stats
from itertools import product

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

# test metrics selected by validation AUC
data = {
    "ASSISTments_time": {
        "dNeuralCDM-unified": {
            "AUC":  [0.706293, 0.706792, 0.707310, 0.705407, 0.706120],
            "ACC":  [0.700382, 0.697305, 0.698716, 0.702740, 0.697367],
            "RMSE": [0.442523, 0.444239, 0.443357, 0.441609, 0.444617],
        },
        "dNeuralCDM-zfastslow": {
            "AUC":  [0.7093628710560477, 0.7086917255570796, 0.7115998085352625, 0.7106985954395298, 0.7117656353418745],
            "ACC":  [0.7043167956304051, 0.7047064178425125, 0.7122985889849796, 0.7032353208921256, 0.7093855257168866],
            "RMSE": [0.44078138498844655, 0.4403494368226727, 0.43766089253094487, 0.4416253840592518, 0.43843832128741556],
        },
        "dNeuralCDM-zfastslow+prereq": {
            "AUC":  [0.7114792038547587, 0.7111379816990782, 0.7124904585483104, 0.7074548182952509, 0.7119357851527033],
            "ACC":  [0.7097168866636322, 0.70745197997269, 0.7082239417387346, 0.7055056895766955, 0.7007865270823851],
            "RMSE": [0.4386373989727116, 0.4393941424863134, 0.4384699776100196, 0.4397232207227353, 0.44254537995416343],
        },
    },
    "EDNet": {
        "dNeuralCDM-unified": {
            "AUC":  [0.716286, 0.719281, 0.717211, 0.717027, 0.716898],
            "ACC":  [0.703879, 0.706156, 0.705738, 0.701422, 0.704399],
            "RMSE": [0.440928, 0.440345, 0.441085, 0.441896, 0.440514],
        },
        "dNeuralCDM-zfastslow": {
            "AUC":  [0.7398749088020906, 0.7396183295902762, 0.7390202905948463, 0.7390509622823502, 0.7392723855608772],
            "ACC":  [0.7130057662406482, 0.7132102923095874, 0.7132869895854396, 0.7129802004820308, 0.7131335950337352],
            "RMSE": [0.433557601611984, 0.43359777998032595, 0.43377157073253747, 0.4334190342168799, 0.4337990425060997],
        },
        "dNeuralCDM-zfastslow+prereq": {
            "AUC":  [0.7408886495880656, 0.73844483358036, 0.7404693239744338, 0.7402491503026131, 0.7398242872586669],
            "ACC":  [0.7138773261935142, 0.7119134110997227, 0.7123968363535791, 0.7131475399929811, 0.7138819745132629],
            "RMSE": [0.43298935969376906, 0.43430323112923114, 0.43407737229704724, 0.4332864932646333, 0.43314759075071835],
        },
    }
}

def mean_std(vals):
    return stats.mean(vals), stats.stdev(vals)

def fmt(vals):
    m, s = mean_std(vals)
    return f"{m:.6f} ± {s:.6f}"

def exact_paired_signflip_p(diffs):
    """
    Exact paired randomization/sign-flip test.
    Two-sided p-value based on absolute mean difference.
    n=5, so p has coarse granularity but does not need scipy.
    """
    n = len(diffs)
    obs = abs(stats.mean(diffs))
    count = 0
    total = 0
    for signs in product([-1, 1], repeat=n):
        val = abs(sum(d * sg for d, sg in zip(diffs, signs)) / n)
        if val >= obs - 1e-15:
            count += 1
        total += 1
    return count / total

def cohen_dz(diffs):
    sd = stats.stdev(diffs)
    if sd == 0:
        return float("inf")
    return stats.mean(diffs) / sd

def improvement_diffs(a_vals, b_vals, metric):
    """
    Compare model B against model A.
    For AUC/ACC: positive means B is better.
    For RMSE: positive means B is better because lower RMSE is better.
    """
    if metric in ["AUC", "ACC"]:
        return [b - a for a, b in zip(a_vals, b_vals)]
    if metric == "RMSE":
        return [a - b for a, b in zip(a_vals, b_vals)]
    raise ValueError(metric)

main_md = out_dir / "pbts_dneuralcdm_final_two_dataset_table.md"
sig_csv = out_dir / "pbts_dneuralcdm_significance.csv"
sig_md = out_dir / "pbts_dneuralcdm_significance.md"

# final main table
with open(main_md, "w", encoding="utf-8") as f:
    f.write("# PBTS-CD on dNeuralCDM strong backbone\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE | Note |\n")
    f.write("|---|---|---:|---:|---:|---|\n")
    for dataset in ["ASSISTments_time", "EDNet"]:
        f.write(f"| {dataset} | dNeuralCDM-unified | {fmt(data[dataset]['dNeuralCDM-unified']['AUC'])} | {fmt(data[dataset]['dNeuralCDM-unified']['ACC'])} | {fmt(data[dataset]['dNeuralCDM-unified']['RMSE'])} | baseline |\n")
        f.write(f"| {dataset} | dNeuralCDM-zfastslow | {fmt(data[dataset]['dNeuralCDM-zfastslow']['AUC'])} | {fmt(data[dataset]['dNeuralCDM-zfastslow']['ACC'])} | {fmt(data[dataset]['dNeuralCDM-zfastslow']['RMSE'])} | time behavior |\n")
        f.write(f"| {dataset} | dNeuralCDM-zfastslow+prereq | {fmt(data[dataset]['dNeuralCDM-zfastslow+prereq']['AUC'])} | {fmt(data[dataset]['dNeuralCDM-zfastslow+prereq']['ACC'])} | {fmt(data[dataset]['dNeuralCDM-zfastslow+prereq']['RMSE'])} | time + structure |\n")

comparisons = [
    ("dNeuralCDM-unified", "dNeuralCDM-zfastslow"),
    ("dNeuralCDM-zfastslow", "dNeuralCDM-zfastslow+prereq"),
    ("dNeuralCDM-unified", "dNeuralCDM-zfastslow+prereq"),
]

rows = []
for dataset, models in data.items():
    for a, b in comparisons:
        for metric in ["AUC", "ACC", "RMSE"]:
            diffs = improvement_diffs(models[a][metric], models[b][metric], metric)
            rows.append({
                "dataset": dataset,
                "metric": metric,
                "model_a": a,
                "model_b": b,
                "mean_improvement": stats.mean(diffs),
                "std_improvement": stats.stdev(diffs),
                "cohen_dz": cohen_dz(diffs),
                "p_exact_signflip": exact_paired_signflip_p(diffs),
                "diffs": diffs,
            })

with open(sig_csv, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow([
        "dataset", "metric", "model_a", "model_b",
        "mean_improvement", "std_improvement", "cohen_dz",
        "p_exact_signflip", "diffs"
    ])
    for r in rows:
        writer.writerow([
            r["dataset"], r["metric"], r["model_a"], r["model_b"],
            f"{r['mean_improvement']:.9f}",
            f"{r['std_improvement']:.9f}",
            f"{r['cohen_dz']:.6f}",
            f"{r['p_exact_signflip']:.6f}",
            ";".join(f"{x:.9f}" for x in r["diffs"])
        ])

with open(sig_md, "w", encoding="utf-8") as f:
    f.write("# PBTS-CD significance test on dNeuralCDM\n\n")
    f.write("Exact paired sign-flip test. Positive improvement means model_b is better than model_a. For RMSE, improvement is computed as RMSE(model_a) - RMSE(model_b).\n\n")
    f.write("| Dataset | Metric | Comparison | Mean improvement | Cohen dz | p_exact |\n")
    f.write("|---|---|---|---:|---:|---:|\n")
    for r in rows:
        comp = f"{r['model_a']} → {r['model_b']}"
        f.write(
            f"| {r['dataset']} | {r['metric']} | {comp} | "
            f"{r['mean_improvement']:.6f} | {r['cohen_dz']:.3f} | {r['p_exact_signflip']:.6f} |\n"
        )

print(f"Saved final table: {main_md}")
print(f"Saved significance CSV: {sig_csv}")
print(f"Saved significance markdown: {sig_md}")
print()
print(open(main_md, encoding="utf-8").read())
print()
print(open(sig_md, encoding="utf-8").read())
