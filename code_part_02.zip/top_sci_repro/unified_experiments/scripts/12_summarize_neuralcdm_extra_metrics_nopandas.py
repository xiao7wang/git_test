import csv
import math
from collections import defaultdict
from pathlib import Path

in_path = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main/neuralcdm_unified_extra_metrics.csv")
out_path = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main/neuralcdm_unified_extra_metrics_summary.txt")

rows = []
with open(in_path, newline="", encoding="utf-8") as f:
    reader = csv.DictReader(f)
    for r in reader:
        rows.append(r)

groups = defaultdict(list)
for r in rows:
    groups[r["dataset"]].append(r)

metrics = ["AUC", "ACC", "RMSE", "Precision", "Recall", "F1"]

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    if len(xs) <= 1:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

with open(out_path, "w", encoding="utf-8") as f:
    for dataset, rs in sorted(groups.items()):
        f.write(f"{dataset}\n")
        for m in metrics:
            vals = [float(r[m]) for r in rs]
            f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")
        f.write("\n")

print(open(out_path, encoding="utf-8").read())
