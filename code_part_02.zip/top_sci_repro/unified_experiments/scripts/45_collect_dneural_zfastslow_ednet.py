import re
import math
import csv
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
LOG_DIR = ROOT / "repos/Dynamic-Cognitive-Diagnosis/logs"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

val_pat = re.compile(
    r"\[validation\] stage=1, epoch=(\d+): auc=([0-9.eE+-]+), rmse=([0-9.eE+-]+), acc=([0-9.eE+-]+)"
)
test_pat = re.compile(
    r"\[test\] stage=1, epoch=(\d+): auc=([0-9.eE+-]+), rmse=([0-9.eE+-]+), acc=([0-9.eE+-]+)"
)

rows = []
for seed in range(5):
    path = LOG_DIR / f"dneuralcdm_zfastslow_unified_ednet_seed{seed}.log"
    if not path.exists():
        raise FileNotFoundError(path)

    text = path.read_text(encoding="utf-8")
    vals = val_pat.findall(text)
    tests = test_pat.findall(text)

    if not vals:
        raise RuntimeError(f"No validation results in {path}")
    if not tests:
        raise RuntimeError(f"No test results in {path}")

    val_map = {int(e): (float(a), float(r), float(c)) for e, a, r, c in vals}
    test_map = {int(e): (float(a), float(r), float(c)) for e, a, r, c in tests}

    best_epoch = max(val_map.keys(), key=lambda e: val_map[e][0])
    if best_epoch not in test_map:
        raise RuntimeError(f"Best epoch {best_epoch} has no test result in {path}")

    valid_auc, valid_rmse, valid_acc = val_map[best_epoch]
    test_auc, test_rmse, test_acc = test_map[best_epoch]

    rows.append({
        "dataset": "ednet",
        "model": "dNeuralCDM-zfastslow",
        "seed": seed,
        "best_epoch": best_epoch,
        "valid_AUC": valid_auc,
        "valid_ACC": valid_acc,
        "valid_RMSE": valid_rmse,
        "test_AUC": test_auc,
        "test_ACC": test_acc,
        "test_RMSE": test_rmse,
    })

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

csv_path = OUT / "dneuralcdm_zfastslow_unified_ednet_5seed.csv"
summary_path = OUT / "dneuralcdm_zfastslow_unified_ednet_5seed_summary.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-zfastslow-unified on EDNet\n")
    f.write("5 seeds, 3 epochs, best epoch selected by validation AUC.\n\n")

    for r in rows:
        f.write(
            f"seed={r['seed']}, best_epoch={r['best_epoch']}, "
            f"AUC={r['test_AUC']:.6f}, ACC={r['test_ACC']:.6f}, RMSE={r['test_RMSE']:.6f}\n"
        )

    f.write("\nSummary:\n")
    for m in ["test_AUC", "test_ACC", "test_RMSE"]:
        vals = [r[m] for r in rows]
        f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")

    fast_auc = 0.739116
    fast_acc = 0.713178
    fast_rmse = 0.433614

    attr_auc = 0.733606
    attr_acc = 0.711297
    attr_rmse = 0.435074

    orig_auc = 0.717341
    orig_acc = 0.704319
    orig_rmse = 0.440954

    f.write("\nDelta over dNeuralCDM-fastslow-unified on EDNet:\n")
    f.write(f"Delta AUC: {mean([r['test_AUC'] for r in rows]) - fast_auc:+.6f}\n")
    f.write(f"Delta ACC: {mean([r['test_ACC'] for r in rows]) - fast_acc:+.6f}\n")
    f.write(f"Delta RMSE: {mean([r['test_RMSE'] for r in rows]) - fast_rmse:+.6f}\n")

    f.write("\nDelta over dNeuralCDM attr_idx=4 no-RT matched baseline on EDNet:\n")
    f.write(f"Delta AUC: {mean([r['test_AUC'] for r in rows]) - attr_auc:+.6f}\n")
    f.write(f"Delta ACC: {mean([r['test_ACC'] for r in rows]) - attr_acc:+.6f}\n")
    f.write(f"Delta RMSE: {mean([r['test_RMSE'] for r in rows]) - attr_rmse:+.6f}\n")

    f.write("\nDelta over original dNeuralCDM-unified on EDNet:\n")
    f.write(f"Delta AUC: {mean([r['test_AUC'] for r in rows]) - orig_auc:+.6f}\n")
    f.write(f"Delta ACC: {mean([r['test_ACC'] for r in rows]) - orig_acc:+.6f}\n")
    f.write(f"Delta RMSE: {mean([r['test_RMSE'] for r in rows]) - orig_rmse:+.6f}\n")

print(open(summary_path, encoding="utf-8").read())
print("Saved:", csv_path)
print("Saved:", summary_path)
