import re
import math
import csv
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
RES = ROOT / "unified_experiments/results/ours_trg_current_rt"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

pat = re.compile(
    r"\[best\] epoch=(\d+) valid_auc=([0-9.eE+-]+) "
    r"test_auc=([0-9.eE+-]+) test_acc=([0-9.eE+-]+) "
    r"test_rmse=([0-9.eE+-]+) test_precision=([0-9.eE+-]+) "
    r"test_recall=([0-9.eE+-]+) test_f1=([0-9.eE+-]+)"
)

rows = []

for seed in range(5):
    path = RES / f"ednet_seed{seed}_beta005_ep8.log"
    text = path.read_text(encoding="utf-8")
    m = pat.search(text)
    if not m:
        raise RuntimeError(f"No best line in {path}")

    epoch, valid_auc, auc, acc, rmse, precision, recall, f1 = m.groups()
    rows.append({
        "dataset": "ednet",
        "model": "NeuralCDM+TRG-current-rt",
        "seed": seed,
        "beta": 0.05,
        "epochs": 8,
        "best_epoch": int(epoch),
        "valid_AUC": float(valid_auc),
        "test_AUC": float(auc),
        "test_ACC": float(acc),
        "test_RMSE": float(rmse),
        "test_Precision": float(precision),
        "test_Recall": float(recall),
        "test_F1": float(f1),
    })

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

csv_path = OUT / "ours_trg_current_rt_ednet_beta005_5seed.csv"
summary_path = OUT / "ours_trg_current_rt_ednet_beta005_5seed_summary.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

metrics = ["test_AUC", "test_ACC", "test_RMSE", "test_Precision", "test_Recall", "test_F1"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("NeuralCDM+TRG-current-rt on EDNet, beta=0.05, 8 epochs, 5 seeds\n")
    f.write("Best epoch selected by validation AUC.\n\n")

    for r in rows:
        f.write(
            f"seed={r['seed']}, best_epoch={r['best_epoch']}, "
            f"AUC={r['test_AUC']:.6f}, ACC={r['test_ACC']:.6f}, "
            f"RMSE={r['test_RMSE']:.6f}, F1={r['test_F1']:.6f}\n"
        )

    f.write("\nSummary:\n")
    for m in metrics:
        vals = [r[m] for r in rows]
        f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")

print(open(summary_path, encoding="utf-8").read())
print("Saved:", csv_path)
print("Saved:", summary_path)
