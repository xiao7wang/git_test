from pathlib import Path
import re

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
P = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/data_loader.py"

text = P.read_text(encoding="utf-8", errors="ignore")

bak = P.with_suffix(P.suffix + ".bak_config_fix")
if not bak.exists():
    bak.write_text(text, encoding="utf-8")

if "import os" not in text:
    text = "import os\n" + text

# 兼容 open('config.txt')、open("config.txt")、open('config.txt', encoding=...) 等写法
text = re.sub(
    r"open\(\s*['\"]config\.txt['\"]\s*(,?)",
    r'open(os.environ.get("NEURALCD_CONFIG", "config.txt")\1',
    text
)

P.write_text(text, encoding="utf-8")

print("patched:", P)
print("===== config related lines =====")
for i, line in enumerate(text.splitlines(), 1):
    if "config.txt" in line or "NEURALCD_CONFIG" in line or "knowledge" in line or "student" in line or "exer" in line:
        print(f"{i}: {line}")
