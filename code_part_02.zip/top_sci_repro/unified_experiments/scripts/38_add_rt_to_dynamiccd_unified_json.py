import csv
import json
import shutil
from pathlib import Path
from collections import defaultdict

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
SPLIT_ROOT = ROOT / "unified_experiments/splits"
DYN_ROOT = ROOT / "repos/Dynamic-Cognitive-Diagnosis/data"
OUT_ROOT = ROOT / "unified_experiments/results/main"
OUT_ROOT.mkdir(parents=True, exist_ok=True)

DATASETS = {
    "assistments_time": {
        "src": "assistments_time_unified_dynamiccd",
        "dst": "assistments_time_unified_dynamiccd_trg",
    },
    "ednet": {
        "src": "ednet_unified_dynamiccd",
        "dst": "ednet_unified_dynamiccd_trg",
    },
}

def pick(cols, names):
    low = {c.lower(): c for c in cols}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    raise RuntimeError(f"missing {names}, cols={cols}")

def load_split_rows(dataset, split):
    path = SPLIT_ROOT / dataset / f"{split}.csv"
    by_stu = defaultdict(list)

    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        cols = rd.fieldnames

        stu_c = pick(cols, ["student_id", "stu_id", "user_id", "sid"])
        item_c = pick(cols, ["exercise_id", "item_id", "problem_id", "exer_id", "pid"])
        y_c = pick(cols, ["score", "correct", "label", "r"])
        rt_c = pick(cols, ["response_time", "rt", "elapsed_time", "duration"])
        ts_c = pick(cols, ["timestamp", "time", "order_time", "submit_time"])

        for idx, r in enumerate(rd):
            stu = int(float(r[stu_c]))
            item = int(float(r[item_c]))
            y = int(float(r[y_c]))
            rt = float(r[rt_c])
            ts = float(r[ts_c])
            by_stu[stu].append({
                "idx": idx,
                "stu": stu,
                "item": item,
                "y": y,
                "rt": rt,
                "ts": ts,
            })

    for stu in by_stu:
        by_stu[stu].sort(key=lambda x: (x["ts"], x["idx"]))

    return by_stu

def candidate_student_keys(json_sid):
    return [json_sid, json_sid - 1, json_sid + 1]

def item_match(json_item, csv_item):
    return json_item == csv_item or json_item == csv_item + 1 or json_item + 1 == csv_item

def append_rt_to_file(dataset, json_name, split_name, src_dir, dst_dir):
    src_path = src_dir / json_name
    dst_path = dst_dir / json_name

    data = json.load(open(src_path, encoding="utf-8"))
    by_stu = load_split_rows(dataset, split_name)
    ptr = defaultdict(int)

    total = 0
    matched = 0
    mismatched = 0
    padded_zero = 0
    examples = []

    for stu_rec in data:
        json_sid = int(stu_rec[0])
        logs = stu_rec[2]

        chosen_key = None
        for k in candidate_student_keys(json_sid):
            if k in by_stu:
                chosen_key = k
                break

        for log in logs:
            total += 1

            if len(log) > 5:
                # already has RT
                matched += 1
                continue

            rt = 0.0
            ok = False

            if chosen_key is not None:
                rows = by_stu[chosen_key]
                start = ptr[chosen_key]
                json_item = int(log[1])
                json_y = int(log[2])

                # usually matched at current pointer; allow short lookahead for safety
                best_pos = None
                for pos in range(start, min(start + 100, len(rows))):
                    row = rows[pos]
                    if int(row["y"]) == json_y and item_match(json_item, int(row["item"])):
                        best_pos = pos
                        break

                if best_pos is not None:
                    rt = float(rows[best_pos]["rt"])
                    ptr[chosen_key] = best_pos + 1
                    ok = True

            if ok:
                matched += 1
            else:
                mismatched += 1
                padded_zero += 1
                if len(examples) < 10:
                    examples.append({
                        "json_sid": json_sid,
                        "chosen_key": chosen_key,
                        "log": log,
                    })

            log.append(rt)

    json.dump(data, open(dst_path, "w", encoding="utf-8"), ensure_ascii=False)

    return {
        "dataset": dataset,
        "json_name": json_name,
        "split_name": split_name,
        "total_logs": total,
        "matched": matched,
        "mismatched": mismatched,
        "padded_zero": padded_zero,
        "match_rate": matched / total if total else 0.0,
        "examples": examples,
    }

def main():
    reports = []

    for dataset, cfg in DATASETS.items():
        src_dir = DYN_ROOT / cfg["src"]
        dst_dir = DYN_ROOT / cfg["dst"]

        if dst_dir.exists():
            shutil.rmtree(dst_dir)
        shutil.copytree(src_dir, dst_dir)

        print(f"\n===== {dataset} =====")
        print("src:", src_dir)
        print("dst:", dst_dir)

        reports.append(append_rt_to_file(dataset, "train_0.json", "train", src_dir, dst_dir))
        reports.append(append_rt_to_file(dataset, "val_0.json", "valid", src_dir, dst_dir))
        reports.append(append_rt_to_file(dataset, "test.json", "test", src_dir, dst_dir))

    report_path = OUT_ROOT / "dynamiccd_unified_trg_rt_append_report.json"
    json.dump(reports, open(report_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    print("\n===== RT append report =====")
    for r in reports:
        print(
            r["dataset"], r["json_name"],
            "total=", r["total_logs"],
            "matched=", r["matched"],
            "mismatched=", r["mismatched"],
            "match_rate=", f'{r["match_rate"]:.6f}'
        )
        if r["examples"]:
            print("examples:", r["examples"][:2])

    print("saved:", report_path)

if __name__ == "__main__":
    main()
