import os
import csv
import json
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")

TARGETS = {
    "NeuralCDM": ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD",
    "dNeuralCDM": ROOT / "repos/Dynamic-Cognitive-Diagnosis",
    "CausalCDF": ROOT / "repos/CausalCDF/CasualCDF",
    "ORCDF": ROOT / "repos/ORCDF",
    "HyperCDM": ROOT / "repos/HyperCDM",
    "DisenGCD": ROOT / "repos/Intelligent-Education/DisenGCD/DisenGCD",
}

OUT = ROOT / "unified_experiments/results/main/latest_model_format_inspection.md"
OUT.parent.mkdir(parents=True, exist_ok=True)

def file_size(p):
    try:
        n = p.stat().st_size
        for unit in ["B", "KB", "MB", "GB"]:
            if n < 1024:
                return f"{n:.1f}{unit}"
            n /= 1024
        return f"{n:.1f}TB"
    except Exception:
        return "NA"

def read_head(path, n=5):
    lines = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for i, line in enumerate(f):
                if i >= n:
                    break
                lines.append(line.rstrip("\n"))
    except Exception as e:
        lines.append(f"READ_ERROR: {e}")
    return lines

def csv_header(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
            reader = csv.reader(f)
            return next(reader, [])
    except Exception as e:
        return [f"HEADER_ERROR: {e}"]

md = ["# Latest Model Data Format Inspection\n"]

for name, repo in TARGETS.items():
    md.append(f"\n## {name}\n")
    md.append(f"- repo: `{repo}`")
    md.append(f"- exists: `{repo.exists()}`")

    if not repo.exists():
        continue

    candidates = []
    for ext in ["*.csv", "*.json", "*.txt", "*.pkl", "*.npy"]:
        candidates.extend(repo.rglob(ext))

    # 排除日志和模型权重，优先看 data/dataset/converted 目录
    filtered = []
    for p in candidates:
        s = str(p)
        if any(x in s.lower() for x in ["log", "logs", "__pycache__", "result", "checkpoint", "model.pt", "model.pth"]):
            continue
        if any(x in s.lower() for x in ["data", "dataset", "datasets", "config", "q_matrix", "q.csv", "train", "test", "valid"]):
            filtered.append(p)

    filtered = sorted(filtered, key=lambda x: (str(x).lower().count("data") == 0, str(x)))[:80]

    md.append("\n### Candidate data/config files\n")
    for p in filtered:
        rel = p.relative_to(ROOT)
        md.append(f"- `{rel}` ({file_size(p)})")

    md.append("\n### Heads of small readable files\n")
    shown = 0
    for p in filtered:
        if shown >= 20:
            break
        if p.suffix.lower() not in [".csv", ".json", ".txt"]:
            continue
        if p.stat().st_size > 5 * 1024 * 1024:
            continue

        rel = p.relative_to(ROOT)
        md.append(f"\n#### `{rel}`\n")
        if p.suffix.lower() == ".csv":
            md.append(f"- csv_header: `{csv_header(p)}`")
        for line in read_head(p, 5):
            md.append(f"    {line}")
        shown += 1

OUT.write_text("\n".join(md) + "\n", encoding="utf-8")
print("saved:", OUT)
