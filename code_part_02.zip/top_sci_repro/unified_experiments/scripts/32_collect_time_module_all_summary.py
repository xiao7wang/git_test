import re
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
RES = ROOT / "unified_experiments/results/ours_trg_current_rt"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

pat = re.compile(
    r"\[best\] epoch=(\d+) valid_auc=([0-9.eE+-]+) "
    r"test_auc=([0-9.eE+-]+) test_acc=([0-9.eE+-]+) "
    r"test_rmse=([0-9.eE+-]+) test_precision=([0-9.eE+-]+) "
    r"test_recall=([0-9.eE+-]+) test_f1=([0-9.eE+-]+)"
)

def parse(path):
    text = Path(path).read_text(encoding="utf-8")
    ms = pat.findall(text)
    if not ms:
        raise RuntimeError(f"No [best] line in {path}")
    epoch, valid_auc, auc, acc, rmse, precision, recall, f1 = ms[-1]
    return {
        "epoch": int(epoch),
        "valid_auc": float(valid_auc),
        "AUC": float(auc),
        "ACC": float(acc),
        "RMSE": float(rmse),
        "Precision": float(precision),
        "Recall": float(recall),
        "F1": float(f1),
    }

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

def collect(dataset, prefix, tag):
    rows = []
    for seed in range(5):
        if dataset == "ednet":
            path = RES / f"ednet_seed{seed}_{tag}_ep8.log"
        else:
            path = RES / f"assist_seed{seed}_{tag}_ep8.log"
        r = parse(path)
        r["seed"] = seed
        rows.append(r)
    return rows

def stat_line(rows):
    metrics = ["AUC", "ACC", "RMSE", "Precision", "Recall", "F1"]
    return {m: (mean([r[m] for r in rows]), std([r[m] for r in rows])) for m in metrics}

groups = [
    ("EDNet", "Official-style NeuralCDM", collect("ednet", "ednet", "beta0")),
    ("EDNet", "Ours-v1 current-rt", collect("ednet", "ednet", "beta005")),
    ("EDNet", "Ours-v2 fast-slow", collect("ednet", "ednet", "fastslow_beta005")),
    ("ASSISTments_time", "Official-style NeuralCDM", collect("assist", "assist", "beta0")),
    ("ASSISTments_time", "Ours-v1 current-rt", collect("assist", "assist", "beta005")),
    ("ASSISTments_time", "Ours-v2 fast-slow", collect("assist", "assist", "fastslow_beta005")),
]

summary_path = OUT / "time_module_all_summary.md"

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("# Time-aware module summary\n\n")
    f.write("Protocol: 8 epochs, 5 seeds, best epoch selected by validation AUC.\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE | Precision | Recall | F1 |\n")
    f.write("|---|---|---:|---:|---:|---:|---:|---:|\n")

    stats = {}
    for dataset, model, rows in groups:
        s = stat_line(rows)
        stats[(dataset, model)] = s
        f.write(
            f"| {dataset} | {model} | "
            f"{s['AUC'][0]:.6f} ± {s['AUC'][1]:.6f} | "
            f"{s['ACC'][0]:.6f} ± {s['ACC'][1]:.6f} | "
            f"{s['RMSE'][0]:.6f} ± {s['RMSE'][1]:.6f} | "
            f"{s['Precision'][0]:.6f} ± {s['Precision'][1]:.6f} | "
            f"{s['Recall'][0]:.6f} ± {s['Recall'][1]:.6f} | "
            f"{s['F1'][0]:.6f} ± {s['F1'][1]:.6f} |\n"
        )

    f.write("\n## Improvements over Official-style NeuralCDM\n\n")
    f.write("| Dataset | Model | ΔAUC | ΔACC | ΔRMSE | ΔPrecision | ΔRecall | ΔF1 |\n")
    f.write("|---|---|---:|---:|---:|---:|---:|---:|\n")

    for dataset in ["EDNet", "ASSISTments_time"]:
        base = stats[(dataset, "Official-style NeuralCDM")]
        for model in ["Ours-v1 current-rt", "Ours-v2 fast-slow"]:
            cur = stats[(dataset, model)]
            f.write(
                f"| {dataset} | {model} | "
                f"{cur['AUC'][0] - base['AUC'][0]:+.6f} | "
                f"{cur['ACC'][0] - base['ACC'][0]:+.6f} | "
                f"{cur['RMSE'][0] - base['RMSE'][0]:+.6f} | "
                f"{cur['Precision'][0] - base['Precision'][0]:+.6f} | "
                f"{cur['Recall'][0] - base['Recall'][0]:+.6f} | "
                f"{cur['F1'][0] - base['F1'][0]:+.6f} |\n"
            )

    f.write("\n## Fused gate sensitivity on ASSISTments_time seed0\n\n")
    f.write("| Variant | AUC | ACC | RMSE | Precision | Recall | F1 |\n")
    f.write("|---|---:|---:|---:|---:|---:|---:|\n")

    variants = [
        ("current-rt", RES / "assist_seed0_beta005_ep8.log"),
        ("fast-slow", RES / "assist_seed0_fastslow_beta005_ep8.log"),
        ("fused alpha=0.1", RES / "assist_seed0_fused_alpha0p1_beta005_ep8.log"),
        ("fused alpha=0.2", RES / "assist_seed0_fused_alpha0p2_beta005_ep8.log"),
        ("fused alpha=0.3", RES / "assist_seed0_fused_alpha0p3_beta005_ep8.log"),
        ("fused alpha=0.4", RES / "assist_seed0_fused_alpha0p4_beta005_ep8.log"),
    ]
    for name, path in variants:
        r = parse(path)
        f.write(
            f"| {name} | {r['AUC']:.6f} | {r['ACC']:.6f} | {r['RMSE']:.6f} | "
            f"{r['Precision']:.6f} | {r['Recall']:.6f} | {r['F1']:.6f} |\n"
        )

print(summary_path)
print(summary_path.read_text(encoding="utf-8"))
