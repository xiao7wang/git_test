from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["ASSISTments_time", "dNeuralCDM-zfastslow+prereq", 0, 1, 0.7160101596587497, 0.7162858125322371, 0.43561496433067165, 0.7114792038547587, 0.7097168866636322, 0.4386373989727116],
    ["ASSISTments_time", "dNeuralCDM-zfastslow+prereq", 1, 1, 0.7168016963785991, 0.7165046343331406, 0.4355761772714056, 0.7111379816990782, 0.7074519799726900, 0.4393941424863134],
    ["ASSISTments_time", "dNeuralCDM-zfastslow+prereq", 2, 1, 0.7172434068293619, 0.7158755216555432, 0.43517777125997753, 0.7124904585483104, 0.7082239417387346, 0.4384699776100196],
    ["ASSISTments_time", "dNeuralCDM-zfastslow+prereq", 3, 1, 0.7138725595573256, 0.7158325388017943, 0.4353860368731737, 0.7074548182952509, 0.7055056895766955, 0.4397232207227353],
    ["ASSISTments_time", "dNeuralCDM-zfastslow+prereq", 4, 1, 0.7165968181338699, 0.7105847231122712, 0.43746949425769543, 0.7119357851527033, 0.7007865270823851, 0.44254537995416343],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_zfastslow_prereq_assistments_time_5seed.csv"
summary_path = out_dir / "dneuralcdm_zfastslow_prereq_assistments_time_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_zfastslow_prereq_assistments_time_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

baseline = {
    "auc": 0.706384,
    "acc": 0.699302,
    "rmse": 0.443269,
    "auc_std": 0.000717,
    "acc_std": 0.002295,
    "rmse_std": 0.001233,
}

zfast = {
    "auc": 0.710424,
    "acc": 0.706789,
    "rmse": 0.439771,
    "auc_std": 0.001359,
    "acc_std": 0.003879,
    "rmse_std": 0.001660,
}

auc, auc_std = summary["test_AUC"]
acc, acc_std = summary["test_ACC"]
rmse, rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-zfastslow+prereq on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 1.\n")
    f.write("Prereq lambda = 0.001\n\n")

    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified:\n")
    f.write(f"AUC gain: {auc - baseline['auc']:+.6f}\n")
    f.write(f"ACC gain: {acc - baseline['acc']:+.6f}\n")
    f.write(f"RMSE gain: {rmse - baseline['rmse']:+.6f}\n")

    f.write("\nCompared with dNeuralCDM-zfastslow:\n")
    f.write(f"AUC difference: {auc - zfast['auc']:+.6f}\n")
    f.write(f"ACC difference: {acc - zfast['acc']:+.6f}\n")
    f.write(f"RMSE difference: {rmse - zfast['rmse']:+.6f}\n")

    f.write("\nConclusion: zfastslow+prereq slightly improves AUC over zfastslow on ASSISTments_time, with nearly unchanged RMSE and slightly lower ACC. It should be treated as a structure-enhanced variant rather than a clearly dominant replacement.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-zfastslow+prereq on ASSISTments_time\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-unified | {baseline['auc']:.6f} ± {baseline['auc_std']:.6f} | {baseline['acc']:.6f} ± {baseline['acc_std']:.6f} | {baseline['rmse']:.6f} ± {baseline['rmse_std']:.6f} |\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-zfastslow | {zfast['auc']:.6f} ± {zfast['auc_std']:.6f} | **{zfast['acc']:.6f} ± {zfast['acc_std']:.6f}** | {zfast['rmse']:.6f} ± {zfast['rmse_std']:.6f} |\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-zfastslow+prereq | **{auc:.6f} ± {auc_std:.6f}** | {acc:.6f} ± {acc_std:.6f} | **{rmse:.6f} ± {rmse_std:.6f}** |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
