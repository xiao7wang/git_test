import re
import math
import csv
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
RES = ROOT / "unified_experiments/results/ours_trg_current_rt"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

pat = re.compile(
    r"\[best\] epoch=(\d+) valid_auc=([0-9.eE+-]+) "
    r"test_auc=([0-9.eE+-]+) test_acc=([0-9.eE+-]+) "
    r"test_rmse=([0-9.eE+-]+) test_precision=([0-9.eE+-]+) "
    r"test_recall=([0-9.eE+-]+) test_f1=([0-9.eE+-]+)"
)

rows = []

for beta_name, beta_value in [("beta0", 0.0), ("beta005", 0.05)]:
    for seed in range(5):
        path = RES / f"assist_seed{seed}_{beta_name}_ep8.log"
        text = path.read_text(encoding="utf-8")
        m = pat.search(text)
        if not m:
            raise RuntimeError(f"No best line in {path}")

        epoch, valid_auc, auc, acc, rmse, precision, recall, f1 = m.groups()

        rows.append({
            "dataset": "assistments_time",
            "model": "Official-NeuralCDM" if beta_value == 0.0 else "Ours-v1-TRG-current-rt",
            "beta": beta_value,
            "seed": seed,
            "epochs": 8,
            "best_epoch": int(epoch),
            "valid_AUC": float(valid_auc),
            "test_AUC": float(auc),
            "test_ACC": float(acc),
            "test_RMSE": float(rmse),
            "test_Precision": float(precision),
            "test_Recall": float(recall),
            "test_F1": float(f1),
        })

csv_path = OUT / "ours_trg_assist_beta0_vs_beta005_5seed.csv"
summary_path = OUT / "ours_trg_assist_beta0_vs_beta005_5seed_summary.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

metrics = ["test_AUC", "test_ACC", "test_RMSE", "test_Precision", "test_Recall", "test_F1"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("ASSISTments_time ablation: Official-NeuralCDM beta=0 vs Ours-v1 TRG-current-rt beta=0.05\n")
    f.write("8 epochs, 5 seeds, best epoch selected by validation AUC.\n\n")

    stats = {}
    for beta_value in [0.0, 0.05]:
        sub = [r for r in rows if r["beta"] == beta_value]
        f.write("=" * 80 + "\n")
        f.write(f"beta={beta_value}\n")
        stats[beta_value] = {}
        for m in metrics:
            vals = [r[m] for r in sub]
            stats[beta_value][m] = mean(vals)
            f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")
        f.write("\n")

    f.write("=" * 80 + "\n")
    f.write("Mean improvement: beta=0.05 - beta=0\n")
    for m in metrics:
        diff = stats[0.05][m] - stats[0.0][m]
        f.write(f"{m}: {diff:+.6f}\n")

print(open(summary_path, encoding="utf-8").read())
print("Saved:", csv_path)
print("Saved:", summary_path)
