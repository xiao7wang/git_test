from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
DYN = ROOT / "repos/Dynamic-Cognitive-Diagnosis"

HELPER = r'''
# ===== PBTS prereq patch start =====
import os as _pbts_os

def _pbts_load_prereq_edges(device):
    path = _pbts_os.environ.get("DNEURAL_PREREQ_PATH", "").strip()
    lam = float(_pbts_os.environ.get("DNEURAL_PREREQ_LAMBDA", "0.0"))

    if (not path) or lam <= 0:
        print(f"[PREREQ] disabled path={path!r}, lambda={lam}", flush=True)
        return None, None, None, lam

    adj = np.load(path).astype(np.float32)
    src, dst = np.nonzero(adj > 0)
    w = adj[src, dst].astype(np.float32)

    edge_src = torch.tensor(src, dtype=torch.long, device=device)
    edge_dst = torch.tensor(dst, dtype=torch.long, device=device)
    edge_w = torch.tensor(w, dtype=torch.float32, device=device)

    print(
        f"[PREREQ] loaded path={path}, shape={adj.shape}, "
        f"edges={len(src)}, weight_sum={float(w.sum()):.6f}, lambda={lam}",
        flush=True
    )
    return edge_src, edge_dst, edge_w, lam


def _pbts_prereq_loss(model, stu_ids, exer_ids, knowledge_relevancies, corrs, stage,
                      log_lens, batch_len, edge_src, edge_dst, edge_w):
    if edge_src is None or edge_src.numel() == 0:
        return None

    states = model.get_state(stu_ids, exer_ids, knowledge_relevancies, corrs, stage)

    if isinstance(states, (tuple, list)):
        states = states[0]

    # expected shape: [batch, seq_len - 1, knowledge_n]
    if states.dim() == 2:
        states = states.unsqueeze(1)

    states = torch.clamp(states, 0.0, 1.0)

    batch_len_int = int(batch_len)
    states = states[:batch_len_int]

    seq_n = states.size(1)
    device = states.device

    if torch.is_tensor(log_lens):
        lens = log_lens[:batch_len_int].to(device=device, dtype=torch.long)
    else:
        lens = torch.tensor(log_lens[:batch_len_int], dtype=torch.long, device=device)

    # prediction starts from t=1, so valid prediction length is log_len - 1
    lens = torch.clamp(lens - 1, min=0, max=seq_n)

    t_idx = torch.arange(seq_n, device=device).view(1, -1)
    mask = (t_idx < lens.view(-1, 1)).float()

    # prerequisite direction: src -> dst, so dst mastery should not exceed src mastery
    violation = torch.relu(states[:, :, edge_dst] - states[:, :, edge_src])
    weighted = violation.pow(2) * edge_w.view(1, 1, -1)

    denom = mask.sum() * edge_w.numel() + 1e-8
    loss = (weighted * mask.unsqueeze(-1)).sum() / denom
    return loss
# ===== PBTS prereq patch end =====
'''


def patch_one(src_name: str, dst_name: str):
    src = DYN / src_name
    dst = DYN / dst_name

    if not src.exists():
        raise FileNotFoundError(src)

    text = src.read_text(encoding="utf-8")

    if "PBTS prereq patch start" not in text:
        marker = "def train_stage1(ws, device='cpu', lr=0.004, n_epochs=10):"
        if marker not in text:
            raise RuntimeError(f"Cannot find train_stage1 marker in {src_name}")
        text = text.replace(marker, HELPER + "\n\n" + marker, 1)

    load_marker = "    data_loader = DataLoader(ws_config_dict, cross_idx)\n"
    load_insert = (
        "    data_loader = DataLoader(ws_config_dict, cross_idx)\n"
        "    edge_src, edge_dst, edge_w, prereq_lambda = _pbts_load_prereq_edges(device)\n"
    )
    if "edge_src, edge_dst, edge_w, prereq_lambda = _pbts_load_prereq_edges(device)" not in text:
        if load_marker not in text:
            raise RuntimeError(f"Cannot find data_loader marker in {src_name}")
        text = text.replace(load_marker, load_insert, 1)

    loss_marker = "            pred_loss = pred_loss / batch_log_count\n"
    loss_insert = (
        "            pred_loss = pred_loss / batch_log_count\n"
        "\n"
        "            if prereq_lambda > 0 and edge_src is not None and edge_src.numel() > 0:\n"
        "                prereq_loss = _pbts_prereq_loss(\n"
        "                    model=model,\n"
        "                    stu_ids=stu_ids,\n"
        "                    exer_ids=exer_ids,\n"
        "                    knowledge_relevancies=knowledge_relevancies,\n"
        "                    corrs=corrs,\n"
        "                    stage=1,\n"
        "                    log_lens=log_lens,\n"
        "                    batch_len=batch_len,\n"
        "                    edge_src=edge_src,\n"
        "                    edge_dst=edge_dst,\n"
        "                    edge_w=edge_w,\n"
        "                )\n"
        "                if prereq_loss is not None:\n"
        "                    pred_loss = pred_loss + prereq_lambda * prereq_loss\n"
        "                    if batch_count % 100 == 0:\n"
        "                        print(f\"[PREREQ] epoch={epoch}, batch={batch_count}, prereq_loss={float(prereq_loss.detach().cpu()):.8f}, lambda={prereq_lambda}\", flush=True)\n"
    )
    if "prereq_loss = _pbts_prereq_loss(" not in text:
        if loss_marker not in text:
            raise RuntimeError(f"Cannot find pred_loss marker in {src_name}")
        text = text.replace(loss_marker, loss_insert, 1)

    dst.write_text(text, encoding="utf-8")
    print(f"[OK] {src_name} -> {dst_name}")


patch_one("original_assistments_time_unified_seed0.py", "dneuralcdm_prereq_assistments_unified_seed0.py")
patch_one("original_ednet_unified_seed0.py", "dneuralcdm_prereq_ednet_unified_seed0.py")
patch_one("dneuralcdm_zfastslow_assistments_unified_seed0.py", "dneuralcdm_zfastslow_prereq_assistments_unified_seed0.py")
patch_one("dneuralcdm_zfastslow_ednet_unified_seed0.py", "dneuralcdm_zfastslow_prereq_ednet_unified_seed0.py")
