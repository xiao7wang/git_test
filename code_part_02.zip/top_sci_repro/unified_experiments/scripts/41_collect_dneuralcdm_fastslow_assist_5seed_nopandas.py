from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["ASSISTments_time", "dNeuralCDM-fastslow", 0, 1, 0.7146797853698095, 0.7156254395973679, 0.436463290843726, 0.7087253802370245, 0.7076941283568503, 0.4399578403694744],
    ["ASSISTments_time", "dNeuralCDM-fastslow", 1, 1, 0.7150016597607589, 0.709924350177402, 0.43817877829814295, 0.7084664230030535, 0.6989239872553482, 0.4438747976172694],
    ["ASSISTments_time", "dNeuralCDM-fastslow", 2, 1, 0.7151699944950034, 0.7130855436940245, 0.4372345155922651, 0.7105885232959697, 0.7055894401456532, 0.4402217615896465],
    ["ASSISTments_time", "dNeuralCDM-fastslow", 3, 1, 0.7159488214933007, 0.7184505853483174, 0.4347568441711574, 0.7104931325224655, 0.7125844333181611, 0.43720033500627226],
    ["ASSISTments_time", "dNeuralCDM-fastslow", 4, 1, 0.7174944520450457, 0.7154964910361212, 0.4350186987177944, 0.7120070408737321, 0.7067583067819754, 0.439178790268277],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed.csv"
summary_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_fastslow_assistments_time_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

baseline_auc = 0.706384
baseline_acc = 0.699302
baseline_rmse = 0.443269
baseline_auc_std = 0.000717
baseline_acc_std = 0.002295
baseline_rmse_std = 0.001233

fast_auc, fast_auc_std = summary["test_AUC"]
fast_acc, fast_acc_std = summary["test_ACC"]
fast_rmse, fast_rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-fastslow on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 1.\n\n")
    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified on ASSISTments_time:\n")
    f.write(f"Baseline test_AUC: {baseline_auc:.6f} ± {baseline_auc_std:.6f}\n")
    f.write(f"Fastslow test_AUC: {fast_auc:.6f} ± {fast_auc_std:.6f}\n")
    f.write(f"AUC gain: {fast_auc - baseline_auc:+.6f}\n\n")

    f.write(f"Baseline test_ACC: {baseline_acc:.6f} ± {baseline_acc_std:.6f}\n")
    f.write(f"Fastslow test_ACC: {fast_acc:.6f} ± {fast_acc_std:.6f}\n")
    f.write(f"ACC gain: {fast_acc - baseline_acc:+.6f}\n\n")

    f.write(f"Baseline test_RMSE: {baseline_rmse:.6f} ± {baseline_rmse_std:.6f}\n")
    f.write(f"Fastslow test_RMSE: {fast_rmse:.6f} ± {fast_rmse_std:.6f}\n")
    f.write(f"RMSE gain: {fast_rmse - baseline_rmse:+.6f}\n\n")

    f.write("Conclusion: dNeuralCDM-fastslow improves over dNeuralCDM-unified on ASSISTments_time.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-fastslow on ASSISTments_time\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-unified | {baseline_auc:.6f} ± {baseline_auc_std:.6f} | {baseline_acc:.6f} ± {baseline_acc_std:.6f} | {baseline_rmse:.6f} ± {baseline_rmse_std:.6f} |\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-fastslow | **{fast_auc:.6f} ± {fast_auc_std:.6f}** | **{fast_acc:.6f} ± {fast_acc_std:.6f}** | **{fast_rmse:.6f} ± {fast_rmse_std:.6f}** |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
