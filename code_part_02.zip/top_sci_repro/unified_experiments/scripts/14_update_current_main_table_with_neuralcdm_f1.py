import csv
from pathlib import Path

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
csv_path = out_dir / "current_main_table_unified.csv"
md_path = out_dir / "current_main_table_unified.md"

header = [
    "Model",
    "ASSISTments_time AUC",
    "ASSISTments_time ACC",
    "ASSISTments_time RMSE",
    "ASSISTments_time F1",
    "EDNet AUC",
    "EDNet ACC",
    "EDNet RMSE",
    "EDNet F1",
    "Protocol",
]

rows = [
    [
        "NeuralCDM-unified",
        "0.684499 ± 0.000072",
        "0.669129 ± 0.000964",
        "0.454681 ± 0.000132",
        "0.755213 ± 0.001151",
        "0.714012 ± 0.000470",
        "0.696100 ± 0.000888",
        "0.445690 ± 0.000466",
        "0.783847 ± 0.001658",
        "Unified student-time 7:1:2 split, 5 seeds",
    ]
]

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

def md_row(cols):
    return "| " + " | ".join(cols) + " |"

with open(md_path, "w", encoding="utf-8") as f:
    f.write(md_row(header) + "\n")
    f.write(md_row(["---"] * len(header)) + "\n")
    for r in rows:
        f.write(md_row(r) + "\n")

print(open(md_path, encoding="utf-8").read())
