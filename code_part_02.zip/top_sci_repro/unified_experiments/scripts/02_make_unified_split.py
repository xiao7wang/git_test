import csv
import json
import math
from pathlib import Path
from collections import defaultdict, Counter

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")

DATASETS = {
    "assistments_time": ROOT / "unified_experiments/data/assistments_time",
    "ednet": ROOT / "unified_experiments/data/ednet",
}

SPLIT_ROOT = ROOT / "unified_experiments/splits"
RESULT_DIR = ROOT / "unified_experiments/results/main"
RESULT_DIR.mkdir(parents=True, exist_ok=True)

CANONICAL_FIELDS = ["student_id", "exercise_id", "score", "response_time", "timestamp"]

def to_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default

def to_int_float(x, default=0):
    try:
        return int(float(x))
    except Exception:
        return default

def summarize_csv(path):
    n = 0
    users = set()
    items = set()
    score_sum = 0.0
    score_count = 0
    scores = Counter()

    with open(path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            n += 1
            users.add(row["student_id"])
            items.add(row["exercise_id"])
            s = row["score"]
            scores[s] += 1
            try:
                score_sum += float(s)
                score_count += 1
            except Exception:
                pass

    return {
        "rows": n,
        "users": len(users),
        "items": len(items),
        "score_mean": score_sum / score_count if score_count else None,
        "score_dist": dict(scores),
    }

def write_rows(path, rows):
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=CANONICAL_FIELDS)
        writer.writeheader()
        for r in rows:
            writer.writerow({
                "student_id": r[2],
                "exercise_id": r[3],
                "score": r[4],
                "response_time": r[5],
                "timestamp": r[0],
            })

def make_split(dataset_name, data_dir):
    raw_path = data_dir / "interactions_raw.csv"
    out_dir = SPLIT_ROOT / dataset_name
    out_dir.mkdir(parents=True, exist_ok=True)

    if not raw_path.exists():
        raise FileNotFoundError(raw_path)

    print(f"\n===== {dataset_name} =====")
    print("raw:", raw_path)

    groups = defaultdict(list)
    total = 0

    with open(raw_path, "r", encoding="utf-8", errors="ignore", newline="") as f:
        reader = csv.DictReader(f)
        cols = reader.fieldnames or []
        required = set(CANONICAL_FIELDS)
        missing = required - set(cols)
        if missing:
            raise RuntimeError(f"{dataset_name} missing columns: {missing}; columns={cols}")

        for idx, row in enumerate(reader):
            sid = row["student_id"]
            eid = row["exercise_id"]
            score = row["score"]
            rt = row["response_time"]
            ts = row["timestamp"]

            # tuple: timestamp, original_order, student_id, exercise_id, score, response_time
            groups[sid].append((to_float(ts), idx, sid, eid, score, rt))
            total += 1

    print("loaded rows:", total)
    print("students:", len(groups))

    train_rows = []
    valid_rows = []
    test_rows = []

    user_len_counter = Counter()
    short_users = 0

    for sid, rows in groups.items():
        rows.sort(key=lambda x: (x[0], x[1]))
        n = len(rows)
        user_len_counter[n] += 1

        if n < 3:
            # 过短序列不强行放入验证/测试，避免产生没有历史信息的评价样本
            train_rows.extend(rows)
            short_users += 1
            continue

        n_train = int(math.floor(n * 0.7))
        n_valid = int(math.floor(n * 0.1))

        n_train = max(1, n_train)
        n_valid = max(1, n_valid)

        if n_train + n_valid >= n:
            n_valid = max(0, n - n_train - 1)

        n_test = n - n_train - n_valid
        if n_test <= 0:
            # 保底：至少保留最后一个交互作为测试
            n_test = 1
            if n_valid > 0:
                n_valid -= 1
            else:
                n_train = max(1, n_train - 1)

        train_rows.extend(rows[:n_train])
        valid_rows.extend(rows[n_train:n_train + n_valid])
        test_rows.extend(rows[n_train + n_valid:])

    train_path = out_dir / "train.csv"
    valid_path = out_dir / "valid.csv"
    test_path = out_dir / "test.csv"

    write_rows(train_path, train_rows)
    write_rows(valid_path, valid_rows)
    write_rows(test_path, test_rows)

    split_summary = {
        "dataset": dataset_name,
        "split_policy": "per-student chronological split; train=first 70%, valid=next 10%, test=last 20%",
        "raw_rows": total,
        "users_total": len(groups),
        "short_users_lt3_all_to_train": short_users,
        "train": summarize_csv(train_path),
        "valid": summarize_csv(valid_path),
        "test": summarize_csv(test_path),
        "user_sequence_length_min": min(user_len_counter.keys()) if user_len_counter else None,
        "user_sequence_length_max": max(user_len_counter.keys()) if user_len_counter else None,
        "user_sequence_length_distribution_head": dict(sorted(user_len_counter.items())[:20]),
    }

    summary_path = out_dir / "split_summary.json"
    summary_path.write_text(json.dumps(split_summary, ensure_ascii=False, indent=2), encoding="utf-8")

    print("saved:", train_path)
    print("saved:", valid_path)
    print("saved:", test_path)
    print("saved:", summary_path)
    print(json.dumps(split_summary, ensure_ascii=False, indent=2))

    return split_summary

all_summaries = []
for name, d in DATASETS.items():
    all_summaries.append(make_split(name, d))

summary_all_path = RESULT_DIR / "unified_split_summary.json"
summary_all_path.write_text(json.dumps(all_summaries, ensure_ascii=False, indent=2), encoding="utf-8")

md = ["# Unified Split Summary\n"]
for s in all_summaries:
    md.append(f"\n## {s['dataset']}\n")
    md.append(f"- policy: {s['split_policy']}")
    md.append(f"- raw_rows: {s['raw_rows']}")
    md.append(f"- users_total: {s['users_total']}")
    md.append(f"- short_users_lt3_all_to_train: {s['short_users_lt3_all_to_train']}")
    for part in ["train", "valid", "test"]:
        x = s[part]
        md.append(
            f"- {part}: rows={x['rows']}, users={x['users']}, items={x['items']}, "
            f"score_mean={x['score_mean']}, score_dist={x['score_dist']}"
        )

summary_md_path = RESULT_DIR / "unified_split_summary.md"
summary_md_path.write_text("\n".join(md) + "\n", encoding="utf-8")

print("\n===== all saved =====")
print(summary_all_path)
print(summary_md_path)
