#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro
source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
source ~/anaconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate cd5090

for SEED in 1 2 3 4
do
  echo "===== running Ours-v2 fast-slow EDNet beta=0.05 seed${SEED} ep8 ====="
  date

  CUDA_VISIBLE_DEVICES=0 python -u unified_experiments/scripts/28_train_neuralcdm_fastslow_trg.py \
    --dataset ednet \
    --seed ${SEED} \
    --epochs 8 \
    --batch_size 2048 \
    --eval_batch_size 8192 \
    --beta 0.05 \
    2>&1 | tee unified_experiments/results/ours_trg_current_rt/ednet_seed${SEED}_fastslow_beta005_ep8.log

  echo "===== finished EDNet fast-slow seed${SEED} ====="
  date
done
