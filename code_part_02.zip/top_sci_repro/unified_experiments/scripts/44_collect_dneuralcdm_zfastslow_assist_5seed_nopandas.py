from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["ASSISTments_time", "dNeuralCDM-zfastslow", 0, 1, 0.7153666381700357, 0.7134098688632208, 0.43629812609810115, 0.7093628710560477, 0.7043167956304051, 0.44078138498844655],
    ["ASSISTments_time", "dNeuralCDM-zfastslow", 1, 1, 0.7141594545352165, 0.7141327623126338, 0.4364213378416119, 0.7086917255570796, 0.7047064178425125, 0.4403494368226727],
    ["ASSISTments_time", "dNeuralCDM-zfastslow", 2, 1, 0.7166633075751141, 0.7178019350099252, 0.43503439171555947, 0.7115998085352625, 0.7122985889849796, 0.43766089253094487],
    ["ASSISTments_time", "dNeuralCDM-zfastslow", 3, 1, 0.7155385553637597, 0.711807780678035, 0.43735106473964513, 0.7106985954395298, 0.7032353208921256, 0.4416253840592518],
    ["ASSISTments_time", "dNeuralCDM-zfastslow", 4, 1, 0.7160892921136057, 0.7161412338423545, 0.43558621918479745, 0.7117656353418745, 0.7093855257168866, 0.43843832128741556],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_zfastslow_assistments_time_5seed.csv"
summary_path = out_dir / "dneuralcdm_zfastslow_assistments_time_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_zfastslow_assistments_time_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

baseline_auc = 0.706384
baseline_acc = 0.699302
baseline_rmse = 0.443269
baseline_auc_std = 0.000717
baseline_acc_std = 0.002295
baseline_rmse_std = 0.001233

fast_auc = 0.710056
fast_acc = 0.706310
fast_rmse = 0.440087

z_auc, z_auc_std = summary["test_AUC"]
z_acc, z_acc_std = summary["test_ACC"]
z_rmse, z_rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-zfastslow on ASSISTments_time, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 1.\n\n")

    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-unified on ASSISTments_time:\n")
    f.write(f"Baseline test_AUC: {baseline_auc:.6f} ± {baseline_auc_std:.6f}\n")
    f.write(f"Zfastslow test_AUC: {z_auc:.6f} ± {z_auc_std:.6f}\n")
    f.write(f"AUC gain: {z_auc - baseline_auc:+.6f}\n\n")

    f.write(f"Baseline test_ACC: {baseline_acc:.6f} ± {baseline_acc_std:.6f}\n")
    f.write(f"Zfastslow test_ACC: {z_acc:.6f} ± {z_acc_std:.6f}\n")
    f.write(f"ACC gain: {z_acc - baseline_acc:+.6f}\n\n")

    f.write(f"Baseline test_RMSE: {baseline_rmse:.6f} ± {baseline_rmse_std:.6f}\n")
    f.write(f"Zfastslow test_RMSE: {z_rmse:.6f} ± {z_rmse_std:.6f}\n")
    f.write(f"RMSE gain: {z_rmse - baseline_rmse:+.6f}\n\n")

    f.write("Compared with dNeuralCDM-fastslow on ASSISTments_time:\n")
    f.write(f"AUC difference: {z_auc - fast_auc:+.6f}\n")
    f.write(f"ACC difference: {z_acc - fast_acc:+.6f}\n")
    f.write(f"RMSE difference: {z_rmse - fast_rmse:+.6f}\n\n")

    f.write("Conclusion: zfastslow slightly improves over fastslow on ASSISTments_time across AUC, ACC, and RMSE.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-zfastslow on ASSISTments_time\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write("| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |\n")
    f.write("| ASSISTments_time | dNeuralCDM-fastslow | 0.710056 ± 0.001464 | 0.706310 ± 0.004913 | 0.440087 ± 0.002426 |\n")
    f.write(f"| ASSISTments_time | dNeuralCDM-zfastslow | **{z_auc:.6f} ± {z_auc_std:.6f}** | **{z_acc:.6f} ± {z_acc_std:.6f}** | **{z_rmse:.6f} ± {z_rmse_std:.6f}** |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
