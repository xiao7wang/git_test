import json
from pathlib import Path
from collections import Counter

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis/data")

DATASETS = [
    "assistments_time_dynamiccd",
    "ednet_kt1_time_dynamiccd",
    "assistments_time_dynamiccd_trg",
    "ednet_kt1_time_dynamiccd_trg",
]

def count_file(path):
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    n_users = len(data)
    n_logs = 0
    keys = Counter()

    first_stu = data[0] if data else None
    first_log = None

    for stu in data:
        if isinstance(stu, dict):
            keys.update(stu.keys())
            if "logs" in stu and isinstance(stu["logs"], list):
                n_logs += len(stu["logs"])
                if first_log is None and stu["logs"]:
                    first_log = stu["logs"][0]
            elif "log" in stu and isinstance(stu["log"], list):
                n_logs += len(stu["log"])
                if first_log is None and stu["log"]:
                    first_log = stu["log"][0]
            elif "exer_id" in stu or "problem_id" in stu:
                n_logs += 1
                if first_log is None:
                    first_log = stu
        elif isinstance(stu, list):
            n_logs += len(stu)
            if first_log is None and stu:
                first_log = stu[0]

    return n_users, n_logs, keys, first_stu, first_log

for ds in DATASETS:
    ds_dir = ROOT / ds
    print("=" * 100)
    print(ds)

    if not ds_dir.exists():
        print("MISSING:", ds_dir)
        continue

    cfg = ds_dir / "data_config.txt"
    if cfg.exists():
        print("data_config.txt:")
        print(cfg.read_text(encoding="utf-8", errors="ignore"))

    for name in ["train_0.json", "val_0.json", "test.json"]:
        path = ds_dir / name
        if path.exists():
            n_users, n_logs, keys, first_stu, first_log = count_file(path)
            print(f"{name}: users={n_users}, logs={n_logs}, keys={dict(keys)}")
            print(f"first_log={first_log}")
        else:
            print(f"{name}: MISSING")
