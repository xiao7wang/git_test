import re
import csv
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
LOG_DIR = ROOT / "repos/Neural_Cognitive_Diagnosis-NeuralCD/logs/unified"
OUT_DIR = ROOT / "unified_experiments/results/main"
OUT_DIR.mkdir(parents=True, exist_ok=True)

EPOCHS = 5
DATASET = "ednet"
MODEL = "NeuralCDM-unified"

pat = re.compile(
    r"epoch=\s*(\d+),\s*accuracy=\s*([0-9.]+),\s*rmse=\s*([0-9.]+),\s*auc=\s*([0-9.]+)"
)

def parse_metrics(path):
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        m = pat.search(line)
        if m:
            rows.append({
                "epoch": int(m.group(1)),
                "ACC": float(m.group(2)),
                "RMSE": float(m.group(3)),
                "AUC": float(m.group(4)),
            })
    return rows

def mean(xs):
    return sum(xs) / len(xs) if xs else float("nan")

def std(xs):
    if len(xs) <= 1:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

result_rows = []

for seed in range(5):
    train_log = LOG_DIR / f"{DATASET}_seed{seed}_epoch{EPOCHS}_train.log"
    val_rows = parse_metrics(train_log)
    if not val_rows:
        print("missing validation metrics:", train_log)
        continue

    best = max(val_rows, key=lambda x: x["AUC"])
    best_epoch = best["epoch"]

    test_log = LOG_DIR / f"{DATASET}_seed{seed}_epoch{EPOCHS}_best{best_epoch}_test.log"
    test_rows = parse_metrics(test_log)
    if not test_rows:
        print("missing test metrics:", test_log)
        continue

    test = test_rows[-1]

    result_rows.append({
        "model": MODEL,
        "dataset": DATASET,
        "seed": seed,
        "best_epoch": best_epoch,
        "valid_AUC": best["AUC"],
        "valid_ACC": best["ACC"],
        "valid_RMSE": best["RMSE"],
        "test_AUC": test["AUC"],
        "test_ACC": test["ACC"],
        "test_RMSE": test["RMSE"],
        "train_log": str(train_log),
        "test_log": str(test_log),
    })

csv_path = OUT_DIR / "neuralcdm_unified_ednet_5seed.csv"
with open(csv_path, "w", encoding="utf-8", newline="") as f:
    fieldnames = [
        "model", "dataset", "seed", "best_epoch",
        "valid_AUC", "valid_ACC", "valid_RMSE",
        "test_AUC", "test_ACC", "test_RMSE",
        "train_log", "test_log"
    ]
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()
    writer.writerows(result_rows)

summary_path = OUT_DIR / "neuralcdm_unified_ednet_5seed_summary.txt"

with open(summary_path, "w", encoding="utf-8") as f:
    f.write(f"{MODEL} on {DATASET}, {EPOCHS} epochs, 5 seeds\n")
    f.write("=" * 80 + "\n")
    for r in result_rows:
        f.write(str(r) + "\n")
    f.write("\n")
    for metric in ["test_AUC", "test_ACC", "test_RMSE", "valid_AUC"]:
        xs = [r[metric] for r in result_rows]
        f.write(f"{metric}: {mean(xs):.6f} ± {std(xs):.6f}\n")

print("saved:", csv_path)
print("saved:", summary_path)
print(summary_path.read_text(encoding="utf-8"))
