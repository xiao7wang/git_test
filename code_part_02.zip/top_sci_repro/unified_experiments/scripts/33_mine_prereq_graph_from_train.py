import argparse
import csv
import math
from pathlib import Path
from collections import defaultdict

import numpy as np

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
SPLIT = ROOT / "unified_experiments/splits"
DATA = ROOT / "unified_experiments/data"
OUT = ROOT / "unified_experiments/results/prereq_graph"
OUT.mkdir(parents=True, exist_ok=True)

META = {
    "assistments_time": {"item": 52690, "k": 218},
    "ednet": {"item": 12198, "k": 141},
}

def pick(cols, names):
    low = {c.lower(): c for c in cols}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    raise RuntimeError(f"missing {names}, cols={cols}")

def read_q(path, item_n, k_n):
    rows = []
    with open(path, encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row:
                continue
            ok = True
            vals = []
            for x in row:
                try:
                    vals.append(float(x))
                except Exception:
                    ok = False
                    break
            if ok:
                rows.append(vals)

    q = np.zeros((item_n, k_n), dtype=np.float32)
    for i, r in enumerate(rows):
        if len(r) == k_n:
            idx, vals = i, r
        elif len(r) == k_n + 1:
            raw = int(r[0])
            idx, vals = (raw if raw < item_n else raw - 1), r[1:]
        else:
            continue
        if 0 <= idx < item_n:
            q[idx] = vals

    q[q.sum(1) == 0, 0] = 1.0
    return q

def read_train(dataset):
    path = SPLIT / dataset / "train.csv"
    by_stu = defaultdict(list)

    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        cols = rd.fieldnames
        stu_c = pick(cols, ["student_id", "stu_id", "user_id", "sid"])
        item_c = pick(cols, ["exercise_id", "item_id", "problem_id", "exer_id", "pid"])
        y_c = pick(cols, ["score", "correct", "label", "r"])
        ts_c = pick(cols, ["timestamp", "time", "order_time", "submit_time"])

        for idx, r in enumerate(rd):
            stu = int(float(r[stu_c]))
            item = int(float(r[item_c]))
            y = int(float(r[y_c]))
            ts = float(r[ts_c])
            by_stu[stu].append((ts, idx, item, y))

    return by_stu

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["assistments_time", "ednet"])
    ap.add_argument("--window", type=int, default=5)
    ap.add_argument("--min_support", type=int, default=200)
    ap.add_argument("--top_k", type=int, default=800)
    ap.add_argument("--asym_threshold", type=float, default=0.03)
    args = ap.parse_args()

    meta = META[args.dataset]
    q = read_q(DATA / args.dataset / "q.csv", meta["item"], meta["k"])
    item_concepts = [np.where(q[i] > 0)[0].tolist() for i in range(meta["item"])]

    by_stu = read_train(args.dataset)
    print(f"[data] dataset={args.dataset}, students={len(by_stu)}, k={meta['k']}", flush=True)

    C = np.zeros((meta["k"], meta["k"]), dtype=np.float64)

    for n, (stu, seq) in enumerate(by_stu.items(), 1):
        seq.sort(key=lambda x: (x[0], x[1]))

        for i in range(len(seq)):
            _, _, item_i, y_i = seq[i]
            if y_i != 1:
                continue

            ci = item_concepts[item_i]
            if not ci:
                continue

            end = min(len(seq), i + 1 + args.window)
            for j in range(i + 1, end):
                _, _, item_j, y_j = seq[j]
                if y_j != 1:
                    continue

                cj = item_concepts[item_j]
                if not cj:
                    continue

                for a in ci:
                    for b in cj:
                        if a != b:
                            C[a, b] += 1.0

        if n % 1000 == 0:
            print(f"[mine] processed students={n}", flush=True)

    edges = []
    for a in range(meta["k"]):
        for b in range(meta["k"]):
            if a == b:
                continue
            forward = C[a, b]
            backward = C[b, a]
            if forward < args.min_support:
                continue
            asym = (forward - backward) / (forward + backward + 1e-9)
            if asym < args.asym_threshold:
                continue
            score = asym * math.log1p(forward)
            edges.append((score, asym, forward, backward, a, b))

    edges.sort(reverse=True)
    edges = edges[:args.top_k]

    adj = np.zeros((meta["k"], meta["k"]), dtype=np.float32)
    max_score = max([e[0] for e in edges], default=1.0)
    for score, asym, forward, backward, a, b in edges:
        adj[a, b] = float(score / max_score)

    npy_path = OUT / f"{args.dataset}_prereq_graph_mined.npy"
    csv_path = OUT / f"{args.dataset}_prereq_graph_mined_edges.csv"

    np.save(npy_path, adj)

    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        wr = csv.writer(f)
        wr.writerow(["src_concept", "dst_concept", "weight", "score", "asym", "forward", "backward"])
        for score, asym, forward, backward, a, b in edges:
            wr.writerow([a, b, adj[a, b], score, asym, forward, backward])

    print(f"[done] edges={len(edges)}")
    print(f"[done] saved npy={npy_path}")
    print(f"[done] saved csv={csv_path}")

if __name__ == "__main__":
    main()
