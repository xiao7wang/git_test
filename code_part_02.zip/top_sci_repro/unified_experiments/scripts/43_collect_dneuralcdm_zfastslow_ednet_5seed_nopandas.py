from pathlib import Path
import csv
import statistics as stats

out_dir = Path("/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/results/main")
out_dir.mkdir(parents=True, exist_ok=True)

rows = [
    ["EDNet", "dNeuralCDM-zfastslow", 0, 2, 0.7397189298931087, 0.7166360487590180, 0.4318957553269695, 0.7398749088020906, 0.7130057662406482, 0.43355760161198400],
    ["EDNet", "dNeuralCDM-zfastslow", 1, 2, 0.7385378663082744, 0.7157557839141168, 0.4321370690625290, 0.7396183295902762, 0.7132102923095874, 0.43359777998032595],
    ["EDNet", "dNeuralCDM-zfastslow", 2, 2, 0.7387714742139445, 0.7161767801442869, 0.4321201625184135, 0.7390202905948463, 0.7132869895854396, 0.43377157073253747],
    ["EDNet", "dNeuralCDM-zfastslow", 3, 2, 0.7390887148981586, 0.7165547199418260, 0.4317845445641799, 0.7390509622823502, 0.7129802004820308, 0.43341903421687990],
    ["EDNet", "dNeuralCDM-zfastslow", 4, 2, 0.7389939471631572, 0.7141626959067685, 0.4328158540615181, 0.7392723855608772, 0.7131335950337352, 0.43379904250609970],
]

header = [
    "dataset", "model", "seed", "best_epoch",
    "valid_AUC", "valid_ACC", "valid_RMSE",
    "test_AUC", "test_ACC", "test_RMSE"
]

csv_path = out_dir / "dneuralcdm_zfastslow_ednet_5seed.csv"
summary_path = out_dir / "dneuralcdm_zfastslow_ednet_5seed_summary.txt"
md_path = out_dir / "dneuralcdm_zfastslow_ednet_5seed_table.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(header)
    writer.writerows(rows)

idx = {name: i for i, name in enumerate(header)}

def mean_std(col):
    vals = [float(r[idx[col]]) for r in rows]
    return stats.mean(vals), stats.stdev(vals)

metrics = ["valid_AUC", "valid_ACC", "valid_RMSE", "test_AUC", "test_ACC", "test_RMSE"]
summary = {m: mean_std(m) for m in metrics}

fast_auc = 0.739116
fast_acc = 0.713178
fast_rmse = 0.433614

z_auc, z_auc_std = summary["test_AUC"]
z_acc, z_acc_std = summary["test_ACC"]
z_rmse, z_rmse_std = summary["test_RMSE"]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-zfastslow on EDNet, 5 seeds\n")
    f.write("Best epoch selected by validation AUC. All best_epoch = 2.\n\n")
    for m in metrics:
        mean, std = summary[m]
        f.write(f"{m}: {mean:.6f} ± {std:.6f}\n")

    f.write("\nCompared with dNeuralCDM-fastslow on EDNet:\n")
    f.write(f"Fastslow test_AUC: {fast_auc:.6f}\n")
    f.write(f"Zfastslow test_AUC: {z_auc:.6f} ± {z_auc_std:.6f}\n")
    f.write(f"AUC difference: {z_auc - fast_auc:+.6f}\n\n")

    f.write(f"Fastslow test_ACC: {fast_acc:.6f}\n")
    f.write(f"Zfastslow test_ACC: {z_acc:.6f} ± {z_acc_std:.6f}\n")
    f.write(f"ACC difference: {z_acc - fast_acc:+.6f}\n\n")

    f.write(f"Fastslow test_RMSE: {fast_rmse:.6f}\n")
    f.write(f"Zfastslow test_RMSE: {z_rmse:.6f} ± {z_rmse_std:.6f}\n")
    f.write(f"RMSE difference: {z_rmse - fast_rmse:+.6f}\n\n")

    f.write("Conclusion: zfastslow slightly improves AUC over fastslow on EDNet, but ACC/RMSE are nearly unchanged or slightly worse. Treat it as a normalization ablation rather than replacing the main model yet.\n")

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# dNeuralCDM-zfastslow on EDNet\n\n")
    f.write("| Dataset | Model | AUC | ACC | RMSE |\n")
    f.write("|---|---|---:|---:|---:|\n")
    f.write("| EDNet | dNeuralCDM-fastslow | 0.739116 ± 0.000267 | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |\n")
    f.write(f"| EDNet | dNeuralCDM-zfastslow | **{z_auc:.6f} ± {z_auc_std:.6f}** | {z_acc:.6f} ± {z_acc_std:.6f} | {z_rmse:.6f} ± {z_rmse_std:.6f} |\n")

print(f"Saved CSV: {csv_path}")
print(f"Saved summary: {summary_path}")
print(f"Saved markdown table: {md_path}")
print()
print(open(summary_path, encoding="utf-8").read())
