from pathlib import Path
import csv
import math
import numpy as np
from sklearn.metrics import roc_auc_score

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
IN_DIR = ROOT / "unified_experiments/results/analysis"
OUT_DIR = ROOT / "unified_experiments/results/analysis"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def read_csv(path):
    with open(path, "r", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def metrics(labels, preds):
    labels = np.asarray(labels, dtype=np.int64)
    preds = np.asarray(preds, dtype=np.float64)
    binary = (preds >= 0.5).astype(np.int64)
    auc = roc_auc_score(labels, preds) if len(set(labels.tolist())) > 1 else float("nan")
    acc = float(np.mean(binary == labels))
    rmse = math.sqrt(float(np.mean((preds - labels) ** 2)))
    return auc, acc, rmse

def group_name(rt):
    rt = float(rt)
    if rt < -0.5:
        return "fast"
    if rt > 0.5:
        return "slow"
    return "normal"

def analyze_dataset(dataset, baseline_file, pbts_file):
    base = read_csv(IN_DIR / baseline_file)
    pbts = read_csv(IN_DIR / pbts_file)

    if len(base) != len(pbts):
        raise RuntimeError(f"{dataset}: row count mismatch baseline={len(base)}, pbts={len(pbts)}")

    groups = {"fast": [], "normal": [], "slow": []}
    mismatch = 0
    missing_rt = 0

    for b, p in zip(base, pbts):
        if b["label"] != p["label"]:
            mismatch += 1
        if p["rt_residual"] == "":
            missing_rt += 1
            continue
        g = group_name(p["rt_residual"])
        groups[g].append((b, p))

    print(f"[{dataset}] n={len(base)}, label_mismatch={mismatch}, missing_rt={missing_rt}")

    rows = []
    for g, pairs in groups.items():
        b_labels = [int(x[0]["label"]) for x in pairs]
        b_preds = [float(x[0]["pred"]) for x in pairs]
        p_labels = [int(x[1]["label"]) for x in pairs]
        p_preds = [float(x[1]["pred"]) for x in pairs]

        b_auc, b_acc, b_rmse = metrics(b_labels, b_preds)
        p_auc, p_acc, p_rmse = metrics(p_labels, p_preds)

        rows.append([dataset, g, "baseline", len(pairs), b_auc, b_acc, b_rmse])
        rows.append([dataset, g, "PBTS-CD", len(pairs), p_auc, p_acc, p_rmse])
        rows.append([dataset, g, "gain", len(pairs), p_auc - b_auc, p_acc - b_acc, b_rmse - p_rmse])

    return rows

all_rows = []
all_rows += analyze_dataset(
    "ASSISTments_time",
    "assist_baseline_seed0_test_predictions.csv",
    "assist_pbts_seed0_test_predictions.csv",
)
all_rows += analyze_dataset(
    "EDNet",
    "ednet_baseline_seed0_test_predictions.csv",
    "ednet_pbts_seed0_test_predictions.csv",
)

csv_path = OUT_DIR / "rt_group_analysis_seed0.csv"
md_path = OUT_DIR / "rt_group_analysis_seed0.md"

with open(csv_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["dataset", "rt_group", "model", "n", "AUC", "ACC", "RMSE_or_RMSE_gain"])
    writer.writerows(all_rows)

with open(md_path, "w", encoding="utf-8") as f:
    f.write("# Response-time group analysis, seed0\n\n")
    f.write("Groups are defined by item-normalized response-time residual: fast < -0.5, normal in [-0.5, 0.5], slow > 0.5.\n\n")
    f.write("| Dataset | RT group | Model | n | AUC | ACC | RMSE / RMSE gain |\n")
    f.write("|---|---|---|---:|---:|---:|---:|\n")
    for r in all_rows:
        dataset, g, model, n, auc, acc, rmse = r
        f.write(f"| {dataset} | {g} | {model} | {n} | {auc:.6f} | {acc:.6f} | {rmse:.6f} |\n")

print(f"Saved: {csv_path}")
print(f"Saved: {md_path}")
print()
print(md_path.read_text(encoding="utf-8"))
