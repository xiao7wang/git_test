#!/usr/bin/env bash
set -e
cd /home/wangxiao/QCCDM/top_sci_repro
source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
source ~/anaconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate cd5090

for DATASET in ednet assistments_time
do
  for SEED in 0 1 2 3 4
  do
    echo "===== running Ours-TRG DATASET=${DATASET} SEED=${SEED} ====="
    date
    CUDA_VISIBLE_DEVICES=0 python -u unified_experiments/scripts/22_train_neuralcdm_trg_current_rt_min.py \
      --dataset ${DATASET} \
      --seed ${SEED} \
      --epochs 3 \
      --batch_size 4096 \
      --eval_batch_size 8192 \
      --beta 0.3 \
      2>&1 | tee unified_experiments/results/ours_trg_current_rt/${DATASET}_seed${SEED}_min.log
    date
  done
done
