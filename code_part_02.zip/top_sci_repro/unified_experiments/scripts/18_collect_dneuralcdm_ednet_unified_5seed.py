import re
import csv
import math
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
REPO = ROOT / "repos/Dynamic-Cognitive-Diagnosis"
OUT_DIR = ROOT / "unified_experiments/results/main"
OUT_DIR.mkdir(parents=True, exist_ok=True)

pattern = re.compile(
    r"\[(validation|test)\] stage=(\d+), epoch=(\d+): "
    r"auc=([0-9.eE+-]+), rmse=([0-9.eE+-]+), acc=([0-9.eE+-]+), "
    r"precision=([0-9.eE+-]+), recall=([0-9.eE+-]+), f1=([0-9.eE+-]+)"
)

rows = []

for seed in range(5):
    result_path = REPO / f"ws/dneuralcdm/ednet_unified_dynamiccd_original_seed{seed}_lr001/results.txt"

    if not result_path.exists():
        raise FileNotFoundError(f"Missing results file: {result_path}")

    records = []
    for line in result_path.read_text(encoding="utf-8").splitlines():
        m = pattern.search(line)
        if not m:
            continue
        dtype, stage, epoch, auc, rmse, acc, precision, recall, f1 = m.groups()
        records.append({
            "dtype": dtype,
            "stage": int(stage),
            "epoch": int(epoch),
            "AUC": float(auc),
            "RMSE": float(rmse),
            "ACC": float(acc),
            "Precision": float(precision),
            "Recall": float(recall),
            "F1": float(f1),
        })

    val_records = [r for r in records if r["dtype"] == "validation"]
    test_records = [r for r in records if r["dtype"] == "test"]

    if not val_records:
        raise RuntimeError(f"No validation records in {result_path}")
    if not test_records:
        raise RuntimeError(f"No test records in {result_path}")

    best_val = max(val_records, key=lambda x: x["AUC"])
    best_epoch = best_val["epoch"]

    matched_test = [r for r in test_records if r["epoch"] == best_epoch]
    if not matched_test:
        raise RuntimeError(f"No matched test record for seed={seed}, best_epoch={best_epoch}")

    test = matched_test[0]

    rows.append({
        "dataset": "ednet",
        "model": "dNeuralCDM-unified",
        "seed": seed,
        "best_epoch": best_epoch,
        "valid_AUC": best_val["AUC"],
        "valid_ACC": best_val["ACC"],
        "valid_RMSE": best_val["RMSE"],
        "valid_Precision": best_val["Precision"],
        "valid_Recall": best_val["Recall"],
        "valid_F1": best_val["F1"],
        "test_AUC": test["AUC"],
        "test_ACC": test["ACC"],
        "test_RMSE": test["RMSE"],
        "test_Precision": test["Precision"],
        "test_Recall": test["Recall"],
        "test_F1": test["F1"],
    })

csv_path = OUT_DIR / "dneuralcdm_unified_ednet_5seed.csv"
summary_path = OUT_DIR / "dneuralcdm_unified_ednet_5seed_summary.txt"

header = list(rows[0].keys())
with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=header)
    writer.writeheader()
    writer.writerows(rows)

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    if len(xs) <= 1:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

metrics = [
    "valid_AUC", "valid_ACC", "valid_RMSE", "valid_Precision", "valid_Recall", "valid_F1",
    "test_AUC", "test_ACC", "test_RMSE", "test_Precision", "test_Recall", "test_F1",
]

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-unified on EDNet, 5 seeds\n")
    f.write("Best epoch selected by validation AUC.\n\n")
    for r in rows:
        f.write(
            f"seed={r['seed']}, best_epoch={r['best_epoch']}, "
            f"test_AUC={r['test_AUC']:.6f}, test_ACC={r['test_ACC']:.6f}, "
            f"test_RMSE={r['test_RMSE']:.6f}, test_F1={r['test_F1']:.6f}\n"
        )
    f.write("\nSummary:\n")
    for m in metrics:
        vals = [r[m] for r in rows]
        f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")

print(open(summary_path, encoding="utf-8").read())
print("Saved:", csv_path)
print("Saved:", summary_path)
