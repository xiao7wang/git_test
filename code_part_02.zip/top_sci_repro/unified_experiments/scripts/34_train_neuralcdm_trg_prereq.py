import argparse, csv, math, random
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import roc_auc_score, accuracy_score, mean_squared_error, precision_score, recall_score, f1_score

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
SPLIT = ROOT / "unified_experiments/splits"
DATA = ROOT / "unified_experiments/data"
OUT = ROOT / "unified_experiments/results/ours_trg_current_rt"

META = {
    "assistments_time": {"stu": 20257, "item": 52690, "k": 218},
    "ednet": {"stu": 10000, "item": 12198, "k": 141},
}

def seed_all(seed):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)

def pick(cols, names, required=True):
    low = {c.lower(): c for c in cols}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    if required:
        raise RuntimeError(f"missing column from {names}, columns={cols}")
    return None

def read_q(path, item_n, k_n):
    arr = []
    with open(path, encoding="utf-8") as f:
        for row in csv.reader(f):
            if row and all(x.replace(".", "", 1).replace("-", "", 1).isdigit() for x in row):
                arr.append([float(x) for x in row])
    q = np.zeros((item_n, k_n), dtype=np.float32)
    for i, r in enumerate(arr):
        if len(r) == k_n:
            idx, vals = i, r
        elif len(r) == k_n + 1:
            raw = int(r[0])
            idx, vals = (raw if raw < item_n else raw - 1), r[1:]
        else:
            continue
        if 0 <= idx < item_n:
            q[idx] = vals
    q[q.sum(1) == 0, 0] = 1.0
    return q

def read_split(path):
    rows = []
    with open(path, encoding="utf-8") as f:
        rd = csv.DictReader(f)
        cols = rd.fieldnames
        stu_c = pick(cols, ["student_id", "stu_id", "user_id", "sid"])
        item_c = pick(cols, ["exercise_id", "item_id", "problem_id", "exer_id", "pid"])
        y_c = pick(cols, ["score", "correct", "label", "r"])
        rt_c = pick(cols, ["response_time", "rt", "elapsed_time", "time_spent", "answer_time", "duration"], False)
        ts_c = pick(cols, ["timestamp", "time", "order_time", "submit_time"], False)
        print(f"[COLUMNS] {path.name}: stu={stu_c}, item={item_c}, y={y_c}, rt={rt_c}, ts={ts_c}", flush=True)
        for i, r in enumerate(rd):
            rows.append([
                int(float(r[stu_c])),
                int(float(r[item_c])),
                int(float(r[y_c])),
                float(r[rt_c]) if rt_c and r.get(rt_c, "") not in ("", None) else math.nan,
                float(r[ts_c]) if ts_c and r.get(ts_c, "") not in ("", None) else math.nan,
                i
            ])
    return rows, rt_c, ts_c

def normalize_ids(all_sets, stu_n, item_n):
    all_stu = [r[0] for rows in all_sets for r in rows]
    all_item = [r[1] for rows in all_sets for r in rows]
    stu_shift = 0 if min(all_stu) == 0 else 1
    item_shift = 0 if min(all_item) == 0 else 1
    for rows in all_sets:
        for r in rows:
            r[0] -= stu_shift
            r[1] -= item_shift
            if not (0 <= r[0] < stu_n and 0 <= r[1] < item_n):
                raise RuntimeError(f"id out of range: {r}")
    print(f"[ID] stu_shift={stu_shift}, item_shift={item_shift}", flush=True)

def add_rt(train, valid, test):
    has_rt = any(not math.isnan(r[3]) for r in train + valid + test)
    has_ts = any(not math.isnan(r[4]) for r in train + valid + test)

    if has_rt:
        src = "response_time"
        for rows in [train, valid, test]:
            for r in rows:
                v = 0.0 if math.isnan(r[3]) or r[3] < 0 else r[3]
                r.append(math.log1p(v))
    elif has_ts:
        src = "timestamp_gap_proxy"
        for rows in [train, valid, test]:
            by_stu = {}
            for r in rows:
                by_stu.setdefault(r[0], []).append(r)
            for _, rs in by_stu.items():
                rs.sort(key=lambda x: (x[4], x[5]))
                prev = None
                for r in rs:
                    gap = 0.0 if prev is None or math.isnan(r[4]) else max(0.0, r[4] - prev)
                    r.append(math.log1p(gap))
                    if not math.isnan(r[4]):
                        prev = r[4]
    else:
        raise RuntimeError("No response_time/rt or timestamp column. Stop: TRG-current-rt cannot be run.")

    mean = float(np.mean([r[6] for r in train]))
    std = float(np.std([r[6] for r in train]))
    std = std if std > 1e-6 else 1.0
    for rows in [train, valid, test]:
        for r in rows:
            r[6] = float(np.clip((r[6] - mean) / std, -5, 5))
    print(f"[RT] source={src}, mean={mean:.6f}, std={std:.6f}", flush=True)
    return src

class DS(Dataset):
    def __init__(self, rows):
        self.s = np.array([r[0] for r in rows], np.int64)
        self.i = np.array([r[1] for r in rows], np.int64)
        self.y = np.array([r[2] for r in rows], np.float32)
        self.rt = np.array([r[6] for r in rows], np.float32)
    def __len__(self): return len(self.y)
    def __getitem__(self, idx): return self.s[idx], self.i[idx], self.rt[idx], self.y[idx]


class NCDM_TRG(nn.Module):
    def __init__(self, stu_n, item_n, k_n, q, beta):
        super().__init__()
        self.stu = nn.Embedding(stu_n, k_n)
        self.diff = nn.Embedding(item_n, k_n)
        self.disc = nn.Embedding(item_n, 1)

        self.rt_gate = nn.Sequential(
            nn.Linear(1, k_n),
            nn.Sigmoid()
        )

        self.fc1 = nn.Linear(k_n, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, 1)
        self.drop1 = nn.Dropout(0.5)
        self.drop2 = nn.Dropout(0.5)

        self.beta = beta
        self.register_buffer("q", torch.tensor(q, dtype=torch.float32))

        nn.init.xavier_normal_(self.stu.weight)
        nn.init.xavier_normal_(self.diff.weight)
        nn.init.xavier_normal_(self.disc.weight)

    def apply_clipper(self):
        # NeuralCDM 单调性约束：预测网络权重非负
        self.fc1.weight.data.clamp_(0)
        self.fc2.weight.data.clamp_(0)
        self.fc3.weight.data.clamp_(0)

    def forward(self, s, i, rt):
        q = self.q[i]
        mastery = torch.sigmoid(self.stu(s))
        diff = torch.sigmoid(self.diff(i))
        disc = torch.sigmoid(self.disc(i)) * 10.0

        # beta=0 时退化为普通 NeuralCDM；beta>0 时启用当前响应时长门控
        if self.beta != 0:
            gate = self.rt_gate(rt.view(-1, 1))
            mastery = mastery * (1.0 + self.beta * (gate - 0.5))
            mastery = torch.clamp(mastery, 0.0, 1.0)

        x = disc * (mastery - diff) * q
        x = torch.sigmoid(self.fc1(x))
        x = self.drop1(x)
        x = torch.sigmoid(self.fc2(x))
        x = self.drop2(x)
        x = torch.sigmoid(self.fc3(x)).squeeze(1)
        return x

def evaluate(model, loader, dev):
    model.eval(); ps=[]; ys=[]
    with torch.no_grad():
        for s,i,rt,y in loader:
            s,i,rt = s.to(dev), i.to(dev), rt.to(dev)
            p = model(s,i,rt).cpu().numpy()
            ps.extend(p.tolist()); ys.extend(y.numpy().tolist())
    ps = np.array(ps); ys = np.array(ys).astype(int); by = (ps >= 0.5).astype(int)
    return {
        "auc": roc_auc_score(ys, ps),
        "acc": accuracy_score(ys, by),
        "rmse": math.sqrt(mean_squared_error(ys, ps)),
        "precision": precision_score(ys, by, zero_division=0),
        "recall": recall_score(ys, by, zero_division=0),
        "f1": f1_score(ys, by, zero_division=0),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True, choices=["assistments_time", "ednet"])
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--batch_size", type=int, default=4096)
    ap.add_argument("--eval_batch_size", type=int, default=8192)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--beta", type=float, default=0.05)
    ap.add_argument("--prereq_path", type=str, default="")
    ap.add_argument("--prereq_lambda", type=float, default=0.0)
    args = ap.parse_args()

    seed_all(args.seed)
    meta = META[args.dataset]
    dev = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    train, _, _ = read_split(SPLIT / args.dataset / "train.csv")
    valid, _, _ = read_split(SPLIT / args.dataset / "valid.csv")
    test, _, _ = read_split(SPLIT / args.dataset / "test.csv")
    normalize_ids([train, valid, test], meta["stu"], meta["item"])
    rt_src = add_rt(train, valid, test)

    q = read_q(DATA / args.dataset / "q.csv", meta["item"], meta["k"])
    model = NCDM_TRG(meta["stu"], meta["item"], meta["k"], q, args.beta).to(dev)

    if args.prereq_path and args.prereq_lambda > 0:
        adj = np.load(args.prereq_path).astype(np.float32)
        src, dst = np.nonzero(adj > 0)
        w = adj[src, dst]
        model.edge_src = torch.tensor(src, dtype=torch.long, device=dev)
        model.edge_dst = torch.tensor(dst, dtype=torch.long, device=dev)
        model.edge_w = torch.tensor(w, dtype=torch.float32, device=dev)
        print(f"[PREREQ] loaded edges={len(src)}, lambda={args.prereq_lambda}, path={args.prereq_path}", flush=True)
    else:
        model.edge_src = None
        model.edge_dst = None
        model.edge_w = None
        print("[PREREQ] disabled", flush=True)
    opt = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=1e-6)
    loss_fn = nn.BCELoss()

    out_dir = OUT / args.dataset
    out_dir.mkdir(parents=True, exist_ok=True)
    res = out_dir / f"neuralcdm_trg_current_rt_{args.dataset}_seed{args.seed}.txt"

    loaders = {
        "train": DataLoader(DS(train), batch_size=args.batch_size, shuffle=True, num_workers=2, pin_memory=True),
        "valid": DataLoader(DS(valid), batch_size=args.eval_batch_size, shuffle=False, num_workers=2, pin_memory=True),
        "test": DataLoader(DS(test), batch_size=args.eval_batch_size, shuffle=False, num_workers=2, pin_memory=True),
    }

    best = None
    with open(res, "w", encoding="utf-8") as f:
        f.write(f"dataset={args.dataset}, seed={args.seed}, rt_source={rt_src}, beta={args.beta}\n")

    for ep in range(args.epochs):
        model.train(); total=0; n=0
        for step, (s,i,rt,y) in enumerate(loaders["train"], 1):
            s,i,rt,y = s.to(dev), i.to(dev), rt.to(dev), y.to(dev)
            opt.zero_grad()
            pred = model(s,i,rt)
            loss = loss_fn(pred, y)

            if args.prereq_lambda > 0 and model.edge_src is not None and model.edge_src.numel() > 0:
                uniq_s = torch.unique(s)
                mastery = torch.sigmoid(model.stu(uniq_s))
                violation = torch.relu(mastery[:, model.edge_dst] - mastery[:, model.edge_src])
                prereq_loss = (violation.pow(2) * model.edge_w.view(1, -1)).mean()
                loss = loss + args.prereq_lambda * prereq_loss

            loss.backward(); opt.step(); model.apply_clipper()
            total += loss.item() * y.numel(); n += y.numel()
            if step % 100 == 0:
                print(f"[train] epoch={ep}, step={step}, loss={total/n:.6f}", flush=True)

        val = evaluate(model, loaders["valid"], dev)
        tst = evaluate(model, loaders["test"], dev)
        print(f"[validation] epoch={ep}: {val}", flush=True)
        print(f"[test] epoch={ep}: {tst}", flush=True)

        with open(res, "a", encoding="utf-8") as f:
            f.write(f"[validation] epoch={ep}: {val}\n")
            f.write(f"[test] epoch={ep}: {tst}\n")

        if best is None or val["auc"] > best["valid_auc"]:
            best = {"epoch": ep, "valid_auc": val["auc"], **{f"test_{k}": v for k,v in tst.items()}}

    line = " ".join([f"{k}={v}" for k,v in best.items()])
    print("[best] " + line, flush=True)
    with open(res, "a", encoding="utf-8") as f:
        f.write("[best] " + line + "\n")

if __name__ == "__main__":
    main()
