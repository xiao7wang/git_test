import re
import math
import csv
from pathlib import Path

ROOT = Path("/home/wangxiao/QCCDM/top_sci_repro")
LOG_DIR = ROOT / "repos/Dynamic-Cognitive-Diagnosis/logs"
OUT = ROOT / "unified_experiments/results/main"
OUT.mkdir(parents=True, exist_ok=True)

val_pat = re.compile(
    r"\[validation\] stage=1, epoch=(\d+): auc=([0-9.eE+-]+), rmse=([0-9.eE+-]+), acc=([0-9.eE+-]+), precision=([0-9.eE+-]+), recall=([0-9.eE+-]+), f1=([0-9.eE+-]+)"
)
test_pat = re.compile(
    r"\[test\] stage=1, epoch=(\d+): auc=([0-9.eE+-]+), rmse=([0-9.eE+-]+), acc=([0-9.eE+-]+), precision=([0-9.eE+-]+), recall=([0-9.eE+-]+), f1=([0-9.eE+-]+)"
)

rows = []

for seed in range(5):
    path = LOG_DIR / f"dneuralcdm_unified_ednet_attr4_matched_seed{seed}.log"
    if not path.exists():
        raise FileNotFoundError(path)

    text = path.read_text(encoding="utf-8")
    vals = val_pat.findall(text)
    tests = test_pat.findall(text)

    if not vals:
        raise RuntimeError(f"No validation results in {path}")
    if not tests:
        raise RuntimeError(f"No test results in {path}")

    val_map = {
        int(e): {
            "auc": float(a),
            "rmse": float(rmse),
            "acc": float(acc),
            "precision": float(p),
            "recall": float(rec),
            "f1": float(f1),
        }
        for e, a, rmse, acc, p, rec, f1 in vals
    }

    test_map = {
        int(e): {
            "auc": float(a),
            "rmse": float(rmse),
            "acc": float(acc),
            "precision": float(p),
            "recall": float(rec),
            "f1": float(f1),
        }
        for e, a, rmse, acc, p, rec, f1 in tests
    }

    best_epoch = max(val_map.keys(), key=lambda e: val_map[e]["auc"])
    if best_epoch not in test_map:
        raise RuntimeError(f"Best epoch {best_epoch} has no test result in {path}")

    v = val_map[best_epoch]
    t = test_map[best_epoch]

    rows.append({
        "dataset": "ednet",
        "model": "dNeuralCDM-attr4-noRT-matched",
        "seed": seed,
        "best_epoch": best_epoch,
        "valid_AUC": v["auc"],
        "valid_ACC": v["acc"],
        "valid_RMSE": v["rmse"],
        "test_AUC": t["auc"],
        "test_ACC": t["acc"],
        "test_RMSE": t["rmse"],
        "test_Precision": t["precision"],
        "test_Recall": t["recall"],
        "test_F1": t["f1"],
    })

def mean(xs):
    return sum(xs) / len(xs)

def std(xs):
    m = mean(xs)
    return math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1))

csv_path = OUT / "dneuralcdm_unified_ednet_attr4_matched_5seed.csv"
summary_path = OUT / "dneuralcdm_unified_ednet_attr4_matched_5seed_summary.txt"

with open(csv_path, "w", newline="", encoding="utf-8") as f:
    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

with open(summary_path, "w", encoding="utf-8") as f:
    f.write("dNeuralCDM-unified EDNet attr_idx=4 no-RT matched baseline\n")
    f.write("5 valid seeds, 3 epochs, best epoch selected by validation AUC.\n\n")

    for r in rows:
        f.write(
            f"seed={r['seed']}, best_epoch={r['best_epoch']}, "
            f"AUC={r['test_AUC']:.6f}, ACC={r['test_ACC']:.6f}, RMSE={r['test_RMSE']:.6f}, "
            f"Precision={r['test_Precision']:.6f}, Recall={r['test_Recall']:.6f}, F1={r['test_F1']:.6f}\n"
        )

    f.write("\nSummary:\n")
    for m in ["test_AUC", "test_ACC", "test_RMSE", "test_Precision", "test_Recall", "test_F1"]:
        vals = [r[m] for r in rows]
        f.write(f"{m}: {mean(vals):.6f} ± {std(vals):.6f}\n")

    fast_auc = 0.739116
    fast_acc = 0.713178
    fast_rmse = 0.433614

    f.write("\nDelta of dNeuralCDM-fastslow-unified EDNet over this matched attr4 no-RT baseline:\n")
    f.write(f"Delta AUC: {fast_auc - mean([r['test_AUC'] for r in rows]):+.6f}\n")
    f.write(f"Delta ACC: {fast_acc - mean([r['test_ACC'] for r in rows]):+.6f}\n")
    f.write(f"Delta RMSE: {fast_rmse - mean([r['test_RMSE'] for r in rows]):+.6f}\n")

print(open(summary_path, encoding="utf-8").read())
print("Saved:", csv_path)
print("Saved:", summary_path)
