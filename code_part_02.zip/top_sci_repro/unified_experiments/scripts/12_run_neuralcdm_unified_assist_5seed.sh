#!/usr/bin/env bash
set -euo pipefail

source /home/wangxiao/miniconda3/etc/profile.d/conda.sh
conda activate cd5090

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD

export NEURALCD_DATA_DIR=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time
export NEURALCD_CONFIG=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/data_unified/assistments_time/config.txt

mkdir -p logs/unified result model model_unified

EPOCHS=5
DATASET=assistments_time

for SEED in 0 1 2 3 4
do
  export NEURALCD_MODEL_DIR=/home/wangxiao/QCCDM/top_sci_repro/repos/Neural_Cognitive_Diagnosis-NeuralCD/model_unified/${DATASET}_seed${SEED}_epoch${EPOCHS}
  mkdir -p "$NEURALCD_MODEL_DIR"

  TRAIN_LOG=logs/unified/${DATASET}_seed${SEED}_epoch${EPOCHS}_train.log
  BEST_FILE=logs/unified/${DATASET}_seed${SEED}_epoch${EPOCHS}_best_epoch.txt

  echo "============================================================"
  echo "NeuralCDM unified ASSISTments_time seed=${SEED}, epochs=${EPOCHS}"
  echo "DATA_DIR=$NEURALCD_DATA_DIR"
  echo "CONFIG=$NEURALCD_CONFIG"
  echo "MODEL_DIR=$NEURALCD_MODEL_DIR"
  echo "TRAIN_LOG=$TRAIN_LOG"
  echo "============================================================"

  python train_original_seed.py cuda:0 ${EPOCHS} ${SEED} 2>&1 | tee "$TRAIN_LOG"

  python - <<PY > "$BEST_FILE"
import re
log_path = "$TRAIN_LOG"
best_epoch = None
best_auc = -1.0
pat = re.compile(r"epoch=\\s*(\\d+),\\s*accuracy=\\s*([0-9.]+),\\s*rmse=\\s*([0-9.]+),\\s*auc=\\s*([0-9.]+)")
for line in open(log_path, "r", encoding="utf-8", errors="ignore"):
    m = pat.search(line)
    if m:
        ep = int(m.group(1))
        auc = float(m.group(4))
        if auc > best_auc:
            best_auc = auc
            best_epoch = ep
print(best_epoch)
PY

  BEST_EPOCH=$(cat "$BEST_FILE")
  echo "BEST_EPOCH=$BEST_EPOCH"

  TEST_LOG=logs/unified/${DATASET}_seed${SEED}_epoch${EPOCHS}_best${BEST_EPOCH}_test.log
  python predict_original_seed.py ${BEST_EPOCH} ${SEED} 2>&1 | tee "$TEST_LOG"
done

echo "All ASSISTments_time 5-seed NeuralCDM runs finished."
