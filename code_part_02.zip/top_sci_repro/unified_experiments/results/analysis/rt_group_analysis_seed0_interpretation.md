# Response-time subgroup analysis interpretation

## ASSISTments_time

PBTS-CD improves AUC across all response-time groups on ASSISTments_time.

| Group | AUC gain | ACC gain | RMSE gain |
|---|---:|---:|---:|
| fast | +0.006068 | -0.001330 | -0.000156 |
| normal | +0.002748 | +0.005026 | +0.002017 |
| slow | +0.004216 | -0.003700 | -0.002447 |

The largest AUC gain appears in the fast group, followed by the slow group. This indicates that response-time modeling mainly improves ranking ability for behaviorally distinctive interactions. However, ACC and RMSE are not consistently improved in fast and slow groups, so the result should not be overclaimed as uniform improvement across all metrics.

## EDNet

The effect on EDNet is more behavior-dependent.

| Group | AUC gain | ACC gain | RMSE gain |
|---|---:|---:|---:|
| fast | -0.005990 | -0.002146 | -0.001262 |
| normal | +0.001794 | -0.000635 | -0.000792 |
| slow | +0.000368 | +0.007993 | +0.005895 |

PBTS-CD provides the clearest benefit for slow responses on EDNet, where ACC and RMSE improve substantially. However, the fast group decreases, indicating that response-time signals are dataset-dependent and may affect different behavioral regimes differently.

## Conclusion

This analysis supports the behavioral motivation of PBTS-CD, but the evidence should be described cautiously. The model does not uniformly improve all response-time groups. Instead, response-time modeling provides behavior-dependent gains: stronger AUC gains for fast/slow groups on ASSISTments_time and better calibration for slow responses on EDNet.

This table is currently treated as exploratory because the exported seed0 checkpoints may not exactly correspond to the final 5-seed main-table checkpoints due to workspace overwriting. A final version should be regenerated using uniquely named workspaces for the official seed0 configurations.
