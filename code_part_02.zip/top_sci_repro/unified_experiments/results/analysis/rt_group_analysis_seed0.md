# Response-time group analysis, seed0

Groups are defined by item-normalized response-time residual: fast < -0.5, normal in [-0.5, 0.5], slow > 0.5.

| Dataset | RT group | Model | n | AUC | ACC | RMSE / RMSE gain |
|---|---|---|---:|---:|---:|---:|
| ASSISTments_time | fast | baseline | 190246 | 0.745923 | 0.721440 | 0.429541 |
| ASSISTments_time | fast | PBTS-CD | 190246 | 0.751991 | 0.720110 | 0.429698 |
| ASSISTments_time | fast | gain | 190246 | 0.006068 | -0.001330 | -0.000156 |
| ASSISTments_time | normal | baseline | 207128 | 0.701170 | 0.712719 | 0.435523 |
| ASSISTments_time | normal | PBTS-CD | 207128 | 0.703917 | 0.717745 | 0.433505 |
| ASSISTments_time | normal | gain | 207128 | 0.002748 | 0.005026 | 0.002017 |
| ASSISTments_time | slow | baseline | 151876 | 0.658752 | 0.657181 | 0.467322 |
| ASSISTments_time | slow | PBTS-CD | 151876 | 0.662968 | 0.653480 | 0.469769 |
| ASSISTments_time | slow | gain | 151876 | 0.004216 | -0.003700 | -0.002447 |
| EDNet | fast | baseline | 74099 | 0.749228 | 0.728309 | 0.426534 |
| EDNet | fast | PBTS-CD | 74099 | 0.743238 | 0.726164 | 0.427796 |
| EDNet | fast | gain | 74099 | -0.005990 | -0.002146 | -0.001262 |
| EDNet | normal | baseline | 263082 | 0.744677 | 0.732179 | 0.422854 |
| EDNet | normal | PBTS-CD | 263082 | 0.746471 | 0.731544 | 0.423646 |
| EDNet | normal | gain | 263082 | 0.001794 | -0.000635 | -0.000792 |
| EDNet | slow | baseline | 93082 | 0.692664 | 0.641134 | 0.472607 |
| EDNet | slow | PBTS-CD | 93082 | 0.693031 | 0.649127 | 0.466712 |
| EDNet | slow | gain | 93082 | 0.000368 | 0.007993 | 0.005895 |
