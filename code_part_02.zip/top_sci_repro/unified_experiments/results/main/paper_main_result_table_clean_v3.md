# Paper Main Result Table Clean V3

Protocol: unified student split, 5 seeds, best epoch selected by validation AUC.

## Strong-backbone results on ASSISTments_time

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |
| ASSISTments_time | dNeuralCDM-fastslow-unified | 0.710056 ± 0.001464 | 0.706310 ± 0.004913 | 0.440087 ± 0.002426 |
| ASSISTments_time | dNeuralCDM-zfastslow-unified | **0.710424 ± 0.001359** | **0.706789 ± 0.003879** | **0.439771 ± 0.001660** |

Observation: On ASSISTments_time, the item-normalized fast-slow response-time module achieves the best result among the current dNeuralCDM variants. Compared with the original dNeuralCDM, it improves AUC by +0.004040, ACC by +0.007487, and reduces RMSE by -0.003498.

## Strong-backbone results on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 |
| EDNet | dNeuralCDM-unified attr_idx=4 no-RT matched | 0.733606 ± 0.000633 | 0.711297 ± 0.000700 | 0.435074 ± 0.000479 |
| EDNet | dNeuralCDM-fastslow-unified attr_idx=4 | 0.739116 ± 0.000267 | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |
| EDNet | dNeuralCDM-zfastslow-unified attr_idx=4 | **0.739367 ± 0.000371** | 0.713123 ± 0.000131 | 0.433629 ± 0.000158 |

Observation: On EDNet, zfastslow achieves the best AUC, while fastslow gives slightly better ACC and RMSE. Both variants clearly outperform the matched attr_idx=4 no-RT baseline. Compared with the matched no-RT baseline, zfastslow improves AUC by +0.005761, ACC by +0.001826, and reduces RMSE by -0.001445.

## Current conclusion

The current strong-backbone evidence supports the claim that personalized response-time behavior modeling transfers to dNeuralCDM. ASSISTments_time favors zfastslow across AUC/ACC/RMSE, while EDNet shows that zfastslow gives the best AUC and fastslow gives marginally better ACC/RMSE. For the main paper, zfastslow can be reported as the AUC-best variant, with fastslow retained as a strong ablation/balanced variant.
