# Paper Main Result Table

Protocol: unified student split, 5 seeds where available, best epoch selected by validation AUC.

## Main comparison

| Dataset | Model | AUC | ACC | RMSE | Precision | Recall | F1 |
|---|---|---:|---:|---:|---:|---:|---:|
| EDNet | NeuralCDM-unified | 0.714012 ± 0.000470 | 0.696100 ± 0.000888 | 0.445690 ± 0.000466 | 0.743483 ± 0.001767 | 0.828877 ± 0.005825 | 0.783847 ± 0.001658 |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | 0.732097 ± 0.008951 | 0.876487 ± 0.027212 | 0.797515 ± 0.006059 |
| EDNet | Official-style NeuralCDM | 0.721748 ± 0.000262 | 0.700477 ± 0.001198 | 0.440750 ± 0.000196 | 0.748838 ± 0.003654 | 0.826878 ± 0.010988 | 0.785874 ± 0.002872 |
| EDNet | TS-NeuralCDM-current-rt | 0.726116 ± 0.000098 | 0.702614 ± 0.001171 | 0.439595 ± 0.000117 | 0.752364 ± 0.003913 | 0.823969 ± 0.011315 | 0.786484 ± 0.002929 |
| EDNet | TS-NeuralCDM-fast-slow | **0.726845 ± 0.000211** | 0.702475 ± 0.001214 | 0.439622 ± 0.000286 | **0.753592 ± 0.002807** | 0.820944 ± 0.008626 | 0.785796 ± 0.002463 |
| EDNet | TS-NeuralCDM-prereq | 0.726192 ± 0.000203 | 0.702660 ± 0.001166 | **0.439520 ± 0.000213** | 0.752239 ± 0.003827 | 0.824335 ± 0.011121 | 0.786585 ± 0.002886 |
| ASSISTments_time | NeuralCDM-unified | 0.684499 ± 0.000072 | 0.669129 ± 0.000964 | 0.454681 ± 0.000132 | 0.770735 ± 0.000467 | 0.740308 ± 0.002498 | 0.755213 ± 0.001151 |
| ASSISTments_time | dNeuralCDM-unified | **0.706384 ± 0.000717** | **0.699302 ± 0.002295** | **0.443269 ± 0.001233** | **0.765314 ± 0.003362** | 0.813340 ± 0.011544 | 0.788542 ± 0.003610 |
| ASSISTments_time | Official-style NeuralCDM | 0.670066 ± 0.009667 | 0.697710 ± 0.000549 | 0.446209 ± 0.000953 | 0.733944 ± 0.007546 | **0.881386 ± 0.020650** | **0.800757 ± 0.003902** |
| ASSISTments_time | TS-NeuralCDM-current-rt | 0.682284 ± 0.002256 | 0.694937 ± 0.001424 | 0.445689 ± 0.000291 | 0.745411 ± 0.004402 | 0.846886 ± 0.012964 | 0.792843 ± 0.003298 |
| ASSISTments_time | TS-NeuralCDM-fast-slow | 0.679695 ± 0.009154 | 0.697119 ± 0.001737 | 0.445070 ± 0.001059 | 0.740599 ± 0.008700 | 0.863613 ± 0.023966 | 0.797144 ± 0.005092 |
| ASSISTments_time | TS-NeuralCDM-prereq | 0.688313 ± 0.000314 | 0.694083 ± 0.001919 | 0.444838 ± 0.000690 | 0.752203 ± 0.002949 | 0.829655 ± 0.010372 | 0.788990 ± 0.003149 |

## Key observations

1. On EDNet, TS-NeuralCDM variants clearly improve AUC over NeuralCDM-unified and dNeuralCDM-unified. The fast-slow module achieves the best AUC, while the prerequisite module achieves the best RMSE.

2. On ASSISTments_time, TS-NeuralCDM-prereq improves over NeuralCDM-unified in AUC, RMSE, and F1, but it does not outperform dNeuralCDM-unified. This means the current TS modules are effective on the NeuralCDM-style backbone, but the ASSISTments_time result is not yet strong enough against dNeuralCDM.

3. The current-rt module is the most stable basic enhancement. The fast-slow module helps classification balance, while the prerequisite module improves AUC/RMSE/Precision, especially on ASSISTments_time.

4. The fused gate variant is not adopted because it improves AUC slightly but hurts ACC/RMSE/F1 stability.

## New strong-backbone result

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |
| ASSISTments_time | dNeuralCDM-fastslow-unified | **0.710056 ± 0.001464** | **0.706310 ± 0.004913** | **0.440087 ± 0.002426** |

Conclusion: The personalized fast-slow response-time module improves the strong dNeuralCDM backbone on ASSISTments_time, demonstrating that the proposed response-behavior enhancement is transferable beyond the NeuralCDM-style backbone.

## Updated strong-backbone time-behavior results on ASSISTments_time

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |
| ASSISTments_time | dNeuralCDM-fastslow-unified | 0.710056 ± 0.001464 | 0.706310 ± 0.004913 | 0.440087 ± 0.002426 |
| ASSISTments_time | dNeuralCDM-zfastslow-unified | **0.710424 ± 0.001359** | **0.706789 ± 0.003879** | **0.439771 ± 0.001660** |

Conclusion: The item-normalized fast-slow response-time module further improves the strong dNeuralCDM backbone. Compared with the original dNeuralCDM, dNeuralCDM-zfastslow improves AUC by +0.004040, ACC by +0.007487, and reduces RMSE by -0.003498 on ASSISTments_time. This result supports the transferability of the proposed personalized response-behavior enhancement module.

## Updated strong-backbone time-behavior results on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 |
| EDNet | dNeuralCDM-unified attr_idx=4 no-RT seed0 | 0.734101 | 0.711816 | 0.434721 |
| EDNet | dNeuralCDM-fastslow-unified attr_idx=4 | **0.739116 ± 0.000267** | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |

Conclusion: On EDNet, the strong dNeuralCDM-fastslow variant achieves stable gains over the original dNeuralCDM. A matched seed0 comparison further shows that, under the same attr_idx=4 configuration, the fast-slow response-time module still improves AUC by +0.005121, ACC by +0.001627, and reduces RMSE by -0.001317.
