# HO-NCD + PBTS transfer summary

| Dataset | Model | ACC | AUC | Precision | Recall | F1 | RMSE |
|---|---|---:|---:|---:|---:|---:|---:|
| ASSISTments_time | HO-NCD | 0.706076 | 0.678637 | 0.754993 | 0.857165 | 0.802179 | 0.446755 |
| ASSISTments_time | HO-NCD + PBTS | 0.703626 | 0.684353 | 0.762491 | 0.835479 | 0.796666 | 0.444693 |
| EDNet | HO-NCD | 0.703114 | 0.734671 | 0.758623 | 0.805504 | 0.781283 | 0.438771 |
| EDNet | HO-NCD + PBTS | 0.703183 | 0.732941 | 0.751732 | 0.822537 | 0.784451 | 0.440866 |

## Difference

| Dataset | AUC gain | ACC gain | RMSE gain |
|---|---:|---:|---:|
| ASSISTments_time | +0.005716 | -0.002450 | +0.002062 |
| EDNet | -0.001730 | +0.000069 | -0.002094 |

## Current interpretation

The PBTS modules are technically transferable to HO-NCD and improve AUC/RMSE on ASSISTments_time. However, the current combined setting does not improve EDNet. Further ablation is required to determine whether the decrease comes from the z-normalized response-time gate, the prerequisite regularization, or their interaction.
