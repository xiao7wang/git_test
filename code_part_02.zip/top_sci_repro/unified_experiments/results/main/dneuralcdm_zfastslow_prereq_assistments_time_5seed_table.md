# dNeuralCDM-zfastslow+prereq on ASSISTments_time

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |
| ASSISTments_time | dNeuralCDM-zfastslow | 0.710424 ± 0.001359 | **0.706789 ± 0.003879** | 0.439771 ± 0.001660 |
| ASSISTments_time | dNeuralCDM-zfastslow+prereq | **0.710900 ± 0.001991** | 0.706337 ± 0.003454 | **0.439754 ± 0.001645** |
