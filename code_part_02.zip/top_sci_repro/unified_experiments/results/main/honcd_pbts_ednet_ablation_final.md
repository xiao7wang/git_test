# HO-NCD + PBTS EDNet ablation

## Baseline

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | HO-NCD | 0.734671 | 0.703114 | 0.438771 |

## PBTS variants on HO-NCD

| Variant | AUC | ACC | RMSE | AUC gain vs HO-NCD | RMSE gain vs HO-NCD |
|---|---:|---:|---:|---:|---:|
| zrt only | 0.732294 | 0.702655 | 0.441016 | -0.002377 | -0.002245 |
| prereq only, lambda=0.001 | 0.731809 | 0.703409 | 0.440816 | -0.002862 | -0.002045 |
| zrt + prereq, lambda=0.0001 | 0.732632 | 0.702163 | 0.440891 | -0.002039 | -0.002120 |
| zrt + prereq, lambda=0.0005 | 0.732376 | 0.703008 | 0.440887 | -0.002295 | -0.002116 |
| zrt + prereq, lambda=0.001 | 0.732941 | 0.703183 | 0.440866 | -0.001730 | -0.002095 |

## Conclusion

The current PBTS transfer to HO-NCD does not improve EDNet. Although the model is trainable and the modules can be integrated into the HO-NCD architecture, all EDNet variants underperform the original HO-NCD in AUC and RMSE. Therefore, HO-NCD transfer should be reported cautiously: PBTS improves HO-NCD on ASSISTments_time but does not provide consistent gains on EDNet.

This negative result suggests that PBTS is not a universally plug-and-play module for all backbones. Since HO-NCD already contains a raw response-time embedding, the additional z-normalized response-time gate may interfere with the original time representation on EDNet.
