# PBTS-CD on dNeuralCDM strong backbone

| Dataset | Model | AUC | ACC | RMSE | Note |
|---|---|---:|---:|---:|---|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 | baseline |
| ASSISTments_time | dNeuralCDM-zfastslow | 0.710424 ± 0.001359 | 0.706789 ± 0.003879 | 0.439771 ± 0.001660 | time behavior |
| ASSISTments_time | dNeuralCDM-zfastslow+prereq | 0.710900 ± 0.001991 | 0.706337 ± 0.003454 | 0.439754 ± 0.001645 | time + structure |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | baseline |
| EDNet | dNeuralCDM-zfastslow | 0.739367 ± 0.000371 | 0.713123 ± 0.000131 | 0.433629 ± 0.000158 | time behavior |
| EDNet | dNeuralCDM-zfastslow+prereq | 0.739975 ± 0.000938 | 0.713043 ± 0.000881 | 0.433561 ± 0.000590 | time + structure |
