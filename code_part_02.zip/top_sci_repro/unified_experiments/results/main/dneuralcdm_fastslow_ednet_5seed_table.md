# dNeuralCDM-fastslow on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 |
| EDNet | dNeuralCDM-fastslow | **0.739116 ± 0.000267** | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |
