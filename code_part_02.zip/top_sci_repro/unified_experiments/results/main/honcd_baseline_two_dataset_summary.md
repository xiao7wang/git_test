# HO-NCD baseline results

| Dataset | Model | ACC | AUC | Precision | Recall | F1 | RMSE | Note |
|---|---|---:|---:|---:|---:|---:|---:|---|
| ASSISTments_time_ours | HO-NCD | 0.706076 | 0.678637 | 0.754993 | 0.857165 | 0.802179 | 0.446755 | K=5, epoch=5 |
| EDNet_time_ours | HO-NCD | 0.703114 | 0.734671 | 0.758623 | 0.805504 | 0.781283 | 0.438771 | K=5, epoch=5, batch_size=64 |

## Comparison with current PBTS-CD on dNeuralCDM backbone

| Dataset | HO-NCD AUC | PBTS-CD AUC | AUC Difference |
|---|---:|---:|---:|
| ASSISTments_time | 0.678637 | 0.710900 | +0.032263 |
| EDNet | 0.734671 | 0.739975 | +0.005304 |

Note: The current HO-NCD results follow the HO-NCD internal K-fold protocol. They should be treated as adapted strong-baseline results. For strict main-table comparison, HO-NCD should ideally be patched to use the same unified train/valid/test split as the dNeuralCDM experiments.
