# dNeuralCDM response-time normalization ablation

| Dataset | Model | AUC | ACC | RMSE | Note |
|---|---|---:|---:|---:|---|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 | baseline |
| ASSISTments_time | dNeuralCDM-fastslow | 0.710056 ± 0.001464 | 0.706310 ± 0.004913 | 0.440087 ± 0.002426 | raw fast-slow |
| ASSISTments_time | dNeuralCDM-zfastslow | **0.710424 ± 0.001359** | **0.706789 ± 0.003879** | **0.439771 ± 0.001660** | z-score fast-slow |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | baseline |
| EDNet | dNeuralCDM-fastslow | 0.739116 ± 0.000267 | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** | raw fast-slow |
| EDNet | dNeuralCDM-zfastslow | **0.739367 ± 0.000371** | 0.713123 ± 0.000131 | 0.433629 ± 0.000158 | z-score fast-slow |
