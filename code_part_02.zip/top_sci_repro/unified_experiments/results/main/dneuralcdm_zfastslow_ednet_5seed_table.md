# dNeuralCDM-zfastslow on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-fastslow | 0.739116 ± 0.000267 | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |
| EDNet | dNeuralCDM-zfastslow | **0.739367 ± 0.000371** | 0.713123 ± 0.000131 | 0.433629 ± 0.000158 |
