# Unified Dataset Inspection


## assistments_time

- data: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/assistments_time/interactions_raw.csv`
- q: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/assistments_time/q.csv`
- config: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/assistments_time/config.json`
- rows: 2652854
- columns: ['student_id', 'exercise_id', 'score', 'response_time', 'timestamp']
- detected user_col: `student_id`
- detected item_col: `exercise_id`
- detected score_col: `score`
- detected knowledge_col: `None`
- detected time_col: `timestamp`
- detected response_time_col: `response_time`
- users: 20256
- items: 52681
- score_unique_count: 2
- score_mean: 0.6963572062390165
- score_dist: `{'1': 1847334, '0': 805520}`
- q_shape: (52690, 218)
- q_nonzero: 52681
- config: `{'dataset': 'assistments_time_ours', 'q_file': 'q.csv', 'data': 'assistments_time_oursTotalData.csv', 'student_num': 20257, 'exercise_num': 52690, 'knowledge_num': 218}`

### Head
- `{'student_id': '2', 'exercise_id': '31902', 'score': '1', 'response_time': '56.083', 'timestamp': '1349347418'}`
- `{'student_id': '2', 'exercise_id': '31903', 'score': '1', 'response_time': '14.107', 'timestamp': '1349347477'}`
- `{'student_id': '2', 'exercise_id': '31904', 'score': '1', 'response_time': '11.156', 'timestamp': '1349347492'}`
- `{'student_id': '2', 'exercise_id': '31905', 'score': '0', 'response_time': '10.636', 'timestamp': '1349347504'}`
- `{'student_id': '2', 'exercise_id': '31906', 'score': '1', 'response_time': '9.519', 'timestamp': '1349347515'}`
- `{'student_id': '2', 'exercise_id': '31907', 'score': '1', 'response_time': '9.368', 'timestamp': '1349347525'}`
- `{'student_id': '2', 'exercise_id': '31909', 'score': '1', 'response_time': '392.055', 'timestamp': '1349347950'}`
- `{'student_id': '2', 'exercise_id': '31910', 'score': '0', 'response_time': '26.248', 'timestamp': '1349348343'}`
- `{'student_id': '2', 'exercise_id': '31911', 'score': '1', 'response_time': '14.349', 'timestamp': '1349348370'}`
- `{'student_id': '2', 'exercise_id': '31912', 'score': '1', 'response_time': '11.118', 'timestamp': '1349348385'}`

## ednet

- data: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/ednet/interactions_raw.csv`
- q: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/ednet/q.csv`
- config: `/home/wangxiao/QCCDM/top_sci_repro/unified_experiments/data/ednet/config.json`
- rows: 2118984
- columns: ['student_id', 'exercise_id', 'score', 'response_time', 'timestamp']
- detected user_col: `student_id`
- detected item_col: `exercise_id`
- detected score_col: `score`
- detected knowledge_col: `None`
- detected time_col: `timestamp`
- detected response_time_col: `response_time`
- users: 9999
- items: 12196
- score_unique_count: 2
- score_mean: 0.6584872750336954
- score_dist: `{'1': 1395324, '0': 723660}`
- q_shape: (12198, 141)
- q_nonzero: 12196
- config: `{'dataset': 'ednet_time_ours', 'q_file': 'q.csv', 'data': 'ednet_time_oursTotalData.csv', 'student_num': 10000, 'exercise_num': 12198, 'knowledge_num': 141}`

### Head
- `{'student_id': '1', 'exercise_id': '1', 'score': '0', 'response_time': '46.0', 'timestamp': '1565270361'}`
- `{'student_id': '1', 'exercise_id': '2', 'score': '1', 'response_time': '24.0', 'timestamp': '1565270391'}`
- `{'student_id': '1', 'exercise_id': '3', 'score': '1', 'response_time': '16.0', 'timestamp': '1565270411'}`
- `{'student_id': '1', 'exercise_id': '4', 'score': '1', 'response_time': '36.0', 'timestamp': '1565270451'}`
- `{'student_id': '1', 'exercise_id': '5', 'score': '1', 'response_time': '40.0', 'timestamp': '1565270494'}`
- `{'student_id': '1', 'exercise_id': '6', 'score': '0', 'response_time': '38.0', 'timestamp': '1565270536'}`
- `{'student_id': '1', 'exercise_id': '7', 'score': '1', 'response_time': '34.0', 'timestamp': '1565270573'}`
- `{'student_id': '1', 'exercise_id': '8', 'score': '0', 'response_time': '31.0', 'timestamp': '1565270607'}`
- `{'student_id': '1', 'exercise_id': '9', 'score': '0', 'response_time': '33.0', 'timestamp': '1565270644'}`
- `{'student_id': '1', 'exercise_id': '10', 'score': '0', 'response_time': '23.0', 'timestamp': '1565270671'}`
