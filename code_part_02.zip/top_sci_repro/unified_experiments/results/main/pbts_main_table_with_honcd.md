# PBTS-CD main table with HO-NCD baseline

| Dataset | Model | AUC | ACC | RMSE | Note |
|---|---|---:|---:|---:|---|
| ASSISTments_time | HO-NCD | 0.678637 | 0.706076 | 0.446755 | adapted strong baseline |
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 | strong backbone baseline |
| ASSISTments_time | dNeuralCDM-zfastslow | 0.710424 ± 0.001359 | **0.706789 ± 0.003879** | 0.439771 ± 0.001660 | time behavior |
| ASSISTments_time | PBTS-CD / zfastslow+prereq | **0.710900 ± 0.001991** | 0.706337 ± 0.003454 | **0.439754 ± 0.001645** | time + structure |
| EDNet | HO-NCD | 0.734671 | 0.703114 | 0.438771 | adapted strong baseline |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | strong backbone baseline |
| EDNet | dNeuralCDM-zfastslow | 0.739367 ± 0.000371 | **0.713123 ± 0.000131** | 0.433629 ± 0.000158 | time behavior |
| EDNet | PBTS-CD / zfastslow+prereq | **0.739975 ± 0.000938** | 0.713043 ± 0.000881 | **0.433561 ± 0.000590** | time + structure |
