# dNeuralCDM-fastslow two-dataset summary

| Dataset | Model | AUC | ACC | RMSE | AUC Gain |
|---|---|---:|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 | - |
| ASSISTments_time | dNeuralCDM-fastslow | **0.710056 ± 0.001464** | **0.706310 ± 0.004913** | **0.440087 ± 0.002426** | **+0.003672** |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | - |
| EDNet | dNeuralCDM-fastslow | **0.739116 ± 0.000267** | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** | **+0.021775** |
