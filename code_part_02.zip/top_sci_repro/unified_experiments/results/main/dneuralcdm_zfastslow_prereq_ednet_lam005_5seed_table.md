# dNeuralCDM-zfastslow+prereq on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 |
| EDNet | dNeuralCDM-zfastslow | 0.739367 ± 0.000371 | **0.713123 ± 0.000131** | 0.433629 ± 0.000158 |
| EDNet | dNeuralCDM-zfastslow+prereq | **0.739975 ± 0.000938** | 0.713043 ± 0.000881 | **0.433561 ± 0.000590** |
