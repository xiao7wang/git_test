# Paper Main Result Table Clean V2

Protocol: unified student split, 5 seeds, best epoch selected by validation AUC.

## Strong-backbone results on ASSISTments_time

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 |
| ASSISTments_time | dNeuralCDM-fastslow-unified | 0.710056 ± 0.001464 | 0.706310 ± 0.004913 | 0.440087 ± 0.002426 |
| ASSISTments_time | dNeuralCDM-zfastslow-unified | **0.710424 ± 0.001359** | **0.706789 ± 0.003879** | **0.439771 ± 0.001660** |

Observation: On ASSISTments_time, the item-normalized fast-slow response-time module achieves the best result among the current dNeuralCDM variants. Compared with the original dNeuralCDM, it improves AUC by +0.004040, ACC by +0.007487, and reduces RMSE by -0.003498.

## Strong-backbone results on EDNet

| Dataset | Model | AUC | ACC | RMSE |
|---|---|---:|---:|---:|
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 |
| EDNet | dNeuralCDM-unified attr_idx=4 no-RT matched | 0.733606 ± 0.000633 | 0.711297 ± 0.000700 | 0.435074 ± 0.000479 |
| EDNet | dNeuralCDM-fastslow-unified attr_idx=4 | **0.739116 ± 0.000267** | **0.713178 ± 0.000209** | **0.433614 ± 0.000210** |

Observation: On EDNet, the attr_idx=4 configuration itself strengthens the dNeuralCDM backbone, but under the same matched configuration, the fast-slow response-time module still brings clear additional gains: AUC +0.005510, ACC +0.001881, and RMSE -0.001460.

## Current conclusion

The current results support the core claim that personalized response-time behavior modeling can transfer to a strong dynamic cognitive diagnosis backbone. The strongest current evidence is:

1. On ASSISTments_time, dNeuralCDM-zfastslow improves over original dNeuralCDM across AUC, ACC, and RMSE.
2. On EDNet, dNeuralCDM-fastslow improves over both original dNeuralCDM and the matched attr_idx=4 no-RT baseline.
3. The EDNet matched comparison reduces the risk that the improvement is only caused by the attr_idx setting.
