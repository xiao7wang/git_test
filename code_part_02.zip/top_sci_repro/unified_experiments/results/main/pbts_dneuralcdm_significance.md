# PBTS-CD significance test on dNeuralCDM

Exact paired sign-flip test. Positive improvement means model_b is better than model_a. For RMSE, improvement is computed as RMSE(model_a) - RMSE(model_b).

| Dataset | Metric | Comparison | Mean improvement | Cohen dz | p_exact |
|---|---|---|---:|---:|---:|
| ASSISTments_time | AUC | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.004039 | 2.590 | 0.062500 |
| ASSISTments_time | ACC | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.007487 | 1.371 | 0.062500 |
| ASSISTments_time | RMSE | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.003498 | 1.331 | 0.125000 |
| ASSISTments_time | AUC | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | 0.000476 | 0.209 | 0.687500 |
| ASSISTments_time | ACC | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | -0.000452 | -0.079 | 0.875000 |
| ASSISTments_time | RMSE | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | 0.000017 | 0.007 | 1.000000 |
| ASSISTments_time | AUC | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.004515 | 3.061 | 0.062500 |
| ASSISTments_time | ACC | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.007035 | 1.944 | 0.062500 |
| ASSISTments_time | RMSE | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.003515 | 2.408 | 0.062500 |
| EDNet | AUC | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.022027 | 18.849 | 0.062500 |
| EDNet | ACC | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.008805 | 5.015 | 0.062500 |
| EDNet | RMSE | dNeuralCDM-unified → dNeuralCDM-zfastslow | 0.007325 | 10.269 | 0.062500 |
| EDNet | AUC | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | 0.000608 | 0.580 | 0.250000 |
| EDNet | ACC | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | -0.000080 | -0.082 | 0.875000 |
| EDNet | RMSE | dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq | 0.000068 | 0.118 | 0.875000 |
| EDNet | AUC | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.022635 | 11.065 | 0.062500 |
| EDNet | ACC | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.008725 | 3.542 | 0.062500 |
| EDNet | RMSE | dNeuralCDM-unified → dNeuralCDM-zfastslow+prereq | 0.007393 | 7.633 | 0.062500 |
