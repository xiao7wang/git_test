# Unified Split Summary


## assistments_time

- policy: per-student chronological split; train=first 70%, valid=next 10%, test=last 20%
- raw_rows: 2652854
- users_total: 20256
- short_users_lt3_all_to_train: 0
- train: rows=1847688, users=20256, items=49463, score_mean=0.6991662012201194, score_dist={'1': 1291841, '0': 555847}
- valid: rows=255916, users=20256, items=36476, score_mean=0.6909063911595993, score_dist={'1': 176814, '0': 79102}
- test: rows=549250, users=20256, items=41377, score_mean=0.6894474283113337, score_dist={'1': 378679, '0': 170571}

## ednet

- policy: per-student chronological split; train=first 70%, valid=next 10%, test=last 20%
- raw_rows: 2118984
- users_total: 9999
- short_users_lt3_all_to_train: 0
- train: rows=1479693, users=9999, items=12175, score_mean=0.6548959818016304, score_dist={'0': 510648, '1': 969045}
- valid: rows=209028, users=9999, items=11762, score_mean=0.6708909811125782, score_dist={'0': 68793, '1': 140235}
- test: rows=430263, users=9999, items=11931, score_mean=0.6648119870869678, score_dist={'1': 286044, '0': 144219}
