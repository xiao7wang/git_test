# PBTS-CD dNeuralCDM Stage Conclusion

## 1. Current experimental status

We have completed the dNeuralCDM strong-backbone validation under the unified split protocol on ASSISTments_time and EDNet. The tested variants include:

1. dNeuralCDM-unified: original strong baseline.
2. dNeuralCDM-zfastslow: response-time behavior enhanced model.
3. dNeuralCDM-zfastslow+prereq: response-time behavior plus prerequisite consistency regularization.

All results are based on 5 random seeds, and the best epoch is selected by validation AUC.

## 2. Final results

| Dataset | Model | AUC | ACC | RMSE | Note |
|---|---|---:|---:|---:|---|
| ASSISTments_time | dNeuralCDM-unified | 0.706384 ± 0.000717 | 0.699302 ± 0.002295 | 0.443269 ± 0.001233 | baseline |
| ASSISTments_time | dNeuralCDM-zfastslow | 0.710424 ± 0.001359 | 0.706789 ± 0.003879 | 0.439771 ± 0.001660 | time behavior |
| ASSISTments_time | dNeuralCDM-zfastslow+prereq | **0.710900 ± 0.001991** | 0.706337 ± 0.003454 | **0.439754 ± 0.001645** | time + structure |
| EDNet | dNeuralCDM-unified | 0.717341 ± 0.001139 | 0.704319 ± 0.001870 | 0.440954 ± 0.000606 | baseline |
| EDNet | dNeuralCDM-zfastslow | 0.739367 ± 0.000371 | 0.713123 ± 0.000131 | 0.433629 ± 0.000158 | time behavior |
| EDNet | dNeuralCDM-zfastslow+prereq | **0.739975 ± 0.000938** | 0.713043 ± 0.000881 | **0.433561 ± 0.000590** | time + structure |

## 3. Main findings

The zfastslow response-time behavior module is the main source of performance improvement. Compared with the original dNeuralCDM, it improves AUC by +0.004039 on ASSISTments_time and +0.022027 on EDNet.

The prerequisite regularization further improves AUC on both datasets, but the gain is small. Compared with dNeuralCDM-zfastslow, zfastslow+prereq improves AUC by +0.000476 on ASSISTments_time and +0.000608 on EDNet. ACC is nearly unchanged or slightly lower.

Therefore, the current conclusion is that zfastslow is the main predictive enhancement module, while prereq should be treated as a structure-consistency regularization module. The final dNeuralCDM-stage candidate is dNeuralCDM-zfastslow+prereq, but the paper should not overclaim the independent performance contribution of prereq.

## 4. Statistical interpretation

The exact paired sign-flip test with 5 seeds has a minimum two-sided p-value of 0.0625. Therefore, the results should be interpreted using both p-values and effect sizes.

For dNeuralCDM-unified → dNeuralCDM-zfastslow, the improvements are consistent and the effect sizes are large, especially on EDNet.

For dNeuralCDM-zfastslow → dNeuralCDM-zfastslow+prereq, the improvements are directionally positive in AUC but not statistically significant. This supports using prereq as an interpretability and structural consistency module rather than the main performance driver.

## 5. Next step

The dNeuralCDM stage is complete. The next stage should migrate PBTS-CD to another strong backbone or add a direct response-time baseline. The recommended priority is:

1. Inspect whether JRT-NCD / RT-NCD style baselines exist in the current repositories.
2. If available, reproduce them under the unified split.
3. If not available or too costly, move to HO-NCD as the next strong cognitive diagnosis backbone.
4. Then compare PBTS-CD against HyperCDM / HO-NCD / JRT-NCD-style baselines in the main table.
