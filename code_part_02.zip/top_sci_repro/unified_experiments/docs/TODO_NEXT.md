# TODO for Unified Experiments

## P0: Dataset Unification

- [ ] Locate full ASSISTments_time dataset.
- [ ] Locate full EDNet KT1 dataset.
- [ ] Check fields: user_id, item_id, score, knowledge_code, timestamp, response_time.
- [ ] Standardize column names.
- [ ] Generate unified train/valid/test splits.
- [ ] Generate unified Q-matrix.

## P1: Baseline under Unified Protocol

- [ ] Run NCDM on ASSISTments_time.
- [ ] Run NCDM on EDNet.
- [ ] Run dNeuralCDM on ASSISTments_time.
- [ ] Run dNeuralCDM on EDNet.
- [ ] Run 5 seeds for each baseline.

## P2: Plug-in Module Implementation

- [ ] Implement DCR: Difficulty-Calibrated Residual.
- [ ] Implement RTG: Response-Time Guided Gate.
- [ ] Implement KCR: Knowledge Consistency Regularization.
- [ ] Verify each module can be independently switched on/off.

## P3: Ablation

- [ ] NCDM
- [ ] NCDM + DCR
- [ ] NCDM + RTG
- [ ] NCDM + KCR
- [ ] NCDM + DCR + RTG
- [ ] PE-NCDM full

## P4: Paper Tables

- [ ] Main performance table.
- [ ] Ablation table.
- [ ] Sensitivity table.
- [ ] Runtime table.
- [ ] Case study / interpretability table.
