# Unified Latest-Model Benchmark Plan

## 1. Core Goal

The current task is to evaluate recent cognitive diagnosis models under the same datasets, same train/valid/test split, same Q-matrix, same metrics, and same random seeds.

Previous results based on sample splits or repository-default splits are archived as reproduction records only. They will not be used as the final main comparison.

## 2. Unified Datasets

Main datasets:

1. ASSISTments_time
2. EDNet

Both datasets use per-student chronological splitting:

- train: first 70%
- valid: next 10%
- test: last 20%

## 3. Latest Baseline Models

The main comparison will include:

1. NeuralCDM / NCDM
2. dNeuralCDM
3. CausalCDF-NCDM-logit-fix
4. ORCDF-unified
5. HyperCDM-unified
6. DisenGCD-unified, optional if adaptation is feasible

Classical models such as IRT, DINA, and MIRT can be added as supplementary baselines if time permits, but they are not the current priority.

## 4. Proposed Model

PE-NCDM: Plug-in Enhanced Neural Cognitive Diagnosis Model

Plug-in modules:

1. DCR: Difficulty-Calibrated Residual
2. RTG: Response-Time Guided Gate
3. KCR: Knowledge Consistency Regularization

## 5. Main Experiment Matrix

For each dataset:

1. NeuralCDM
2. dNeuralCDM
3. CausalCDF-NCDM-logit-fix
4. ORCDF-unified
5. HyperCDM-unified
6. DisenGCD-unified, optional
7. PE-NCDM full

## 6. Ablation Matrix

For each dataset:

1. NCDM
2. NCDM + DCR
3. NCDM + RTG
4. NCDM + KCR
5. NCDM + DCR + RTG
6. PE-NCDM full: NCDM + DCR + RTG + KCR

## 7. Metrics

Prediction metrics:

- AUC
- ACC
- RMSE
- F1

Optional interpretability metrics:

- DOA
- concept-level consistency

## 8. Seeds

All final results use seeds:

0, 1, 2, 3, 4

Final reporting format:

mean ± std

## 9. Immediate Tasks

1. Inspect each latest model repository input format.
2. Build unified data adapters for each model.
3. Run seed0 smoke test for each model on ASSISTments_time.
4. Run seed0 smoke test for each model on EDNet.
5. Run 5 seeds after smoke tests pass.
6. Implement PE-NCDM modules.
7. Run ablation and final comparison.
