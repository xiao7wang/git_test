# Unified Cognitive Diagnosis Experiment Plan

## 1. Route Adjustment

The previous stage focused on reproducing multiple models under their original repository protocols. Some experiments used sample splits, repo-default splits, or model-specific preprocessing pipelines. These results will be retained as reproduction records but will no longer be used as the main experimental comparison.

The next stage will focus on unified datasets, unified splits, unified metrics, and plug-in model improvements.

## 2. Main Principle

The final main experiments must use:

- the same dataset,
- the same train/valid/test split,
- the same Q-matrix,
- the same evaluation metrics,
- the same random seeds,
- and the same result reporting format.

The final results will be reported as mean ± std over 5 seeds.

## 3. Main Datasets

Main datasets:

1. ASSISTments_time full dataset
2. EDNet KT1 full dataset

Sample datasets such as assist_sample5000_item12000 and assistments_time_sample5000_item12000 will only be archived as reproduction records.

## 4. Baselines

The main baseline set will be reduced to models that can run under the unified protocol:

- IRT
- DINA
- MIRT
- NCDM / NeuralCDM
- dNeuralCDM

Optional:
- CausalCDF-logit-fix if it can be adapted to the unified protocol without special split dependency.

Models that rely heavily on cut datasets or repository-default splits will not be included in the final main comparison.

## 5. Proposed Plug-in Model

Tentative model name:

PE-NCDM: Plug-in Enhanced Neural Cognitive Diagnosis Model

Main plug-in modules:

1. DCR: Difficulty-Calibrated Residual
2. RTG: Response-Time Guided Gate
3. KCR: Knowledge Consistency Regularization

## 6. Experiment Matrix

Under each unified dataset:

1. NCDM
2. NCDM + DCR
3. NCDM + RTG
4. NCDM + KCR
5. NCDM + DCR + RTG
6. PE-NCDM full: NCDM + DCR + RTG + KCR

If time permits:

7. dNeuralCDM
8. dNeuralCDM + DCR
9. dNeuralCDM + RTG
10. dNeuralCDM + DCR + RTG

## 7. Metrics

Main prediction metrics:

- AUC
- ACC
- RMSE
- F1

Interpretability / consistency metrics:

- DOA
- concept-level consistency

## 8. Seeds

All main experiments use:

0, 1, 2, 3, 4

## 9. Immediate Next Steps

1. Stop sample split experiments.
2. Locate full ASSISTments_time and EDNet data files.
3. Build unified train/valid/test splits.
4. Run unified NCDM baseline.
5. Run unified dNeuralCDM baseline.
6. Implement DCR.
7. Implement RTG.
8. Implement KCR.
9. Run ablation experiments.
10. Generate final main tables.
