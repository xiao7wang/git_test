import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import sha,write
from count_core import dev_users
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='pfa_comparison_') as temp:
  root=Path(temp);pkg=root/'pkg';pkg.mkdir();p1=root/'p1';p1.mkdir()
  for n in ('run_experiment.py','pfa_core.py','count_core.py','cross_core.py','review_stats.py','package_results.py','show_results.py'):shutil.copy2(ROOT/n,pkg/n)
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  a=fixture.data.arrays;dev=dev_users(a['student_idx'][a['split']==1]);ids=np.flatnonzero((a['split']==1)&np.isin(a['student_idx'],list(dev)))
  pd.DataFrame({'record_idx':ids,'student_idx':a['student_idx'][ids],'label':a['label'][ids],'R2':.5}).to_csv(p1/'dev_predictions.csv.gz',index=False,compression='gzip')
  write(p1/'config.json',{'data_fingerprint':fixture.data.fingerprint,'code_sha256':{'count_core.py':sha(pkg/'count_core.py')},'test_evaluated':False,'holdout_evaluated':False,'feedback':'row immediate assumption'})
  write(p1/'status.json',{'status':'complete'});write(p1/'summary.json',{'status':'complete'})
  write(pkg/'locked_p1.json',{'p1_files':{n:sha(p1/n) for n in ('status.json','config.json','summary.json','dev_predictions.csv.gz')}})
  cmd=[sys.executable,'-B',str(pkg/'run_experiment.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--p1-dir',str(p1),'--output-dir',str(root/'out'),'--device','cpu','--epochs','3','--patience','2','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  s=json.loads((root/'out/summary.json').read_text());assert len(s['runs'])==6 and not s['test_evaluated'] and not s['holdout_evaluated']
  for variant,selection in s['selected'].items():
   candidates=[r for r in s['runs'].values() if r['variant']==variant];assert selection['dev']['nll']==min(x['dev']['nll'] for x in candidates)
  assert np.array_equal(pd.read_csv(root/'out/dev_predictions.csv.gz').record_idx.to_numpy(),ids)
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  with zipfile.ZipFile(root/'out/pfa_results.zip') as z:
   m=json.loads(z.read('manifest.json'));assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items())
  q=subprocess.run([sys.executable,str(pkg/'show_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  with (p1/'status.json').open('a') as f:f.write(' ')
  bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((root/'bad/status.json').read_text())['status']=='failed'
  print('PASS synthetic six-run train, dev model selection, event pairing, package and provenance guards')
finally:fixture.tearDown()
