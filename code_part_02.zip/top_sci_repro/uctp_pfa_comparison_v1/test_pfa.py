import unittest
import torch
from pfa_core import PFA

class Tests(unittest.TestCase):
 def test_raw_counts_and_bias_difference(self):
  s=torch.tensor([0,0]);i=torch.tensor([0,0]);k=torch.tensor([0,0]);p=torch.tensor([1.,10.]);n=torch.tensor([2.,20.])
  for variant in ('pfa_equation','pfa_with_biases'):
   m=PFA(1,1,1,variant)
   with torch.no_grad():
    m.kc.weight[0]=torch.tensor([.2,.3,-.1])
    if variant=='pfa_with_biases':m.student.weight[0]=.4;m.item.weight[0]=-.2
   expected=torch.tensor([.3,1.2])+(0.2 if variant=='pfa_with_biases' else 0)
   self.assertTrue(torch.allclose(m(s,i,k,p,n),expected,atol=1e-6))
 def test_success_nonnegative_and_failure_unrestricted(self):
  m=PFA(1,1,1,'pfa_equation')
  with torch.no_grad():m.kc.weight[0]=torch.tensor([.1,-.2,-.3])
  m.project_success_nonnegative();self.assertEqual(m.kc.weight[0,1].item(),0);self.assertLess(m.kc.weight[0,2].item(),0)
if __name__=='__main__':unittest.main()
