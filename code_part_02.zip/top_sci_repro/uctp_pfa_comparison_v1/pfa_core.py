"""PFA raw-count equation and explicit student/item-bias extension."""
import torch
from torch import nn

class PFA(nn.Module):
    def __init__(self, students, items, kcs, variant):
        super().__init__()
        if variant not in ('pfa_equation','pfa_with_biases'):raise ValueError('Unknown variant')
        self.variant=variant;self.kc=nn.Embedding(kcs,3)
        if variant=='pfa_with_biases':self.student=nn.Embedding(students,1);self.item=nn.Embedding(items,1)
        for p in self.parameters():nn.init.zeros_(p)
    def forward(self,student,item,kc,success,failure):
        v=self.kc(kc);z=v[:,0]+v[:,1]*success+v[:,2]*failure
        if self.variant=='pfa_with_biases':z=z+self.student(student).squeeze(-1)+self.item(item).squeeze(-1)
        return z
    @torch.no_grad()
    def project_success_nonnegative(self):self.kc.weight[:,1].clamp_(min=0)
