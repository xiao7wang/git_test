"""Exploratory one-seed raw-count PFA equation comparisons on development only."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,prior_count_features,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics,losses,cluster_intervals
from pfa_core import PFA
ROOT=Path(__file__).resolve().parent
VARIANTS=('pfa_equation','pfa_with_biases')
LRS=(0.01,0.001,0.0001)

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if min(a.epochs,a.patience)<1:raise ValueError('Invalid epoch or patience')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
 started=time.monotonic();status={'status':'running','phase':'verify','test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  lock=read(ROOT/'locked_p1.json');p1=Path(a.p1_dir)
  for name,digest in lock['p1_files'].items():
   if sha(p1/name)!=digest:raise ValueError('P1 source changed: '+name)
  old_cfg=read(p1/'config.json')
  if read(p1/'status.json')['status']!='complete' or old_cfg['test_evaluated'] or old_cfg['holdout_evaluated'] or old_cfg['feedback']!='row immediate assumption':raise ValueError('P1 protocol mismatch')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old_cfg['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  if sha(ROOT/'count_core.py')!=old_cfg['code_sha256']['count_core.py']:raise ValueError('Historical feature source differs')
  data=Data(a.data_dir);dev=dev_users(data.arrays['student_idx'][data.arrays['split']==1]);status['phase']='features';write(out/'status.json',status)
  print('Building audited prior counts',flush=True);f=prior_count_features(data.arrays,dev);ti=np.flatnonzero(f['split']==0);vi=np.flatnonzero(f['split']==1)
  if not len(ti) or not len(vi):raise ValueError('Empty partition')
  ref=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student'),('label','label')]:
   if not np.array_equal(ref[col].to_numpy(),f[key][vi]):raise ValueError('P1 event identity mismatch: '+col)
  device=torch.device(a.device);torch.set_num_threads(4);torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  tensor={k:torch.as_tensor(f[k],dtype=torch.long if k in ('student','item','kc') else torch.float32,device=device) for k in ('student','item','kc','success','failure','label')}
  tr=torch.as_tensor(ti,dtype=torch.long,device=device);va=torch.as_tensor(vi,dtype=torch.long,device=device);dims=data.manifest['summary']
  cfg={'protocol':'exploratory development only; no test or holdout','data_fingerprint':data.fingerprint,'partition_salt':SALT,'feedback':'row immediate assumption',
   'pfa_equation':'KC intercept + KC success coefficient * prior raw successes + KC failure coefficient * prior raw failures; success coefficient projected nonnegative',
   'pfa_with_biases':'pfa_equation plus student and item biases; explicitly a PFA extension',
   'reference':'Pavlik et al. 2009 equation 3; nonnegative success slope used in their KT comparison; self-written, not author software',
   'citation_url':'https://files.eric.ed.gov/fulltext/ED506305.pdf','differences_from_paper':'single-KC processed data; AdamW, regularization and dev early stopping; no 2009 paper replication; use previous-model metric clipping',
   'selection':'minimum development event NLL separately per variant among all epochs and prespecified learning rates',
   'seed':0,'learning_rates':LRS,'epochs_max':a.epochs,'patience':a.patience,'optimizer':'AdamW with projection','weight_decay':1e-5,'batch_size':8192,'gradient_clip':5,
   'train_rows':len(tr),'development_rows':len(va),'development_students':len(dev),'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),
   'prior_max_correct_train':int(f['success'][ti].max()),'prior_max_incorrect_train':int(f['failure'][ti].max()),
   'source_p1_files':lock['p1_files'],'code_sha256':{n:sha(ROOT/n) for n in ('run_experiment.py','pfa_core.py','count_core.py','cross_core.py','review_stats.py')},'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg);runs={};selected={};probs={};labels=f['label'][vi];students=f['student'][vi]
  for variant in VARIANTS:
   for lr in LRS:
    name=variant+'_lr_'+format(lr,'.0e');status.update(phase='training',model=name,epoch=0);write(out/'status.json',status)
    torch.manual_seed(0)
    if device.type=='cuda':torch.cuda.manual_seed_all(0)
    model=PFA(dims['students'],dims['items'],dims['knowledges'],variant).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-5);rng=torch.Generator(device=device).manual_seed(0)
    best=float('inf');stale=0;history=[];model_begin=time.monotonic()
    def logits(ix):return model(*(tensor[k][ix] for k in ('student','item','kc','success','failure')))
    for epoch in range(1,a.epochs+1):
     t=time.monotonic();status.update(epoch=epoch);write(out/'status.json',status);model.train();perm=tr[torch.randperm(len(tr),device=device,generator=rng)];total=0.0
     for j in range(0,len(tr),8192):
      ix=perm[j:j+8192];opt.zero_grad(set_to_none=True);loss=F.binary_cross_entropy_with_logits(logits(ix),tensor['label'][ix])
      if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite loss')
      loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();model.project_success_nonnegative();total+=float(loss.detach())*len(ix)
     model.eval()
     with torch.no_grad():pr=torch.sigmoid(logits(va)).cpu().numpy()
     met=metrics(labels,pr);nll=float(met['nll']);history.append({'epoch':epoch,'train_bce':total/len(tr),'dev':met,'seconds':time.monotonic()-t});write(out/(name+'_history.json'),history)
     print(json.dumps({'model':name,'epoch':epoch,'dev_nll':nll,'seconds':history[-1]['seconds']}),flush=True)
     if nll<best:
      best=nll;stale=0;tmp=out/(name+'.pending.pt');torch.save({'model_state':model.state_dict(),'epoch':epoch,'dev_nll':nll,'variant':variant,'lr':lr,'data_fingerprint':data.fingerprint},tmp);tmp.replace(out/(name+'.pt'))
     else:stale+=1
     if stale>=a.patience:break
    ck=torch.load(out/(name+'.pt'),map_location=device,weights_only=True);model.load_state_dict(ck['model_state']);model.eval()
    with torch.no_grad():pr=torch.sigmoid(logits(va)).cpu().numpy()
    met=metrics(labels,pr)
    if abs(met['nll']-best)>1e-7:raise AssertionError('Best checkpoint mismatch')
    if float(model.kc.weight[:,1].min()) < 0:raise AssertionError('Success coefficient projection failed')
    runs[name]={'variant':variant,'lr':lr,'dev':met,'best_epoch':ck['epoch'],'epochs':len(history),'seconds':time.monotonic()-model_begin,'parameters':sum(x.numel() for x in model.parameters()),'checkpoint_sha256':sha(out/(name+'.pt')),'best_at_epoch_limit':ck['epoch']==a.epochs}
    if variant not in selected or best<selected[variant]['dev']['nll']:
     selected[variant]={'run':name,'lr':lr,'dev':met,'best_epoch':ck['epoch'],'best_at_epoch_limit':ck['epoch']==a.epochs};probs[variant]=pr.copy()
  status.update(phase='paired_analysis',model=None);write(out/'status.json',status)
  probs['previous_log_count_R2']=ref['R2'].to_numpy(dtype=np.float32);rows={};ls={};_,inv,n=np.unique(students,return_inverse=True,return_counts=True)
  for key,p in probs.items():
   ls[key]=losses(labels,p)[:,0];rows[key]={'dev':metrics(labels,p),'student_macro_nll':float(np.mean(np.bincount(inv,weights=ls[key])/n))}
  pairs=[('pfa_equation','previous_log_count_R2'),('pfa_with_biases','previous_log_count_R2'),('pfa_with_biases','pfa_equation')]
  boot=cluster_intervals(students,np.stack([ls[x]-ls[y] for x,y in pairs],axis=1),1000,20261109)
  pd.DataFrame({'record_idx':f['record_idx'][vi],'student_idx':students,'label':labels,**probs}).to_csv(out/'dev_predictions.csv.gz',index=False,compression='gzip')
  summary={'status':'complete','runs':runs,'selected':selected,'rows':rows,'paired':{x+'_minus_'+y:r for (x,y),r in zip(pairs,boot['comparisons'])},
   'scope':'exploratory repeatedly used development, seed 0; lr and epoch selected on same data; no test or holdout',
   'confidence_interval':'student-cluster bootstrap conditional on selected trained models; excludes training and hyperparameter-selection uncertainty','test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-started}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-started);write(out/'status.json',status);print('PFA DEVELOPMENT SCREEN COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-started);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
