"""CPU/CUDA tests -> all preflights -> batching gates -> 4 frozen validation probes."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True
from probe_core import MODES, require, read_json, save, sha
from run_probe import ROOT, DEFAULT_EXPORT, check_package, verify_metadata


def compare_batches(left, right):
    import numpy as np
    import pandas as pd
    a = pd.read_csv(Path(left)/"predictions.csv.gz")
    b = pd.read_csv(Path(right)/"predictions.csv.gz")
    identity = [k for k in a if not k.endswith("_probability")]
    require(a[identity].equals(b[identity]), "Batch-check identity mismatch")
    errors = {m: float(np.max(np.abs(a[m+"_probability"]-b[m+"_probability"]))) for m in MODES}
    require(all(np.isfinite(v) and v <= 1e-6 for v in errors.values()), f"Batch 128/17 mismatch: {errors}")
    return {"success": True, "n": len(a), "atol": 1e-6, "max_absolute_difference": errors}


def archive_results(root):
    root = Path(root)
    files = sorted(p for p in root.rglob("*") if p.is_file() and p.suffix != ".zip")
    require(not (root/"a0_results.zip").exists(), "Refusing archive overwrite")
    save(root/"results_manifest.json", {"files": {str(p.relative_to(root)).replace('\\','/'): sha(p) for p in files}})
    files.append(root/"results_manifest.json")
    with zipfile.ZipFile(root/"a0_results.zip", "x", compression=zipfile.ZIP_DEFLATED) as z:
        for path in files:
            z.write(path, str(path.relative_to(root)).replace('\\','/'))
    with zipfile.ZipFile(root/"a0_results.zip") as z:
        require(z.testzip() is None, "Result archive CRC failure")


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--export-root", default=DEFAULT_EXPORT)
    p.add_argument("--output-root", required=True)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--full", action="store_true", help="Complete 4 VALIDATION probes after all safety gates; never train")
    p.add_argument("--ack-row-feedback", action="store_true")
    a = p.parse_args()
    require(a.ack_row_feedback, "--ack-row-feedback required; bundles are not verified")
    root = Path(a.output_root).resolve()
    require(root != ROOT/"outputs" and root.is_relative_to(ROOT/"outputs"), "Output must be new package outputs subdirectory")
    require(not root.exists(), f"Existing results preserved: {root}")
    root.mkdir(parents=True, exist_ok=False)
    state = {"status": "running", "active_job": "input_checks", "pid": os.getpid(), "jobs": [],
             "trained": False, "test_evaluated": False, "args": vars(a)}
    status_path = root/"suite_status.json"
    save(status_path, state)
    started = time.perf_counter()
    try:
        check_package()
        policy = read_json(ROOT/"accepted_inputs.json")
        save(root/"suite_config.json", {"args": vars(a), "policy_sha256": sha(ROOT/"accepted_inputs.json"),
              "package_manifest": read_json(ROOT/"PACKAGE_MANIFEST.json"), "jobs": list(policy["jobs"]),
              "primary": "first KC event NLL and student macro NLL; concept versus original AND global",
              "not_a_trained_model": True})
        for name in policy["jobs"]:
            verify_metadata(a.project_dir, a.export_root, name, policy)
        print("All 4 existing checkpoint/reference identities passed. No training will run.", flush=True)
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", CUBLAS_WORKSPACE_CONFIG=":4096:8",
                   OPENBLAS_NUM_THREADS="2", OMP_NUM_THREADS="4")

        def run(name, command):
            log = root/(name+".log")
            state["active_job"] = name
            save(status_path, state)
            print(f"Starting {name}; log: {log}", flush=True)
            t = time.perf_counter()
            with log.open("x", encoding="utf-8") as f:
                r = subprocess.run(command, cwd=ROOT, env=env, stdout=f, stderr=subprocess.STDOUT, check=False)
            elapsed = time.perf_counter()-t
            state["jobs"].append({"name": name, "returncode": r.returncode, "seconds": elapsed, "command": command})
            save(status_path, state)
            require(r.returncode == 0, f"{name} failed. Read {log}; old results preserved")
            print(f"Completed {name} ({elapsed:.1f}s)", flush=True)

        for device in (("cpu", "cuda") if a.device == "cuda" else ("cpu",)):
            run("tests_"+device, [sys.executable,"-B","-u",str(ROOT/"test_probe.py"),
                "--project-dir",a.project_dir,"--device",device,"--report",str(root/f"tests_{device}.json")])
        for name in policy["jobs"]:
            for tag, batch in (("preflight", 128), ("batch17", 17)):
                out = root/(name+"_"+tag)
                command = [sys.executable,"-B","-u",str(ROOT/"run_probe.py"),"--project-dir",a.project_dir,
                           "--export-root",a.export_root,"--job",name,"--output-dir",str(out),
                           "--device",a.device,"--batch-size",str(batch),"--max-students","32","--ack-row-feedback"]
                run(name+"_"+tag,command)
        checks = {name: compare_batches(root/(name+"_preflight"),root/(name+"_batch17")) for name in policy["jobs"]}
        save(root/"batch_comparison.json",checks)
        if a.full:
            for name in policy["jobs"]:
                run(name+"_full",[sys.executable,"-B","-u",str(ROOT/"run_probe.py"),"--project-dir",a.project_dir,
                    "--export-root",a.export_root,"--job",name,"--output-dir",str(root/(name+"_full")),
                    "--device",a.device,"--batch-size","128","--ack-row-feedback"])
        state.update(status="complete", active_job=None, seconds=time.perf_counter()-started,
                     full_validations_completed=4 if a.full else 0)
        save(status_path,state)
        archive_results(root)
        print(f"ALL_RUNS_COMPLETED\nResults archive: {root/'a0_results.zip'}",flush=True)
    except BaseException as exc:
        state.update(status="failed",error=repr(exc),active_job=None,seconds=time.perf_counter()-started)
        save(status_path,state)
        raise


if __name__ == "__main__": main()
