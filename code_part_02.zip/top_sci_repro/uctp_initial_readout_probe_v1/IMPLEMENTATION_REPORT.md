# A0 独立读出探针实现报告

2026-10-04。本次用户确认继续上一轮 A0 方案后实施。

## 边界

仅新增 `uctp_initial_readout_probe_v1` 独立目录。未编辑原 clean、temporal、mechanism fix01/fix02 项目、原 checkpoint、原数据或既有结果。本轮未启动服务器作业或任何训练。

## 文件清单

| 文件 | 作用 |
|---|---|
| accepted_inputs.json | 从已验收 seed1/2 导出包提取四个 unit 作业的 checkpoint、训练元数据、验证 CSV、源码与数据身份 |
| probe_core.py | 训练支持集合、共享静态 logit 参照、首次读出、指标与学生簇 bootstrap |
| run_probe.py | 检查输入、载入原 clean checkpoint、运行一个验证探针、失败即停止 |
| test_probe.py | 35 项合成单元/集成测试；支持 CPU/CUDA |
| run_suite.py | 所有输入预检、CPU/GPU 测试、4×预检、batch17 一致性、4 个完整验证及归档 |
| show_results.py | 显示状态、失败原因、原始/探针指标和下载路径 |
| run_server.sh | 指定 yydw 解释器、GPU 0，执行固定验证方案 |
| SERVER_GUIDE.md | 上传、解压、tmux、一键运行、故障处理和解释边界 |
| PACKAGE_MANIFEST.json | 打包时生成的源文件 SHA-256 清单，用于发现上传或编辑差异 |

## 计算定义

对训练中出现过的唯一 student–KC 对构成集合 S。每名学生在同一 KC 上反复作答不会重复增加支持权重。

- concept：对某 KC，平均所有训练中观察过该 KC 的学生静态 logit。
- global：对 S 中全部唯一 student–KC 静态 logit 等权平均。这不是每个 KC 等权，也不是每个响应等权。
- 没有训练支持的 KC：concept 回退到同一个 global；明确报告人数与记录数。
- 全训练集合为空：失败，不自造参照。
- 不采用验证标签拟合混合系数、阈值或权重，不搜索多个均值形式。

这些是冻结模型内部的 latent logit 参照，不是已校准贝叶斯先验。新效果可能来自收缩或校准，故全局参照是必要对照。

## 数据流和因果边界

1. 校验原 checkpoint、数据与已验收验证 CSV 的哈希；核对 best epoch、源码、配置和在线反馈设置。
2. 仅用结构字段确定 train 支持集合及预测前 KC 次数；独立重建计数并对照保存值。
3. 用训练支持与冻结静态参数计算两个共享参照。
4. 对首次 KC 的当前预测：使用学生/题目/KC 与共享参照读出；函数没有当前答案或 RT 参数。
5. 模型原写入函数不变。实际快捷评测不调用 observe，而是复用已验收的非首次预测；合成完整序列测试验证了这一路径的等价条件。

完整回放中，题目难度决定的原写入不依赖被替换的学生静态 logit。只替换首次预测而不改变参数，故 P/N 状态和后续非首次预测保持不变。这个等价性只对当前冻结、单 KC、原写入函数成立；不推广到未来加入可靠性网络的模型。

数据接口要求单题单 KC；多 KC 直接拒绝，避免将“某个 KC 未见”和“当前题全部 KC 未见”混淆。

`records.npz` 的 label/response_time 字段不加载。结构字段可能包含 test 行，进入支持统计和前缀计算前先排除 split=2。评分标签只来自已验收的 valid CSV。词表仍沿用原数据的无标签 train/valid/test ID 并集策略，未重建划分。

## 数值检查

- 独立首次读出 vs 原 CleanCD.predict 的零目标状态读出，≤1e-6。
- 原生首次读出 vs 原验证 CSV 恢复后的 float32 概率，≤1e-6。
- 原验证总体 AUC/NLL/Brier vs 已验收训练 history，≤1e-12（不是探针收益阈值）。
- 32 名预检学生的 batch128 vs batch17，≤1e-6。
- 非首次三种概率逐值一致；模型参数前后摘要一致；源输入文件前后哈希一致。
- 任一校验失败即停止，不降低精度标准，不更改原检查点的 model_family。

输出的“原始”指标在原 CSV 精度空间；没有使用此前机制诊断的 FP64 分支分数替代它。

## 本地验证

- Python 环境：已有本地 clean 项目 `.venv`；PyTorch 2.11.0+cpu、NumPy 2.3.5、pandas 3.0.1。
- CPU 35 tests 全部通过，failures/errors/skipped 均为空。
- 覆盖：支持去重及手算均值、训练外支持隔离、标签不参与参照、前缀计数、同时间标记、多 KC 拒绝、原生/独立/CSV 对照、坏概率检出、batch 等价、回退、参数/梯度不变、完整序列 P/N 不变、当前与未来标签不泄漏、bootstrap 手工对照、完整入口跑通、文件损坏与覆盖拒绝、结果 ZIP 哈希。
- 完整入口使用合成 checkpoint/数据/验证预测跑通；没有把这项测试称为真实 full-data 实验。
- CUDA 尚未在本地执行；服务器一键套件会先执行 CUDA 测试再进入真实探针。
- 尝试核对本地 full records.npz 时，其文件哈希不等于这次已验收服务器输入，因此没有使用它冒充服务器 full-data 通过，也未修改或重新预处理它。服务器将继续使用 readiness 已确认的原文件；若服务器也出现哈希不符，应停止排查。

## 主分析约定

本轮先 unit_write seeds1/2 × 两数据集，避免同时扩展两种骨干或重新训练 seed0。所有作业使用原验证 AUC 选择的检查点，不根据 test 调参。

主组 first_kc；同时报告 all/nonfirst_kc，首次 KC 中学生总历史 <50 / ≥50、排除同时间评分行、无训练支持回退组。指标含 NLL、学生宏平均 NLL、AUC、Brier、ECE15、平均概率、实际正确率。

比较 concept−original、global−original、concept−global，NLL 负值为改善。每个 checkpoint 固定 2000 次学生簇 bootstrap，分析种子 20260929。同一重采样用于所有模式和分组。区间是固定模型下的探索性逐项区间，不包含重新训练或模型选择的不确定性，不做因果效果解释。

若没有稳定改善或只剩校准解释，应据实收窄；不自动触发新的网络或参数搜索。得到本轮服务器结果后再决定是否做可训练模型。
