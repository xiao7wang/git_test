"""Synthetic tests only. Never train; never use private server data."""
import argparse
import copy
import hashlib
import os
from pathlib import Path
import sys
import tempfile
import unittest

sys.dont_write_bytecode = True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch
from probe_core import (MODES, build_priors, first_readout, import_clean, make_context,
                        parameter_digest, probe, read_json, save, select_rows, sha, summarize, validate_frame)
from run_probe import run_job, ROOT

PROJECT, DEVICE, MODEL, METRIC = None, "cpu", None, None


def fixture():
    # (student, item, response, timestamp, split). Test labels included ONLY in synthetic fixture.
    rows = [(0,0,1,0,0),(0,0,0,1,0),(0,1,1,10,1),(0,1,0,10,1),(0,2,1,12,1),(0,0,0,20,2),
            (1,1,1,0,0),(1,1,1,1,0),(1,0,0,10,1),(1,3,1,11,1),(1,2,0,20,2),
            (2,0,0,0,0),(2,1,1,1,0),(2,2,1,10,1),(2,1,0,11,1),(2,2,1,20,2),
            (3,1,0,0,0),(3,0,1,10,1),(3,2,0,11,1),(3,1,0,20,2)]
    a = np.array(rows)
    x = {"student_idx": a[:,0].astype(np.int32), "item_idx": a[:,1].astype(np.int32),
         "label": a[:,2].astype(np.float32), "timestamp": a[:,3].astype(np.float64),
         "split": a[:,4].astype(np.int32), "item_q": np.eye(3, dtype=bool)[[0,1,2,0]],
         "kc_count_before": np.zeros(len(a)), "student_count_before": np.zeros(len(a), np.int32)}
    kcounts, ucounts = {}, {}
    for i, (u, it) in enumerate(zip(x["student_idx"], x["item_idx"])):
        k = int(x["item_q"][it].argmax())
        x["kc_count_before"][i] = kcounts.get((u,k), 0)
        x["student_count_before"][i] = ucounts.get(u, 0)
        kcounts[u,k] = kcounts.get((u,k), 0)+1
        ucounts[u] = ucounts.get(u, 0)+1
    return x


def model(variant="unit_write"):
    torch.manual_seed(7)
    m = MODEL(4,4,3,variant=variant,ncd_hidden_dim=8).to(DEVICE)
    m.eval().requires_grad_(False)
    return m


@torch.inference_mode()
def replay(m, x, mode="original", priors=None):
    rows, states = [], []
    last = None
    for i in np.flatnonzero(x["split"] <= 1):
        u, it = int(x["student_idx"][i]), int(x["item_idx"][i])
        if u != last:
            state = m.init_state(1, DEVICE)
            last = u
        ut, item = torch.tensor([u], device=DEVICE), torch.tensor([it], device=DEVICE)
        q = torch.tensor(x["item_q"][it:it+1], dtype=torch.float32, device=DEVICE)
        pred = m.predict(state, ut, item, q)
        p = pred["probability"]
        if x["split"][i] == 1 and x["kc_count_before"][i] == 0 and mode != "original":
            k = q.argmax(1).item()
            value = priors["concept"][k] if mode == "concept" else priors["global"]
            p = first_readout(m, ut, item, q, torch.tensor([value], dtype=torch.float32, device=DEVICE))
        if x["split"][i] == 1:
            rows.append({"record_idx": i, "student_idx": u, "item_idx": it, "label": float(x["label"][i]),
                "timestamp": x["timestamp"][i], "split": 1, "kc_count_before": x["kc_count_before"][i],
                "student_count_before": x["student_count_before"][i], "probability": p.item(),
                "uncertainty": pred["uncertainty"].item(), "evidence": pred["evidence"].item()})
        state = m.observe(state, q, torch.tensor([x["label"][i]], device=DEVICE),
                          pred["difficulty_scalar"], torch.tensor([True], device=DEVICE))
        states.append((state.positive.cpu().clone(), state.negative.cpu().clone()))
    return pd.DataFrame(rows), states


def pipeline_fixture(root):
    """Make isolated fake data/checkpoint/reference with REAL pinned model source."""
    root = Path(root)
    policy = read_json(ROOT/"accepted_inputs.json")
    x = fixture()
    m = model()
    frame, _ = replay(m, x)
    run, data, export = [root/n for n in ("train_run", "data", "export")]
    for p in (run, data, export):
        p.mkdir()
    evaluation = export/"fake_job"/"attempt_001"
    evaluation.mkdir(parents=True)
    np.savez_compressed(data/"records.npz", **x)
    save(data/"vocabulary.json", {"student_ids": list(range(4))})
    save(data/"manifest.json", {"feedback_protocol": "row_immediate_assumption", "feedback_boundaries_verified": False})
    fp = sha(data/"manifest.json")
    mc = {"num_students": 4, "num_items": 4, "num_knowledges": 3, "variant": "unit_write", "ncd_hidden_dim": 8}
    sources = policy["source_pins"]
    torch.save({"model_config": mc, "model_state": m.state_dict(), "epoch": 1,
                "data_fingerprint": fp, "source_code": sources}, run/"best_model.pt")
    cksha = sha(run/"best_model.pt")
    metrics = METRIC(frame.label, frame.probability)
    cfg = {"args": {"seed": 1}, "model_config": mc, "data_fingerprint": fp, "source_code": sources}
    save(run/"run_config.json", cfg)
    save(run/"status.json", {"status": "complete", "best_epoch": 1, "checkpoint_sha256": cksha})
    save(run/"history.json", [{"epoch": 1, "valid": metrics}])
    frame.to_csv(evaluation/"predictions.csv", index=False, float_format="%.17g")
    save(evaluation/"metrics.json", metrics)
    save(evaluation/"subgroup_metrics.json", {})
    save(evaluation/"evaluation.json", {"epoch": 1, "checkpoint_sha256": cksha, "data_fingerprint": fp,
         "source_code": sources, "args": {"view": "valid", "update_targets": 1, "ack_row_feedback": True,
                                           "batch_size": 8, "chunk_size": 100}})
    save(export/"export_plan.json", {})
    save(export/"completed.json", {})
    name = "fake_unit_write_seed1"
    j = {"variant": "unit_write", "seed": 1, "dataset": "fake", "run": str(run),
         "checkpoint": str(run/"best_model.pt"), "checkpoint_sha256": cksha, "data_dir": str(data),
         "data_fingerprint": fp, "best_epoch": 1, "n": len(frame), "expected_validation": metrics,
         "metadata_hashes": {n: sha(run/n) for n in ("run_config.json", "history.json", "status.json")},
         "export": {"evaluation_dir": "fake_job/attempt_001", "verification": {"files": {
             n: sha(evaluation/n) for n in ("predictions.csv", "metrics.json", "subgroup_metrics.json", "evaluation.json")}}}}
    policy.update(jobs={name: j}, training_settings={"fake": {}}, data={"fake": {
        "fingerprint": fp, "records_sha256": sha(data/"records.npz"), "vocabulary_sha256": sha(data/"vocabulary.json")}},
        export_plan_sha256=sha(export/"export_plan.json"), completed_sha256=sha(export/"completed.json"))
    args = argparse.Namespace(project_dir=str(PROJECT), export_root=str(export), job=name,
        output_dir=str(root/"outputs"/"run"), device=DEVICE, threads=1, batch_size=3, max_students=0, ack_row_feedback=True)
    return args, policy, x


class ProbeTests(unittest.TestCase):
    def setUp(self):
        self.x = fixture()
        self.c = make_context(self.x, 4)
        self.m = model()
        self.priors = build_priors(self.m.student_mastery_logit.weight.detach().cpu().numpy(), self.c["pairs"])
        self.f, _ = replay(self.m, self.x)

    def run_probe(self, batch=3):
        return probe(self.m, self.f, self.c, self.priors, np.arange(len(self.f)), batch, DEVICE)

    def test_hand_prior_unweighted_unique_students_and_pairs(self):
        z = np.array([[1, 5, 99], [3, 7, 99], [9, 11, 99], [13, 15, 99]])
        p = build_priors(z, self.c["pairs"])
        # K0 supported by students 0,2. K1 by 1,2,3. K2 unsupported.
        np.testing.assert_array_equal(p["support"], [2,3,0])
        np.testing.assert_allclose(p["concept"], [5,11,8.6])
        self.assertAlmostEqual(p["global"], 8.6)
        self.assertTrue(p["fallback"][2])

    def test_no_validation_test_support(self):
        np.testing.assert_array_equal(self.c["pairs"], [0,4,6,7,10])
        self.assertFalse(np.isin(self.c["record_idx"], np.flatnonzero(self.x["split"] == 2)).any())

    def test_labels_not_needed_for_context(self):
        x = copy.deepcopy(self.x)
        del x["label"]
        np.testing.assert_array_equal(make_context(x, 4)["pairs"], self.c["pairs"])

    def test_labels_and_test_ids_do_not_change_support(self):
        x = copy.deepcopy(self.x)
        x["label"][:] = np.nan
        x["student_idx"][x["split"] == 2] = -999
        x["item_idx"][x["split"] == 2] = -999
        np.testing.assert_array_equal(make_context(x, 4)["pairs"], self.c["pairs"])

    def test_prefix_excludes_current(self):
        ix = list(self.c["record_idx"]).index(2)
        self.assertEqual(self.c["kc_count"][ix], 0)
        self.assertEqual(self.c["kc_count"][ix+1], 1)

    def test_same_time_identified(self):
        np.testing.assert_array_equal(self.c["tied"][:3], [True, True, False])

    def test_reject_multikc(self):
        self.x["item_q"][0,1] = True
        with self.assertRaises(ValueError): make_context(self.x, 4)

    def test_reject_wrong_prefix(self):
        self.x["kc_count_before"][2] = 1
        with self.assertRaises(ValueError): make_context(self.x, 4)

    def test_reject_backwards_time(self):
        self.x["timestamp"][3] = -10
        with self.assertRaises(ValueError): make_context(self.x, 4)

    def test_reject_no_train_support(self):
        self.x["split"][self.x["split"] == 0] = 1
        with self.assertRaises(ValueError): make_context(self.x, 4)

    def test_reject_duplicate_prior_pairs(self):
        with self.assertRaises(ValueError): build_priors(np.zeros((4,3)), np.array([0,0]))

    def test_reference_id_and_label_validity(self):
        validate_frame(self.f, self.c)
        f = self.f.copy()
        f.loc[0,"item_idx"] = 3
        with self.assertRaises(ValueError): validate_frame(f, self.c)
        f = self.f.copy()
        f.loc[0,"label"] = 2
        with self.assertRaises(ValueError): validate_frame(f, self.c)

    def test_reject_cold_state_not_empty(self):
        f = self.f.copy()
        f.loc[0,"evidence"] = 1.
        with self.assertRaises(ValueError): validate_frame(f, self.c)

    def test_native_and_saved_reference_gate(self):
        _, gate = self.run_probe()
        self.assertTrue(gate["success"])

    def test_corrupted_probability_fails_gate(self):
        self.f.loc[0,"probability"] = float(self.f.loc[0,"probability"])+.01
        _, gate = self.run_probe()
        self.assertFalse(gate["success"])

    def test_readout_batch_17_equivalence(self):
        a, _ = self.run_probe(1)
        b, _ = self.run_probe(17)
        for mode in MODES:
            np.testing.assert_allclose(a[mode+"_probability"], b[mode+"_probability"], rtol=0, atol=1e-6)

    def test_fallback_equals_global(self):
        f, _ = self.run_probe()
        m = (f.kc_count_before == 0) & f.global_fallback
        np.testing.assert_array_equal(f.loc[m,"concept_probability"], f.loc[m,"global_probability"])

    def test_nonfirst_exact_unchanged(self):
        f, _ = self.run_probe()
        m = f.kc_count_before > 0
        for mode in MODES:
            np.testing.assert_array_equal(f.loc[m,mode+"_probability"], f.loc[m,"original_probability"])

    def test_no_parameter_or_gradient_change(self):
        digest = parameter_digest(self.m)
        self.run_probe()
        self.assertEqual(digest, parameter_digest(self.m))
        self.assertTrue(all(p.grad is None for p in self.m.parameters()))

    def test_full_sequential_state_invariance_all_modes(self):
        original, original_states = replay(self.m, self.x)
        for mode in ("concept", "global"):
            altered, states = replay(self.m, self.x, mode, self.priors)
            for a, b in zip(original_states, states):
                for av, bv in zip(a,b): self.assertTrue(torch.equal(av,bv))
            m = original.kc_count_before > 0
            np.testing.assert_array_equal(original.loc[m,"probability"], altered.loc[m,"probability"])

    def test_shortcut_equals_independent_full_replay(self):
        f, _ = self.run_probe()
        for mode in MODES:
            direct, _ = replay(self.m, self.x, mode, self.priors)
            np.testing.assert_allclose(f[mode+"_probability"], direct.probability, rtol=0, atol=1e-6)

    def test_current_response_not_in_current_prediction(self):
        a, _ = replay(self.m, self.x, "concept", self.priors)
        x = copy.deepcopy(self.x)
        x["label"][2] = 1-x["label"][2]
        b, _ = replay(self.m, x, "concept", self.priors)
        self.assertEqual(a.probability.iloc[0], b.probability.iloc[0])

    def test_future_response_not_in_prior_predictions(self):
        a, _ = replay(self.m, self.x, "concept", self.priors)
        x = copy.deepcopy(self.x)
        x["label"][4] = 1-x["label"][4]
        b, _ = replay(self.m, x, "concept", self.priors)
        np.testing.assert_array_equal(a.probability.iloc[:3], b.probability.iloc[:3])

    def test_other_kc_state_does_not_affect_cold_prediction(self):
        st = self.m.init_state(1, DEVICE)
        st.positive[0,0] = 1000
        st.negative[0,2] = 50
        u, it = torch.tensor([0], device=DEVICE), torch.tensor([1], device=DEVICE)
        q = torch.tensor([[0,1,0]], dtype=torch.float32, device=DEVICE)
        a = self.m.predict(st, u, it, q)["probability"]
        b = first_readout(self.m, u, it, q)
        torch.testing.assert_close(a,b,rtol=0,atol=1e-6)

    def test_preflight_deterministic_no_label_selection(self):
        np.testing.assert_array_equal(select_rows(self.c,2), select_rows(self.c,2))
        self.assertEqual(len(np.unique(self.c["student_idx"][select_rows(self.c,2)])),2)

    def test_bootstrap_zero_effect_and_empty_group(self):
        f, _ = self.run_probe()
        for mode in MODES: f[mode+"_probability"] = f.original_probability
        r = summarize(f, METRIC, reps=100)
        self.assertEqual(r["groups"]["first_kc"]["comparisons"]["concept_minus_original"]["event_interval"]["ci95"], [0.,0.])
        self.assertEqual(r["groups"]["first_kc_user_ge50"]["n"],0)
        self.assertIsNone(r["groups"]["first_kc_user_ge50"]["metrics"]["original"]["auc"])

    def test_bootstrap_matches_literal_student_draws(self):
        f, _ = self.run_probe()
        r = summarize(f, METRIC, reps=100)
        from probe_core import nll
        u, y = f.student_idx.to_numpy(), f.label.to_numpy()
        delta = nll(y,f.concept_probability.to_numpy())-nll(y,f.original_probability.to_numpy())
        us = np.unique(u); rng = np.random.default_rng(20260929)
        micro, macro = [], []
        for _ in range(100):
            picked = us[rng.integers(len(us),size=len(us))]
            arrays = [delta[u == s] for s in picked]
            micro.append(np.concatenate(arrays).mean())
            macro.append(np.mean([x.mean() for x in arrays]))
        entry = r["groups"]["all"]["comparisons"]["concept_minus_original"]
        np.testing.assert_allclose(entry["event_interval"]["ci95"], np.quantile(micro,[.025,.975]), atol=1e-15,rtol=0)
        np.testing.assert_allclose(entry["macro_interval"]["ci95"], np.quantile(macro,[.025,.975]), atol=1e-15,rtol=0)

    def test_pipeline_and_overwrite_guard(self):
        with tempfile.TemporaryDirectory(prefix="a0_probe_test_") as d:
            args, policy, _ = pipeline_fixture(d)
            result = run_job(args, policy, Path(d)/"outputs")
            self.assertEqual(result["status"], "complete")
            self.assertFalse(result["trained"])
            with self.assertRaises(ValueError): run_job(args, policy, Path(d)/"outputs")

    def test_pipeline_modified_reference_fails_closed(self):
        with tempfile.TemporaryDirectory(prefix="a0_probe_test_") as d:
            args, policy, _ = pipeline_fixture(d)
            csv = Path(args.export_root)/"fake_job/attempt_001/predictions.csv"
            csv.write_text(csv.read_text()+"\n")
            with self.assertRaisesRegex(ValueError,"Input changed"):
                run_job(args,policy,Path(d)/"outputs")
            self.assertFalse((Path(args.output_dir)/"summary.json").exists())

    def test_pipeline_missing_file_and_ack_fail(self):
        with tempfile.TemporaryDirectory(prefix="a0_probe_test_") as d:
            args, policy, _ = pipeline_fixture(d)
            args.ack_row_feedback = False
            with self.assertRaises(ValueError): run_job(args,policy,Path(d)/"outputs")
            self.assertFalse(Path(args.output_dir).exists())
            args.ack_row_feedback = True
            policy["jobs"][args.job]["checkpoint"] = str(Path(d)/"absent.pt")
            with self.assertRaisesRegex(ValueError,"Missing input"):
                run_job(args,policy,Path(d)/"outputs")

    def test_pipeline_modified_checkpoint_fails_before_loading(self):
        with tempfile.TemporaryDirectory(prefix="a0_probe_test_") as d:
            args, policy, _ = pipeline_fixture(d)
            ck = Path(policy["jobs"][args.job]["checkpoint"])
            with ck.open("ab") as f: f.write(b"changed")
            with self.assertRaisesRegex(ValueError,"Input changed"):
                run_job(args,policy,Path(d)/"outputs")

    def test_preflight_contains_nonfirst_rows_too(self):
        ix = select_rows(self.c,4)
        self.assertTrue((self.c["kc_count"][ix] > 0).any())
        self.assertTrue((self.c["kc_count"][ix] == 0).any())

    def test_batch_suite_detects_prediction_corruption(self):
        from run_suite import compare_batches
        with tempfile.TemporaryDirectory(prefix="a0_batch_test_") as d:
            a,b = Path(d)/"a",Path(d)/"b"
            a.mkdir(); b.mkdir()
            f,_ = self.run_probe()
            f.to_csv(a/"predictions.csv.gz",index=False)
            f.to_csv(b/"predictions.csv.gz",index=False)
            self.assertTrue(compare_batches(a,b)["success"])
            f.loc[0,"concept_probability"] = float(f.loc[0,"concept_probability"])+.01
            f.to_csv(b/"predictions.csv.gz",index=False)
            with self.assertRaises(ValueError): compare_batches(a,b)

    def test_batch_suite_detects_identity_corruption(self):
        from run_suite import compare_batches
        with tempfile.TemporaryDirectory(prefix="a0_batch_test_") as d:
            a,b = Path(d)/"a",Path(d)/"b"
            a.mkdir(); b.mkdir()
            f,_ = self.run_probe()
            f.to_csv(a/"predictions.csv.gz",index=False)
            f.loc[0,"label"] = 1-f.loc[0,"label"]
            f.to_csv(b/"predictions.csv.gz",index=False)
            with self.assertRaises(ValueError): compare_batches(a,b)

    def test_archive_hashes_and_no_overwrite(self):
        import zipfile
        from run_suite import archive_results
        with tempfile.TemporaryDirectory(prefix="a0_archive_test_") as d:
            root = Path(d)
            save(root/"suite_status.json", {"status":"complete"})
            archive_results(root)
            with zipfile.ZipFile(root/"a0_results.zip") as z:
                manifest = read_json(root/"results_manifest.json")
                for name,h in manifest["files"].items():
                    self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(),h)
            with self.assertRaises(ValueError): archive_results(root)


def main():
    global PROJECT, DEVICE, MODEL, METRIC
    p = argparse.ArgumentParser()
    p.add_argument("--project-dir", required=True)
    p.add_argument("--device", choices=("cpu","cuda"), default="cpu")
    p.add_argument("--report")
    a = p.parse_args()
    PROJECT, DEVICE = Path(a.project_dir), a.device
    if DEVICE == "cuda" and not torch.cuda.is_available(): raise RuntimeError("CUDA unavailable")
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    MODEL, METRIC = import_clean(PROJECT, read_json(ROOT/"accepted_inputs.json")["source_pins"])
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ProbeTests))
    report = {"success": result.wasSuccessful(), "tests_run": result.testsRun, "device": DEVICE,
              "torch": str(torch.__version__), "failures": [(str(t),s) for t,s in result.failures],
              "errors": [(str(t),s) for t,s in result.errors], "skipped": result.skipped}
    if a.report:
        path = Path(a.report)
        if path.exists(): raise FileExistsError(path)
        save(path, report)
    print(report, flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__": main()
