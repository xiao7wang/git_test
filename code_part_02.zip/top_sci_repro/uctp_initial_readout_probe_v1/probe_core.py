"""A0: train-supported, frozen first-KC readout probe; never fits model parameters."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

MODES = ("original", "concept", "global")
ATOL = 1e-6


def require(ok, message):
    if not ok:
        raise ValueError(message)

 
def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1048576), b""):
            h.update(b)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def import_clean(project, pins):
    project = Path(project).resolve()
    for rel, expected in pins.items():
        require(sha(project / rel) == expected, f"Frozen clean source changed: {rel}")
    Model = load_module(project / "src/model.py", "a0_frozen_clean_model").CleanCD
    metric = load_module(project / "src/metrics.py", "a0_frozen_clean_metrics").compute_metrics
    return Model, metric


def parameter_digest(model):
    h = hashlib.sha256()
    for name, tensor in model.state_dict().items():
        h.update(name.encode())
        a = tensor.detach().cpu().contiguous().numpy()
        h.update(str((a.shape, a.dtype)).encode())
        h.update(a.tobytes())
    return h.hexdigest()


def make_context(arrays, num_students):
    """Only structural fields; train/valid masking precedes any support/count use."""
    q = np.asarray(arrays["item_q"])
    require(q.ndim == 2 and np.isin(q, [0, 1]).all() and (q.sum(1) == 1).all(),
            "A0 v1 requires verified single-KC Q; refusing multi-KC shortcut")
    split = np.asarray(arrays["split"])
    require(np.isin(split, [0, 1, 2]).all(), "Invalid split")
    ids = np.flatnonzero(split <= 1)
    u = np.asarray(arrays["student_idx"])[ids]
    it = np.asarray(arrays["item_idx"])[ids]
    time = np.asarray(arrays["timestamp"])[ids]
    sp = split[ids]
    require(np.issubdtype(u.dtype, np.integer) and np.issubdtype(it.dtype, np.integer), "Noninteger IDs")
    require(len(ids) > 0 and ((u >= 0) & (u < num_students)).all(), "Invalid students")
    require(((it >= 0) & (it < len(q))).all() and np.isfinite(time).all(), "Invalid item/time")
    require((np.diff(u) >= 0).all(), "Student order")
    same = np.diff(u) == 0
    require((np.diff(time)[same] >= 0).all(), "Time order")
    require((np.diff(sp.astype(int))[same] >= 0).all(), "Split interleaving")
    kc = q.argmax(1)[it]
    key = u.astype(np.int64)*q.shape[1]+kc
    order = np.lexsort((ids, key))
    first = np.r_[True, key[order][1:] != key[order][:-1]]
    start = np.maximum.accumulate(np.where(first, np.arange(len(ids)), 0))
    counts = np.empty(len(ids), np.int64)
    counts[order] = np.arange(len(ids))-start
    uf = np.r_[True, u[1:] != u[:-1]]
    user_counts = np.arange(len(ids))-np.maximum.accumulate(np.where(uf, np.arange(len(ids)), 0))
    require(np.array_equal(counts, np.asarray(arrays["kc_count_before"])[ids]), "Saved KC prefixes disagree")
    require(np.array_equal(user_counts, np.asarray(arrays["student_count_before"])[ids]), "Saved user prefixes disagree")
    left_tie = np.r_[False, same & (np.diff(time) == 0)]
    tied = left_tie | np.r_[left_tie[1:], False]
    pairs = np.unique(key[sp == 0])  # unique train student-KC, NOT per interaction
    require(len(pairs) > 0, "No train support; no prior is defined")
    valid = sp == 1
    return {"q": q, "pairs": pairs, "record_idx": ids[valid], "student_idx": u[valid],
            "item_idx": it[valid], "timestamp": time[valid], "kc": kc[valid],
            "kc_count": counts[valid], "user_count": user_counts[valid], "tied": tied[valid]}


def build_priors(student_logits, pairs):
    z = np.asarray(student_logits, dtype=np.float64)
    require(z.ndim == 2 and np.isfinite(z).all(), "Invalid static parameters")
    pairs = np.asarray(pairs)
    require(np.issubdtype(pairs.dtype, np.integer) and len(pairs) and len(np.unique(pairs)) == len(pairs), "Invalid support pairs")
    require(((pairs >= 0) & (pairs < z.size)).all(), "Pair outside parameter table")
    k = pairs % z.shape[1]
    values = z[pairs // z.shape[1], k]
    count = np.bincount(k, minlength=z.shape[1])
    global_mean = float(values.mean())
    concept = np.divide(np.bincount(k, weights=values, minlength=z.shape[1]), count,
                        out=np.full(z.shape[1], global_mean), where=count > 0)
    return {"concept": concept, "global": global_mean, "support": count,
            "fallback": count == 0, "unique_train_student_kc_pairs": len(pairs)}


@torch.inference_mode()
def first_readout(model, student, item, q, replacement=None):
    """Independent first-KC readout. No label/RT/history-response argument."""
    base = model.student_mastery_logit(student).clone()
    if replacement is not None:
        require(replacement.shape == student.shape, "Replacement shape")
        base = torch.where(q.bool(), replacement[:, None], base)
    mastery = torch.sigmoid(base)
    difficulty = torch.sigmoid(model.item_difficulty_logit(item))
    discr = F.softplus(model.item_discrimination_raw(item)).squeeze(-1)+1e-4
    interaction = discr[:, None]*(mastery-difficulty)*q
    logit = (model.item_bias(item).squeeze(-1) + F.softplus(model.raw_direct_scale)*
             interaction.sum(-1)/q.sum(-1).clamp_min(1) + model.ncd(interaction).squeeze(-1))
    return torch.sigmoid(logit)


def validate_frame(frame, context):
    require(frame.record_idx.is_unique, "Duplicate reference records")
    require(len(frame) == len(context["record_idx"]) and (frame.split == 1).all(), "Reference must cover full validation only")
    for col in ("record_idx", "student_idx", "item_idx", "timestamp"):
        require(np.array_equal(frame[col], context[col]), f"Reference identity mismatch: {col}")
    for col, key in (("kc_count_before", "kc_count"), ("student_count_before", "user_count")):
        require(np.array_equal(frame[col], context[key]), f"Reference prefix mismatch: {col}")
    require(np.isin(frame.label, [0, 1]).all(), "Reference label invalid")
    for col in ("probability", "uncertainty", "evidence"):
        require(np.isfinite(frame[col]).all() and (frame[col] >= 0).all(), f"Invalid reference {col}")
    require((frame.probability <= 1).all() and (frame.uncertainty <= 1).all(), "Reference range")
    cold = context["kc_count"] == 0
    require((frame.loc[cold, "evidence"] == 0).all() and (frame.loc[cold, "uncertainty"] == 1).all(), "First-KC state not zero in original replay")


def select_rows(context, max_students=0):
    if max_students == 0:
        return np.arange(len(context["record_idx"]))
    require(max_students > 0, "Invalid max students")
    cold_users = np.unique(context["student_idx"][context["kc_count"] == 0])
    selected = np.random.default_rng(20261004).permutation(cold_users)[:max_students]
    require(len(selected) > 0, "No first-KC observations")
    return np.flatnonzero(np.isin(context["student_idx"], selected))


@torch.inference_mode()
def probe(model, frame, context, priors, rows, batch_size, device):
    require(batch_size > 0 and not model.training, "Invalid inference settings")
    require(all(not p.requires_grad for p in model.parameters()), "Model must be frozen")
    before = parameter_digest(model)
    selected = frame.iloc[rows].reset_index(drop=True)
    # Original probabilities restored to original FP32 precision; no modifications to source CSV.
    original = selected.probability.to_numpy().astype(np.float32).astype(float)
    outputs = {mode: original.copy() for mode in MODES}
    cold = context["kc_count"][rows] == 0
    local = np.flatnonzero(cold)
    require(len(local) > 0, "No cold observations in selection")
    audit = {"independent_vs_native": 0., "native_vs_saved": 0., "batch_size": batch_size}
    for start in range(0, len(local), batch_size):
        loc = local[start:start+batch_size]
        ix = rows[loc]
        student = torch.as_tensor(context["student_idx"][ix], dtype=torch.long, device=device)
        item = torch.as_tensor(context["item_idx"][ix], dtype=torch.long, device=device)
        q = torch.as_tensor(context["q"][context["item_idx"][ix]], dtype=torch.float32, device=device)
        native = model.predict(model.init_state(len(ix), device), student, item, q)["probability"]
        independent = first_readout(model, student, item, q)
        a = native.cpu().numpy().astype(float)
        b = independent.cpu().numpy().astype(float)
        audit["independent_vs_native"] = max(audit["independent_vs_native"], float(np.max(np.abs(a-b))))
        audit["native_vs_saved"] = max(audit["native_vs_saved"], float(np.max(np.abs(a-original[loc]))))
        for mode in ("concept", "global"):
            values = priors["concept"][context["kc"][ix]] if mode == "concept" else np.full(len(ix), priors["global"])
            replacement = torch.as_tensor(values, dtype=torch.float32, device=device)
            outputs[mode][loc] = first_readout(model, student, item, q, replacement).cpu().numpy().astype(float)
    audit["atol"] = ATOL
    audit["success"] = audit["independent_vs_native"] <= ATOL and audit["native_vs_saved"] <= ATOL
    require(parameter_digest(model) == before, "Model parameters changed")
    result = selected[["record_idx", "student_idx", "item_idx", "label", "timestamp"]].copy()
    result["split"] = 1
    result["kc"] = context["kc"][rows]
    result["kc_count_before"] = context["kc_count"][rows]
    result["student_count_before"] = context["user_count"][rows]
    result["same_time"] = context["tied"][rows]
    result["train_kc_support_students"] = priors["support"][context["kc"][rows]]
    result["global_fallback"] = priors["fallback"][context["kc"][rows]]
    for mode in MODES:
        require(np.isfinite(outputs[mode]).all(), "Nonfinite probe")
        require(np.array_equal(outputs[mode][~cold], original[~cold]), "Nonfirst predictions changed")
        result[mode+"_probability"] = outputs[mode]
    return result, audit


def nll(y, p):
    c = np.clip(p, 1e-7, 1-1e-7)
    return -(y*np.log(c)+(1-y)*np.log1p(-c))


def summarize(frame, metric, reps=2000):
    """Exploratory paired student bootstrap, fixed groups; no tuning or selection."""
    require(reps >= 1, "Bootstrap repetitions must be positive")
    u = frame.student_idx.to_numpy()
    y = frame.label.to_numpy()
    cold = frame.kc_count_before.to_numpy() == 0
    groups = {"all": np.ones(len(frame), bool), "first_kc": cold, "nonfirst_kc": ~cold,
              "first_kc_user_lt50": cold & (frame.student_count_before.to_numpy() < 50),
              "first_kc_user_ge50": cold & (frame.student_count_before.to_numpy() >= 50),
              "first_kc_not_tied": cold & ~frame.same_time.to_numpy(),
              "first_kc_global_fallback": cold & frame.global_fallback.to_numpy()}
    predictions = {m: frame[m+"_probability"].to_numpy() for m in MODES}
    losses = {m: nll(y, p) for m, p in predictions.items()}
    pairs = (("concept", "original"), ("global", "original"), ("concept", "global"))
    names = [a+"_minus_"+b for a, b in pairs]
    inv = np.unique(u, return_inverse=True)[1]
    ns = int(inv.max())+1
    counts = np.column_stack([np.bincount(inv[m], minlength=ns) for m in groups.values()]).astype(float)
    totals = np.stack([np.column_stack([np.bincount(inv[m], weights=(losses[a]-losses[b])[m], minlength=ns)
                                       for m in groups.values()]) for a, b in pairs], axis=1)
    means = np.divide(totals, counts[:, None, :], out=np.zeros_like(totals), where=counts[:, None, :] > 0)
    rng = np.random.default_rng(20260929)
    draws, macro_draws = [], []
    for start in range(0, reps, 40):
        weights = np.stack([np.bincount(rng.integers(ns, size=ns), minlength=ns)
                            for _ in range(min(40, reps-start))]).astype(float)
        num = (weights @ totals.reshape(ns, -1)).reshape(-1, len(pairs), len(groups))
        mac = (weights @ means.reshape(ns, -1)).reshape(num.shape)
        den, md = weights @ counts, weights @ (counts > 0)
        draws.append(np.divide(num, den[:, None, :], out=np.full_like(num, np.nan), where=den[:, None, :] > 0))
        macro_draws.append(np.divide(mac, md[:, None, :], out=np.full_like(mac, np.nan), where=md[:, None, :] > 0))
    draws, macro_draws = np.concatenate(draws), np.concatenate(macro_draws)

    def ci(v):
        good = v[np.isfinite(v)]
        return {"ci95": np.quantile(good, [.025, .975]).tolist() if len(good) else None,
                "valid_resamples": len(good)}

    result = {"bootstrap_reps": reps, "bootstrap_seed": 20260929,
              "intervals": "pointwise, student clustered; conditional on frozen checkpoint, not causal", "groups": {}}
    for j, (name, mask) in enumerate(groups.items()):
        entry = {"n": int(mask.sum()), "students": len(np.unique(u[mask])), "metrics": {}, "comparisons": {}}
        for mode, p in predictions.items():
            m = metric(y[mask], p[mask])
            c = counts[:, j]
            sums = np.bincount(inv[mask], weights=losses[mode][mask], minlength=ns)
            m["student_macro_nll"] = float((sums[c > 0]/c[c > 0]).mean()) if mask.any() else None
            m["observed_rate"] = float(y[mask].mean()) if mask.any() else None
            m["mean_probability"] = float(p[mask].mean()) if mask.any() else None
            entry["metrics"][mode] = m
        for i, pair in enumerate(pairs):
            a, b = [entry["metrics"][m] for m in pair]
            entry["comparisons"][names[i]] = {
                "delta_nll": a["nll"]-b["nll"] if mask.any() else None,
                "delta_student_macro_nll": a["student_macro_nll"]-b["student_macro_nll"] if mask.any() else None,
                "event_interval": ci(draws[:, i, j]), "macro_interval": ci(macro_draws[:, i, j])}
        result["groups"][name] = entry
    return result
