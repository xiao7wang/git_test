# A0 首次知识点读出探针：服务器运行指南

版本：uctp_initial_readout_probe_v1；日期：2026-10-04。

## 这次究竟跑什么

不是重新训练。使用原来的 unit_write 检查点，在 ASSIST、EDNet 上各跑 seed1、seed2，共 4 个完整验证诊断。每个检查点比较 original / concept / global 三种读出，模型参数全部冻结。

只在预测前目标 KC 历史为 0 时替换静态读出参照。其余验证预测复用已验收 CSV，完全不动。该快捷路径已用合成完整序列回放做等价检查；真实数据的首次原始读出还必须通过 native/reference ≤1e-6 的运行期检查。

原 clean、temporal、fix02 目录、训练结果和 checkpoint 均不修改。没有新 optimizer，没有训练 epoch，没有测试集评测，没有 checkpoint 格式转换。

## 1. 上传并解压

把本次提供的 `uctp_initial_readout_probe_v1.zip` 上传到服务器：

`/home/wangxiao/QCCDM/top_sci_repro/`

ZIP 在 VS Code 文本编辑器中显示“二进制文件不能显示”是正常的；不要点开当代码编辑。

在服务器终端复制以下整块命令。不要复制提示符 `(base) ...$`。

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
if [ -e /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1 ]; then
  printf '%s\n' '目录已经存在，请停止，不要覆盖。'
elif [ ! -f /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1.zip ]; then
  printf '%s\n' '没有找到 ZIP，请先上传到 top_sci_repro。'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e \
    /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1.zip \
    /home/wangxiao/QCCDM/top_sci_repro
fi
```

确认以下文件存在，再进入第 2 步：

```bash
ls -l /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/run_server.sh
```

## 2. 一条命令在 tmux 后台跑完

下面使用绝对路径 yydw Python，不需要在当前 `(base)` 终端额外激活环境。它固定 GPU 0；如果正在被其他任务占用，先协调 GPU，不并行重复启动本套件。

```bash
tmux new-session -d -s a0_probe 'bash /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/run_server.sh server_a0_01; exec bash'
```

看到 `duplicate session: a0_probe` 表示同名会话已经存在，不要连续重复执行，也不要直接杀掉已有会话。

查看该会话：

```bash
tmux attach-session -t a0_probe
```

离开会话且保持运行：先按 **Ctrl+B**，松开，再按 **D**。不要用 Ctrl+C 退出运行中的实验；终端复制一般使用 Ctrl+Shift+C。

命令末尾保留一个 bash，因此任务跑完后 tmux 会话仍可存在。**会话存在不等于仍在计算。** 以 suite_status、日志和进程为准。

### 自动执行顺序

1. 核对 4 个既有 checkpoint、训练元数据、数据文件、导出 CSV 和 clean 源码的固定哈希。
2. CPU 35 项合成单元/集成测试。
3. CUDA 35 项相同测试。
4. 4 个作业各抽取固定规则选择的 32 名有首次 KC 记录的学生做 preflight。
5. 同一批学生再用 batch-size=17 检查，与 batch-size=128 对齐比较；必须 ≤1e-6。
6. 全部检查通过后，依次完成 4 个完整验证探针。
7. 输出可下载的 `a0_results.zip`。

预检抽样只依赖身份与预测前历史，不看标签或模型分数。即使完整验证时首次预测没有改善，也会如实输出；不会因为结果不好反复换参数。

## 3. 怎么看进度和结果

任何服务器终端都可以执行：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/show_results.py \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/outputs/server_a0_01
```

成功时显示 `Suite: complete`，并给出下载路径：

```text
/home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/outputs/server_a0_01/a0_results.zip
```

下载这个 ZIP 发回即可，不需要上传 checkpoint、原始数据或 test_predictions。

完整验证预期：

| 数据集 | 每个 seed 的验证行数 | 首次 KC 行数 |
|---|---:|---:|
| ASSIST | 255916 | 27998 |
| EDNet | 209028 | 21201 |

结果含：首次 KC、全部验证、非首次、学生总历史 <50 / ≥50、排除同时间评分行、训练无支持回退组。非首次三种预测必须一致。主比较是 concept−original，同时必须看 concept−global，不能只挑更有利的一项。

### 显示 running 但不知道是否真的在跑

```bash
pgrep -a -u wangxiao -f 'uctp_initial_readout_probe_v1/(run_suite[.]py|run_probe[.]py|test_probe[.]py)'
```

再查看状态中 active_job 对应的 `.log`。例如：

```bash
tail -n 80 /home/wangxiao/QCCDM/top_sci_repro/uctp_initial_readout_probe_v1/outputs/server_a0_01/assist_unit_write_seed1_full.log
```

单个探针的日志可能主要在结束时输出；不因几十秒没有新行就断言卡死。套件会显示每个作业的开始和完成时间。

### 显示 failed

不是“还没跑完”。复制错误和失败作业日志发回，不要升级/降级 pandas 或 torch，不要修改容差、accepted_inputs.json 或源码绕过检查。

既有输出目录不支持覆盖。确实需要修复后重跑时，保留旧目录，改成新输出名，例如 `server_a0_02`；先确认没有旧进程在跑。不要单纯看到失败就立即重复整套命令。

## 4. 需要哪些现有服务器文件

不需要再下载数据，使用此前已经确认存在的：

- 项目：`/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research`
- 数据：该项目下 `data/assist_full`、`data/ednet_full`。
- ASSIST checkpoint：`outputs/server_assist_baselines_e20_p5_v1_rerun01/unit_write_seed1` 和 `unit_write_seed2`。
- EDNet checkpoint：`outputs/server_ednet_baselines_e20_p5_v1/unit_write_seed1` 和 `unit_write_seed2`。
- 验证导出根目录：`outputs/server_seed12_valid_export_20260929_01`，保留 `export_plan.json`、`completed.json` 及四个 unit 作业的 `attempt_001/`。
- 每个训练 run 要保留 `best_model.pt`、`run_config.json`、`status.json`、`history.json`。

默认严格使用这些已经验收的输入身份。如文件确实移动过，先报告实际路径，不要用新文件替换原文件来凑哈希。不是要上传本地 full 数据覆盖服务器数据。

## 5. 大约要多久

这次不做多轮训练，也不逐条重放所有状态更新；主要工作是读取/校验输入、计算首次 KC 的读出和 bootstrap。工作量远小于此前一天多的训练矩阵。但本地没有完整服务器 checkpoint，也没有验证 RTX 5090 耗时，因此不承诺固定分钟数。

先看前两个 preflight 的实际耗时。套件会逐项显示秒数；如果遇到错误应立即处理，不要按“可能要跑一天”一直等待。

## 6. 如何解释结果

- concept 比 original 和 global 都稳定好：支持进一步研究知识点相关的初始信息共享，但尚不是新模型最终效果。
- concept 和 global 差不多：优先解释为整体收缩/读出校准，不能声称知识点特异机制成立。
- 只改善事件平均，学生宏平均不改善：保留人群加权差异，不宣布普遍受益。
- 两个探针都不好：停止 A0 探针扩展，不继续搜索大量替换公式；再讨论相同初始化下的写入对照。

任何结果都不直接证明真实学习效果、认知掌握真值或可发表的新颖性。row-immediate 反馈假设仍未核实；排除同时间评分行没有修复历史反馈顺序。
