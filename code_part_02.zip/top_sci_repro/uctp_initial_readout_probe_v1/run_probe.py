"""Validation-only A0 runner. Uses accepted clean checkpoints without conversion."""
import argparse
import os
from pathlib import Path
import platform
import sys
import time

sys.dont_write_bytecode = True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch
from probe_core import (require, sha, read_json, save, import_clean, make_context,
                        build_priors, validate_frame, select_rows, probe, summarize)

ROOT = Path(__file__).resolve().parent
DEFAULT_EXPORT = "/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/outputs/server_seed12_valid_export_20260929_01"


def check_package():
    manifest = read_json(ROOT / "PACKAGE_MANIFEST.json")
    for rel, expected in manifest["files"].items():
        require(sha(ROOT / rel) == expected, f"Probe package changed: {rel}")


def verify_metadata(project, export, job_name, policy):
    """No writes, no deserialization until all file identities have passed."""
    require(job_name in policy["jobs"], "Job not in accepted policy")
    job = policy["jobs"][job_name]
    require(job["variant"] == "unit_write" and job["seed"] in (1, 2), "Out of initial A0 scope")
    project, export = Path(project).resolve(), Path(export).resolve()
    expected_files = {export/"export_plan.json": policy["export_plan_sha256"],
                      export/"completed.json": policy["completed_sha256"],
                      Path(job["checkpoint"]): job["checkpoint_sha256"]}
    for rel, h in policy["source_pins"].items():
        expected_files[project/rel] = h
    run = Path(job["run"])
    for name, h in job["metadata_hashes"].items():
        expected_files[run/name] = h
    evaluation = (export/job["export"]["evaluation_dir"]).resolve()
    require(evaluation.is_relative_to(export), "Invalid evaluation path")
    for name, h in job["export"]["verification"]["files"].items():
        expected_files[evaluation/name] = h
    data = Path(job["data_dir"])
    ds = policy["data"][job["dataset"]]
    expected_files[data/"manifest.json"] = ds["fingerprint"]
    expected_files[data/"records.npz"] = ds["records_sha256"]
    expected_files[data/"vocabulary.json"] = ds["vocabulary_sha256"]
    for path, h in expected_files.items():
        require(path.is_file(), f"Missing input: {path}")
        require(sha(path) == h, f"Input changed: {path}")
    cfg, status, history = [read_json(run/(n+".json")) for n in ("run_config", "status", "history")]
    ev = read_json(evaluation/"evaluation.json")
    manifest = read_json(data/"manifest.json")
    best = max(history, key=lambda h: h["valid"]["auc"])
    require(status["status"] == "complete", "Training not complete")
    require(status["checkpoint_sha256"] == ev["checkpoint_sha256"] == job["checkpoint_sha256"], "Checkpoint metadata mismatch")
    require(best["epoch"] == ev["epoch"] == status["best_epoch"] == job["best_epoch"], "Best epoch mismatch")
    require(cfg["data_fingerprint"] == ev["data_fingerprint"] == job["data_fingerprint"], "Fingerprint mismatch")
    require(cfg["args"]["seed"] == job["seed"] and cfg["model_config"]["variant"] == "unit_write", "Training variant/seed")
    for key, value in policy["training_settings"][job["dataset"]].items():
        require(cfg["args"][key] == value, f"Training setting {key}")
    for key, value in {"view": "valid", "update_targets": 1, "ack_row_feedback": True,
                       "batch_size": 8, "chunk_size": 100}.items():
        require(ev["args"][key] == value, f"Reference evaluation setting {key}")
    for rel, h in policy["source_pins"].items():
        require(cfg["source_code"][rel] == h and ev["source_code"][rel] == h, f"Training/reference source {rel}")
    require(manifest["feedback_protocol"] == "row_immediate_assumption", "Unexpected feedback protocol")
    return job, cfg, manifest, evaluation, expected_files


def run_job(args, policy, output_base=None):
    output = Path(args.output_dir).resolve()
    base = (ROOT/"outputs") if output_base is None else Path(output_base).resolve()
    require(output != base and output.is_relative_to(base), "Output must be a NEW subdirectory of package outputs")
    require(not output.exists(), f"Refusing overwrite: {output}")
    require(args.ack_row_feedback, "Row-immediate assumption must be acknowledged")
    require(args.device in ("cpu", "cuda"), "Explicit CPU/CUDA required")
    require(args.batch_size > 0 and args.threads > 0 and args.max_students >= 0, "Invalid resource settings")
    if args.device == "cuda":
        require(torch.cuda.is_available(), "CUDA unavailable; use the yydw interpreter")
    torch.set_num_threads(args.threads)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    started = time.perf_counter()
    output.mkdir(parents=True, exist_ok=False)
    save(output/"status.json", {"status": "running", "job": args.job, "pid": os.getpid()})
    try:
        job, cfg, manifest, evaluation, expected_files = verify_metadata(args.project_dir, args.export_root, args.job, policy)
        Model, metric = import_clean(args.project_dir, policy["source_pins"])
        ckpt = torch.load(job["checkpoint"], map_location="cpu", weights_only=True)
        require(ckpt.get("model_family") is None, "Expected ORIGINAL clean checkpoint, not temporal or converted")
        require(ckpt["model_config"] == cfg["model_config"], "Checkpoint model config mismatch")
        require(ckpt["epoch"] == job["best_epoch"] and ckpt["data_fingerprint"] == job["data_fingerprint"], "Checkpoint provenance")
        for rel, h in policy["source_pins"].items():
            require(ckpt["source_code"][rel] == h, f"Checkpoint source {rel}")
        model = Model(**ckpt["model_config"])
        model.load_state_dict(ckpt["model_state"], strict=True)
        del ckpt
        model.eval().requires_grad_(False)
        device = torch.device(args.device)
        # Deliberately do not access records.npz/label.npy or response_time.npy.
        needed = ("student_idx", "item_idx", "timestamp", "split", "item_q",
                  "kc_count_before", "student_count_before")
        with np.load(Path(job["data_dir"])/"records.npz", allow_pickle=False) as archive:
            arrays = {k: archive[k] for k in needed}
        context = make_context(arrays, cfg["model_config"]["num_students"])
        require(context["q"].shape == (cfg["model_config"]["num_items"], cfg["model_config"]["num_knowledges"]), "Q/model dimensions")
        priors = build_priors(model.student_mastery_logit.weight.detach().numpy(), context["pairs"])
        frame = pd.read_csv(evaluation/"predictions.csv").sort_values("record_idx").reset_index(drop=True)
        validate_frame(frame, context)
        require(len(frame) == job["n"], "Validation row count")
        # Freeze evaluation identity independently of the probe's outcome.
        reference_metrics = metric(frame.label.to_numpy(), frame.probability.to_numpy().astype(np.float32).astype(float))
        for key in ("auc", "nll", "brier"):
            require(abs(reference_metrics[key]-job["expected_validation"][key]) <= 1e-12, f"Accepted reference metric {key}")
        rows = select_rows(context, args.max_students)
        save(output/"run_config.json", {"job": job, "args": vars(args), "scope": "validation-only first-KC readout, no fitting",
            "policy_sha256": sha(ROOT/"accepted_inputs.json"), "model_family": "original clean (no conversion)",
            "feedback_boundaries_verified": manifest["feedback_boundaries_verified"],
            "training_support": "unique observed train student-KC pairs; no label-dependent weighting",
            "global_weighting": "equal weight per supported student-KC pair, not per response or per KC",
            "concept_weighting": "equal weight per train-supported student within that KC",
            "fallback": "unseen-in-training KC uses global mean; abort if no training support anywhere",
            "loaded_npz_fields": list(needed), "test_labels_loaded": False,
            "structural_test_rows": "IDs/split/timestamp may be decompressed; excluded before support/count use",
            "inference": "cold readout only; noncold predictions reused unchanged from accepted reference; no observe call",
            "python": platform.python_version(), "torch": str(torch.__version__), "numpy": np.__version__, "pandas": pd.__version__})
        model.to(device)
        predictions, gate = probe(model, frame, context, priors, rows, args.batch_size, device)
        save(output/"reference_gate.json", gate)
        require(gate["success"], "Cold native/reference gate failed; do not change tolerances or accept output")
        summary = summarize(predictions, metric, reps=2000)
        for path, h in expected_files.items():
            require(sha(path) == h, f"Input changed during probe: {path}")
        predictions.to_csv(output/"predictions.csv.gz", index=False, float_format="%.17g", compression="gzip")
        save(output/"priors.json", {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in priors.items()})
        save(output/"summary.json", summary)
        save(output/"input_hashes.json", {str(k): v for k, v in expected_files.items()})
        result = {"status": "complete", "job": args.job, "seconds": time.perf_counter()-started,
                  "n": len(predictions), "first_kc_n": int((predictions.kc_count_before == 0).sum()),
                  "trained": False, "test_evaluated": False, "parameters_changed": False,
                  "source_inputs_unchanged": True, "native_reference_gate": gate}
        save(output/"status.json", result)
        print(result, flush=True)
        return result
    except BaseException as exc:
        save(output/"status.json", {"status": "failed", "job": args.job, "error": repr(exc),
                                   "seconds": time.perf_counter()-started})
        raise


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True, help="ORIGINAL uctp_cd_clean_research, not temporal")
    p.add_argument("--export-root", default=DEFAULT_EXPORT)
    p.add_argument("--job", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--max-students", type=int, default=0, help="0=all; preflight selects eligible students with fixed seed")
    p.add_argument("--ack-row-feedback", action="store_true")
    return p


if __name__ == "__main__":
    check_package()
    run_job(parser().parse_args(), read_json(ROOT/"accepted_inputs.json"))
