"""Display saved A0 status. Running status alone is not proof of a live process."""
import argparse
from pathlib import Path
from probe_core import read_json


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-root", required=True)
    a = p.parse_args()
    root = Path(a.output_root)
    if not (root/"suite_status.json").is_file():
        raise SystemExit(f"No suite status at {root}. Check upload/extraction and launch command; do not assume it is running.")
    status = read_json(root/"suite_status.json")
    print(f"Suite: {status['status']}; active_job={status.get('active_job')}; pid={status.get('pid')}")
    print("A saved running status is not proof of a live process.")
    for job in status["jobs"]:
        print(f"{job['name']:<45} code={job['returncode']} seconds={job['seconds']:.1f}")
    if status.get("error"): print("ERROR:",status["error"])
    for path in sorted(root.glob("*_full/summary.json")):
        print("\n"+path.parent.name)
        summary = read_json(path)
        gate = read_json(path.parent/"reference_gate.json")
        print("Native/reference gate:",gate)
        for group in ("first_kc","all","nonfirst_kc"):
            entry = summary["groups"][group]
            print(f"{group}: n={entry['n']}, students={entry['students']}")
            for mode, m in entry["metrics"].items():
                if m["n"]:
                    auc = "NA" if m["auc"] is None else f"{m['auc']:.6f}"
                    print(f"  {mode:<9} AUC={auc} NLL={m['nll']:.6f} macroNLL={m['student_macro_nll']:.6f}")
            if group == "first_kc":
                for pair, c in entry["comparisons"].items():
                    print(f"  {pair}: deltaNLL={c['delta_nll']:.6f} CI={c['event_interval']['ci95']}")
    archive = root/"a0_results.zip"
    if status["status"] == "complete" and archive.is_file():
        print("\nDownload:",archive)
    elif status["status"] == "failed":
        print("\nFAILED: read failed log; do not wait or restart blindly. No accepted results archive.")


if __name__ == "__main__": main()
