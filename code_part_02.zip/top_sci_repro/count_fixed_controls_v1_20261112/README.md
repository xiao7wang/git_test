# Fixed-discount controls: development-only exploratory experiment

This package reuses the previously saved predictions for undiscounted A,
fixed 0.8 B, elapsed-time half-life 168 h C, and DKVMN with student/item biases.
It trains three additional fixed discounts (0.9, 0.99, 0.999), each with seeds
0, 1, 2 and the same count-model implementation, optimizer settings, batch
size, development-NLL early stopping, and feature construction as before.
Each new job checks initialization and epoch shuffle hashes against B at its
own seed for all shared epochs. The earlier predictions are loaded from locked
ZIPs, not retrained. Their row identities, labels, same-KC history counts,
gap metadata, archive digests, and member digests must match.

The three primary contrasts are C minus each additional control, measured as
paired development event NLL averaged across seeds; negative favors C. The
report also contains per-seed values, student-macro NLL, Brier, AUC, gap and
development-activity subgroups, and student-cluster percentile intervals.
Each interval conditions on fitted, selected models and does not incorporate
training, hyperparameter selection, or model-selection uncertainty. The
three seeds reuse the same data and are not independent data replications.
DKVMN uses a different architecture, features, and training procedure, so its
comparisons do not isolate the role of decay. Fixed discounts are applied on
every repeated KC event, including a zero-time gap, while time decay uses no
decay at zero gap. The feedback protocol predicts before each row's response
is incorporated; real platform feedback timing has not been verified. Event
timestamps are proxies rather than observed feedback times.

The development set has been reused and these strengths were chosen after
inspecting previous development results. All three are reported; the
comparisons and intervals are unadjusted for multiple exploration. Findings
are exploratory, not causal or claims of state-of-the-art performance. Test
and holdout are not scored here. The data loader reads the prepared archive as
a whole, including test labels, but the feature construction excludes them.
The holdout has previously been used elsewhere and is not an untouched set.

## Reference-hash transcription correction

The initial frozen protocol contains a 63-character transcription of the
previous result SHA-256 (one `a` was omitted). The actual reference archive
and the earlier independent JSON review both give the 64-character digest
`eab986459c2bea65cd016393da9c85127e2ce7086243e93242eb9b9420509733`.
The server verifies this full corrected digest, records both values and the
correction in output metadata, and verifies every archive member. It never
accepts a different previous result based on the malformed value.

## Running

Use `bash run_server.sh server_countfixed_01` on the original server, with the
prepared data and environment at the pinned paths. The script creates a new
log before verification, verifies package hashes and frozen source files,
runs synthetic preflight, and then performs the formal GPU experiment. It
refuses to overwrite either an existing output directory or launch log. No
automatic retry or CPU fallback occurs. Output status and launch log remain
on failure. A `complete` status by itself does not guarantee the ZIP is ready;
wait for `SUCCESS` and check ZIP integrity.

The final ZIP includes all nine new development prediction files, selected
training histories, summary statistics, event metadata, and an internal hash
manifest. Model weights stay on the server and are not included. The original
reference ZIPs are included in the code package, never in the result ZIP.
