#!/usr/bin/env bash
set -euo pipefail

task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
task_name="${1:-server_laggap_01}"
if [[ ! "$task_name" =~ ^[A-Za-z0-9_-]+$ ]]; then
  printf 'Invalid run name: %s\n' "$task_name" >&2
  exit 2
fi
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_project=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
task_data=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
task_old=/home/wangxiao/QCCDM/top_sci_repro/dkvmn_count_time_overnight_fix01_20261113/outputs/server_overnight_fix01
task_output="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
mkdir -p "$task_root/outputs"
if [[ -e "$task_output" || -e "$task_log" ]]; then
  printf 'Run output or launch log already exists; refusing to overwrite: %s\n' "$task_name" >&2
  exit 2
fi
( set -o noclobber; : > "$task_log" ) || { echo 'Cannot create a new launch log' >&2; exit 2; }
exec > >(tee -a "$task_log") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$task_root/src${PYTHONPATH:+:$PYTHONPATH}"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "$task_root"
printf 'Starting %s at %s\n' "$task_name" "$(date --iso-8601=seconds)"
echo 'Stage 1/4: verify release, frozen protocol and prior source'
"$task_python" -B -m lagprobe.server --verify-only
"$task_python" -B checks/guard.py
"$task_python" -B -c 'import shutil,sys; free=shutil.disk_usage(sys.argv[1]).free; required=1073741824; print("Free bytes:", free, "Required:", required, flush=True); sys.exit(free < required)' "$task_root/outputs"
for task_required in "$task_data/manifest.json" "$task_project/src/data.py" \
  "$task_old/overnight_results.zip" "$task_old/jobs/time_168h_seed1/best_model.pt" \
  "$task_old/jobs/time_168h_seed2/best_model.pt"; do
  if [[ ! -f "$task_required" ]]; then
    printf 'Required prior file is missing: %s\n' "$task_required" >&2
    exit 1
  fi
done
echo 'Stage 2/4: synthetic CPU contract tests (not real data)'
"$task_python" -B checks/verify.py --strict
echo 'Stage 3/4: synthetic CUDA full pipeline (not real data)'
"$task_python" -B checks/gpu_preflight.py
echo 'Stage 4/4: real-data replay then two matched lag-gap retraining jobs'
"$task_python" -B -m lagprobe.server \
  --project-dir "$task_project" --data-dir "$task_data" \
  --old-output-dir "$task_old" --output-dir "$task_output" \
  --ack-row-feedback --ack-time-proxy
printf 'SUCCESS: %s/lag_gap_results.zip\n' "$task_output"
