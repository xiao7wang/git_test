"""Synthetic CUDA exercise before accessing real training data."""
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "contract_tests"))

import torch
from fixture import exercise_full_run

if __name__ == "__main__":
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable: synthetic GPU preflight cannot run")
    with tempfile.TemporaryDirectory(prefix="lag_gap_gpu_") as temp:
        exercise_full_run(Path(temp), device="cuda")
    print("CUDA synthetic replay, lag training, checkpoints and snapshots: PASS", flush=True)
