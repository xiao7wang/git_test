"""Ensure the vendored previous scientific implementation remains unchanged."""
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    expected = json.loads((ROOT / "contracts/vendor_hashes.json").read_text(encoding="utf-8"))
    actual_names = set()
    for folder in ("src/count_time", "src/fixed_controls", "src/dkvmn_ref", "src/overnight", "vendor"):
        actual_names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob("*")
                            if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    if actual_names != set(expected):
        raise ValueError("vendored file inventory changed")
    for name, digest in expected.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"vendored file changed: {name}")
    print(f"Protected previous implementation: {len(expected)} files verified")
    return 0

if __name__ == "__main__":
    sys.exit(main())
