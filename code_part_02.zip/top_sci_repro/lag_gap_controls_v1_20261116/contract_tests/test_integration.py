import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from fixture import exercise_full_run


class IntegrationTests(unittest.TestCase):
    def test_synthetic_cpu_provenance_replay_training_and_archives(self):
        with tempfile.TemporaryDirectory(prefix="lag_gap_cpu_") as temp:
            output = exercise_full_run(Path(temp), device="cpu")
            with zipfile.ZipFile(output / "lag_gap_results.zip") as bundle:
                self.assertIsNone(bundle.testzip())
                self.assertFalse(any(name.endswith(".pt") for name in bundle.namelist()))
                self.assertIn("analysis_replay.json", bundle.namelist())
                self.assertIn("analysis_retrained.json", bundle.namelist())
                results = json.loads(bundle.read("analysis_retrained.json"))
                self.assertEqual(results["primary"]["n"], 24)

