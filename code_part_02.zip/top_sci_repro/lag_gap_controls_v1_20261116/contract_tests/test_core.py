import math
import unittest

import numpy as np

from count_time.features import construct
from lagprobe.features import lag_states
from lagprobe.analysis import analyze
from helpers import sample_arrays


def toy():
    return {"student_idx": np.array([0, 0, 0]), "item_idx": np.array([0, 0, 0]),
            "label": np.array([1., 0., 1.]), "split": np.array([0, 0, 1]),
            "timestamp": np.array([0., 24.*3600., 8.*24.*3600.]),
            "item_q": np.ones((1, 1), dtype=np.int8)}


class FeatureTests(unittest.TestCase):
    def test_gap_lag_and_warmup_exact_example(self):
        real = construct(toy(), {0})
        lag = lag_states(real)
        self.assertTrue(np.isnan(lag["gap_hours"][0]))
        np.testing.assert_array_equal(lag["gap_hours"][1:], [24., 24.])
        np.testing.assert_allclose(lag["success"], [0., 2**(-24/168), 2**(-48/168)], atol=1e-12, rtol=0)
        np.testing.assert_allclose(lag["failure"], [0., 0., 2**(-24/168)], atol=1e-12, rtol=0)
        np.testing.assert_allclose(lag["success"][:2], real["states"]["C_real_time"][0][:2], atol=1e-12)
        np.testing.assert_allclose(lag["failure"][:2], real["states"]["C_real_time"][1][:2], atol=1e-12)

    def test_no_current_or_future_response_or_future_timestamp(self):
        source = toy()
        baseline = lag_states(construct(source, {0}))
        for index in range(3):
            changed = {k: v.copy() for k, v in source.items()}
            changed["label"][index] = 1 - changed["label"][index]
            result = lag_states(construct(changed, {0}))
            np.testing.assert_array_equal(result["success"][:index+1], baseline["success"][:index+1])
            np.testing.assert_array_equal(result["failure"][:index+1], baseline["failure"][:index+1])
        changed = {k: v.copy() for k, v in source.items()}
        changed["timestamp"][2] += 9999.
        result = lag_states(construct(changed, {0}))
        np.testing.assert_array_equal(result["success"][:3], baseline["success"][:3])
        np.testing.assert_array_equal(result["failure"][:3], baseline["failure"][:3])

    def test_selected_rows_groups_and_bad_gaps(self):
        raw = sample_arrays()
        real = construct(raw, {0, 1, 2})
        lag = lag_states(real)
        self.assertEqual(len(lag["success"]), len(real["record_idx"]))
        self.assertFalse(np.any(raw["split"][real["record_idx"]] == 2))
        np.testing.assert_array_equal(lag["success"][real["prior_kc_count"] == 0], 0.)
        np.testing.assert_array_equal(lag["failure"][real["prior_kc_count"] == 0], 0.)
        changed = dict(real)
        changed["gap_hours"] = real["gap_hours"].copy()
        changed["gap_hours"][np.flatnonzero(real["prior_kc_count"] > 0)[0]] = -1
        with self.assertRaises(ValueError):
            lag_states(changed)
        changed["gap_hours"][np.flatnonzero(real["prior_kc_count"] > 0)[0]] = float("nan")
        with self.assertRaises(ValueError):
            lag_states(changed)

    def test_zero_gaps_remain_separate_per_student_and_kc(self):
        a = {"student_idx": np.array([0,0,0,0,1,1,1]),
             "item_idx": np.array([0,1,0,1,0,0,0]),
             "label": np.array([1,0,0,1,0,1,1]),
             "split": np.array([0,0,0,1,0,0,1]),
             "timestamp": np.array([0,0,0,0,0,0,0]), "item_q": np.eye(2, dtype=np.int8)}
        f = construct(a, {0,1}); lag = lag_states(f)
        self.assertEqual(lag["success"][2], 1.)
        self.assertEqual(lag["failure"][3], 1.)
        self.assertEqual(lag["success"][6], 1.)
        self.assertEqual(lag["failure"][6], 1.)
        self.assertEqual(lag["gap_hours"][6], 0.)


class AnalysisTests(unittest.TestCase):
    def test_paired_primary_metrics_and_interval(self):
        events = {"label": np.array([1,1,0,0,1]), "student_idx": np.array([0,0,0,1,2]),
                  "prior_kc_count": np.array([2,2,2,2,1]),
                  "same_kc_gap_hours": np.array([1., 0., 300., 48., 1.])}
        real = np.array([.8,.8,.2,.2,.5]); lag = np.array([.4,.4,.6,.6,.5])
        predictions = {"real": {1: real, 2: real}, "lag": {1: lag, 2: lag}}
        a = analyze(events, predictions, {"real_minus_lag": ("real", "lag")}, repetitions=40, seed=7)
        primary = a["primary"]
        self.assertEqual(primary["n"], 4)
        self.assertEqual(primary["students"], 2)
        delta = primary["paired"]["real_minus_lag"]
        self.assertLess(delta["event_delta"], 0.)
        self.assertAlmostEqual(delta["event_delta"], -math.log(2), places=10)
        self.assertEqual(len(delta["event_ci95"]), 2)
        self.assertEqual(a["overall"]["n"], 5)

