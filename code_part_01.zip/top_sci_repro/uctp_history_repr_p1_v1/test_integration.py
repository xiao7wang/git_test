"""Synthetic end-to-end: identity checks, training, no holdout, refusal to overwrite."""
import hashlib, json, os, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import sha, write
from count_core import dev_users

ROOT=Path(__file__).resolve().parent; PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='p1_repr_') as temp:
  root=Path(temp); pkg=root/'pkg'; pkg.mkdir(); p0=root/'p0';p0.mkdir();count=root/'count';count.mkdir()
  for n in ('run_experiment.py','representation.py','count_core.py','cross_core.py','review_stats.py','package_results.py','show_results.py'): shutil.copy2(ROOT/n,pkg/n)
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  a=fixture.data.arrays; dv=dev_users(a['student_idx'][a['split']==1]);ids=np.flatnonzero((a['split']==1)&np.isin(a['student_idx'],list(dv)))
  pd.DataFrame({'record_idx':ids,'student_idx':a['student_idx'][ids],'label':a['label'][ids],'probability':np.full(len(ids),.5)}).to_csv(count/'dev_predictions.csv.gz',index=False,compression='gzip')
  write(count/'config.json',{'data_fingerprint':fixture.data.fingerprint,'code_sha256':{'count_core.py':sha(pkg/'count_core.py')}})
  write(p0/'status.json',{'status':'complete'});write(p0/'count_audit.json',{'passed':True})
  write(pkg/'locked_p0.json',{'p0_files':{n:sha(p0/n) for n in ('status.json','count_audit.json')},'count_files':{n:sha(count/n) for n in ('config.json','dev_predictions.csv.gz')}})
  cmd=[sys.executable,'-B',str(pkg/'run_experiment.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--count-dir',str(count),'--p0-dir',str(p0),'--output-dir',str(root/'out'),'--device','cpu','--epochs','3','--patience','2','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  result=json.loads((root/'out/summary.json').read_text())
  assert set(result['rows'])=={'R0','R1','R2','existing_count_seed0'} and not result['test_evaluated'] and not result['holdout_evaluated']
  for mode,row in result['rows'].items():
   if mode=='existing_count_seed0': continue
   h=json.loads((root/'out'/f'{mode}_history.json').read_text());assert row['dev']['nll']==min(x['dev']['nll'] for x in h)
  pred=pd.read_csv(root/'out/dev_predictions.csv.gz');assert np.array_equal(pred.record_idx.to_numpy(),ids)
  package=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  assert package.returncode==0,package.stdout
  with zipfile.ZipFile(root/'out/p1_results.zip') as z:
   m=json.loads(z.read('manifest.json'));assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==d for n,d in m.items())
  show=subprocess.run([sys.executable,str(pkg/'show_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  assert show.returncode==0,show.stdout
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  with (p0/'status.json').open('a') as f:f.write(' ')
  bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((root/'bad/status.json').read_text())['status']=='failed'
  print('PASS synthetic training, best epoch, dev identity, no holdout, overwrite and provenance guards')
finally:fixture.tearDown()
