#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_p1_01}"
if [[ ! "$NAME" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid name' >&2; exit 2; fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
COUNT=/home/wangxiao/QCCDM/top_sci_repro/uctp_count_baseline_v1/outputs/server_count_01
P0=/home/wangxiao/QCCDM/top_sci_repro/uctp_count_p0_audit_v1/outputs/server_p0_01
OUT="$DIR/outputs/$NAME"; LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]]; then echo 'Existing output preserved' >&2; exit 2; fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$DIR/verify_package.py"
"$PY" -B "$DIR/test_representation.py"
"$PY" -B -u "$DIR/run_experiment.py" --project-dir "$PROJECT" --data-dir "$DATA" --count-dir "$COUNT" --p0-dir "$P0" --output-dir "$OUT" --device cuda --epochs 20 --patience 5 --ack-row-feedback
"$PY" -B "$DIR/package_results.py" --output-dir "$OUT"
