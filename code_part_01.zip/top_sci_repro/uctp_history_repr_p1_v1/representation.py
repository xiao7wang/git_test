"""Controlled nested logistic representations of prior correct/incorrect counts."""
import torch
from torch import nn

class RepresentationModel(nn.Module):
    def __init__(self, students, items, kcs, mode):
        super().__init__()
        if mode not in ('R0','R1','R2'): raise ValueError('unknown mode')
        self.mode = mode
        self.student = nn.Embedding(students, 1)
        self.item = nn.Embedding(items, 1)
        self.kc_bias = nn.Embedding(kcs, 1)
        if mode != 'R0': self.weight = nn.Embedding(kcs, 1 if mode == 'R1' else 2)
        for p in self.parameters(): nn.init.zeros_(p)

    def forward(self, student, item, kc, success, failure):
        z = self.student(student).squeeze(-1) + self.item(item).squeeze(-1) + self.kc_bias(kc).squeeze(-1)
        pos, neg = torch.log1p(success), torch.log1p(failure)
        if self.mode == 'R1': z = z + self.weight(kc).squeeze(-1) * (pos-neg)
        if self.mode == 'R2':
            w = self.weight(kc)
            z = z + w[:,0]*pos + w[:,1]*neg
        return z
