"""One-seed exploratory R0/R1/R2; training and development only."""
import argparse, json, os, platform, time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users, prior_count_features, SALT
from representation import RepresentationModel
from cross_core import import_project, read, sha, write
from review_stats import metrics, losses, cluster_intervals

ROOT=Path(__file__).resolve().parent

def run(a):
    if not a.ack_row_feedback: raise ValueError('Row-immediate feedback acknowledgement required')
    if a.device=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable')
    if min(a.epochs,a.patience)<1: raise ValueError('Invalid epoch or patience')
    output=Path(a.output_dir).resolve(); output.mkdir(parents=True, exist_ok=False)
    begin=time.monotonic(); status={'status':'running','phase':'verify','test_evaluated':False,'holdout_evaluated':False}
    write(output/'status.json',status)
    try:
        lock=read(ROOT/'locked_p0.json'); p0=Path(a.p0_dir); count=Path(a.count_dir)
        for name,digest in lock['p0_files'].items():
            if sha(p0/name)!=digest: raise ValueError('P0 file mismatch: '+name)
        for name,digest in lock['count_files'].items():
            if sha(count/name)!=digest: raise ValueError('Count source mismatch: '+name)
        if read(p0/'status.json')['status']!='complete' or not read(p0/'count_audit.json')['passed']:
            raise ValueError('P0 audit is not complete and passed')
        cfg0=read(count/'config.json'); spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
        Data,_,_=import_project(a.project_dir,spec['source'])
        if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or cfg0['data_fingerprint']!=spec['data_fingerprint']:
            raise ValueError('Data fingerprint differs')
        if sha(ROOT/'count_core.py')!=cfg0['code_sha256']['count_core.py']: raise ValueError('Count feature source differs')
        data=Data(a.data_dir); dev=dev_users(data.arrays['student_idx'][data.arrays['split']==1])
        status['phase']='features'; write(output/'status.json',status); print('Building audited prior counts',flush=True)
        f=prior_count_features(data.arrays,dev); tr_idx=np.flatnonzero(f['split']==0); va_idx=np.flatnonzero(f['split']==1)
        if not len(tr_idx) or not len(va_idx): raise ValueError('Empty partition')
        ref=pd.read_csv(count/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
        for left,right in [('record_idx','record_idx'),('student_idx','student'),('label','label')]:
            if not np.array_equal(ref[left].to_numpy(),f[right][va_idx]): raise ValueError('Reference event identity mismatch: '+left)
        device=torch.device(a.device); torch.set_num_threads(4); torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark=False; torch.backends.cudnn.deterministic=True
        tensor={k:torch.as_tensor(f[k],dtype=torch.long if k in ('student','item','kc') else torch.float32,device=device)
                for k in ('student','item','kc','success','failure','label')}
        tr=torch.as_tensor(tr_idx,dtype=torch.long,device=device); va=torch.as_tensor(va_idx,dtype=torch.long,device=device)
        dims=data.manifest['summary']; probs={}; rows={}; start_train=time.monotonic()
        config={'protocol':'exploratory development only; no test or holdout','data_fingerprint':data.fingerprint,'partition_salt':SALT,
          'feedback':'row immediate assumption','feature':'same student/KC prior counts log1p; predict before update',
          'R0':'student + item + KC bias','R1':'R0 + KC coefficient*(log1p(success)-log1p(failure))',
          'R2':'R0 + separate unconstrained KC coefficients for log1p(success) and log1p(failure)',
          'constraint':'R1/R2 signs unconstrained; R2 has one extra coefficient per KC; absolute scale and capacity remain entangled',
          'seed':0,'epochs_max':a.epochs,'patience':a.patience,'optimizer':'AdamW','lr':.01,'weight_decay':1e-5,
          'batch_size':8192,'gradient_clip':5,'selection':'development event NLL', 'device':a.device,
          'torch':str(torch.__version__),'python':platform.python_version(),'train_rows':len(tr),'development_rows':len(va),
          'development_students':len(dev),'source_p0_files':lock['p0_files'],'count_files':lock['count_files'],
          'code_sha256':{n:sha(ROOT/n) for n in ('run_experiment.py','representation.py','count_core.py','cross_core.py','review_stats.py')},
          'test_evaluated':False,'holdout_evaluated':False}
        write(output/'config.json',config)
        for mode in ('R0','R1','R2'):
            status.update(phase='training',model=mode,epoch=0); write(output/'status.json',status)
            torch.manual_seed(0)
            if device.type=='cuda': torch.cuda.manual_seed_all(0)
            model=RepresentationModel(dims['students'],dims['items'],dims['knowledges'],mode).to(device)
            opt=torch.optim.AdamW(model.parameters(),lr=.01,weight_decay=1e-5)
            # Model initialization consumes a mode-dependent RNG count, so use
            # a separate identically seeded generator for training row order.
            order_rng=torch.Generator(device=device).manual_seed(0)
            best=float('inf'); stale=0; history=[]; model_start=time.monotonic()
            def logits(ix): return model(*(tensor[k][ix] for k in ('student','item','kc','success','failure')))
            for epoch in range(1,a.epochs+1):
                t=time.monotonic(); status.update(epoch=epoch); write(output/'status.json',status)
                model.train(); perm=tr[torch.randperm(len(tr),device=device,generator=order_rng)]; total=0.0
                for j in range(0,len(tr),8192):
                    ix=perm[j:j+8192]; opt.zero_grad(set_to_none=True)
                    loss=F.binary_cross_entropy_with_logits(logits(ix),tensor['label'][ix])
                    if not bool(torch.isfinite(loss)): raise FloatingPointError('Nonfinite loss')
                    loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True); opt.step()
                    total+=float(loss.detach())*len(ix)
                model.eval()
                with torch.no_grad(): prob=torch.sigmoid(logits(va)).cpu().numpy()
                met=metrics(f['label'][va_idx],prob); nll=float(met['nll'])
                history.append({'epoch':epoch,'train_bce':total/len(tr),'dev':met,'seconds':time.monotonic()-t})
                write(output/(mode+'_history.json'),history)
                print(json.dumps({'mode':mode,'epoch':epoch,'dev_nll':nll,'seconds':history[-1]['seconds']}),flush=True)
                if nll<best:
                    best=nll; stale=0
                    tmp=output/(mode+'.pending.pt'); torch.save({'model_state':model.state_dict(),'epoch':epoch,'dev_nll':nll,'mode':mode,'data_fingerprint':data.fingerprint},tmp); tmp.replace(output/(mode+'.pt'))
                else: stale+=1
                if stale>=a.patience: break
            ckpt=torch.load(output/(mode+'.pt'),map_location=device,weights_only=True); model.load_state_dict(ckpt['model_state']); model.eval()
            with torch.no_grad(): prob=torch.sigmoid(logits(va)).cpu().numpy()
            met=metrics(f['label'][va_idx],prob)
            if abs(met['nll']-best)>1e-7: raise AssertionError('Best model mismatch')
            probs[mode]=prob; rows[mode]={'dev':met,'best_epoch':ckpt['epoch'],'epochs':len(history),'seconds':time.monotonic()-model_start,'parameters':sum(p.numel() for p in model.parameters()),'checkpoint_sha256':sha(output/(mode+'.pt'))}
        status.update(phase='paired_analysis',model=None); write(output/'status.json',status)
        y=f['label'][va_idx]; ids=f['student'][va_idx]
        probs['existing_count_seed0']=ref['probability'].to_numpy(dtype=np.float32)
        rows['existing_count_seed0']={'dev':metrics(y,probs['existing_count_seed0']),'best_epoch':None,'epochs':None,'seconds':None,'parameters':None,'checkpoint_sha256':None}
        ls={k:losses(y,v)[:,0] for k,v in probs.items()}
        names=('R1_minus_R0','R2_minus_R1','R2_minus_R0','R2_minus_existing_count_seed0')
        cols=np.stack([ls['R1']-ls['R0'],ls['R2']-ls['R1'],ls['R2']-ls['R0'],ls['R2']-ls['existing_count_seed0']],axis=1)
        paired=cluster_intervals(ids,cols,1000,20261109)
        for name in rows:
            _,inverse,count_per=np.unique(ids,return_inverse=True,return_counts=True)
            rows[name]['student_macro_nll']=float(np.mean(np.bincount(inverse,weights=ls[name])/count_per))
        pd.DataFrame({'record_idx':f['record_idx'][va_idx],'student_idx':ids,'label':y,**probs}).to_csv(output/'dev_predictions.csv.gz',index=False,compression='gzip')
        summary={'status':'complete','rows':rows,'paired':dict(zip(names,paired['comparisons'])),
          'scope':'exploratory development set, seed 0; R2 has higher capacity, no test or holdout',
          'confidence_interval':'student-cluster bootstrap, conditional on fixed trained models; no training or selection uncertainty',
          'test_evaluated':False,'holdout_evaluated':False,'training_seconds':time.monotonic()-start_train,'seconds':time.monotonic()-begin}
        write(output/'summary.json',summary); status.update(status='complete',phase=None,seconds=time.monotonic()-begin);write(output/'status.json',status)
        print('EXPERIMENT COMPLETE',flush=True)
    except BaseException as e:
        status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin); write(output/'status.json',status); raise

def main():
    p=argparse.ArgumentParser()
    for key in ('project-dir','data-dir','count-dir','p0-dir','output-dir'): p.add_argument('--'+key,required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true')
    run(p.parse_args())
if __name__=='__main__':main()
