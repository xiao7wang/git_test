import unittest
import torch
from representation import RepresentationModel

class Tests(unittest.TestCase):
    def test_nested_models_and_zero_history(self):
        s=torch.tensor([0,1,0]); i=torch.tensor([1,0,1]); k=torch.tensor([0,1,0])
        p=torch.tensor([0.,3.,9.]); n=torch.tensor([0.,4.,1.])
        r0=RepresentationModel(2,2,2,'R0'); r1=RepresentationModel(2,2,2,'R1'); r2=RepresentationModel(2,2,2,'R2')
        with torch.no_grad():
            r1.weight.weight[:]=torch.tensor([[.7],[-.2]])
            r2.weight.weight[:,0]=r1.weight.weight[:,0];r2.weight.weight[:,1]=-r1.weight.weight[:,0]
        self.assertTrue(torch.allclose(r1(s,i,k,p,n),r2(s,i,k,p,n)))
        self.assertEqual(r0(s,i,k,p,n)[0].item(),r1(s,i,k,p,n)[0].item())
        self.assertEqual(r1(s,i,k,p,n)[0].item(),r2(s,i,k,p,n)[0].item())
        self.assertEqual(sum(x.numel() for x in r2.parameters())-sum(x.numel() for x in r1.parameters()),2)
    def test_failure_effect_not_forced_positive(self):
        model=RepresentationModel(1,1,1,'R2')
        with torch.no_grad(): model.weight.weight[0]=torch.tensor([.5,-.7])
        ids=torch.tensor([0]);z=torch.tensor([0.]);one=torch.tensor([1.])
        self.assertGreater(model(ids,ids,ids,one,z).item(),0)
        self.assertLess(model(ids,ids,ids,z,one).item(),0)

if __name__=='__main__':unittest.main()
