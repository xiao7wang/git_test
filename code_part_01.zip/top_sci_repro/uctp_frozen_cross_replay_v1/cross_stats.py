"""All four cells, all seeds. No fitting or model selection from these statistics."""
import numpy as np
from review_stats import losses, metrics, groups, cluster_intervals
from cross_core import BRANCHES

# Order NN, NS, SN, SS. N = no time decay, S = support decay (168h).
CONTRASTS = {
    'replay_on_under_N_weights': [-1, 1, 0, 0],
    'replay_on_under_S_weights': [0, 0, -1, 1],
    'trained_weights_under_N_replay': [-1, 0, 1, 0],
    'trained_weights_under_S_replay': [0, -1, 0, 1],
    'original_total_SS_minus_NN': [-1, 0, 0, 1],
    'interaction': [1, -1, -1, 1],
}


def masks_for(frame, pairs):
    masks = groups(frame)
    masks['single_kc_long_gap_current'] = (frame.single_kc.to_numpy(bool) &
        (frame.kc_count_before.to_numpy() > 0) & (frame.delta_t_k_hours.to_numpy() > 168))
    ids = frame.record_idx.to_numpy()
    masks['single_kc_long_gap_matched_current'] = np.isin(ids, pairs[:, 0])
    masks['single_kc_long_gap_next_event'] = np.isin(ids, pairs[:, 1])
    return masks


def summarize_group(frame, predictions, mask, reps=2000, bootstrap_seed=20261025):
    ids = np.flatnonzero(mask)
    if len(ids) == 0:
        return {'n': 0, 'students': 0, 'metrics': {}, 'paired': {}}
    # seeds x branches x records; mean LOSSES across seeds, not an ensemble.
    if predictions.shape != (3, 4, len(frame)):
        raise ValueError('Exactly seeds 0,1,2 and all four branches must be aligned')
    y = frame.label.to_numpy()[ids]
    student = frame.student_idx.to_numpy()[ids]
    value = np.empty((3, 4, len(ids), 2))
    rows = {}
    for s in range(3):
        for b, branch in enumerate(BRANCHES):
            p = predictions[s, b, ids]
            value[s, b] = losses(y, p)
            row = metrics(y, p)
            users, inverse = np.unique(student, return_inverse=True)
            counts = np.bincount(inverse)
            for li, loss in enumerate(('nll', 'brier')):
                row[f'student_macro_{loss}'] = float(np.mean(
                    np.bincount(inverse, weights=value[s, b, :, li]) / counts))
            rows[f'{branch}_seed{s}'] = row
    names, columns = [], []
    for label, v in [(f'seed{s}', value[s]) for s in range(3)] + [('seed_mean', value.mean(0))]:
        for name, weights in CONTRASTS.items():
            delta = np.einsum('b,bnl->nl', weights, v)
            for li, loss in enumerate(('nll', 'brier')):
                names.append(f'{label}/{name}/{loss}')
                columns.append(delta[:, li])
    intervals = cluster_intervals(student, np.stack(columns, axis=1), reps, bootstrap_seed)
    summary, auc = {}, {}
    for branch in BRANCHES:
        summary[branch] = {}
        for name in ('auc', 'nll', 'brier', 'student_macro_nll', 'student_macro_brier'):
            vals = [rows[f'{branch}_seed{s}'][name] for s in range(3)]
            summary[branch][name] = {'mean': None if None in vals else float(np.mean(vals)),
                                    'sample_sd': None if None in vals else float(np.std(vals, ddof=1))}
    for name, weights in CONTRASTS.items():
        vals = [[rows[f'{b}_seed{s}']['auc'] for b in BRANCHES] for s in range(3)]
        diffs = [None if None in v else float(np.dot(weights, v)) for v in vals]
        auc[name] = {'per_seed': diffs, 'mean': None if None in diffs else float(np.mean(diffs))}
    return {'n': len(ids), 'students': intervals['students'], 'metrics': rows,
            'branch_summary': summary, 'auc_contrasts_descriptive_only': auc,
            'paired': dict(zip(names, intervals['comparisons']))}
