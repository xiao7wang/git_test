"""Build a pinned, independent diagnostic release; never edit training sources."""
import hashlib
import json
import zipfile
import sys
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
ARCHIVE = Path('D:/xunlei/factorial_review_results.zip')
EXPECTED = 'd967d3fb02132014923d3a0dd139ab9829c15eb5a47d08ba892428d2b7f24c1b'


def main():
    assert hashlib.sha256(ARCHIVE.read_bytes()).hexdigest() == EXPECTED
    with zipfile.ZipFile(ARCHIVE) as z:
        assert z.testzip() is None
        for name, digest in json.loads(z.read('result_manifest.json')).items():
            assert hashlib.sha256(z.read(name)).hexdigest() == digest
        report = json.loads(z.read('review.json'))
    expected = {'review_archive_sha256': EXPECTED, 'datasets': {}}
    for name, dataset in report['datasets'].items():
        audit = dataset['audit']
        assert audit['passed']
        selected = []
        for run in audit['runs']:
            if run['mode'] not in ('none', 'support_only'):
                continue
            run = dict(run)
            server = PurePosixPath(run.pop('path'))
            run['relative_run_dir'] = str(PurePosixPath(*server.parts[server.parts.index('outputs'):]))
            selected.append(run)
        assert len(selected) == 6
        expected['datasets'][name] = {'shared_protocol': audit['shared_protocol'], 'runs': selected}
    (ROOT / 'expected_inputs.json').write_text(json.dumps(expected, indent=2), encoding='utf-8')
    # Reuse the previously tested loss/AUC/student-bootstrap implementation exactly.
    source = ROOT.parent / 'uctp_factorial_review_v1/review_stats.py'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == report['analysis_source']['review_stats.py']
    (ROOT / 'review_stats.py').write_bytes(source.read_bytes())
    if '--prepare-only' in sys.argv:
        print('Prepared pinned input manifest and unchanged statistics dependency.')
        return
    files = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name != 'PACKAGE_MANIFEST.json')
    manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (ROOT / 'PACKAGE_MANIFEST.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    target = Path('C:/Users/xwsws/Desktop/uctp_frozen_cross_replay_v1.zip')
    # A release may be rebuilt locally; never replace a user-owned existing ZIP.
    if target.exists():
        raise FileExistsError(target)
    with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as z:
        for path in files + [ROOT / 'PACKAGE_MANIFEST.json']:
            z.write(path, f'{ROOT.name}/{path.name}')
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
    print(target)
    print('sha256:', hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
