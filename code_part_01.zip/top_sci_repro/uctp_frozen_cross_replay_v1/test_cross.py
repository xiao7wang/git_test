"""Synthetic CPU/CUDA gates: no real checkpoints/data are required for these tests."""
import argparse
import contextlib
import io
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import tempfile
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import torch

from cross_core import (ROOT, RATE, BRANCHES, KEYS, read, write, sha, check_hash, import_project,
                        frozen_model, model_digest, replay, reference_bridge, cold_guard, compare,
                        long_followup, validation_frame, selected_users, audit_inputs)
from cross_stats import summarize_group, masks_for, CONTRASTS
from review_stats import losses, metrics, cluster_intervals

PROJECT = None
DEVICE = 'cpu'


class ReplayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.sources = read(ROOT / 'expected_inputs.json')['datasets']['assist']['shared_protocol']['source']
        cls.Data, cls.Model, cls.forward_fn = import_project(PROJECT, cls.sources)

    def setUp(self):
        torch.manual_seed(7)
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)
        from src.data import encode_frame
        rows = []
        for user in range(4):
            # Training first, validation later, with long gaps and a cold validation KC.
            for i in range(10):
                kc = 'cold' if i == 8 else 'normal'
                rows.append(dict(student_id=str(user), item_id=kc, knowledge_ids=(kc,),
                    timestamp=1_700_000_000.125 + i * 200 * 3600,
                    response_time=1., rt_valid=True, source_row=i,
                    label=float((i + user) % 3 > 0), split=0 if i < 2 else (1 if i < 9 else 2)))
        arrays, vocab, summary = encode_frame(pd.DataFrame(rows))
        np.savez_compressed(self.path / 'records.npz', **arrays)
        write(self.path / 'vocabulary.json', vocab)
        write(self.path / 'manifest.json', {'schema_version': 1, 'summary': summary,
              'records_sha256': sha(self.path / 'records.npz'),
              'vocabulary_sha256': sha(self.path / 'vocabulary.json')})
        self.data = self.Data(self.path)
        config = dict(num_students=4, num_items=2, num_knowledges=2, variant='unit_write',
                      ncd_hidden_dim=8, time_mode='none', decay_rate_per_hour=0.)
        model = self.Model(**config)
        self.ckpt = {'model_family': 'time_factorial_v1', 'model_config': config,
                     'model_state': model.state_dict(), 'data_fingerprint': self.data.fingerprint,
                     'source_code': self.sources, 'epoch': 2}

    def tearDown(self):
        self.temp.cleanup()

    def model(self, mode='none', ckpt=None):
        return frozen_model(self.Model, ckpt or self.ckpt, mode, torch.device(DEVICE),
                            self.data.fingerprint, self.sources)

    def run_replay(self, mode='none', chunk=100, batch=8, model=None):
        with contextlib.redirect_stdout(io.StringIO()):
            return replay(model or self.model(mode), self.data, type(self).forward_fn,
                          torch.device(DEVICE), mode, batch_size=batch, chunk_size=chunk)

    def test_native_engine_equivalence(self):
        from src.engine import evaluate
        model = self.model()
        _, ref, _ = evaluate(model, self.data, torch.device(DEVICE), 'valid', 8, 100, True)
        result = self.run_replay(model=model)
        original = {k: ref[k].to_numpy() for k in ('record_idx',) + KEYS}
        self.assertTrue(compare(result, original)['success'])

    def test_support_native_engine_equivalence(self):
        from src.engine import evaluate
        model = self.model('support_only')
        _, ref, _ = evaluate(model, self.data, torch.device(DEVICE), 'valid', 8, 100, True)
        result = self.run_replay(model=model)
        self.assertTrue(compare(result, {k: ref[k].to_numpy() for k in ('record_idx',)+KEYS})['success'])

    def test_chunk_batch_none(self):
        self.assertTrue(compare(self.run_replay(), self.run_replay(chunk=3, batch=3))['success'])

    def test_chunk_batch_support(self):
        self.assertTrue(compare(self.run_replay('support_only'),
                                self.run_replay('support_only', chunk=3, batch=3))['success'])

    def test_parameters_frozen_and_identical_across_modes(self):
        a, b = self.model(), self.model('support_only')
        self.assertEqual(model_digest(a.state_dict()), model_digest(b.state_dict()))
        self.assertFalse(any(p.requires_grad for p in b.parameters()))
        digest = model_digest(a.state_dict())
        self.run_replay(model=a)
        self.assertEqual(digest, model_digest(a.state_dict()))

    def test_support_changes_repeated_kc_not_cold(self):
        a, b = self.run_replay(), self.run_replay('support_only')
        result = cold_guard(dict(NN=a, NS=b, SN=a, SS=b), self.data)
        self.assertTrue(result['success'])
        self.assertEqual(result['checks']['NN_vs_NS']['n'], 4)
        self.assertGreater(np.max(np.abs(a['probability']-b['probability'])), 1e-5)

    def test_test_labels_never_consumed(self):
        a = self.run_replay('support_only')
        self.data.arrays['label'][self.data.arrays['split'] == 2] = np.nan
        b = self.run_replay('support_only')
        self.assertTrue(compare(a, b)['success'])
        self.assertTrue((self.data.arrays['split'][a['record_idx']] == 1).all())

    def test_current_label_not_used_before_prediction(self):
        a = self.run_replay('support_only')
        row = a['record_idx'][1]
        self.data.arrays['label'][row] = 1 - self.data.arrays['label'][row]
        b = self.run_replay('support_only')
        same = a['record_idx'] <= row
        self.assertTrue(np.array_equal(a['probability'][same], b['probability'][same]))
        later = (a['record_idx'] > row) & (self.data.arrays['student_idx'][a['record_idx']] == 0)
        self.assertTrue((a['probability'][later] != b['probability'][later]).any())

    def test_repeat_replay_resets_states(self):
        model = self.model('support_only')
        self.assertTrue(compare(self.run_replay(model=model), self.run_replay(model=model))['success'])

    def test_checkpoint_save_load_strict(self):
        file = self.path / 'fixture.pt'
        torch.save(self.ckpt, file)
        ckpt = torch.load(file, map_location='cpu', weights_only=True)
        model = self.model('support_only', ckpt)
        self.assertEqual(model_digest(model.state_dict()), model_digest(ckpt['model_state']))

    def test_wrong_data_rejected(self):
        ckpt = dict(self.ckpt, data_fingerprint='wrong')
        with self.assertRaises(ValueError): self.model(ckpt=ckpt)

    def test_wrong_source_rejected(self):
        ckpt = dict(self.ckpt, source_code={})
        with self.assertRaises(ValueError): self.model(ckpt=ckpt)

    def test_wrong_rate_rejected(self):
        ckpt = dict(self.ckpt, model_config=dict(self.ckpt['model_config'], time_mode='support_only', decay_rate_per_hour=.01))
        with self.assertRaises(ValueError): self.model(ckpt=ckpt)

    def test_missing_tensor_rejected(self):
        ckpt = dict(self.ckpt, model_state={})
        with self.assertRaises(RuntimeError): self.model(ckpt=ckpt)

    def test_reference_roundtrip(self):
        result = self.run_replay()
        frame = validation_frame(self.data, result['record_idx'])
        for k in KEYS: frame[k] = result[k]
        path = self.path / 'ref.csv'
        frame.to_csv(path, index=False)
        self.assertTrue(reference_bridge(result, self.data, path)['success'])

    def test_reference_wrong_label_rejected(self):
        result = self.run_replay()
        frame = validation_frame(self.data, result['record_idx'])
        for k in KEYS: frame[k] = result[k]
        frame.loc[0, 'label'] = 1 - frame.loc[0, 'label']
        path = self.path / 'ref.csv'; frame.to_csv(path, index=False)
        with self.assertRaises(AssertionError): reference_bridge(result, self.data, path)

    def test_reference_bad_probability_fails_gate(self):
        result = self.run_replay()
        frame = validation_frame(self.data, result['record_idx'])
        for k in KEYS: frame[k] = result[k]
        frame.loc[0, 'probability'] = np.float32(float(frame.loc[0, 'probability']) + .01)
        path = self.path / 'ref.csv'; frame.to_csv(path, index=False)
        self.assertFalse(reference_bridge(result, self.data, path)['success'])

    def test_followup_only_valid_unique_next_event(self):
        ids = np.flatnonzero(self.data.arrays['split'] == 1)
        pairs = long_followup(self.data, ids)
        self.assertEqual(pairs.shape, (20, 2))
        self.assertTrue((pairs[:, 1] > pairs[:, 0]).all())
        self.assertEqual(len(np.unique(pairs[:, 1])), len(pairs))
        self.assertTrue(np.isin(pairs, ids).all())

    def test_followup_rejects_same_time(self):
        ids = np.flatnonzero(self.data.arrays['split'] == 1)
        self.data.arrays['timestamp'][3] = self.data.arrays['timestamp'][2]
        pairs = long_followup(self.data, ids)
        self.assertFalse((pairs[:, 0] == 2).any())

    def test_followup_does_not_skip_multikc_next_event(self):
        ids = np.flatnonzero(self.data.arrays['split'] == 1)
        self.data.arrays['item_q'][0] = [True, True]  # cold item at row8, still a next normal-KC event.
        self.data.arrays['split'][9] = 1  # later singleton exists, but must NOT skip row8.
        ids = np.flatnonzero(self.data.arrays['split'] == 1)
        pairs = long_followup(self.data, ids)
        self.assertFalse((pairs[:, 0] == 7).any())

    def test_preflight_fixed_whole_batches(self):
        self.assertTrue(np.array_equal(selected_users(self.data), np.arange(4)))

    def test_compare_rejects_ids_and_nan(self):
        a = self.run_replay()
        b = {k: v.copy() for k, v in a.items()}
        b['record_idx'][0] += 1
        with self.assertRaises(AssertionError): compare(a, b)
        b = {k: v.copy() for k, v in a.items()}; b['probability'][0] = np.nan
        with self.assertRaises(AssertionError): compare(a, b)


class StatisticsTests(unittest.TestCase):
    def test_loss_matches_original(self):
        from src.metrics import compute_metrics
        y = np.array([0, 1, 0, 1, 1]); p = np.array([.2, .7, .7, 1., 0.], np.float32)
        ref = compute_metrics(y, p)
        out = metrics(y, p)
        for k in ('auc', 'nll', 'brier'): self.assertAlmostEqual(out[k], ref[k], places=12)

    def test_invalid_probability_rejected(self):
        with self.assertRaises(ValueError): losses([0], [1.1])

    def test_cluster_bootstrap_identical_zero(self):
        r = cluster_intervals([0, 0, 1, 1], np.zeros((4, 2)), 20)
        for c in r['comparisons']:
            self.assertEqual(c['delta'], 0); self.assertEqual(c['ci95'], [0, 0])

    def test_event_vs_student_weighting(self):
        r = cluster_intervals([0, 0, 0, 1], np.array([1, 1, 1, -2])[:, None], 20)['comparisons'][0]
        self.assertAlmostEqual(r['delta'], .25)
        self.assertAlmostEqual(r['student_macro_delta'], -.5)

    def test_one_student_no_ci(self):
        r = cluster_intervals([0, 0], np.ones((2, 1)), 20)
        self.assertIsNone(r['comparisons'][0]['ci95'])

    def test_decomposition_two_paths_identity(self):
        a = np.array(CONTRASTS['replay_on_under_N_weights'])
        b = np.array(CONTRASTS['trained_weights_under_S_replay'])
        total = np.array(CONTRASTS['original_total_SS_minus_NN'])
        self.assertTrue(np.array_equal(a+b, total))
        a = np.array(CONTRASTS['trained_weights_under_N_replay'])
        b = np.array(CONTRASTS['replay_on_under_S_weights'])
        self.assertTrue(np.array_equal(a+b, total))

    def test_summary_is_loss_mean_not_probability_ensemble(self):
        f = pd.DataFrame(dict(label=[1,0,1,0], student_idx=[0,0,1,1]))
        p = np.empty((3,4,4))
        for s, prob in enumerate((.2,.5,.9)): p[s] = prob
        out = summarize_group(f, p, np.ones(4, bool), reps=20)
        expected = np.mean([metrics(f.label.to_numpy(), p[s,0])['nll'] for s in range(3)])
        self.assertAlmostEqual(out['branch_summary']['NN']['nll']['mean'], expected)
        ensemble = metrics(f.label.to_numpy(), p[:,0].mean(0))['nll']
        self.assertGreater(abs(expected-ensemble), .01)
        for r in out['paired'].values(): self.assertAlmostEqual(r['delta'], 0)

    def test_masks_proxy_partition(self):
        f = pd.DataFrame(dict(record_idx=range(5), delta_t_k_hours=[0,0,1,100,200],
                             kc_count_before=[0,1,1,1,1], single_kc=[True]*5))
        m = masks_for(f, np.array([[3,4]]))
        total = sum(m[k].astype(int) for k in ('no_previous_kc', 'repeat_gap_zero',
                    'repeat_gap_0_to_24h', 'repeat_gap_24_to_168h', 'repeat_gap_gt168h'))
        self.assertTrue(np.array_equal(total, np.ones(5)))
        self.assertEqual(m['single_kc_long_gap_next_event'].sum(), 1)

    def test_hash_corruption_rejected(self):
        with tempfile.TemporaryDirectory() as t:
            file = Path(t)/'fixture'; file.write_bytes(b'original'); digest = sha(file)
            check_hash(file, digest); file.write_bytes(b'changed')
            with self.assertRaises(ValueError): check_hash(file, digest)


def main():
    global PROJECT, DEVICE
    p = argparse.ArgumentParser()
    p.add_argument('--project-dir', required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), default='cpu')
    p.add_argument('--report')
    args = p.parse_args()
    PROJECT, DEVICE = args.project_dir, args.device
    if DEVICE == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA required; tests are NOT skipped')
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(c)
                               for c in (ReplayTests, StatisticsTests)])
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    record = {'success': result.wasSuccessful() and not result.skipped, 'tests_run': result.testsRun,
              'device': DEVICE, 'torch': str(torch.__version__),
              'failures': [(str(t), s) for t,s in result.failures],
              'errors': [(str(t), s) for t,s in result.errors], 'skipped': result.skipped}
    if args.report: write(args.report, record)
    if not record['success']: raise SystemExit(1)


if __name__ == '__main__':
    main()
