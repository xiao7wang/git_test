"""One dataset/seed, four independent frozen validation replays."""
import argparse
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import platform
import time
from pathlib import Path
import numpy as np
import torch
from cross_core import (ROOT, MODES, BRANCHES, KEYS, read, write, sha, audit_inputs,
                        import_project, frozen_model, replay, selected_users, reference_bridge,
                        cold_guard, compare, validation_frame, long_followup)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project-dir', required=True)
    p.add_argument('--data-root', required=True)
    p.add_argument('--output-dir', required=True)
    p.add_argument('--dataset', choices=('assist', 'ednet'), required=True)
    p.add_argument('--seed', type=int, choices=(0, 1, 2), required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), required=True)
    p.add_argument('--preflight', action='store_true')
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Both feedback/time-proxy acknowledgements are required')
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=False)
    started = time.monotonic()
    write(out / 'status.json', {'status': 'running', 'pid': os.getpid()})
    try:
        expected = read(ROOT / 'expected_inputs.json')
        selected = audit_inputs(args.project_dir, args.data_root, args.dataset, args.seed, expected)
        sources = expected['datasets'][args.dataset]['shared_protocol']['source']
        PreparedData, Model, forward = import_project(args.project_dir, sources)
        data = PreparedData(Path(args.data_root) / f'{args.dataset}_full')
        torch.set_num_threads(4)
        torch.manual_seed(0)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.use_deterministic_algorithms(True)
        if args.device == 'cuda' and not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable; no automatic CPU fallback')
        device = torch.device(args.device)
        users = selected_users(data) if args.preflight else None
        write(out / 'run_config.json', {'args': vars(args), 'data_fingerprint': data.fingerprint,
               'selected_inputs': selected, 'expected_sources': sources,
               'selected_preflight_users': None if users is None else users.tolist(),
               'native_precision': 'float32', 'timestamps_precision': 'float64',
               'half_life_hours': 168, 'batch_size': 8, 'chunk_size': 100,
               'native_reference_atol': 1e-6, 'trained': False, 'test_evaluated': False,
               'replay_scope': 'entire train+valid history, feedback after prediction; only valid scored',
               'environment': {'python': platform.python_version(), 'torch': str(torch.__version__),
                               'numpy': np.__version__, 'device': str(device)}})
        results, gates = {}, {}
        # Both native bridges must pass BEFORE either cross replay runs.
        for branch in ('NN', 'SS', 'NS', 'SN'):
            mode = MODES[branch[0]]
            run = selected[mode]
            folder = Path(args.project_dir) / run['relative_run_dir']
            checkpoint = torch.load(folder / 'best_model.pt', map_location='cpu', weights_only=True)
            if checkpoint['model_config']['time_mode'] != mode or checkpoint['epoch'] != run['best_epoch']:
                raise AssertionError('Checkpoint mode/selected epoch mismatch')
            model = frozen_model(Model, checkpoint, MODES[branch[1]], device, data.fingerprint, sources)
            write(out / 'status.json', {'status': 'running', 'branch': branch, 'pid': os.getpid()})
            result = replay(model, data, forward, device, branch, users=users)
            results[branch] = result
            if branch in ('NN', 'SS'):
                gate = reference_bridge(result, data, folder / 'validation_predictions.csv')
                gates[f'{branch}_native_reference'] = gate
                write(out / 'gates.json', gates)
                if not gate['success']:
                    raise AssertionError(f'{branch} native bridge failed; tolerance NOT changed')
            if args.preflight:
                alternate = replay(model, data, forward, device, branch + '_batch17_chunk17',
                                   batch_size=17, chunk_size=17, users=users)
                gate = compare(result, alternate)
                gates[f'{branch}_batch17_chunk17'] = gate
                write(out / 'gates.json', gates)
                if not gate['success']:
                    raise AssertionError(f'{branch} batch/chunk invariance failed')
            del model, checkpoint
            if device.type == 'cuda':
                torch.cuda.empty_cache()
            print(f'Completed branch {branch}', flush=True)
        gates['same_weights_cold_kc'] = cold_guard(results, data)
        write(out / 'gates.json', gates)
        if not gates['same_weights_cold_kc']['success']:
            raise AssertionError('Cold-KC same-weight invariant failed')
        ids = results['NN']['record_idx']
        for branch in BRANCHES:
            if not np.array_equal(ids, results[branch]['record_idx']):
                raise AssertionError('Branch event alignment failed')
        arrays = {'record_idx': ids}
        arrays.update({f'{branch}_{key}': results[branch][key] for branch in BRANCHES for key in KEYS})
        np.savez_compressed(out / 'predictions.npz', **arrays)
        validation_frame(data, ids).to_csv(out / 'events.csv.gz', index=False, compression='gzip')
        if not args.preflight:
            pairs = long_followup(data, ids)
            np.save(out / 'long_gap_next_single_kc_pairs.npy', pairs, allow_pickle=False)
        # Detect concurrent edits to the immutable inputs before accepting this job.
        audit_inputs(args.project_dir, args.data_root, args.dataset, args.seed, expected)
        write(out / 'artifact_manifest.json', {p.name: sha(p) for p in sorted(out.iterdir())
                                             if p.is_file() and p.name != 'status.json'})
        write(out / 'status.json', {'status': 'complete', 'seconds': time.monotonic()-started,
               'n': len(ids), 'trained': False, 'test_evaluated': False,
               'inputs_modified': False, 'all_gates_passed': True})
    except BaseException as exc:
        write(out / 'status.json', {'status': 'failed', 'error': repr(exc), 'seconds': time.monotonic()-started})
        raise


if __name__ == '__main__':
    main()
