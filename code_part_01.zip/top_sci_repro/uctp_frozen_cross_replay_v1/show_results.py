import argparse
from pathlib import Path
from cross_core import read


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output-root', required=True)
    args = p.parse_args()
    root = Path(args.output_root).resolve()
    path = root / 'suite_status.json'
    if not path.exists():
        raise SystemExit(f'No suite status at {path}; verify launch/output path. This is not proof of running.')
    s = read(path)
    print(f'Suite status: {s["status"]}; active job: {s.get("active_job")}')
    print('A saved running status does NOT prove a live process.')
    for job in s['jobs']:
        print(f'{job["name"]:<28} returncode={job["returncode"]} seconds={job["seconds"]:.1f}')
    if s['status'] == 'failed':
        print('FAILED:', s.get('error'))
        print('Do not restart over this directory. Send the corresponding .log.')
    archive = root / 'cross_replay_results.zip'
    if s['status'] == 'complete' and archive.exists():
        print('Results ready:', archive)
        report = root / 'REPORT.md'
        if report.exists():
            print(report.read_text(encoding='utf-8'))
    elif s['status'] == 'complete':
        print('Replays/summary complete; archive may still be packaging. Check runner/log.')


if __name__ == '__main__':
    main()
