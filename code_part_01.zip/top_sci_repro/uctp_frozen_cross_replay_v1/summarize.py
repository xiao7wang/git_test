"""Read only newly produced validation replays and summarize paired contrasts."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import BRANCHES, read, write, check_hash
from cross_stats import masks_for, summarize_group


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output-root', required=True)
    args = p.parse_args()
    root = Path(args.output_root)
    if (root / 'summary.json').exists():
        raise FileExistsError('Existing summary preserved')
    report = {'trained': False, 'test_evaluated': False, 'half_life_hours': 168,
              'branch_order': list(BRANCHES), 'meaning': 'first letter trained weights; second letter replay rule',
              'inference': 'Conditional on the three fixed selected checkpoints and validation cohort; student cluster bootstrap, 2000 resamples; no multiplicity correction; AUC descriptive',
              'limits': ['Cross replay may shift state distribution away from training distribution.',
                         'Trained-weight contrasts include different selected epochs and optimization trajectories.',
                         'No causal claim about students learning/forgetting; operational support is not calibrated confidence.',
                         'Train and valid history replayed with row-immediate feedback; test events never replayed.',
                         'Long-gap next-event strata are global replay, NOT isolated-anchor interventions.',
                         'Multi-KC scalar gap/count summaries are proxies; singleton subsets reported separately.'],
              'datasets': {}}
    lines = ['# 冻结交叉回放结果', '',
             'N=不做时间衰减，S=支持量衰减（固定168小时）。第一位为训练参数来源，第二位为回放规则。', '',
             '这是冻结模型的验证集机制诊断，不是新训练结果、独立测试集结论或真实教育干预。', '']
    for dataset in ('assist', 'ednet'):
        predictions, frame, pairs, origins = [], None, None, []
        for seed in range(3):
            job = root / f'{dataset}_seed{seed}_full'
            status = read(job / 'status.json')
            if status['status'] != 'complete' or not status['all_gates_passed']:
                raise ValueError(f'Incomplete job: {job}')
            for name, digest in read(job / 'artifact_manifest.json').items():
                check_hash(job / name, digest)
            current = pd.read_csv(job / 'events.csv.gz', float_precision='round_trip')
            current_pairs = np.load(job / 'long_gap_next_single_kc_pairs.npy', allow_pickle=False)
            if frame is None:
                frame, pairs = current, current_pairs
            elif not current.equals(frame) or not np.array_equal(pairs, current_pairs):
                raise AssertionError('Seed identity/selection differs')
            with np.load(job / 'predictions.npz', allow_pickle=False) as z:
                if not np.array_equal(z['record_idx'], frame.record_idx.to_numpy()):
                    raise AssertionError('Prediction/event identity mismatch')
                predictions.append(np.stack([z[f'{b}_probability'] for b in BRANCHES]))
            origins.append(read(job / 'run_config.json')['selected_inputs'])
        predictions = np.stack(predictions)
        if not (frame.split == 1).all():
            raise AssertionError('Only validation rows may be scored')
        result = {'origins': origins, 'long_followup_pairs': len(pairs), 'groups': {}}
        for name, mask in masks_for(frame, pairs).items():
            print(f'Summarizing {dataset}/{name}: {int(mask.sum())} events', flush=True)
            result['groups'][name] = summarize_group(frame, predictions, mask)
        report['datasets'][dataset] = result
        lines += [f'## {dataset.upper()}', '', '|组合|验证AUC均值|NLL均值|学生等权NLL均值|', '|---|---:|---:|---:|']
        all_rows = result['groups']['all']
        for b in BRANCHES:
            row = all_rows['branch_summary'][b]
            lines.append(f'|{b}|{row["auc"]["mean"]:.6f}|{row["nll"]["mean"]:.6f}|{row["student_macro_nll"]["mean"]:.6f}|')
        lines += ['', '以下均为NLL差值；负值更好，区间为条件学生聚类bootstrap 95%区间。', '']
        for name in ('all', 'repeat_gap_gt168h', 'no_previous_kc', 'single_kc_long_gap_next_event'):
            group = result['groups'][name]
            lines += [f'### {name}: n={group["n"]}, students={group["students"]}', '']
            if not group['n']:
                continue
            for contrast in ('replay_on_under_N_weights', 'replay_on_under_S_weights', 'original_total_SS_minus_NN', 'interaction'):
                v = group['paired'][f'seed_mean/{contrast}/nll']
                lines.append(f'- {contrast}: Δ={v["delta"]:+.6f}; CI={v["ci95"]}; macro Δ={v["student_macro_delta"]:+.6f}; macro CI={v["student_macro_ci95"]}')
            lines.append('')
    lines += ['## 解释边界', ''] + [f'- {x}' for x in report['limits']]
    write(root / 'summary.json', report)
    (root / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')


if __name__ == '__main__':
    main()
