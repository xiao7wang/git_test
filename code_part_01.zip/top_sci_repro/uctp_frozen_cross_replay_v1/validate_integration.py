"""Local synthetic end-to-end test, including the real suite CLI and archive.

All fixtures are constructed in a fresh temporary directory. No original
checkpoint, dataset, experiment output, or training source is modified.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
import torch
from cross_core import ROOT, RATE, read, write, sha, import_project


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project-dir', required=True)
    args = p.parse_args()
    project = Path(args.project_dir).resolve()
    sources = read(ROOT / 'expected_inputs.json')['datasets']['assist']['shared_protocol']['source']
    import_project(project, sources)
    import test_cross
    test_cross.PROJECT = str(project)
    test_cross.ReplayTests.setUpClass()
    fixture = test_cross.ReplayTests(methodName='test_reference_roundtrip')
    fixture.setUp()
    try:
        with tempfile.TemporaryDirectory(prefix='cross_integration_') as temp:
            base = Path(temp).resolve()
            original, data_root, package = base / 'project', base / 'data', base / 'package'
            package.mkdir()
            for file in ROOT.iterdir():
                if file.is_file() and file.suffix in ('.py', '.sh'):
                    shutil.copyfile(file, package / file.name)
            for name in sources:
                target = original / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(project / name, target)
            manifest = {'datasets': {}}
            from src.engine import evaluate
            for dataset in ('assist', 'ednet'):
                data_path = data_root / f'{dataset}_full'
                data_path.mkdir(parents=True)
                for name in ('records.npz', 'manifest.json', 'vocabulary.json'):
                    shutil.copyfile(fixture.path / name, data_path / name)
                spec = {'shared_protocol': {'source': sources, 'data_fingerprint': fixture.data.fingerprint}, 'runs': []}
                for seed in range(3):
                    for mode in ('none', 'support_only'):
                        torch.manual_seed(seed + (mode == 'support_only') * 100)
                        cfg = dict(fixture.ckpt['model_config'], time_mode=mode,
                                   decay_rate_per_hour=0.0 if mode == 'none' else RATE)
                        model = fixture.Model(**cfg)
                        ckpt = dict(fixture.ckpt, model_config=cfg, model_state=model.state_dict())
                        relative = f'outputs/{dataset}/{mode}_seed{seed}'
                        folder = original / relative
                        folder.mkdir(parents=True)
                        torch.save(ckpt, folder / 'best_model.pt')
                        met, frame, _ = evaluate(model, fixture.data, torch.device('cpu'), 'valid', 8, 100, True)
                        frame.to_csv(folder / 'validation_predictions.csv', index=False)
                        write(folder / 'validation_metrics.json', met)
                        write(folder / 'status.json', {'status': 'complete'})
                        write(folder / 'run_config.json', {'model_family': 'time_factorial_v1', 'args': {
                              'time_mode': mode, 'seed': seed, 'variant': 'unit_write',
                              'eval_update_targets': 1, 'evaluate_test': False}})
                        spec['runs'].append({'dataset': dataset, 'mode': mode, 'seed': seed,
                            'relative_run_dir': relative, 'best_epoch': 2,
                            'checkpoint_sha256': sha(folder / 'best_model.pt'),
                            'input_hashes': {name: sha(folder / name) for name in
                                ('run_config.json', 'status.json', 'validation_metrics.json', 'validation_predictions.csv')}})
                manifest['datasets'][dataset] = spec
            write(package / 'expected_inputs.json', manifest)
            write(package / 'PACKAGE_MANIFEST.json', {p.name: sha(p) for p in package.iterdir() if p.is_file()})
            before = {str(p): sha(p) for root in (original, data_root) for p in root.rglob('*') if p.is_file()}
            output = base / 'results'
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
            command = [sys.executable, '-B', str(package / 'run_suite.py'), '--project-dir', str(original),
                       '--data-root', str(data_root), '--output-root', str(output), '--device', 'cpu',
                       '--ack-row-feedback', '--ack-time-proxy']
            log_path = ROOT / 'LOCAL_INTEGRATION_LOG.txt'
            with log_path.open('w', encoding='utf-8') as log:
                code = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT).returncode
            if code:
                print(log_path.read_text(encoding='utf-8'))
                for log in output.glob('*.log'):
                    print(log.name, log.read_text(encoding='utf-8')[-5000:])
                raise AssertionError(f'Synthetic suite failed: {code}')
            status = read(output / 'suite_status.json')
            assert status['status'] == 'complete' and len(status['jobs']) == 14
            assert all(j['returncode'] == 0 for j in status['jobs'])
            assert before == {str(p): sha(p) for root in (original, data_root) for p in root.rglob('*') if p.is_file()}
            with zipfile.ZipFile(output / 'cross_replay_results.zip') as z:
                assert z.testzip() is None
                import hashlib
                for name, digest in json.loads(z.read('result_manifest.json')).items():
                    assert hashlib.sha256(z.read(name)).hexdigest() == digest
                result = json.loads(z.read('summary.json'))
                assert not result['test_evaluated'] and not result['trained']
                for d in result['datasets'].values():
                    assert d['groups']['all']['n'] == 28
                    for row in d['groups']['all']['paired'].values():
                        assert len(row['ci95']) == 2
            # Refuse reusing an existing output directory, retaining its finished outputs.
            old_status = sha(output / 'suite_status.json')
            code = subprocess.run(command, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode
            assert code != 0 and sha(output / 'suite_status.json') == old_status
            report = {'success': True, 'suite_jobs': len(status['jobs']), 'all_job_returncodes_zero': True,
                      'data_and_project_unchanged': True, 'existing_outputs_preserved': True,
                      'archive_all_hashes_verified': True, 'device': 'cpu', 'torch': str(torch.__version__),
                      'scope': 'synthetic end-to-end; real server checkpoints and CUDA not available locally'}
            write(ROOT / 'LOCAL_INTEGRATION_REPORT.json', report)
            print(json.dumps(report, indent=2))
    finally:
        fixture.tearDown()


if __name__ == '__main__':
    main()
