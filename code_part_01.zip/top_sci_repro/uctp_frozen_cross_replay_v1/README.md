# 冻结交叉回放：区分“状态规则作用”与“训练参数差异”

## 本轮要回答什么

上一轮 24 个训练作业已经完成并完成验证集审计。ASSIST 的 support_only 总体改善比较一致，但长间隔当前事件不一定改善；EDNet 的总体改善较小，学生等权结果和首次接触 KC 的改善还受到 seed2 的明显影响。首次接触当前 KC 时，该 KC 并没有旧状态可衰减，因此不能把不同模型在这些事件上的差异直接归因于支持量衰减的即时作用。

本轮固定已经训练好的参数，只切换历史回放规则，检查：

1. 不重新训练，直接打开支持量衰减，是否仍然改善预测？
2. 已按 support_only 训练的参数，关闭衰减后还能保留多少优势？
3. 结果是否依赖训练参数与回放规则的配合？
4. 整体、长间隔、首次 KC、后续同 KC 事件，以及学生等权结论是否一致？

这不是放弃“时间作用于掌握均值、历史支持量，还是二者同时作用”的主问题，而是先核查上一轮支持量结果的来源。不能据此宣称“已证明心理置信度下降”或“已排除单纯更新尺度解释”。

## 四格设计

|冻结参数来源|不衰减回放|支持量衰减回放|
|---|---|---|
|none 训练的最佳验证 checkpoint|NN：原生复现|NS：打开衰减|
|support_only 训练的最佳验证 checkpoint|SN：关闭衰减|SS：原生复现|

N=none，S=support_only。首字母是**参数来源**，第二字母是**回放规则**。

- 每个数据集保留 seeds 0、1、2，不挑种子。共 6 个完整四格作业。
- 一共 24 次全量验证回放：12 次原生复现、12 次新增交叉回放。另有小样本预检查与单元测试。
- 参数来源固定为已审计、按原验证 AUC 选出的 checkpoint；不换 epoch，不调参。
- 回放规则均复用原来的 `FactorialTimeCD`，不复制或改写时间状态公式。
- 支持量规则固定半衰期 168 小时、支持量下限 2，均值不直接衰减。
- 每个分支都从独立初始状态回放完整训练历史与验证历史。先预测当前响应，再观察当前反馈并写入状态。
- 只记录、评分验证事件；不会回放或预测 test 事件。原 NPZ 文件含 test 数据，读取整个文件不等于进行 test 评测。

## 主要比较怎样读

以下是原始 NLL/Brier 差值，负值更好；AUC 差值正值更好。

|比较|含义|
|---|---|
|NS − NN|同一组 none 参数下，打开支持量衰减|
|SS − SN|同一组 support 参数下，打开支持量衰减|
|SN − NN|都不衰减时，换参数来源|
|SS − NS|都衰减时，换参数来源|
|SS − NN|上一轮两种完整方案的总差异|
|SS − SN − NS + NN|参数来源与回放规则的交互|

总差异可沿两条路径拆分，不能把某一条路径的“贡献比例”当作唯一因果归因。不同训练模式的参数差异也包括优化轨迹和最佳 epoch 的差异；并非同一训练过程中的单独随机干预。

若 NS−NN 与 SS−SN 都改善，说明状态规则在两种固定参数下都有帮助；若只在其中一种参数下改善，应强调参数—状态分布的配合。若 SS−NN 改善，但两个同权重规则比较不改善，不能继续把总优势简单解释成“时间降低历史证据信任”的即时效果。交叉回放可能造成训练/评估状态分布不匹配，这一点必须报告。

## 验证门禁

1. 本包固定 12 个 checkpoint、对应 validation CSV、状态/配置/历史文件、数据 manifest 与训练源码哈希。EDNet 补跑种子使用真正完成的 `server_ednet_support_resume_20261020_01`，不读取旧的中断 run。
2. 实际加载数据时，原 PreparedData 再核对 records.npz 和 vocabulary.json 哈希。
3. 每组 NN 和 SS 原生分支必须通过旧 CSV 桥接，然后才进行 NS、SN。概率、uncertainty、evidence 全部检查。
4. 原 CSV 数值恢复到其原始 float32 精度比较，绝对阈值固定 `1e-6`。不升级为 FP64 后冒充原生重放，不自动放宽阈值。
5. 小样本预检查采用原始完整 batch，额外运行 batch=17、chunk=17；比较全部三个输出。
6. 同一参数来源下，当前题目涉及的 KC 全部未见过时，两个规则输出应一致。不同参数来源不要求一致。
7. 每次回放前后检查参数张量哈希；不创建 optimizer，不反向传播。
8. 任一失败即停止；保留失败日志与已产生文件。现有输出目录拒绝覆盖。

## 分组与统计

- 保留上一轮的整体、重复 KC、间隔为0、0–24小时、24–168小时、超过168小时、首次 KC 组。
- 多 KC 题目的已有 scalar gap/count 是均值代理，不宣称等同于精确的单 KC 遗忘窗口。
- 另外统计单 KC 长间隔当前事件，并匹配其下一次实际同 KC 事件。仅 valid→valid，下一事件也必须单 KC，且时间严格递增。若真正的下一事件是多 KC 或同时间事件，则排除，不跳过它另找有利目标。
- 后续事件是全历史规则回放中的观察分组，**不是单锚点因果干预实验**，不得和早期机制包的 h1 数值直接混为同一设计。
- 每个种子单独报告，以及三个固定种子的均值；平均的是损失，不是预测概率，不构造集成模型。
- 事件等权与学生等权同时报告。95% 区间按学生聚类 bootstrap（2000次，同一重采样用于所有比较），保留同一学生的全部事件和全部种子。
- 区间以当前验证群体及已选 checkpoint 为条件；未校正多重比较；AUC 仅作描述，不附未经计算的显著性结论。

## 新增文件与数据流

|新增文件|作用|
|---|---|
|expected_inputs.json|从已验收的 factorial_review_results.zip 提取不可变输入清单|
|cross_core.py|原源码导入、身份校验、独立原生回放、桥接与分组|
|run_job.py|一个数据集/种子的四格回放|
|cross_stats.py、review_stats.py|配对统计；后者原样复用已经测试的统计代码|
|run_suite.py、run_server.sh|串行执行、日志、失败停止、打包|
|summarize.py、show_results.py|生成报告、查看进度和结果|
|test_cross.py、validate_integration.py|数值与协议单元测试、合成数据端到端验收|

数据流：固定输入哈希 → CPU/GPU 测试 → 六组小样本桥接与分块检查 → 六组完整四格回放 → 三种子配对/分组统计 → 结果 ZIP。

没有修改旧模型、训练脚本、数据、旧结果；没有加入新的可训练模块。原环境继续使用 yydw，无须升级依赖。

## 最简服务器步骤

先上传桌面的 `uctp_frozen_cross_replay_v1.zip` 到服务器 `/home/wangxiao/QCCDM/top_sci_repro/`。
下面只复制代码框内部命令，不复制三反引号、`bash` 标题、提示符或输出。

### 1. 解压到独立新目录

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
if [ -e uctp_frozen_cross_replay_v1 ]; then
  echo '目录已存在，请保留，勿重复解压覆盖'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_frozen_cross_replay_v1.zip &&
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_frozen_cross_replay_v1.zip .
fi
```

### 2. 一条命令在后台 tmux 启动完整流程

```bash
tmux new-session -d -s frozen_cross_01 "bash /home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/run_server.sh server_cross_01"
```

这是后台启动，不需要再进入会话重复运行脚本。如提示 duplicate session，不要重复启动，先检查已有会话/进程。

查看终端：`tmux attach -t frozen_cross_01`。退出查看时按 Ctrl+B，再按 D；不要用 Ctrl+C。成功结束后 tmux 会话可能自动消失，以 suite_status.json 和结果包为准。

### 3. 查看结果

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B /home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/show_results.py --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/outputs/server_cross_01
```

必须看到 `Suite status: complete` 和 `Results ready` 才算完整结束。下载：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/outputs/server_cross_01/cross_replay_results.zip`

若失败：读 active_job 对应 `.log`，把最后100行发来，不要覆盖现有目录、删除旧结果或放宽阈值。

若连 suite_status.json 都没有生成，查看 `outputs/server_cross_01.launch.log`：它保留启动前身份校验等错误，不代表“还在等训练”。

### 4. 判断是否真的在跑

```bash
pgrep -a -u wangxiao -f 'uctp_frozen_cross_replay_v1/(run_suite[.]py|run_job[.]py|test_cross[.]py|summarize[.]py)'
```

所有回放会每100个学生 batch 打印进度。状态为 running 本身不能证明进程仍在。切勿根据界面无输出就重复启动。

这轮不训练，但有24次完整历史回放，不能按之前31秒的汇总脚本估计。首个完整作业结束后，用显示的 seconds 估计同数据集后续作业，两个数据集耗时可能不同。脚本不会人为设定“睡一晚就一定完成”。

## 本地验证范围

见 LOCAL_TEST_REPORT.json 与 LOCAL_INTEGRATION_REPORT.json。真实 checkpoint 和全量数据只在服务器，本地检查不能替代服务器原生桥接。GPU 检查由启动脚本在服务器执行，不会将缺失 GPU 记为跳过并视为通过。
