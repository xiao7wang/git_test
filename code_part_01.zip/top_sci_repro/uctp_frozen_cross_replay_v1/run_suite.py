"""Fail-fast, serial suite. New output directory required; never overwrites old runs."""
import argparse
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

from cross_core import ROOT, read, write, sha, check_hash, audit_inputs


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project-dir', required=True)
    p.add_argument('--data-root', required=True)
    p.add_argument('--output-root', required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), default='cuda')
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Read README.md and acknowledge both protocol assumptions')
    for name, digest in read(ROOT / 'PACKAGE_MANIFEST.json').items():
        check_hash(ROOT / name, digest)
    expected = read(ROOT / 'expected_inputs.json')
    for dataset in ('assist', 'ednet'):
        for seed in range(3):
            audit_inputs(args.project_dir, args.data_root, dataset, seed, expected)
    print('All 12 frozen checkpoints/references and data manifests verified.', flush=True)
    out = Path(args.output_root).resolve()
    out.mkdir(parents=True, exist_ok=False)
    started, jobs = time.monotonic(), []
    status = {'status': 'running', 'active_job': None, 'jobs': jobs, 'pid': os.getpid(),
              'trained': False, 'test_evaluated': False, 'inputs_modified': False}
    write(out / 'suite_config.json', {'args': vars(args), 'package_hashes': read(ROOT / 'PACKAGE_MANIFEST.json'),
                                      'expected_inputs_sha256': sha(ROOT / 'expected_inputs.json')})
    write(out / 'suite_status.json', status)
    env = dict(os.environ, CUBLAS_WORKSPACE_CONFIG=':4096:8', PYTHONDONTWRITEBYTECODE='1')

    def job(name, command):
        status['active_job'] = name
        write(out / 'suite_status.json', status)
        log = out / f'{name}.log'
        print(f'Starting {name}; log: {log}', flush=True)
        begin = time.monotonic()
        with log.open('x', encoding='utf-8') as stream:
            process = subprocess.Popen([sys.executable, '-B', '-u'] + command,
                                       cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
            status['child_pid'] = process.pid
            write(out / 'suite_status.json', status)
            rc = process.wait()
        jobs.append({'name': name, 'returncode': rc, 'seconds': time.monotonic()-begin})
        write(out / 'suite_status.json', status)
        if rc != 0:
            raise RuntimeError(f'{name} failed: read {log}; previous results preserved')
        print(f'Completed {name} ({jobs[-1]["seconds"]:.1f}s)', flush=True)

    try:
        devices = ('cpu', 'cuda') if args.device == 'cuda' else ('cpu',)
        for device in devices:
            job(f'tests_{device}', [str(ROOT / 'test_cross.py'), '--project-dir', args.project_dir,
                                   '--device', device, '--report', str(out / f'tests_{device}.json')])
        for preflight in (True, False):
            for dataset in ('assist', 'ednet'):
                for seed in range(3):
                    name = f'{dataset}_seed{seed}_' + ('preflight' if preflight else 'full')
                    command = [str(ROOT / 'run_job.py'), '--project-dir', args.project_dir,
                               '--data-root', args.data_root, '--output-dir', str(out / name),
                               '--dataset', dataset, '--seed', str(seed), '--device', args.device,
                               '--ack-row-feedback', '--ack-time-proxy']
                    if preflight:
                        command.append('--preflight')
                    job(name, command)
        job('summary', [str(ROOT / 'summarize.py'), '--output-root', str(out)])
        status.update(status='complete', active_job=None, child_pid=None, seconds=time.monotonic()-started)
        write(out / 'suite_status.json', status)
        paths = sorted(p for p in out.rglob('*') if p.is_file())
        write(out / 'result_manifest.json', {str(p.relative_to(out)).replace('\\', '/'): sha(p) for p in paths})
        archive = out / 'cross_replay_results.zip'
        with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
            for file in paths + [out / 'result_manifest.json']:
                z.write(file, str(file.relative_to(out)))
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise RuntimeError('Archive integrity check failed')
        print(f'ALL_COMPLETED. Download: {archive}', flush=True)
    except BaseException as exc:
        status.update(status='failed', error=repr(exc), seconds=time.monotonic()-started)
        write(out / 'suite_status.json', status)
        raise


if __name__ == '__main__':
    main()
