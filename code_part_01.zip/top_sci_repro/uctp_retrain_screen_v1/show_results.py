import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();root=Path(a.output_dir)
if not (root/'status.json').exists():print('Not started or tests still running; check launch log.')
else:
 s=read(root/'status.json');print('Suite:',s.get('status'),'active:',s.get('active'),'error:',s.get('error','-'))
 print('Saved running status does not prove a live process.')
 for name in ('A_none','B_0.6','B_0.8','B_0.9','C_168','C_672','C_2688'):
  path=root/name/'status.json'
  if not path.exists():print(name,'not_started');continue
  st=read(path);print(name,st.get('status'),'epoch=',st.get('epoch',st.get('epochs')),'phase=',st.get('phase'), 'best_nll=',st.get('best_dev_nll'))
 if (root/'summary.json').exists():print('Selected on development:',read(root/'summary.json')['selected'])
 if (root/'screen_results.zip').exists():print('Results archive:',root/'screen_results.zip')
