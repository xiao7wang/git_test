import argparse
import hashlib
import json
import zipfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);root=Path(p.parse_args().output_dir).resolve()
if json.loads((root/'status.json').read_text(encoding='utf8'))['status']!='complete':raise ValueError('Suite incomplete')
names=['status.json','suite_config.json','summary.json']
for candidate in ('A_none','B_0.6','B_0.8','B_0.9','C_168','C_672','C_2688'):
 names.extend([candidate+'.log',candidate+'/status.json',candidate+'/history.json',candidate+'/dev_predictions.csv.gz'])
manifest={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
archive=root/'screen_results.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
 for name in names:z.write(root/name,name)
 z.writestr('manifest.json',json.dumps(manifest,indent=2))
with zipfile.ZipFile(archive) as z:
 if z.testzip() is not None or any(hashlib.sha256(z.read(k)).hexdigest()!=v for k,v in manifest.items()):raise ValueError('Archive corrupt')
print('RESULTS READY:',archive,flush=True)
