"""Sequential frozen-grid, development-only seed 0 ASSIST training suite."""
import argparse
import json
import subprocess
import sys
import time
import platform
from pathlib import Path
import torch
from cross_core import read, sha, write

ROOT=Path(__file__).resolve().parent
PLAN=[('A',0,'A_none'),('B',0,'B_0.6'),('B',1,'B_0.8'),('B',2,'B_0.9'),
      ('C',0,'C_168'),('C',1,'C_672'),('C',2,'C_2688')]

def main():
    p=argparse.ArgumentParser()
    for name in ('project-dir','data-dir','output-dir'):p.add_argument('--'+name,required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--epochs',type=int,default=20)
    p.add_argument('--patience',type=int,default=5)
    p.add_argument('--ack-row-feedback',action='store_true')
    p.add_argument('--ack-time-proxy',action='store_true')
    a=p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy:p.error('Both acknowledgements required')
    if min(a.epochs,a.patience)<1:p.error('Invalid settings')
    out=Path(a.output_dir).resolve()
    out.mkdir(parents=True,exist_ok=False)
    start=time.monotonic()
    status={'status':'running','active':None,'test_evaluated':False,'holdout_evaluated':False}
    write(out/'status.json',status)
    config={'plan':PLAN,'seed':0,'epochs':a.epochs,'patience':a.patience,'selection':'minimum development event NLL',
            'tie_break':'first candidate in plan','test_evaluated':False,'holdout_evaluated':False,
            'data_manifest_sha256':sha(Path(a.data_dir)/'manifest.json'),
            'code_sha256':{name:sha(ROOT/name) for name in ('run_suite.py','run_candidate.py','screen_core.py','pilot_core.py','decision_core.py','cross_core.py')},
            'feedback':'row immediate assumption','time':'event-time proxy','training_update_targets':True,
            'optimizer':'AdamW','lr':0.001,'weight_decay':0.00001,'batch_size':8,'chunk_size':50,'eval_chunk_size':100,
            'python':platform.python_version(),'torch':str(torch.__version__),'device':a.device,
            'gpu':torch.cuda.get_device_name(0) if a.device=='cuda' and torch.cuda.is_available() else None,
            'expected_inputs_sha256':sha(ROOT/'expected_inputs.json'),
            'checkpoint_policy':'best model per candidate retained on server; no automatic resume'}
    write(out/'suite_config.json',config)
    try:
        rows=[]
        for rule,index,name in PLAN:
            status['active']=name
            write(out/'status.json',status)
            cmd=[sys.executable,'-B','-u',str(ROOT/'run_candidate.py'),'--project-dir',a.project_dir,
                 '--data-dir',a.data_dir,'--output-dir',str(out/name),'--rule',rule,'--index',str(index),
                 '--device',a.device,'--epochs',str(a.epochs),'--patience',str(a.patience),
                 '--ack-row-feedback','--ack-time-proxy']
            log=out/(name+'.log')
            print('START',name,'log:',log,flush=True)
            with log.open('x',encoding='utf-8') as stream:
                code=subprocess.run(cmd,stdout=stream,stderr=subprocess.STDOUT).returncode
            if code: raise RuntimeError(f'{name} failed, returncode={code}, log={log}')
            row=read(out/name/'status.json')
            if row['status']!='complete' or row['seed']!=0: raise ValueError('Candidate incomplete')
            rows.append(row)
            print('COMPLETED',name,'best_epoch',row['best_epoch'],'dev_nll',row['best_dev_nll'],flush=True)
        if len({r['initial_state_sha256'] for r in rows})!=1:
            raise AssertionError('Candidate initialization differs')
        picked={rule:min((r for r in rows if r['rule']==rule),key=lambda x:x['best_dev_nll']) for rule in ('A','B','C')}
        write(out/'summary.json',{'scope':'seed0 development selection only; not independent confirmation',
              'candidates':rows,'selected':{k:{'value':v['value'],'best_epoch':v['best_epoch'],
              'best_dev_nll':v['best_dev_nll'],'checkpoint_sha256':v['checkpoint_sha256']} for k,v in picked.items()},
              'holdout_evaluated':False,'test_evaluated':False})
        status.update(status='complete',active=None,seconds=time.monotonic()-start)
        write(out/'status.json',status)
        print('SUITE COMPLETE',flush=True)
    except BaseException as exc:
        status.update(status='failed',error=repr(exc),seconds=time.monotonic()-start)
        write(out/'status.json',status)
        raise

if __name__=='__main__':main()
