"""Run complete seven-candidate suite on synthetic data, never on server data."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import test_step
from cross_core import read,write

ROOT=Path(__file__).resolve().parent
PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
test_step.PROJECT=str(PROJECT)
test_step.StepTests.setUpClass()
fixture=test_step.StepTests()
fixture.setUp()
try:
    with tempfile.TemporaryDirectory(prefix='screen_test_') as temp:
        root=Path(temp);pkg=root/'pkg';pkg.mkdir()
        for n in ('run_suite.py','run_candidate.py','screen_core.py','pilot_core.py','decision_core.py','cross_core.py','package_results.py'):
            shutil.copy2(ROOT/n,pkg/n)
        write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{
            'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
        cmd=[sys.executable,'-B',str(pkg/'run_suite.py'),'--project-dir',str(PROJECT),
             '--data-dir',str(fixture.path),'--output-dir',str(root/'out'),'--device','cpu',
             '--epochs','2','--patience','1','--ack-row-feedback','--ack-time-proxy']
        env=dict(os.environ,PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
        result=subprocess.run(cmd,env=env,text=True,encoding='utf8',stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        if result.returncode:raise RuntimeError(result.stdout)
        summary=read(root/'out/summary.json')
        assert len(summary['candidates'])==7 and set(summary['selected'])=={'A','B','C'}
        assert not summary['test_evaluated'] and not summary['holdout_evaluated']
        assert len({r['initial_state_sha256'] for r in summary['candidates']})==1
        for rule,index,name in [('A',0,'A_none'),('B',0,'B_0.6'),('B',1,'B_0.8'),('B',2,'B_0.9'),('C',0,'C_168'),('C',1,'C_672'),('C',2,'C_2688')]:
            folder=root/'out'/name
            stat=read(folder/'status.json');hist=read(folder/'history.json')
            assert stat['status']=='complete' and 1<=stat['best_epoch']<=len(hist)
            assert abs(stat['best_dev_nll']-min(x['dev']['nll'] for x in hist))<1e-12
            assert (folder/'best_model.pt').is_file() and (folder/'dev_predictions.csv.gz').is_file()
        for rule in ('A','B','C'):
            assert summary['selected'][rule]['best_dev_nll']==min(r['best_dev_nll'] for r in summary['candidates'] if r['rule']==rule)
        again=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        assert again.returncode!=0
        package=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        assert package.returncode==0,package.stdout
        import hashlib,zipfile
        with zipfile.ZipFile(root/'out/screen_results.zip') as z:
            assert z.testzip() is None
            manifest=json.loads(z.read('manifest.json'))
            assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
            assert not any(n.endswith('.pt') for n in z.namelist())
        print(json.dumps({'synthetic_suite':True,'candidates':7,'nll_selection':True,'checkpoint_recheck':True,'overwrite_rejected':True,'archive_verified':True,'real_gpu_tested':False}))
finally:
    fixture.tearDown()
