import argparse
import importlib
import json
import os
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import torch
from cross_core import import_project,read,sha,write
from pilot_core import DevelopmentData,development_users,SALT
from screen_core import fit_candidate

ROOT=Path(__file__).resolve().parent
GRID={'A':[None],'B':[0.6,0.8,0.9],'C':[168,672,2688]}

def main():
    p=argparse.ArgumentParser()
    for name in ('project-dir','data-dir','output-dir','rule'): p.add_argument('--'+name,required=True)
    p.add_argument('--index',type=int,required=True)
    p.add_argument('--device',choices=('cpu','cuda'),default='cuda')
    p.add_argument('--ack-row-feedback',action='store_true')
    p.add_argument('--ack-time-proxy',action='store_true')
    p.add_argument('--epochs',type=int,default=20)
    p.add_argument('--patience',type=int,default=5)
    a=p.parse_args()
    if not a.ack_row_feedback or not a.ack_time_proxy: p.error('Acknowledge feedback and time proxy')
    if a.rule not in GRID or a.index<0 or a.index>=len(GRID[a.rule]): p.error('Invalid rule/index')
    if a.epochs<1 or a.patience<1: p.error('Invalid early stopping settings')
    if a.device=='cuda' and not torch.cuda.is_available(): raise RuntimeError('CUDA unavailable')
    spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
    Data,Base,_=import_project(a.project_dir,spec['source'])
    if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint']: raise ValueError('Data fingerprint mismatch')
    data=Data(a.data_dir)
    if not (data.arrays['item_q'].sum(1)==1).all(): raise ValueError('Requires single KC')
    users=development_users(data.arrays['student_idx'][data.arrays['split']==1])
    if not users: raise ValueError('No development students')
    dev=DevelopmentData(data,users)
    torch.set_num_threads(4)
    torch.backends.cudnn.benchmark=False
    torch.backends.cudnn.deterministic=True
    torch.use_deterministic_algorithms(True)
    result=fit_candidate(dev,Base,importlib.import_module('src.engine'),a.rule,GRID[a.rule][a.index],0,
                         torch.device(a.device),a.output_dir,a.epochs,a.patience)
    print(json.dumps({'candidate_complete':result},ensure_ascii=False),flush=True)

if __name__=='__main__': main()
