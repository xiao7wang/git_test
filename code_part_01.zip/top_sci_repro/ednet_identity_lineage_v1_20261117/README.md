# EDNet identity lineage feasibility probe

This is a read-only, bounded and exploratory source-alignment diagnostic. It
does not train models, read the unified test CSV, calculate accuracy, or use
answer/score values. The sampled raw user files contain complete histories and
may therefore include records corresponding to historical test splits. CSV
parsers necessarily read complete source rows, including answer columns; only
student/item identifiers, timestamps, elapsed time and solving ID are used in
memory. Result ZIPs contain only aggregate counts, fingerprints and rules; no
raw IDs, candidate mapping tables, answers or event timestamps are exported.

Train-only unique timestamp anchors nominate raw-user candidates. Separate
valid-only seconds and answer-independent response-time agreement must pass;
ambiguous users and timestamp collisions are rejected within the sampled raw
files, which cannot establish uniqueness across the whole archive. Item candidates require
at least two distinct train users plus an additional valid user, and all
observed one-to-many conflicts are rejected. No candidate is an officially
verified lineage or a verified feedback time.

The code deterministically samples at most 30,000 raw user members from the
existing KT1 ZIP, with a 600-second cap on the first scan phase only. Hashing
the archive, building the ZIP index, validating candidates and packaging are
outside that cap. If the cap or candidate limit is reached, the result is
explicitly marked `complete_limited`; zero observed matches do not prove none
exist. It checks a historical `meta.pkl` with `pickletools` opcodes only; it
never loads or executes the pickle or other historical preprocessing scripts.

The raw archive can have hundreds of thousands of ZIP directory entries;
building the index requires RAM. Existing train and valid CSV hashes and the
prepared-data manifest are pinned to previous project records. Run
`bash run_server.sh server_identity_01`; existing output is never overwritten.
