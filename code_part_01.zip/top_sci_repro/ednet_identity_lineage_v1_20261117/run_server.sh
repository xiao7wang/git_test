#!/usr/bin/env bash
set -Eeuo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_name="${1:-server_identity_01}"
case "$task_name" in ''|*[!A-Za-z0-9_-]*) echo '任务名只允许字母、数字、下划线和短横线' >&2; exit 2;; esac
task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_out="$task_root/outputs/$task_name"
task_log="$task_root/outputs/$task_name.launch.log"
task_zip="$task_out/identity_probe_results.zip"
mkdir -p "$task_root/outputs"
if [ -e "$task_out" ]; then echo "运行目录已存在，停止：$task_out" >&2; exit 1; fi
if ! ( set -C; : > "$task_log" ) 2>/dev/null; then echo "启动日志已存在，停止：$task_log" >&2; exit 1; fi
exec > >(tee -a "$task_log") 2>&1
trap 'task_rc=$?; if [ "$task_rc" -ne 0 ]; then printf "FAILURE: exit=%s; see log above\n" "$task_rc"; fi' EXIT
cd "$task_root"
export PYTHONPATH="$task_root/src:$task_root"
export PYTHONUTF8=1
printf 'Starting %s at %s\n' "$task_name" "$(date -Is)"
echo 'Stage 1/3: verify release and run synthetic matching contracts'
"$task_python" checks/verify.py
"$task_python" -m unittest discover -s tests -p 'test_*.py'
echo 'Stage 2/3: inspect and match bounded, label-free source metadata'
"$task_python" -m lineage_probe.server --output-dir "$task_out" --qccdm-root /home/wangxiao/QCCDM
echo 'Stage 3/3: validate packaged results'
unzip -tqq "$task_zip"
printf 'SUCCESS: %s\n' "$task_zip"
