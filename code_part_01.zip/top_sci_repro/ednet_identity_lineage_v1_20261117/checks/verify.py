import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verify_release():
    raw = (ROOT / 'release_manifest.json').read_bytes()
    files = json.loads(raw)['files']
    required = {'README.md', 'run_server.sh', 'checks/verify.py', 'tests/test_contracts.py',
                'tests/test_pipeline.py', 'src/lineage_probe/matcher.py',
                'src/lineage_probe/probe.py', 'src/lineage_probe/server.py'}
    if not isinstance(files, dict) or not required.issubset(files):
        raise ValueError('release manifest is missing required files')
    for name, digest in files.items():
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file():
            raise ValueError(f'unsafe or missing release file: {name}')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f'release file changed: {name}')
    return {'manifest_sha256': hashlib.sha256(raw).hexdigest(), 'file_count': len(files)}


if __name__ == '__main__':
    print(json.dumps({'phase': 'release_verified', **verify_release()}))
