import csv
import hashlib
import io
import json
import pickle
import tempfile
import unittest
import zipfile
from pathlib import Path

from lineage_probe.probe import (choose_members, inspect_pickle_static, run, sha_file,
                                 _source_second, _raw_second)


def write_fixture(root, *, duplicate=False):
    rows = {'train': [], 'valid': []}
    archive = root / 'raw.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        for person in range(1, 4):
            buf = io.StringIO(newline='')
            w = csv.writer(buf)
            w.writerow(('timestamp', 'solving_id', 'question_id', 'user_answer', 'elapsed_time'))
            base = person * 1000
            for split, start in (('train', base), ('valid', base+100)):
                for j in range(10 if split == 'train' else 5):
                    sec = start + j
                    q1 = (person in (1, 2) and split == 'train') or (person == 3 and split == 'valid') or (person == 1 and split == 'valid' and j == 0)
                    question, item = ('private_q_A', 'ITEM_A') if q1 else ('private_q_B', 'ITEM_B')
                    group = 'cross_group' if person == 1 and j == 0 else f'{split}_{j}'
                    rows[split].append([f'PERSON_{person}', item, 'secret_answer', '1.0', str(sec)])
                    w.writerow((sec*1000+123, group, question, 'secret_answer', 1000))
            content = buf.getvalue()
            z.writestr(f'KT1/KT1/u{100+person}.csv', content)
            if person == 1 and duplicate:
                z.writestr('KT1/KT1/u104.csv', content)
    for split in ('train', 'valid'):
        with (root / f'{split}.csv').open('w', encoding='utf-8', newline='') as f:
            w = csv.writer(f)
            w.writerow(('student_id', 'exercise_id', 'score', 'response_time', 'timestamp'))
            w.writerows(rows[split])
    return root / 'train.csv', root / 'valid.csv', archive


def run_fixture(root, *, duplicate=False, seconds=15):
    train, valid, archive = write_fixture(root, duplicate=duplicate)
    out = root / 'result'
    result = run(train, valid, archive, out, expected_train_sha=sha_file(train), expected_valid_sha=sha_file(valid),
                 sample_limit=10, scan_seconds=seconds, metadata={'synthetic': True})
    with zipfile.ZipFile(result) as z:
        assert z.testzip() is None
        manifest = json.loads(z.read('manifest.json'))['files']
        assert set(z.namelist()) == set(manifest) | {'manifest.json'}
        assert all(hashlib.sha256(z.read(name)).hexdigest() == digest for name, digest in manifest.items())
        return json.loads(z.read('summary.json')), '\n'.join(z.read(name).decode('utf-8') for name in manifest)


class PipelineContracts(unittest.TestCase):
    def test_full_sample_stages_and_no_identity_export(self):
        with tempfile.TemporaryDirectory(prefix='identity_probe_') as temp:
            summary, contents = run_fixture(Path(temp))
            self.assertEqual(summary['status'], 'complete')
            self.assertEqual(summary['sampling']['files_processed'], 3)
            self.assertEqual(summary['candidate_validation']['accepted_user_candidates'], 3)
            self.assertEqual(summary['question_evidence']['accepted_item_pairs'], 1)
            self.assertEqual(summary['solving_group_evidence']['candidate_groups_crossing_train_valid'], 1)
            self.assertFalse(summary['test_file_read'])
            self.assertFalse(summary['answers_or_scores_used'])
            for secret in ('PERSON_', 'private_q_', 'secret_answer', 'u101.csv', '1000123'):
                self.assertNotIn(secret, contents)

    def test_duplicate_raw_student_candidates_are_quarantined(self):
        with tempfile.TemporaryDirectory(prefix='identity_duplicate_') as temp:
            summary, _ = run_fixture(Path(temp), duplicate=True)
            self.assertEqual(summary['candidate_validation']['conflicted_users'], 1)
            self.assertEqual(summary['candidate_validation']['accepted_user_candidates'], 2)
            self.assertEqual(summary['question_evidence']['accepted_item_pairs'], 0)

    def test_zero_scan_budget_is_explicitly_incomplete(self):
        with tempfile.TemporaryDirectory(prefix='identity_limited_') as temp:
            summary, _ = run_fixture(Path(temp), seconds=0)
            self.assertEqual(summary['status'], 'complete_limited')
            self.assertEqual(summary['scan_stop_reason'], 'time_budget')
            self.assertFalse(summary['scan_completed_requested_sample'])
            self.assertEqual(summary['sampling'].get('files_processed', 0), 0)

    def test_candidate_overflow_never_selects_an_arbitrary_prefix(self):
        with tempfile.TemporaryDirectory(prefix='identity_overflow_') as temp:
            root = Path(temp)
            train, valid, archive = write_fixture(root)
            result = run(train, valid, archive, root / 'result',
                         expected_train_sha=sha_file(train), expected_valid_sha=sha_file(valid),
                         sample_limit=10, scan_seconds=15, max_proposals=1)
            with zipfile.ZipFile(result) as z:
                summary = json.loads(z.read('summary.json'))
            self.assertEqual(summary['status'], 'complete_limited')
            self.assertEqual(summary['scan_stop_reason'], 'proposal_cap')
            self.assertGreater(summary['sampling']['time_candidate'], 1)
            self.assertEqual(summary['candidate_validation']['accepted_user_candidates'], 0)

    def test_empty_raw_archive_is_limited_not_positive_evidence(self):
        with tempfile.TemporaryDirectory(prefix='identity_empty_') as temp:
            root = Path(temp)
            train, valid, archive = write_fixture(root)
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('readme.txt', 'no raw users')
            result = run(train, valid, archive, root / 'result',
                         expected_train_sha=sha_file(train), expected_valid_sha=sha_file(valid),
                         sample_limit=10, scan_seconds=15)
            with zipfile.ZipFile(result) as z:
                summary = json.loads(z.read('summary.json'))
            self.assertEqual(summary['status'], 'complete_limited')
            self.assertEqual(summary['scan_stop_reason'], 'no_eligible_raw_members')

    def test_wrong_source_hash_fails_without_results(self):
        with tempfile.TemporaryDirectory(prefix='identity_sha_') as temp:
            root = Path(temp)
            train, valid, archive = write_fixture(root)
            out = root / 'result'
            with self.assertRaises(ValueError):
                run(train, valid, archive, out, expected_train_sha='wrong', expected_valid_sha=sha_file(valid))
            self.assertEqual(json.loads((out / 'status.json').read_text())['status'], 'failed')
            self.assertFalse((out / 'identity_probe_results.zip').exists())

    def test_deterministic_sampling_and_duplicate_basename_quarantine(self):
        with tempfile.TemporaryDirectory(prefix='identity_sampling_') as temp:
            paths = []
            for index, names in enumerate((['a/u1.csv', 'a/u2.csv', 'a/u3.csv', 'b/u1.csv'],
                                           ['b/u1.csv', 'a/u3.csv', 'a/u2.csv', 'a/u1.csv'])):
                p = Path(temp) / f'{index}.zip'
                with zipfile.ZipFile(p, 'w') as z:
                    for name in names:
                        z.writestr(name, '')
                with zipfile.ZipFile(p) as z:
                    selected, stats = choose_members(z, 10)
                    paths.append([i.filename for i in selected])
                    self.assertEqual(stats['duplicate_raw_user_basenames'], 1)
            self.assertEqual(paths[0], paths[1])
            self.assertEqual(set(paths[0]), {'a/u2.csv', 'a/u3.csv'})

    def test_pickle_opcodes_only_and_time_conversion(self):
        with tempfile.TemporaryDirectory(prefix='identity_pickle_') as temp:
            path = Path(temp) / 'meta.pkl'
            path.write_bytes(pickle.dumps({'raw_user_map': {'secret_id': 1}, 'raw_item_map': {}}))
            result = inspect_pickle_static(path)
            self.assertEqual(result['named_mapping_keys_seen'], ['raw_item_map', 'raw_user_map'])
            self.assertFalse(result['pickle_loaded'])
            self.assertNotIn('secret_id', json.dumps(result))
            self.assertEqual(_raw_second('1565096190868'), 1565096190)
            self.assertEqual(_source_second('1565096190.999'), 1565096190)
            self.assertIsNone(_raw_second('broken'))


if __name__ == '__main__':
    unittest.main()
