import unittest

from lineage_probe.matcher import (build_index, propose_user, select_users,
                                   unique_event_pairs, select_items, summarize_groups)


def reference():
    train = [(1, i) for i in range(100, 110)] + [(2, i) for i in range(300, 310)]
    valid = [(1, i) for i in range(200, 205)] + [(2, i) for i in range(400, 405)]
    return build_index(train, valid)


def event(user, split, item, question, group='g', span=False):
    return {'user': user, 'split': split, 'item': item, 'question': question,
            'solving': group, 'raw_group_size': 2, 'raw_group_spans_seconds': span}


class UserMatchingContracts(unittest.TestCase):
    def test_train_anchors_and_separate_validation_support(self):
        proposal = propose_user(set(range(100, 110)) | set(range(200, 205)), reference())
        self.assertEqual(proposal['status'], 'time_candidate')
        self.assertEqual(proposal['user'], 1)
        self.assertEqual(proposal['train_anchor_matches'], 10)
        self.assertEqual(proposal['valid_matches'], 5)

    def test_collision_between_reference_users_is_not_an_anchor(self):
        idx = build_index([(1, i) for i in range(100, 108)] + [(2, 100)], [(1, i) for i in range(200, 205)])
        self.assertNotIn(100, idx['unique_owners'])
        self.assertEqual(propose_user(set(range(100, 108)) | set(range(200, 205)), idx)['status'], 'insufficient_train_anchors')

    def test_two_users_above_threshold_is_ambiguous(self):
        proposal = propose_user(set(range(100, 110)) | set(range(300, 310)) | set(range(200, 205)), reference())
        self.assertEqual(proposal['status'], 'ambiguous_train_users')
        self.assertNotIn('user', proposal)

    def test_validation_must_be_separate_from_training_seconds(self):
        idx = build_index([(1, i) for i in range(10, 20)], [(1, i) for i in range(10, 20)])
        proposal = propose_user(set(range(10, 20)), idx)
        self.assertEqual(proposal['status'], 'insufficient_validation_times')

    def test_validation_fraction_below_threshold_is_rejected(self):
        proposal = propose_user(set(range(100, 110)) | {200, 201, 202}, reference())
        self.assertEqual(proposal['status'], 'validation_time_mismatch')

    def test_multiple_raw_candidates_for_same_user_are_all_rejected(self):
        a = {'raw_key': 'a', 'user': 1, 'rt_checked': 3, 'rt_matched': 3}
        b = {'raw_key': 'b', 'user': 1, 'rt_checked': 3, 'rt_matched': 3}
        c = {'raw_key': 'c', 'user': 2, 'rt_checked': 4, 'rt_matched': 4}
        selected, stats = select_users([a, b, c])
        self.assertEqual([x['raw_key'] for x in selected], ['c'])
        self.assertEqual(stats['conflicted_users'], 1)

    def test_insufficient_or_inconsistent_rt_never_qualifies(self):
        cases = [{'raw_key': 'a', 'user': 1, 'rt_checked': 2, 'rt_matched': 2},
                 {'raw_key': 'b', 'user': 2, 'rt_checked': 5, 'rt_matched': 3},
                 {'raw_key': 'c', 'user': 3, 'rt_checked': 5, 'rt_matched': 4}]
        selected, stats = select_users(cases)
        self.assertEqual([x['raw_key'] for x in selected], ['c'])
        self.assertEqual(stats['insufficient_rt'], 1)
        self.assertEqual(stats['rt_mismatch'], 1)


class EventAndItemContracts(unittest.TestCase):
    def test_seconds_with_duplicate_records_or_rt_mismatch_do_not_pair(self):
        ref = {10: [{'item': 1, 'rt_ms': 1000, 'split': 'train'}],
               11: [{'item': 2, 'rt_ms': 500, 'split': 'train'}, {'item': 3, 'rt_ms': 500, 'split': 'valid'}],
               12: [{'item': 2, 'rt_ms': 500, 'split': 'valid'}],
               13: [{'item': 2, 'rt_ms': 500, 'split': 'valid'}]}
        raw = {10: [{'question': 'q1', 'rt_ms': 1000, 'solving': 'g'}],
               11: [{'question': 'q2', 'rt_ms': 500, 'solving': 'g'}],
               12: [{'question': 'q2', 'rt_ms': 500, 'solving': 'g'}, {'question': 'q3', 'rt_ms': 500, 'solving': 'g'}],
               13: [{'question': 'q2', 'rt_ms': 505, 'solving': 'g'}]}
        pairs, stats = unique_event_pairs(ref, raw)
        self.assertEqual([r['second'] for r in pairs], [10])
        self.assertEqual(stats['ambiguous_reference_seconds'], 1)
        self.assertEqual(stats['ambiguous_raw_seconds'], 1)
        self.assertEqual(stats['rt_mismatch'], 1)

    def test_items_require_two_training_users_and_new_validation_user(self):
        events = [event(1, 'train', 10, 'q10'), event(2, 'train', 10, 'q10'),
                  event(3, 'valid', 10, 'q10'), event(1, 'train', 11, 'q11'),
                  event(1, 'train', 11, 'q11'), event(1, 'valid', 11, 'q11')]
        accepted, stats = select_items(events)
        self.assertEqual(accepted, {('q10', 10)})
        self.assertEqual(stats['accepted_item_pairs'], 1)

    def test_competing_item_evidence_is_not_resolved_by_majority_vote(self):
        events = [event(1, 'train', 10, 'q10'), event(2, 'train', 10, 'q10'),
                  event(3, 'valid', 10, 'q10'), event(4, 'train', 10, 'q99')]
        accepted, stats = select_items(events)
        self.assertEqual(accepted, set())
        self.assertGreater(stats['conflicted_pairs'], 0)

    def test_same_user_multiple_events_do_not_replace_two_student_support(self):
        events = [event(1, 'train', 10, 'q10') for _ in range(10)] + [event(2, 'valid', 10, 'q10')]
        accepted, _ = select_items(events)
        self.assertEqual(accepted, set())

    def test_solving_ids_scoped_per_user_and_only_accepted_items_count(self):
        events = [event(1, 'train', 10, 'q10', 'g', True), event(1, 'valid', 10, 'q10', 'g', True),
                  event(2, 'train', 10, 'q10', 'g', False), event(2, 'valid', 11, 'q11', 'g', False)]
        result = summarize_groups(events, {('q10', 10)})
        self.assertEqual(result['candidate_event_pairs'], 3)
        self.assertEqual(result['candidate_solving_groups'], 2)
        self.assertEqual(result['candidate_groups_crossing_train_valid'], 1)
        self.assertEqual(result['candidate_groups_spanning_raw_seconds'], 1)


if __name__ == '__main__':
    unittest.main()
