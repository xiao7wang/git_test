"""Read-only, bounded EDNet timestamp and question identity evidence probe.

No raw identifiers, answers, timestamps, or mapping tables are written to
outputs. A candidate is not verified ancestry and is never written back to a
source dataset. Unified train/valid metadata are aligned; the raw ZIP contains
whole user histories, which can include records from historical test splits.
"""
from __future__ import annotations

import collections
import csv
import hashlib
import heapq
import io
import json
import math
import pickletools
import re
import statistics
import sys
import time
import zipfile
from pathlib import Path, PurePosixPath

from .matcher import (build_index, propose_user, select_users, unique_event_pairs,
                      select_items, summarize_groups)

SALT = b'ednet-lineage-sample-v1-20261117:'
MEMBER = re.compile(r'^u[0-9]+\.csv$')
MAX_MEMBER_BYTES = 8 * 1024 * 1024


def sha_file(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path, value):
    path = Path(path)
    pending = path.with_suffix(path.suffix + '.pending')
    pending.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    pending.replace(path)


def _source_second(value):
    try:
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            return None
        return math.floor(number)
    except (TypeError, ValueError, OverflowError):
        return None


def _raw_second(value):
    try:
        number = int(value)
        return number // 1000 if number > 0 else None
    except (TypeError, ValueError, OverflowError):
        return None


def _source_rt_ms(value):
    try:
        number = float(value)
        if not math.isfinite(number) or number <= 0:
            return None
        return int(round(number * 1000))
    except (TypeError, ValueError, OverflowError):
        return None


def _raw_rt_ms(value):
    try:
        number = int(value)
        return number if number > 0 else None
    except (TypeError, ValueError, OverflowError):
        return None


def read_reference(path, split):
    """Read only student, item, event time and RT; never use the score column."""
    rows = []
    stats = {'rows_seen': 0, 'rows_usable': 0, 'invalid_time_or_id': 0,
             'missing_or_nonpositive_rt': 0, 'fractional_source_seconds': 0}
    with Path(path).open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        needed = {'student_id', 'exercise_id', 'timestamp', 'response_time'}
        if not needed.issubset(reader.fieldnames or []):
            raise ValueError(f'{split} reference header missing required fields')
        for row in reader:
            stats['rows_seen'] += 1
            user, item = row['student_id'].strip(), row['exercise_id'].strip()
            sec = _source_second(row['timestamp'])
            if not user or not item or sec is None:
                stats['invalid_time_or_id'] += 1
                continue
            try:
                stats['fractional_source_seconds'] += int(float(row['timestamp']) != sec)
            except (ValueError, TypeError):
                pass
            rt = _source_rt_ms(row['response_time'])
            if rt is None:
                stats['missing_or_nonpositive_rt'] += 1
            rows.append((sys.intern(user), sec, sys.intern(item), rt, split))
            stats['rows_usable'] += 1
    return rows, stats


def _member_key(info):
    name = PurePosixPath(info.filename)
    if name.is_absolute() or '..' in name.parts or not MEMBER.fullmatch(name.name) or info.is_dir():
        return None
    return name.name


def choose_members(archive, limit):
    """Deterministic hash-ranked sample; exclude duplicated raw user basenames."""
    infos = archive.infolist()
    names = collections.Counter(key for info in infos if (key := _member_key(info)) is not None)
    eligible = [info for info in infos if (key := _member_key(info)) is not None and names[key] == 1]
    def rank(info):
        return (hashlib.sha256(SALT + info.filename.encode('utf-8')).digest(), info.filename)
    chosen = heapq.nsmallest(min(limit, len(eligible)), eligible, key=rank)
    return chosen, {'archive_members': len(infos), 'raw_user_csv_members': sum(names.values()),
                    'duplicate_raw_user_basenames': sum(n > 1 for n in names.values()),
                    'eligible_unique_user_members': len(eligible), 'requested_sample_size': limit,
                    'selected_user_members': len(chosen),
                    'sampling': 'smallest SHA256(salt + ZIP member name), deterministic; no outcome-based selection'}


def _open_csv(archive, info):
    if info.file_size > MAX_MEMBER_BYTES:
        raise ValueError('raw member exceeds 8 MiB cap')
    return io.TextIOWrapper(archive.open(info, 'r'), encoding='utf-8-sig', newline='')


def raw_seconds(archive, info):
    seconds = set()
    with _open_csv(archive, info) as f:
        reader = csv.DictReader(f)
        if not {'timestamp', 'question_id', 'solving_id', 'elapsed_time'}.issubset(reader.fieldnames or []):
            raise ValueError('raw KT1 header differs')
        for row in reader:
            sec = _raw_second(row['timestamp'])
            if sec is None:
                raise ValueError('invalid raw timestamp')
            seconds.add(sec)
    return seconds


def raw_events(archive, info):
    """Read candidate file only; user_answer is never used or retained."""
    by_second = collections.defaultdict(list)
    groups = {}
    with _open_csv(archive, info) as f:
        reader = csv.DictReader(f)
        if not {'timestamp', 'question_id', 'solving_id', 'elapsed_time'}.issubset(reader.fieldnames or []):
            raise ValueError('raw KT1 header differs')
        for row in reader:
            sec = _raw_second(row['timestamp'])
            question, solving = row['question_id'].strip(), row['solving_id'].strip()
            if sec is None or not question or not solving:
                raise ValueError('raw candidate event missing timestamp, question or solving ID')
            group = groups.setdefault(solving, [0, sec, sec])
            group[0] += 1
            group[1], group[2] = min(group[1], sec), max(group[2], sec)
            by_second[sec].append({'question': question, 'solving': solving,
                                   'rt_ms': _raw_rt_ms(row['elapsed_time'])})
    for rows in by_second.values():
        for row in rows:
            group = groups[row['solving']]
            row['raw_group_size'] = group[0]
            row['raw_group_spans_seconds'] = group[1] != group[2]
    return by_second


def inspect_pickle_static(path):
    """Recognize named string opcodes only; never load or execute pickle."""
    path = Path(path)
    report = {'exists': path.is_file(), 'pickle_loaded': False, 'pickle_executed': False,
              'named_mapping_keys_seen': [], 'scope': 'pickletools opcode inspection; no object reconstruction'}
    if not report['exists']:
        return report
    try:
        size = path.stat().st_size
        report.update(bytes=size, sha256=sha_file(path))
        if size > 16 * 1024 * 1024:
            report['inspection'] = 'skipped_size_limit'
            return report
        wanted = {'raw_user_map', 'raw_item_map', 'raw_know_map'}
        seen = set()
        for opcode, value, position in pickletools.genops(path.read_bytes()):
            if isinstance(value, str) and value in wanted:
                seen.add(value)
        report['named_mapping_keys_seen'] = sorted(seen)
        report['inspection'] = 'parsed'
    except Exception as exc:
        report['inspection'] = 'unreadable_or_unparseable'
        report['error_type'] = type(exc).__name__
    return report


def _package(output, names):
    output = Path(output)
    pending, final = output / 'identity_probe_results.zip.pending', output / 'identity_probe_results.zip'
    if pending.exists() or final.exists():
        raise FileExistsError('result archive already exists')
    hashes = {name: sha_file(output / name) for name in names}
    with zipfile.ZipFile(pending, 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for name in names:
            z.write(output / name, name)
        z.writestr('manifest.json', json.dumps({'format': 1, 'files': hashes}, indent=2) + '\n')
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or set(z.namelist()) != set(names) | {'manifest.json'}:
            raise ValueError('result archive CRC or members differ')
        for name, digest in hashes.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise ValueError(f'result member hash differs: {name}')
    pending.replace(final)
    return str(final)


def run(train_path, valid_path, raw_zip, output, *, expected_train_sha, expected_valid_sha,
        expected_data_manifest_sha=None, data_manifest=None, pickle_path=None,
        sample_limit=30000, scan_seconds=600, max_proposals=5000, metadata=None):
    """Probe source metadata and a bounded raw sample; never write source data."""
    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    status = {'status': 'running', 'phase': 'source_hashes', 'processed_raw_files': 0,
              'test_file_read': False, 'models_trained': False}
    write_json(output / 'status.json', status)
    try:
        print(json.dumps({'phase': status['phase']}), flush=True)
        if sample_limit < 1 or scan_seconds < 0 or max_proposals < 1:
            raise ValueError('invalid sample, time or proposal limit')
        if expected_data_manifest_sha and sha_file(data_manifest) != expected_data_manifest_sha:
            raise ValueError('prepared EDNet manifest hash mismatch')
        train_sha, valid_sha = sha_file(train_path), sha_file(valid_path)
        if train_sha != expected_train_sha or valid_sha != expected_valid_sha:
            raise ValueError('train/valid CSV does not match previously audited source hash')
        if not Path(raw_zip).is_file():
            raise FileNotFoundError('raw KT1 ZIP unavailable at expected path')
        status['phase'] = 'hash_raw_archive'
        write_json(output / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        raw_zip_sha = sha_file(raw_zip)
        source_checks = {'train_sha256': train_sha, 'valid_sha256': valid_sha,
                         'prepared_manifest_sha256': expected_data_manifest_sha,
                         'raw_zip_sha256': raw_zip_sha, 'raw_zip_bytes': Path(raw_zip).stat().st_size,
                         'raw_zip_scope': 'computed file hash identifies inspected archive; not proof of official source',
                         'pickle_static_inspection': inspect_pickle_static(pickle_path) if pickle_path else {'exists': False},
                         'unified_test_csv_read': False,
                         'raw_full_histories_may_include_historical_test_rows': True,
                         'raw_csv_parser_reads_answer_column_but_does_not_use_it': True,
                         'test_file_read': False, 'answers_or_scores_used': False}
        write_json(output / 'source_checks.json', source_checks)
        config = {'protocol': 'ednet_train_anchor_valid_rt_identity_probe_v1',
                  'raw_archive_sample_limit': sample_limit, 'scan_time_limit_seconds': scan_seconds,
                  'candidate_limit': max_proposals, 'sampling_salt': SALT.decode('ascii'),
                  'user_candidate_rule': '>=8 distinct train seconds unique across unified train users; >=3 valid-only seconds and >=80% valid-only second match; >=3 valid unique-second RT checks and >=80% RT match within 1ms; no user/raw-file conflict',
                  'event_candidate_rule': 'same floored second, exactly one raw and one unified train-or-valid row, valid RT on both sides within 1ms',
                  'item_candidate_rule': 'one-to-one observed mapping, >=2 distinct train users and >=1 additional valid user',
                  'assumptions': ['raw timestamp interpreted as milliseconds and unified timestamp as seconds',
                                  'raw elapsed_time interpreted as ms and unified response_time as seconds',
                                  'a passing candidate is not verified official ancestry or true feedback timing',
                                  'one-to-one conflict screening is only among sampled raw files',
                                  'sampled archive coverage and candidate thresholds cause false negatives',
                                  'raw user files contain complete histories, including possible historical test rows; no answer values are used',
                                  'valid metadata are used for validation; this is not an independent model test'],
                  'privacy': 'results contain aggregate counts and hashes only; no raw IDs, event timestamps, question IDs, answers or mappings',
                  'metadata': metadata or {}}
        write_json(output / 'config.json', config)
        status['phase'] = 'reference_index'
        write_json(output / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        train, train_stats = read_reference(train_path, 'train')
        valid, valid_stats = read_reference(valid_path, 'valid')
        if not train or not valid:
            raise ValueError('train or valid has no usable reference rows')
        index = build_index(((r[0], r[1]) for r in train), ((r[0], r[1]) for r in valid))
        index_summary = {'train_users_with_usable_times': index['train_users'],
                         'globally_unique_train_seconds': len(index['unique_owners']),
                         'ambiguous_global_train_seconds': index['ambiguous_global_train_seconds']}
        status['phase'] = 'scan_raw_archive'
        write_json(output / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        counts = collections.Counter()
        time_candidates = []
        deadline_reached = False
        overflow = False
        with zipfile.ZipFile(raw_zip) as archive:
            selected, sample_info = choose_members(archive, sample_limit)
            deadline = time.monotonic() + scan_seconds
            for info in selected:
                if time.monotonic() >= deadline:
                    deadline_reached = True
                    break
                counts['files_processed'] += 1
                try:
                    seconds = raw_seconds(archive, info)
                    counts['files_read_ok'] += 1
                    result = propose_user(seconds, index)
                    counts[result['status']] += 1
                    if result['status'] == 'time_candidate':
                        time_candidates.append((info, result))
                        if len(time_candidates) > max_proposals:
                            overflow = True
                            break
                except (OSError, ValueError, UnicodeError, csv.Error, zipfile.BadZipFile):
                    counts['files_skipped_invalid_or_oversize'] += 1
                if counts['files_processed'] % 1000 == 0:
                    status.update(processed_raw_files=counts['files_processed'],
                                  selected_raw_files=len(selected), time_candidates=len(time_candidates))
                    write_json(output / 'status.json', status)
                    print(json.dumps({'phase': status['phase'], 'processed_raw_files': counts['files_processed'],
                                      'selected_raw_files': len(selected), 'time_candidates': len(time_candidates)}), flush=True)
            if overflow:
                # An overflowing candidate set is incomplete: never confirm a prefix.
                time_candidates = []
            status.update(phase='validation_and_item_evidence', processed_raw_files=counts['files_processed'])
            write_json(output / 'status.json', status)
            print(json.dumps({'phase': status['phase'], 'time_candidates': len(time_candidates)}), flush=True)
            target_users = {candidate['user'] for _, candidate in time_candidates}
            reference = collections.defaultdict(lambda: collections.defaultdict(list))
            for user, sec, item, rt, split in train:
                if user in target_users:
                    reference[user][sec].append({'item': item, 'rt_ms': rt, 'split': split})
            for user, sec, item, rt, split in valid:
                if user in target_users:
                    reference[user][sec].append({'item': item, 'rt_ms': rt, 'split': split})
            candidates = []
            pair_stats = collections.Counter()
            for info, candidate in time_candidates:
                try:
                    raw = raw_events(archive, info)
                    ref = reference[candidate['user']]
                    valid_ref = {sec: rows for sec, rows in ref.items() if len(rows) == 1 and rows[0]['split'] == 'valid'}
                    _, rt = unique_event_pairs(valid_ref, raw)
                    pairs, general = unique_event_pairs(ref, raw)
                    pair_stats.update(general)
                    for pair in pairs:
                        pair['user'] = candidate['user']
                    candidates.append({**candidate, 'raw_key': info.filename,
                                       'rt_checked': rt['rt_checked'], 'rt_matched': rt['matched_seconds'],
                                       'events': pairs})
                except (OSError, ValueError, UnicodeError, csv.Error, zipfile.BadZipFile):
                    counts['candidate_reread_failed'] += 1
            selected_users, user_stats = select_users(candidates)
            events = [e for c in selected_users for e in c['events']]
            items, item_stats = select_items(events)
            groups = summarize_groups(events, items)
        no_members = sample_info['eligible_unique_user_members'] == 0
        complete_sample = (not no_members and not deadline_reached and not overflow and
                           counts['files_processed'] == sample_info['selected_user_members'])
        stop_reason = ('no_eligible_raw_members' if no_members else 'proposal_cap' if overflow else
                       'time_budget' if deadline_reached else 'sample_complete')
        count_fields = ('files_processed', 'files_read_ok', 'files_skipped_invalid_or_oversize',
                        'insufficient_train_anchors', 'ambiguous_train_users',
                        'insufficient_validation_times', 'validation_time_mismatch', 'time_candidate',
                        'candidate_reread_failed')
        summary = {'status': 'complete' if complete_sample else 'complete_limited',
                   'scan_completed_requested_sample': complete_sample,
                   'scan_stop_reason': stop_reason, 'no_raw_members_found': no_members,
                   'reference': {'train': train_stats, 'valid': valid_stats, **index_summary},
                   'sampling': {**sample_info, **{key: int(counts[key]) for key in count_fields},
                                'time_budget_seconds': scan_seconds},
                   'candidate_validation': {**user_stats, 'candidate_files_rechecked': len(candidates),
                                            'pair_checks_before_user_conflict_filter': dict(pair_stats)},
                   'question_evidence': item_stats, 'solving_group_evidence': groups,
                   'scope': 'candidate alignment in a bounded sample only; not verified ancestry, official identity mapping or feedback availability',
                   'models_trained': False, 'test_file_read': False,
                   'raw_full_histories_may_include_historical_test_rows': True,
                   'answers_or_scores_used': False,
                   'seconds_before_packaging': time.monotonic() - start}
        write_json(output / 'summary.json', summary)
        archive_path = _package(output, ['config.json', 'source_checks.json', 'summary.json'])
        status.update(status=summary['status'], phase='complete', result_archive=archive_path,
                      scan_completed_requested_sample=complete_sample, seconds=time.monotonic()-start)
        write_json(output / 'status.json', status)
        print(json.dumps({'phase': 'complete', 'status': status['status'], 'archive': archive_path}), flush=True)
        return archive_path
    except BaseException as exc:
        status.update(status='failed', phase='failed', error=repr(exc), seconds=time.monotonic()-start)
        write_json(output / 'status.json', status)
        raise
