"""Pinned server entry for read-only, bounded identity lineage analysis."""
import argparse
import json
import platform
import shutil
from pathlib import Path

from .probe import run

ROOT = Path(__file__).resolve().parents[2]
DATA_MANIFEST_SHA = 'fa8198274d35d980169ba71acf3792cdd2e9892eb28504fc1081a4ae6179da09'
TRAIN_SHA = '558dd2caf1a55a98c68ab78398da2571970bd2376a4dc7c4681ea87cf818e141'
VALID_SHA = '6e258abc7eb441365474dffded9c9c2a4bd0046ab8555ed9e3e560d166330d33'


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--qccdm-root', default='/home/wangxiao/QCCDM')
    args = parser.parse_args(argv)
    from checks.verify import verify_release
    release = verify_release()
    output = Path(args.output_dir).resolve()
    allowed = (ROOT / 'outputs').resolve()
    if output == allowed or not output.is_relative_to(allowed) or output.exists():
        raise ValueError('output must be a new child of the release outputs directory')
    free = shutil.disk_usage(allowed).free
    if free < 536870912:
        raise OSError(f'free space below 512 MiB: {free}')
    root = Path(args.qccdm_root)
    base = root / 'top_sci_repro'
    splits = base / 'unified_experiments' / 'splits' / 'ednet'
    raw_root = root / 'qccdm改进代码'
    metadata = {'release': release, 'python': platform.python_version(),
                'free_bytes_at_start': free, 'device': 'CPU/read-only source scan'}
    archive = run(splits / 'train.csv', splits / 'valid.csv',
                  raw_root / 'data_raw' / 'ednet' / 'EdNet-KT1.zip', output,
                  expected_train_sha=TRAIN_SHA, expected_valid_sha=VALID_SHA,
                  expected_data_manifest_sha=DATA_MANIFEST_SHA,
                  data_manifest=base / 'uctp_cd_clean_research' / 'data' / 'ednet_full' / 'manifest.json',
                  pickle_path=raw_root / 'data' / 'ednet_kt1_time' / 'meta.pkl',
                  sample_limit=30000, scan_seconds=600, max_proposals=5000, metadata=metadata)
    print(json.dumps({'status': 'complete_or_limited', 'archive': archive}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
