"""Bounded, evidence-gated EDNet identity lineage probe."""

