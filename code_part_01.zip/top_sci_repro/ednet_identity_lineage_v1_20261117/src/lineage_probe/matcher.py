"""Strict candidate matching: collisions remain unresolved, never guessed.

The result is diagnostic evidence, not a verified official identity or a
verified feedback boundary. Current answers/scores are not used by this code.
"""
from collections import Counter, defaultdict


def build_index(train_user_seconds, valid_user_seconds):
    owners = {}
    train_by_user = defaultdict(set)
    valid_by_user = defaultdict(set)
    for user, second in train_user_seconds:
        second = int(second)
        train_by_user[user].add(second)
        if second not in owners:
            owners[second] = user
        elif owners[second] != user:
            owners[second] = None
    for user, second in valid_user_seconds:
        valid_by_user[user].add(int(second))
    unique = {sec: user for sec, user in owners.items() if user is not None}
    valid_only = {user: seconds - train_by_user[user] for user, seconds in valid_by_user.items()}
    return {'unique_owners': unique, 'valid_only': valid_only,
            'train_users': len(train_by_user),
            'ambiguous_global_train_seconds': sum(user is None for user in owners.values())}


def propose_user(raw_seconds, index):
    """Use >=8 unique train seconds and >=3 independent valid seconds at >=80%."""
    seconds = set(raw_seconds)
    owners = index['unique_owners']
    votes = Counter(owners[s] for s in seconds if s in owners)
    qualified = [(user, count) for user, count in votes.items() if count >= 8]
    if not qualified:
        return {'status': 'insufficient_train_anchors'}
    if len(qualified) != 1:
        return {'status': 'ambiguous_train_users'}
    user, train_matches = qualified[0]
    valid = index['valid_only'].get(user, set())
    if len(valid) < 3:
        return {'status': 'insufficient_validation_times'}
    matched = len(seconds & valid)
    if matched < 3 or matched / len(valid) < .8:
        return {'status': 'validation_time_mismatch'}
    return {'status': 'time_candidate', 'user': user, 'train_anchor_matches': train_matches,
            'valid_only_seconds': len(valid), 'valid_matches': matched}


def select_users(candidates):
    """Require >=3 comparable validation RTs, >=80% agreement, and one-to-one."""
    rt_pass = []
    stats = {'insufficient_rt': 0, 'rt_mismatch': 0, 'conflicted_users': 0,
             'conflicted_raw_files': 0, 'accepted_user_candidates': 0}
    for c in candidates:
        checked, matched = int(c['rt_checked']), int(c['rt_matched'])
        if checked < 3:
            stats['insufficient_rt'] += 1
        elif matched / checked < .8:
            stats['rt_mismatch'] += 1
        else:
            rt_pass.append(c)
    users = Counter(c['user'] for c in rt_pass)
    raw = Counter(c['raw_key'] for c in rt_pass)
    stats['conflicted_users'] = sum(count > 1 for count in users.values())
    stats['conflicted_raw_files'] = sum(count > 1 for count in raw.values())
    selected = [c for c in rt_pass if users[c['user']] == 1 and raw[c['raw_key']] == 1]
    stats['accepted_user_candidates'] = len(selected)
    return selected, stats


def unique_event_pairs(reference_by_second, raw_by_second):
    """Pair only one-to-one seconds with known response times matching <=1ms."""
    pairs = []
    stats = {'shared_seconds': 0, 'ambiguous_reference_seconds': 0, 'ambiguous_raw_seconds': 0,
             'missing_rt': 0, 'rt_checked': 0, 'rt_mismatch': 0, 'matched_seconds': 0}
    for sec in sorted(set(reference_by_second) & set(raw_by_second)):
        stats['shared_seconds'] += 1
        ref, raw = reference_by_second[sec], raw_by_second[sec]
        if len(ref) != 1:
            stats['ambiguous_reference_seconds'] += 1
        if len(raw) != 1:
            stats['ambiguous_raw_seconds'] += 1
        if len(ref) != 1 or len(raw) != 1:
            continue
        a, b = ref[0], raw[0]
        if a.get('rt_ms') is None or b.get('rt_ms') is None:
            stats['missing_rt'] += 1
            continue
        stats['rt_checked'] += 1
        if abs(a['rt_ms'] - b['rt_ms']) > 1:
            stats['rt_mismatch'] += 1
            continue
        pairs.append({'second': sec, 'split': a['split'], 'item': a['item'],
                      'question': b['question'], 'solving': b['solving'],
                      'raw_group_size': b.get('raw_group_size', 1),
                      'raw_group_spans_seconds': b.get('raw_group_spans_seconds', False)})
        stats['matched_seconds'] += 1
    return pairs, stats


def select_items(events):
    """No conflicts; >=2 train users and a distinct additional validation user."""
    train, valid = defaultdict(set), defaultdict(set)
    by_question, by_item = defaultdict(set), defaultdict(set)
    for e in events:
        pair = (e['question'], e['item'])
        by_question[pair[0]].add(pair[1])
        by_item[pair[1]].add(pair[0])
        if e['split'] == 'train':
            train[pair].add(e['user'])
        elif e['split'] == 'valid':
            valid[pair].add(e['user'])
        else:
            raise ValueError('only train and valid event pairs are allowed')
    seen = set(train) | set(valid)
    conflicts = {pair for pair in seen if len(by_question[pair[0]]) != 1 or len(by_item[pair[1]]) != 1}
    accepted = {pair for pair in seen - conflicts
                if len(train[pair]) >= 2 and len(valid[pair] - train[pair]) >= 1}
    return accepted, {'observed_item_pairs': len(seen), 'conflicted_pairs': len(conflicts),
                      'accepted_item_pairs': len(accepted),
                      'rule': 'one-to-one; >=2 distinct train users; >=1 different valid user'}


def summarize_groups(events, accepted_items):
    """Only aggregate candidate events; IDs and solving_id values stay in memory."""
    groups = defaultdict(list)
    for e in events:
        if (e['question'], e['item']) in accepted_items and e.get('solving'):
            groups[(e['user'], e['solving'])].append(e)
    return {'candidate_event_pairs': sum(len(rows) for rows in groups.values()),
            'candidate_solving_groups': len(groups),
            'candidate_groups_with_raw_multiple_questions': sum(any(r['raw_group_size'] > 1 for r in rows) for rows in groups.values()),
            'candidate_groups_with_two_or_more_paired_events': sum(len(rows) > 1 for rows in groups.values()),
            'candidate_groups_crossing_train_valid': sum({r['split'] for r in rows} == {'train', 'valid'} for rows in groups.values()),
            'candidate_groups_spanning_raw_seconds': sum(any(r['raw_group_spans_seconds'] for r in rows) for rows in groups.values()),
            'scope': 'candidate aligned subset only; not verified lineage or true feedback availability'}

