"""Pinned server entry for the cumulative-strength matched candidate."""
import argparse
import json
import platform
import shutil
from pathlib import Path

import numpy as np
import torch
from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from .references import AUDIT_SHA, BASE_SHA, CALIBRATED_SHA, OLD_RELEASE_SHA
from .runner import run

ROOT = Path(__file__).resolve().parents[2]
POPULATION = {'train': 1847688, 'development': 126854, 'development_students': 10036,
              'eligible': 101427, 'eligible_students': 9116}
EXPECTED_WEIGHT_GUARD = 'ae4de19ffb0dcc67fde6f3e694410b9d1d0b71357cf62ad31cd2abff66b999a5'


def verify_release():
    manifest_path = ROOT / 'release_manifest.json'
    files = json.loads(manifest_path.read_text(encoding='utf-8'))['files']
    required = {'README.md', 'run_server.sh', 'checks/verify.py', 'tests/test_contracts.py',
                'tests/test_pipeline.py', 'src/cumulative_control/server.py', 'src/cumulative_control/runner.py',
                'src/cumulative_control/analysis.py', 'src/cumulative_control/references.py',
                'src/weight_guard/weights.py', 'src/session_control/features.py', 'src/session_control/train.py',
                'references/prior_release_manifest.json', 'references/history_weight_results.zip',
                'references/calibrated_session_results.zip', 'references/session_control_results.zip'}
    if not required.issubset(files):
        raise ValueError('release is missing required source or references')
    for name, digest in files.items():
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file() or sha256_file(path) != digest:
            raise ValueError(f'missing, unsafe or modified release file: {name}')
    frozen = ROOT / 'references' / 'prior_release_manifest.json'
    if sha256_file(frozen) != OLD_RELEASE_SHA:
        raise ValueError('prior release manifest hash differs')
    old = json.loads(frozen.read_text(encoding='utf-8'))['files']
    for name in files:
        if name.startswith(('src/count_time/', 'src/session_control/')):
            if name not in old or files[name] != old[name]:
                raise ValueError(f'vendored prior source differs: {name}')
    expected = {'src/weight_guard/weights.py': EXPECTED_WEIGHT_GUARD,
                'references/history_weight_results.zip': AUDIT_SHA,
                'references/calibrated_session_results.zip': CALIBRATED_SHA,
                'references/session_control_results.zip': BASE_SHA}
    for name, digest in expected.items():
        if files[name] != digest:
            raise ValueError(f'frozen input differs: {name}')
    return {'manifest_sha256': sha256_file(manifest_path), 'file_count': len(files)}


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--verify-only', action='store_true')
    p.add_argument('--project-dir')
    p.add_argument('--data-dir')
    p.add_argument('--output-dir')
    args = p.parse_args(argv)
    release = verify_release()
    print(json.dumps({'phase': 'release_verified', **release}), flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir, args.data_dir, args.output_dir)):
        p.error('project, data and output directories are required')
    output = Path(args.output_dir).resolve()
    allowed = (ROOT / 'outputs').resolve()
    if not output.is_relative_to(allowed) or output == allowed or output.exists():
        raise ValueError('output must be a new child of this release outputs directory')
    free = shutil.disk_usage(allowed).free
    if free < 1073741824:
        raise OSError(f'free disk below 1 GiB: {free}')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; no automatic CPU fallback')
    data = load_prepared(args.project_dir, args.data_dir)
    users = development_users(data.arrays['student_idx'][data.arrays['split'] == 1])
    metadata = {'release': release, 'dataset_manifest_sha256': DATA_FINGERPRINT,
                'source_sha256': SOURCE_HASHES, 'python': platform.python_version(), 'numpy': np.__version__,
                'torch': str(torch.__version__), 'gpu': torch.cuda.get_device_name(), 'free_bytes': free}
    result = run(data.arrays, users, output,
                 audit_path=ROOT / 'references' / 'history_weight_results.zip',
                 calibrated_path=ROOT / 'references' / 'calibrated_session_results.zip',
                 base_path=ROOT / 'references' / 'session_control_results.zip',
                 metadata=metadata, device='cuda', expected_population=POPULATION)
    print(json.dumps({'status': 'complete', 'archive': result}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
