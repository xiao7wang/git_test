"""Seed-paired NLL and student-cluster uncertainty for four frozen rules."""
import numpy as np
from count_time.analysis import _intervals
from count_time.common import binary_losses, metrics

MODES = ('S_cumulative', 'T_time', 'S_session', 'S_calibrated')
CONTRASTS = {'cumulative_minus_time': ('S_cumulative', 'T_time'),
             'cumulative_minus_fixed': ('S_cumulative', 'S_session'),
             'cumulative_minus_transition': ('S_cumulative', 'S_calibrated')}


def _group(y, students, preds, mask, repetitions, seed):
    idx = np.flatnonzero(mask)
    if not len(idx):
        return {'events': 0, 'students': 0, 'models': {}, 'paired': {}}
    yy, uu = y[idx], students[idx]
    losses, models = {}, {}
    for mode in MODES:
        per_seed = []
        losses[mode] = []
        for seed_id in (0, 1, 2):
            p = np.asarray(preds[mode][seed_id], dtype=np.float64)[idx]
            if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f'invalid probability in {mode}/{seed_id}')
            per_seed.append(metrics(yy, p, uu))
            losses[mode].append(binary_losses(yy, p)[0])
        keys = ('nll', 'student_macro_nll', 'auc', 'brier')
        models[mode] = {'per_seed': per_seed,
                        'mean': {k: (None if any(row[k] is None for row in per_seed)
                                     else float(np.mean([row[k] for row in per_seed]))) for k in keys}}
    mean_losses = {m: np.stack(losses[m]).mean(axis=0) for m in MODES}
    columns = np.stack([mean_losses[a] - mean_losses[b] for a, b in CONTRASTS.values()], axis=1)
    intervals = _intervals(uu, columns, repetitions, seed)
    paired = {}
    for (name, (a, b)), entry in zip(CONTRASTS.items(), intervals):
        entry['per_seed_event_delta'] = [float(np.mean(losses[a][j] - losses[b][j])) for j in range(3)]
        paired[name] = entry
    return {'events': len(idx), 'students': int(len(np.unique(uu))), 'models': models, 'paired': paired}


def analyze(features, preds, repetitions=2000, seed=20261117):
    if set(preds) != set(MODES) or repetitions < 1:
        raise ValueError('invalid comparison modes or bootstrap repetitions')
    dev = np.flatnonzero(features['split'] == 1)
    if not len(dev):
        raise ValueError('no development events')
    for mode in MODES:
        if set(preds[mode]) != {0, 1, 2}:
            raise ValueError(f'prediction seeds differ for {mode}')
        for p in preds[mode].values():
            p = np.asarray(p)
            if p.shape != (len(dev),) or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f'invalid development probabilities for {mode}')
    y, u = features['label'][dev], features['student'][dev]
    prior, crossing = features['prior_kc_count'][dev], features['session_crossings'][dev]
    groups = {'all_development': np.ones(len(dev), dtype=bool),
              'prior_kc_at_least_2': prior >= 2,
              'repeat_no_session_crossing': (prior > 0) & (crossing == 0),
              'repeat_one_or_more_session_crossings': (prior > 0) & (crossing > 0)}
    return {'scope': 'reused development data; exploratory model comparison',
            'primary': 'S_cumulative minus T_time event NLL, mean of three paired seed losses',
            'bootstrap': {'unit': 'student', 'repetitions': repetitions, 'seed': seed,
                          'scope': 'conditional on fitted selected models; excludes training and repeated selection uncertainty'},
            'groups': {name: _group(y, u, preds, mask, repetitions, seed + i)
                       for i, (name, mask) in enumerate(groups.items())}}
