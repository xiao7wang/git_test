"""Three matched count-model fits and frozen-development comparisons."""
import hashlib
import json
import time
import zipfile
from pathlib import Path

import numpy as np
from count_time.common import sha256_file, write_json
from count_time.features import check_legacy_counts
from session_control.features import build
from session_control.train import fit
from weight_guard.weights import calibrate, history_totals, prepare_ordered, select_rows
from .analysis import analyze
from .references import EXPECTED_RETENTION, EXPECTED_TARGET, load_audit, load_previous


def verify_full_history(arrays, users, features, audit, *, expected_training_repeats=1582031,
                        expected_target=EXPECTED_TARGET):
    """Recompute the label-free train-only match and verify both history totals."""
    selected = select_rows(arrays, users)
    if not np.array_equal(selected['record_idx'], features['record_idx']):
        raise ValueError('label-free and training feature event selection differs')
    ordered = prepare_ordered(selected['student'], selected['kc'], selected['timestamp'],
                              selected['split'], selected['record_idx'])
    recalibration = calibrate(ordered['crossings'], ordered['gaps_hours'], ordered['first'], ordered['split'])
    c = recalibration['cumulative']
    if (recalibration['training_repeated_kc_events'] != expected_training_repeats or c['status'] != 'matched' or
        abs(c['retention'] - audit['retention']) > 2e-10 or
        abs(c['target'] - expected_target) > 1e-8):
        raise ValueError('recomputed training-only cumulative calibration differs')
    n = len(ordered['first'])
    pos = np.arange(n, dtype=np.int64)
    start = np.maximum.accumulate(np.where(ordered['first'], pos, 0))
    prior = pos - start
    dev = np.flatnonzero(ordered['split'] == 1)
    dev = dev[np.argsort(ordered['record_idx'][dev])]
    columns = (ordered['record_idx'][dev], ordered['student'][dev], ordered['kc'][dev], prior[dev],
               ordered['starts_session'][dev], ordered['crossings'][dev])
    dev_digest = hashlib.sha256(np.column_stack(columns).astype('<i8', copy=False).tobytes()).hexdigest()
    if dev_digest != audit['provenance']['identity_check']['dev_event_history_sha256']:
        raise ValueError('development structural history differs from frozen audit')
    stage, timed = history_totals(ordered['crossings'], ordered['gaps_hours'], ordered['first'], audit['retention'])
    order = ordered['original_position']
    s, f = features['session_states']
    ts, tf = features['states']['C_real_time']
    stage_difference = float(np.max(np.abs(stage - (s + f)[order]), initial=0.))
    time_difference = float(np.max(np.abs(timed - (ts + tf)[order]), initial=0.))
    if max(stage_difference, time_difference) > 1e-8:
        raise ValueError('independent total-history and answer-specific histories differ')
    return {'recomputed_training_calibration': recalibration, 'development_identity_sha256': dev_digest,
            'stage_total_max_abs_error': stage_difference, 'time_total_max_abs_error': time_difference,
            'note': 'train-only match uses timestamps and boundaries without labels; histories compared across selected train/development rows'}


def package(out, archive_name, names):
    out = Path(out)
    hashes = {name: sha256_file(out / name) for name in names}
    pending, final = out / (archive_name + '.pending'), out / archive_name
    if pending.exists() or final.exists():
        raise FileExistsError('result archive exists; refusing overwrite')
    with zipfile.ZipFile(pending, 'x', compression=zipfile.ZIP_STORED, allowZip64=True) as z:
        for name in names:
            z.write(out / name, arcname=name)
        z.writestr('manifest.json', json.dumps({'format': 1, 'files': hashes}, indent=2) + '\n')
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or len(z.namelist()) != len(hashes) + 1 or set(z.namelist()) != set(hashes) | {'manifest.json'}:
            raise ValueError('result archive CRC or members differ')
        for name, expected in hashes.items():
            if hashlib.sha256(z.read(name)).hexdigest() != expected:
                raise ValueError(f'result archive member mismatch: {name}')
    pending.replace(final)
    return str(final)


def fit_and_analyze(features, previous, out, status, *, device='cpu', epochs=20, patience=5,
                    batch_size=8192, repetitions=2000):
    """Fit 3 new seeds; reuse 9 frozen predictions; enforce all pairing checks."""
    out = Path(out)
    (out / 'predictions').mkdir(exist_ok=False)
    (out / 'event_features.csv.gz').write_bytes(previous['events_bytes'])
    predictions = {'S_cumulative': {}, **previous['predictions']}
    for name, content in previous['prediction_files'].items():
        (out / 'predictions' / f'{name}.csv.gz').write_bytes(content)
    pairing, jobs = {}, {}
    for seed in (0, 1, 2):
        status.update(phase='training', seed=seed)
        write_json(out / 'status.json', status)
        job_name = f'S_cumulative_seed{seed}'
        print(json.dumps({'phase': 'cumulative_seed_start', 'seed': seed,
                          'candidate_retention': EXPECTED_RETENTION}), flush=True)
        # The unchanged prior trainer uses the name S_calibrated for any supplied
        # session_states. The frozen candidate retention is recorded separately.
        result = fit(features, 'S_calibrated', seed, out / 'jobs' / job_name,
                     device=device, epochs=epochs, patience=patience, batch_size=batch_size)
        prior_names = [f'{mode}_seed{seed}' for mode in ('S_session', 'S_calibrated', 'T_time')]
        if {previous['jobs'][name]['initial_state_sha256'] for name in prior_names} != {result['summary']['initial_state_sha256']}:
            raise ValueError(f'paired initial state differs: seed {seed}')
        common = min([len(result['history'])] + [len(previous['histories'][name]) for name in prior_names])
        if not common:
            raise ValueError('no common training epoch to validate')
        for i in range(common):
            hashes = {result['history'][i]['train_order_sha256']}
            hashes.update(previous['histories'][name][i]['train_order_sha256'] for name in prior_names)
            if len(hashes) != 1:
                raise ValueError(f'paired training order differs: seed {seed}, epoch {i+1}')
        pairing[str(seed)] = {'initial_state_matches': True, 'common_epoch_orders_match': common,
                              'new_epochs': len(result['history'])}
        jobs[job_name] = result['summary']
        predictions['S_cumulative'][seed] = result['probability']
        raw = (out / 'jobs' / job_name / 'dev_predictions.csv.gz').read_bytes()
        (out / 'predictions' / f'{job_name}.csv.gz').write_bytes(raw)
        status['completed_seeds'].append(seed)
        write_json(out / 'pairing.json', pairing)
        write_json(out / 'status.json', status)
        if seed == 0:
            partial_files = ['config.json', 'calibration_check.json', 'event_features.csv.gz', 'pairing.json',
                             f'jobs/{job_name}/summary.json', f'jobs/{job_name}/history.json',
                             f'predictions/{job_name}.csv.gz']
            partial = package(out, 'partial_cumulative_seed0.zip', partial_files)
            print(json.dumps({'phase': 'seed0_complete', 'partial_archive': partial}), flush=True)
    status.update(phase='paired_analysis', seed=None)
    write_json(out / 'status.json', status)
    summary = {'status': 'complete', 'jobs': jobs, 'pairing': pairing,
               'analysis': analyze(features, predictions, repetitions=repetitions),
               'test_evaluated': False, 'holdout_evaluated': False}
    write_json(out / 'summary.json', summary)
    names = ['config.json', 'calibration_check.json', 'event_features.csv.gz', 'pairing.json', 'summary.json']
    names += [f'predictions/{mode}_seed{seed}.csv.gz' for mode in ('S_cumulative', 'S_session', 'S_calibrated', 'T_time') for seed in (0, 1, 2)]
    names += [f'jobs/S_cumulative_seed{seed}/{name}' for seed in (0, 1, 2) for name in ('summary.json', 'history.json')]
    return package(out, 'cumulative_session_results.zip', names)


def run(arrays, users, output, *, audit_path, calibrated_path, base_path, metadata,
        device='cuda', epochs=20, patience=5, batch_size=8192, repetitions=2000, expected_population=None):
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    status = {'status': 'running', 'phase': 'reference_and_features', 'seed': None, 'completed_seeds': [],
              'test_evaluated': False, 'holdout_evaluated': False}
    write_json(out / 'status.json', status)
    started = time.monotonic()
    try:
        audit = load_audit(audit_path)
        if abs(audit['retention'] - EXPECTED_RETENTION) > 1e-12:
            raise ValueError('candidate retention changed')
        features = build(arrays, users, threshold_hours=10., retention=audit['retention'])
        dev = np.flatnonzero(features['split'] == 1)
        eligible = dev[features['prior_kc_count'][dev] >= 2]
        population = {'train': int(np.sum(features['split'] == 0)), 'development': len(dev),
                      'development_students': int(len(np.unique(features['student'][dev]))),
                      'eligible': len(eligible), 'eligible_students': int(len(np.unique(features['student'][eligible])))}
        if expected_population is not None and population != expected_population:
            raise ValueError(f'population differs: {population}')
        legacy = check_legacy_counts(features)
        if not legacy['match']:
            raise ValueError('cumulative count independent check failed')
        previous = load_previous(calibrated_path, base_path, features)
        status['phase'] = 'training_only_calibration_check'
        write_json(out / 'status.json', status)
        verification = verify_full_history(arrays, users, features, audit)
        write_json(out / 'calibration_check.json', verification)
        config = {'protocol': 'cumulative_session_count_v1_exploratory', 'population': population,
                  'session_threshold_hours': 10., 'candidate_retention': audit['retention'],
                  'calibration': 'mean cumulative same-KC historical weights on train repeat events only; no labels',
                  'candidate_model': 'same PFA-inspired count model with two KC log-count coefficients',
                  'trainer_internal_mode': 'S_calibrated; session_states use the candidate retention',
                  'comparators': {'S_session': 'per session boundary retention 0.5',
                                  'S_calibrated': 'one-transition training mean matched retention 0.5784074',
                                  'T_time': 'continuous elapsed time, half life 168 hours'},
                  'seeds': [0, 1, 2], 'max_epochs': epochs, 'patience': patience, 'batch_size': batch_size,
                  'optimizer': 'AdamW lr=.01 weight_decay=1e-5 clip=5', 'selection': 'development event NLL',
                  'primary': 'S_cumulative minus T_time event NLL on all development events; mean seed losses',
                  'bootstrap': 'student clusters, conditional on selected models',
                  'limitations': ['reused development set; exploratory',
                                  'only mean cumulative total is matched, not sign-specific or log-transformed histories',
                                  '10h threshold from event timestamps is a proxy, not verified session/feedback time',
                                  'prepared loader reads arrays including test labels; no test/holdout rows are used for features or scoring'],
                  'test_evaluated': False, 'holdout_evaluated': False, 'metadata': metadata,
                  'reference_sha256': {'history_audit': audit['archive_sha256'],
                                       'calibrated': previous['archive_sha256'], 'base': previous['base_archive_sha256']},
                  'undiscounted_count_check': legacy}
        write_json(out / 'config.json', config)
        result = fit_and_analyze(features, previous, out, status, device=device, epochs=epochs,
                                 patience=patience, batch_size=batch_size, repetitions=repetitions)
        status.update(status='complete', phase='complete', result_archive=result, seconds=time.monotonic() - started)
        write_json(out / 'status.json', status)
        print(json.dumps({'phase': 'complete', 'archive': result}), flush=True)
        return result
    except BaseException as exc:
        status.update(status='failed', phase='failed', error=repr(exc), seconds=time.monotonic() - started)
        write_json(out / 'status.json', status)
        raise
