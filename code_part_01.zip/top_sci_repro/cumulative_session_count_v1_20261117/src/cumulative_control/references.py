"""Verify frozen source archives and event/seed identities before reuse."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

import numpy as np
import pandas as pd
from count_time.common import binary_losses

AUDIT_SHA = 'e65b25f5f8ebe8b5b15cbd8714f51e130d3c8bbad9b7f21eb7885c9adf7ce078'
CALIBRATED_SHA = 'c49634100ce00363c6792a37a6e910d609cc9dc1399a124eb54290c430e9736a'
BASE_SHA = '5201ed70314c5833bce1ad08410936e5f54b708ea02d913cbea8a0ad32e1fb4c'
DATA_SHA = '18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e'
OLD_RELEASE_SHA = '83690ac3da7fae6bf6079c29972814e50c0a486a5abcb9aa1ee83d18c3be59a0'
AUDIT_RELEASE_SHA = '77ed27a0f0918436b71f0a46e74dbdb60a2d959d0eae470ddaa502171c193374'
EXPECTED_RETENTION = .6529817136852216
EXPECTED_TARGET = 6.358653028966154


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def verified_zip(path, expected_sha):
    if file_sha(path) != expected_sha:
        raise ValueError('reference ZIP SHA-256 mismatch')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        if len(names) != len(set(names)) or z.testzip() is not None:
            raise ValueError('reference ZIP has duplicates or a CRC failure')
        for name in names:
            p = PurePosixPath(name)
            if p.is_absolute() or '..' in p.parts or '\\' in name:
                raise ValueError('unsafe reference ZIP member')
        entries = json.loads(z.read('manifest.json'))['files']
        if set(names) != set(entries) | {'manifest.json'}:
            raise ValueError('reference manifest and members differ')
        content = {}
        for name, digest in entries.items():
            value = z.read(name)
            if hashlib.sha256(value).hexdigest() != digest:
                raise ValueError(f'reference member hash mismatch: {name}')
            content[name] = value
        return content


def check_calibration(calibration, provenance):
    c = calibration['cumulative']
    if (provenance.get('prepared_data_manifest_sha256') != DATA_SHA or
        'label' not in provenance.get('not_loaded', []) or provenance.get('independent_validation') is not False or
        calibration.get('training_repeated_kc_events') != 1582031 or c.get('status') != 'matched' or
        abs(c.get('retention', -1) - EXPECTED_RETENTION) > 1e-12 or
        abs(c.get('target', -1) - EXPECTED_TARGET) > 1e-10 or
        abs(c.get('achieved', -1) - EXPECTED_TARGET) > 1e-9):
        raise ValueError('frozen cumulative training-only calibration differs')
    return float(c['retention'])


def load_audit(path):
    files = verified_zip(path, AUDIT_SHA)
    calibration = json.loads(files['calibration.json'])
    provenance = json.loads(files['provenance.json'])
    if provenance.get('release', {}).get('manifest_sha256') != AUDIT_RELEASE_SHA:
        raise ValueError('history audit release fingerprint differs')
    retention = check_calibration(calibration, provenance)
    return {'retention': retention, 'calibration': calibration, 'provenance': provenance,
            'archive_sha256': AUDIT_SHA}


def read_csv(content):
    with gzip.open(io.BytesIO(content), mode='rt', encoding='utf-8', newline='') as f:
        return pd.read_csv(f, float_precision='round_trip')


def _check_identity(table, features, dev):
    for col, key in (('record_idx', 'record_idx'), ('student_idx', 'student'), ('label', 'label')):
        if not np.array_equal(table[col].to_numpy(), features[key][dev]):
            raise ValueError(f'previous prediction identity mismatch: {col}')


def load_previous(calibrated_path, base_path, features):
    latest = verified_zip(calibrated_path, CALIBRATED_SHA)
    old = verified_zip(base_path, BASE_SHA)
    config, summary = json.loads(latest['config.json']), json.loads(latest['summary.json'])
    old_config, old_summary = json.loads(old['config.json']), json.loads(old['summary.json'])
    if (config.get('protocol') != 'training_mean_calibrated_session_control_v1_exploratory' or
        config.get('metadata', {}).get('dataset_manifest_sha256') != DATA_SHA or
        config.get('metadata', {}).get('release', {}).get('manifest_sha256') != OLD_RELEASE_SHA or
        config.get('seeds') != [0, 1, 2] or config.get('threshold_hours') != 10. or
        config.get('half_life_hours') != 168. or config.get('test_evaluated') is not False or
        config.get('holdout_evaluated') is not False or summary.get('status') != 'complete' or
        old_config.get('protocol') != 'global_session_boundary_count_v1_exploratory' or
        old_summary.get('status') != 'complete'):
        raise ValueError('previous experimental protocol or completion differs')
    if latest['event_features.csv.gz'] != old['event_features.csv.gz']:
        raise ValueError('previous event tables differ')
    event_table = read_csv(latest['event_features.csv.gz'])
    dev = np.flatnonzero(features['split'] == 1)
    _check_identity(event_table, features, dev)
    for col, key in (('kc_idx', 'kc'), ('prior_kc_count', 'prior_kc_count'),
                     ('starts_session', 'starts_session'), ('same_kc_session_crossings', 'session_crossings')):
        if not np.array_equal(event_table[col].to_numpy(), features[key][dev]):
            raise ValueError(f'previous event feature mismatch: {col}')
    for col, key in (('same_kc_gap_hours', 'gap_hours'), ('previous_global_event_gap_hours', 'global_gap_hours')):
        if not np.allclose(event_table[col].to_numpy(), features[key][dev], atol=1e-10, rtol=0, equal_nan=True):
            raise ValueError(f'previous time feature mismatch: {col}')
    predictions = {mode: {} for mode in ('S_session', 'S_calibrated', 'T_time')}
    jobs, histories, files = {}, {}, {}
    for mode in predictions:
        for seed in (0, 1, 2):
            name = f'{mode}_seed{seed}'
            raw = latest[f'predictions/{name}.csv.gz']
            table = read_csv(raw)
            _check_identity(table, features, dev)
            probability = table['probability'].to_numpy(dtype=np.float64)
            if not np.isfinite(probability).all() or ((probability < 0) | (probability > 1)).any():
                raise ValueError(f'invalid prior probability: {name}')
            reported = summary['analysis']['groups']['all_development']['models'][mode]['per_seed'][seed]
            actual = float(binary_losses(features['label'][dev], probability)[0].mean())
            if abs(actual - reported['nll']) > 1e-7:
                raise ValueError(f'prior prediction loss mismatch: {name}')
            if mode == 'S_calibrated':
                job = json.loads(latest[f'jobs/{name}/summary.json'])
                hist = json.loads(latest[f'jobs/{name}/history.json'])
            else:
                if raw != old[f'jobs/{name}/dev_predictions.csv.gz']:
                    raise ValueError(f'base and calibrated prediction bytes differ: {name}')
                job = json.loads(old[f'jobs/{name}/summary.json'])
                hist = json.loads(old[f'jobs/{name}/history.json'])
            if job.get('status') != 'complete' or job.get('seed') != seed or not hist:
                raise ValueError(f'prior job is not complete: {name}')
            predictions[mode][seed], jobs[name], histories[name], files[name] = probability, job, hist, raw
    for seed in (0, 1, 2):
        names = [f'{mode}_seed{seed}' for mode in predictions]
        if len({jobs[name]['initial_state_sha256'] for name in names}) != 1:
            raise ValueError(f'prior models have different initial states: {seed}')
        for i in range(min(len(histories[name]) for name in names)):
            if len({histories[name][i]['train_order_sha256'] for name in names}) != 1:
                raise ValueError(f'prior models have different train order: {seed}/{i+1}')
    return {'predictions': predictions, 'jobs': jobs, 'histories': histories,
            'prediction_files': files, 'events_bytes': latest['event_features.csv.gz'],
            'config': config, 'archive_sha256': CALIBRATED_SHA, 'base_archive_sha256': BASE_SHA}
