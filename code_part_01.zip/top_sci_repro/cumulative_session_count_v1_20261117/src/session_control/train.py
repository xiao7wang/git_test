"""Matched count models with an optional extra pair of time coefficients."""
import copy
import csv
import gzip
import hashlib
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from torch import nn

from count_time.common import metrics, model_digest, sha256_file, write_json
from count_time.training import CountModel


class SessionModel(nn.Module):
    def __init__(self, students, items, kcs):
        super().__init__()
        # CountModel initialization consumes the same random numbers as the old model.
        self.base = CountModel(students, items, kcs)
        # zeros() consumes no RNG, so paired models use the same train permutations.
        self.extra = nn.Parameter(torch.zeros(kcs, 2))

    def forward(self, student, item, kc, primary_s, primary_f, extra_s, extra_f):
        logit = self.base(student, item, kc, primary_s, primary_f)
        weights = self.extra[kc]
        return logit + weights[:, 0] * torch.log1p(extra_s) + weights[:, 1] * torch.log1p(extra_f)


def fit(features, mode, seed, out, *, device="cpu", epochs=20, patience=5, batch_size=8192):
    if mode not in ("S_session", "S_calibrated", "T_time", "ST_both") or seed not in (0, 1, 2):
        raise ValueError("unknown mode or seed")
    out = Path(out)
    out.mkdir(parents=True, exist_ok=False)
    tick_all = time.monotonic()
    torch.set_num_threads(4)
    torch.manual_seed(seed)
    if device == "cuda":
        if not torch.cuda.is_available():
            raise RuntimeError("CUDA unavailable; no fallback")
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    train_idx = np.flatnonzero(features["split"] == 0)
    valid_idx = np.flatnonzero(features["split"] == 1)
    if not len(train_idx) or not len(valid_idx):
        raise ValueError("missing train or development events")
    session = features["session_states"]
    timed = features["states"]["C_real_time"]
    zeros = np.zeros(len(features["student"]), dtype=np.float64)
    primary = timed if mode == "T_time" else session
    extra = timed if mode == "ST_both" else (zeros, zeros)
    tensors = {name: torch.as_tensor(features[name], dtype=torch.long, device=device)
               for name in ("student", "item", "kc")}
    for name, value in zip(("primary_s", "primary_f", "extra_s", "extra_f"), (*primary, *extra)):
        if not np.isfinite(value).all() or (value < 0).any():
            raise ValueError("invalid history state")
        tensors[name] = torch.as_tensor(value, dtype=torch.float32, device=device)
    tensors["label"] = torch.as_tensor(features["label"], dtype=torch.float32, device=device)
    train = torch.as_tensor(train_idx, dtype=torch.long, device=device)
    valid = torch.as_tensor(valid_idx, dtype=torch.long, device=device)
    model = SessionModel(features["n_students"], features["n_items"], features["n_kcs"]).to(device)
    initial = model_digest(model.state_dict())
    optimizer = torch.optim.AdamW(model.parameters(), lr=.01, weight_decay=1e-5)
    names = ("student", "item", "kc", "primary_s", "primary_f", "extra_s", "extra_f")

    def logits(i):
        return model(*(tensors[name][i] for name in names))

    best_nll, best_epoch, stale = float("inf"), None, 0
    best_state, history = None, []
    for epoch in range(1, epochs + 1):
        tick = time.monotonic()
        model.train()
        permuted = train[torch.randperm(len(train), device=device)]
        order_hash = hashlib.sha256(permuted.cpu().numpy().astype("<i8", copy=False).tobytes()).hexdigest()
        total = 0.
        for start in range(0, len(train), batch_size):
            idx = permuted[start:start + batch_size]
            optimizer.zero_grad(set_to_none=True)
            loss = F.binary_cross_entropy_with_logits(logits(idx), tensors["label"][idx])
            if not bool(torch.isfinite(loss)):
                raise FloatingPointError("nonfinite training loss")
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5., error_if_nonfinite=True)
            optimizer.step()
            total += float(loss.detach()) * len(idx)
        model.eval()
        with torch.no_grad():
            probability = torch.sigmoid(logits(valid)).cpu().numpy()
        dev = metrics(features["label"][valid_idx], probability, features["student"][valid_idx])
        improved = dev["nll"] < best_nll
        if improved:
            best_nll, best_epoch, stale = dev["nll"], epoch, 0
            best_state = copy.deepcopy(model.state_dict())
        else:
            stale += 1
        row = {"epoch": epoch, "train_bce": total / len(train), "dev": dev,
               "train_order_sha256": order_hash, "improved": improved,
               "seconds": time.monotonic() - tick}
        history.append(row)
        print(f"{mode} seed={seed} epoch={epoch} dev_nll={dev['nll']:.8f}", flush=True)
        if stale >= patience:
            break
    if best_state is None:
        raise AssertionError("no best state selected")
    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        probability = torch.sigmoid(logits(valid)).cpu().numpy()
    final = metrics(features["label"][valid_idx], probability, features["student"][valid_idx])
    if abs(final["nll"] - best_nll) > 1e-7:
        raise AssertionError("best checkpoint does not reproduce its development NLL")
    checkpoint = out / "best_model.pt"
    torch.save({"model_state": {k:v.detach().cpu() for k,v in best_state.items()},
                "mode": mode, "seed": seed, "epoch": best_epoch, "dev_nll": best_nll}, checkpoint)
    with gzip.open(out / "dev_predictions.csv.gz", "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("record_idx", "student_idx", "label", "probability"))
        for index, p in zip(valid_idx, probability):
            writer.writerow((int(features["record_idx"][index]), int(features["student"][index]),
                             int(features["label"][index]), format(float(p), ".9g")))
    summary = {"status": "complete", "mode": mode, "seed": seed, "epochs": len(history),
               "best_epoch": best_epoch, "dev": final, "initial_state_sha256": initial,
               "checkpoint_sha256": sha256_file(checkpoint), "seconds": time.monotonic()-tick_all,
               "test_evaluated": False, "holdout_evaluated": False}
    write_json(out / "history.json", history)
    write_json(out / "summary.json", summary)
    return {"probability": probability.astype(np.float64), "history": history, "summary": summary}
