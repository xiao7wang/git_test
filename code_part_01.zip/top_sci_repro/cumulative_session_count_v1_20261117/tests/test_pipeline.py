import gzip
import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

import numpy as np
from session_control.features import build
from session_control.train import fit
from cumulative_control import runner
from cumulative_control.references import EXPECTED_RETENTION
from weight_guard.weights import calibrate, prepare_ordered, select_rows


class PipelineContracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='synthetic_cumulative_')
        cls.root = Path(cls.tmp.name)
        students = np.repeat(np.arange(4), 6)
        items = np.tile([0, 1, 0, 0, 1, 1], 4)
        split = np.tile([0, 0, 0, 0, 1, 2], 4)
        time = np.tile([0., 3600., 604800., 608400., 612000., 615600.], 4)
        label = np.tile([1., 0., 1., 0., 1., np.nan], 4)
        for u in (1, 3):
            label[(students == u) & (split == 1)] = 0.
        cls.arrays = {'student_idx': students, 'item_idx': items, 'split': split, 'timestamp': time,
                      'label': label, 'item_q': np.eye(2, dtype=int)}
        cls.users = {0, 1, 2, 3}
        cls.f = build(cls.arrays, cls.users, threshold_hours=10., retention=EXPECTED_RETENTION)
        cls.old = {'predictions': {}, 'jobs': {}, 'histories': {}, 'prediction_files': {},
                   'events_bytes': gzip.compress(b'record_idx,student_idx,label\n'),
                   'archive_sha256': 'synthetic-latest', 'base_archive_sha256': 'synthetic-base'}
        for mode, retention in (('S_session', .5), ('S_calibrated', .5784), ('T_time', .5)):
            f = build(cls.arrays, cls.users, threshold_hours=10., retention=retention)
            cls.old['predictions'][mode] = {}
            for seed in (0, 1, 2):
                name = f'{mode}_seed{seed}'
                result = fit(f, mode, seed, cls.root / 'old' / name, device='cpu',
                             epochs=2, patience=2, batch_size=4)
                cls.old['predictions'][mode][seed] = result['probability']
                cls.old['jobs'][name] = result['summary']
                cls.old['histories'][name] = result['history']
                cls.old['prediction_files'][name] = (cls.root / 'old' / name / 'dev_predictions.csv.gz').read_bytes()

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def test_end_to_end_synthetic_three_seeds_and_both_result_archives(self):
        out = self.root / 'new'
        audit = {'retention': EXPECTED_RETENTION, 'archive_sha256': 'synthetic-audit'}
        with patch.object(runner, 'load_audit', return_value=audit), \
             patch.object(runner, 'load_previous', return_value=self.old), \
             patch.object(runner, 'verify_full_history', return_value={'synthetic': True}):
            result = runner.run(self.arrays, self.users, out, audit_path='unused', calibrated_path='unused',
                                base_path='unused', metadata={'synthetic': True}, device='cpu',
                                epochs=2, patience=2, batch_size=4, repetitions=20)
        status = json.loads((out / 'status.json').read_text(encoding='utf-8'))
        self.assertEqual(status['status'], 'complete')
        self.assertEqual(status['completed_seeds'], [0, 1, 2])
        self.assertFalse(status['test_evaluated'])
        with zipfile.ZipFile(result) as z:
            self.assertIsNone(z.testzip())
            manifest = json.loads(z.read('manifest.json'))['files']
            self.assertEqual(set(z.namelist()), set(manifest) | {'manifest.json'})
            for name, digest in manifest.items():
                self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(), digest)
            summary = json.loads(z.read('summary.json'))
            self.assertEqual(set(summary['analysis']['groups']['all_development']['models']),
                             {'S_cumulative', 'S_calibrated', 'S_session', 'T_time'})
            self.assertEqual(summary['analysis']['groups']['all_development']['events'], 4)
        with zipfile.ZipFile(out / 'partial_cumulative_seed0.zip') as z:
            self.assertIsNone(z.testzip())
            self.assertIn('predictions/S_cumulative_seed0.csv.gz', z.namelist())
        with self.assertRaises(FileExistsError):
            runner.run(self.arrays, self.users, out, audit_path='unused', calibrated_path='unused',
                       base_path='unused', metadata={}, device='cpu', epochs=2, repetitions=2)

    def test_test_labels_do_not_change_selected_history(self):
        other = dict(self.arrays)
        other['label'] = self.arrays['label'].copy()
        other['label'][other['split'] == 2] = 1.
        result = build(other, self.users, threshold_hours=10., retention=EXPECTED_RETENTION)
        for key in ('record_idx', 'student', 'label', 'kc', 'split'):
            np.testing.assert_array_equal(result[key], self.f[key])
        for a, b in zip(result['session_states'], self.f['session_states']):
            np.testing.assert_array_equal(a, b)

    def test_independent_full_history_verification_on_synthetic_data(self):
        selected = select_rows(self.arrays, self.users)
        o = prepare_ordered(selected['student'], selected['kc'], selected['timestamp'],
                            selected['split'], selected['record_idx'])
        cal = calibrate(o['crossings'], o['gaps_hours'], o['first'], o['split'])
        self.assertEqual(cal['cumulative']['status'], 'matched')
        retention = cal['cumulative']['retention']
        feature = build(self.arrays, self.users, threshold_hours=10., retention=retention)
        n = len(o['first'])
        pos = np.arange(n, dtype=np.int64)
        first = np.maximum.accumulate(np.where(o['first'], pos, 0))
        prior = pos - first
        dev = np.flatnonzero(o['split'] == 1)
        dev = dev[np.argsort(o['record_idx'][dev])]
        values = np.column_stack((o['record_idx'][dev], o['student'][dev], o['kc'][dev], prior[dev],
                                  o['starts_session'][dev], o['crossings'][dev])).astype('<i8')
        audit = {'retention': retention, 'provenance': {'identity_check': {
            'dev_event_history_sha256': hashlib.sha256(values.tobytes()).hexdigest()}}}
        checked = runner.verify_full_history(self.arrays, self.users, feature, audit,
                    expected_training_repeats=cal['training_repeated_kc_events'],
                    expected_target=cal['cumulative']['target'])
        self.assertLess(checked['stage_total_max_abs_error'], 1e-10)
        self.assertLess(checked['time_total_max_abs_error'], 1e-10)


if __name__ == '__main__':
    unittest.main()
