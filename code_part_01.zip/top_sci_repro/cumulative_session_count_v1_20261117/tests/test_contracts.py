import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np

from cumulative_control import analysis, references
from weight_guard.weights import calibrate, history_totals


class AnalysisContracts(unittest.TestCase):
    def setUp(self):
        self.features = {'split': np.array([0, 0, 1, 1, 1, 1]),
                         'label': np.array([1., 0., 1., 0., 1., 0.]),
                         'student': np.array([0, 1, 0, 0, 1, 1]),
                         'prior_kc_count': np.array([0, 0, 0, 1, 2, 1]),
                         'session_crossings': np.array([0, 0, 0, 0, 1, 0])}
        self.preds = {mode: {s: np.array([p, 1-p, p, 1-p]) for s in (0, 1, 2)}
                      for mode, p in [('S_cumulative', .7), ('T_time', .6),
                                      ('S_session', .65), ('S_calibrated', .62)]}

    def test_paired_loss_and_student_macro(self):
        output = analysis.analyze(self.features, self.preds, repetitions=40, seed=3)
        group = output['groups']['all_development']
        diff = group['paired']['cumulative_minus_time']
        expected = -np.log(.7) + np.log(.6)
        self.assertAlmostEqual(diff['event_delta'], expected, places=12)
        self.assertAlmostEqual(diff['student_macro_delta'], expected, places=12)
        self.assertEqual(group['events'], 4)
        self.assertEqual(group['students'], 2)
        self.assertEqual(len(diff['per_seed_event_delta']), 3)

    def test_seed_missing_and_nonfinite_are_rejected(self):
        self.preds['T_time'].pop(1)
        with self.assertRaises(ValueError):
            analysis.analyze(self.features, self.preds, repetitions=2)
        self.preds['T_time'][1] = np.array([.6, .4, np.nan, .4])
        with self.assertRaises(ValueError):
            analysis.analyze(self.features, self.preds, repetitions=2)

    def test_mean_of_losses_not_loss_of_average_prediction(self):
        self.preds['S_cumulative'][0] = np.array([.9, .1, .9, .1])
        self.preds['S_cumulative'][1] = np.array([.3, .7, .3, .7])
        self.preds['S_cumulative'][2] = np.array([.9, .1, .9, .1])
        out = analysis.analyze(self.features, self.preds, repetitions=10)
        actual = out['groups']['all_development']['models']['S_cumulative']['mean']['nll']
        self.assertAlmostEqual(actual, (-np.log(.9)-np.log(.3)-np.log(.9))/3, places=12)
        self.assertNotAlmostEqual(actual, -np.log(.7), places=5)


class ReferenceContracts(unittest.TestCase):
    def test_verified_zip_detects_member_corruption_and_unsafe_entries(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'test.zip'
            good = b'abc'
            entries = {'file.txt': hashlib.sha256(good).hexdigest()}
            with zipfile.ZipFile(path, 'w') as z:
                z.writestr('file.txt', good)
                z.writestr('manifest.json', json.dumps({'files': entries}))
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            self.assertEqual(references.verified_zip(path, digest)['file.txt'], good)
            with self.assertRaises(ValueError):
                references.verified_zip(path, '0' * 64)
            with zipfile.ZipFile(path, 'a') as z:
                z.writestr('../unsafe.txt', b'bad')
            with self.assertRaises(ValueError):
                references.verified_zip(path, hashlib.sha256(path.read_bytes()).hexdigest())

    def test_frozen_calibration_contract_rejects_mismatch(self):
        cal = {'training_repeated_kc_events': 1582031,
               'cumulative': {'status': 'matched', 'retention': 0.6529817136852216,
                              'target': 6.358653028966154, 'achieved': 6.358653028968309}}
        provenance = {'prepared_data_manifest_sha256': '18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e',
                      'not_loaded': ['label', 'response_time'], 'independent_validation': False}
        self.assertAlmostEqual(references.check_calibration(cal, provenance), .6529817136852216)
        cal['cumulative']['retention'] = .5
        with self.assertRaises(ValueError):
            references.check_calibration(cal, provenance)

    def test_training_calibration_ignores_development(self):
        k = np.array([0, 1, 2, 0])
        g = np.array([0., 168., 336., 168.])
        first = np.array([True, False, False, False])
        split = np.array([0, 0, 0, 1])
        a = calibrate(k, g, first, split)
        k[3], g[3] = 80, 50000.
        b = calibrate(k, g, first, split)
        self.assertEqual(a['cumulative']['retention'], b['cumulative']['retention'])
        self.assertAlmostEqual(a['cumulative']['retention'], .5, places=9)

    def test_cumulative_history_retention_equal_bruteforce(self):
        k = np.array([0, 1, 0, 2]); gaps = np.array([0., 168., 1., 336.])
        first = np.array([True, False, False, False])
        stage, timed = history_totals(k, gaps, first, .5)
        stage_naive = [sum(.5 ** int(np.sum(k[j+1:i+1])) for j in range(i)) for i in range(4)]
        time_naive = [sum(2 ** (-float(np.sum(gaps[j+1:i+1])) / 168.) for j in range(i)) for i in range(4)]
        np.testing.assert_allclose(stage, stage_naive, atol=1e-12, rtol=0)
        np.testing.assert_allclose(timed, time_naive, atol=1e-12, rtol=0)


if __name__ == '__main__':
    unittest.main()
