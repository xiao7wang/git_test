"""Small CUDA count-model forward/backward contract on synthetic tensors."""
import torch
from session_control.train import SessionModel

if not torch.cuda.is_available():
    raise RuntimeError('CUDA unavailable; no CPU fallback')
torch.use_deterministic_algorithms(True)
torch.manual_seed(1)
model = SessionModel(3, 3, 2).to('cuda')
student = torch.tensor([0, 1], dtype=torch.long, device='cuda')
item = torch.tensor([0, 1], dtype=torch.long, device='cuda')
kc = torch.tensor([0, 1], dtype=torch.long, device='cuda')
values = torch.tensor([.5, 1.], dtype=torch.float32, device='cuda')
zeros = torch.zeros_like(values)
loss = torch.nn.functional.binary_cross_entropy_with_logits(
    model(student, item, kc, values, values, zeros, zeros), values.clamp(0., 1.))
loss.backward()
if not bool(torch.isfinite(loss)):
    raise FloatingPointError('nonfinite synthetic CUDA loss')
print('Synthetic CUDA forward/backward: PASS', flush=True)
