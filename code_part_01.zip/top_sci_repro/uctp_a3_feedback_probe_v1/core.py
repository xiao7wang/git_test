"""A3 frozen validation-deployment diagnostic. No model training or test data.

Policies start after the original unit-write training history. Exclusive prefix
sums exactly reproduce chronological writing for this additive single-KC model.
They do not approximate general recurrent-model counterfactuals.
"""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import sys
import zipfile
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

A1_SHA = "69e9fdebc5ae054492c0f7650b3cabd879cda38e7a210f3fe79e7ecbc4463c50"
MODEL_SHA = "fdd0c94ca6fb7ff40f6421f23f7978262998149dbf16b68c4a9f79a2b4864a0d"
METRIC_SHA = "9c19d3abe8a090776663df1877b206640522792203d21a22a7e0f64a4e087a7b"
JOBS = tuple(f"{d}_unit_write_seed{s}" for d in ("assist", "ednet") for s in (1, 2))
POLICIES = ("unit", "negative_half", "early_negative_half")
READOUTS = ("original", "zero_unsupported")
MODES = tuple(r + "__" + p for r in READOUTS for p in POLICIES)
PAIRS = tuple((r+"__"+p, r+"__unit") for r in READOUTS for p in POLICIES[1:]) + tuple(
    (r+"__early_negative_half", r+"__negative_half") for r in READOUTS) + (
    ("zero_unsupported__unit", "original__unit"),)


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(1024*1024), b""):
            h.update(data)
    return h.hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def verify_archive(path):
    require(sha(path) == A1_SHA, "Wrong A1 archive: expected accepted server_a1_02")
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None and len(z.namelist()) == len(set(z.namelist())), "A1 CRC or duplicate member")
        manifest = json.loads(z.read("results_manifest.json"))["files"]
        require(set(manifest) == set(z.namelist())-{"results_manifest.json"}, "Manifest coverage")
        for name, expected in manifest.items():
            require(hashlib.sha256(z.read(name)).hexdigest() == expected, "A1 member hash: " + name)
        status = json.loads(z.read("suite_status.json"))
        require(status["status"] == "complete" and status["full_validations_completed"] == 4, "A1 incomplete")
        require(not status["trained"] and not status["test_evaluated"], "A1 scope")
    return {"sha256": A1_SHA, "verified_members": len(manifest)}


def read_job(archive, job):
    require(job in JOBS, "Job outside fixed matrix")
    with zipfile.ZipFile(archive) as z:
        prefix = job+"_full/"
        config = json.loads(z.read(prefix+"run_config.json"))
        status = json.loads(z.read(prefix+"status.json"))
        frame = pd.read_csv(io.BytesIO(z.read(prefix+"predictions.csv.gz")), compression="gzip", float_precision="round_trip")
    require(status["status"] == "complete" and status["reference_gate"]["success"], "A1 reference gate")
    require(len(frame) == config["job"]["n"] == status["n"], "A1 coverage")
    return frame, config


def exclusive_sum(values, frame):
    values = pd.Series(np.asarray(values, dtype=np.float64), index=frame.index)
    return (values.groupby([frame.student_idx, frame.kc], sort=False).cumsum()-values).to_numpy()


def policy_states(frame):
    """Infer immutable train prefixes, then apply policies only to valid writes.

    The original A1 exporter checked student chronological split order. Require
    complete consecutive validation KC counts here, and constant inferred train
    P/N. No future response affects the state used to predict an earlier row.
    """
    f = frame.reset_index(drop=True).copy()
    required = {"record_idx", "student_idx", "item_idx", "timestamp", "kc", "label", "split",
                "positive", "negative", "kc_count_before", "same_time", "u0_probability"}
    require(required.issubset(f.columns), "Missing A1 fields")
    require(len(f)>0 and not f[list(required)].isna().any().any(), "Empty/NA input")
    require(f.record_idx.is_unique and f.record_idx.is_monotonic_increasing, "Record order/duplicates")
    require(f.split.eq(1).all() and f.label.isin([0,1]).all(), "Validation-only binary labels")
    for col in ("record_idx", "student_idx", "item_idx", "timestamp", "kc", "positive", "negative", "kc_count_before"):
        require(np.issubdtype(f[col].dtype, np.integer), "Noninteger field: "+col)
    require((f[["positive","negative","kc_count_before"]]>=0).all().all(), "Negative prefix")
    require((f.positive+f.negative).eq(f.kc_count_before).all(), "Unit count mismatch")
    require(f.same_time.isin([True,False]).all(), "Invalid tie flag")
    groups = f.groupby(["student_idx", "kc"], sort=False)
    require(groups.timestamp.diff().dropna().ge(0).all(), "Time backwards")
    ntrain = f.kc_count_before.to_numpy()-groups.cumcount().to_numpy()
    y = f.label.to_numpy(float)
    ptrain = f.positive.to_numpy()-exclusive_sum(y, f)
    nnegative = f.negative.to_numpy()-exclusive_sum(1-y, f)
    require((ntrain>=0).all() and (ptrain>=0).all() and (nnegative>=0).all(), "Invalid inferred train history")
    for arr in (ntrain, ptrain, nnegative):
        require(pd.Series(arr).groupby([f.student_idx,f.kc]).nunique().eq(1).all(), "Incomplete or inconsistent validation history")
    f["train_kc_count"] = ntrain
    f["train_supported"] = ntrain>0
    f["train_positive"] = ptrain
    f["train_negative"] = nnegative
    early = f.kc_count_before.between(1,4).to_numpy()
    weights = {"unit": np.ones(len(f)), "negative_half": np.where(y==0,.5,1.),
               "early_negative_half": np.where((y==0)&early,.5,1.)}
    for policy,w in weights.items():
        f[policy+"_positive"] = ptrain+exclusive_sum(w*y,f)
        f[policy+"_negative"] = nnegative+exclusive_sum(w*(1-y),f)
    require(np.array_equal(f.unit_positive, f.positive) and np.array_equal(f.unit_negative,f.negative), "Unit prefix bridge")
    previous = groups[["timestamp","label","kc_count_before","same_time"]].shift(1)
    gap=f.timestamp-previous.timestamp
    f["after_early_negative"] = (previous.label.eq(0)&previous.kc_count_before.between(1,4)&
        previous.same_time.eq(False)&~f.same_time.astype(bool)&gap.gt(0)&gap.le(604800))
    return f


def load_clean(project):
    project=Path(project)
    require(sha(project/"src/model.py")==MODEL_SHA, "Clean model source changed")
    require(sha(project/"src/metrics.py")==METRIC_SHA, "Clean metrics source changed")
    def load(name,path):
        spec=importlib.util.spec_from_file_location(name,path)
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        spec.loader.exec_module(module)
        return module
    return load("a3_pinned_model",project/"src/model.py"), load("a3_pinned_metrics",project/"src/metrics.py")


def load_checkpoint(module,config,device):
    job=config["job"]
    path=Path(job["checkpoint"])
    require(sha(path)==job["checkpoint_sha256"], "Checkpoint hash mismatch")
    ckpt=torch.load(path,map_location="cpu",weights_only=True)
    require(ckpt.get("model_family") is None and ckpt["model_config"]["variant"]=="unit_write", "Wrong model family")
    require(ckpt["data_fingerprint"]==job["data_fingerprint"] and ckpt["epoch"]==job["best_epoch"], "Checkpoint metadata")
    require(ckpt["source_code"]["src/model.py"]==MODEL_SHA, "Checkpoint model source")
    model=module.CleanCD(**ckpt["model_config"])
    model.load_state_dict(ckpt["model_state"],strict=True)
    return model.eval().requires_grad_(False).to(device)


def parameter_digest(model):
    h=hashlib.sha256()
    for name,t in model.state_dict().items():
        h.update(name.encode())
        h.update(t.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


@torch.inference_mode()
def readout(model,state,u,item,q,unsupported=None):
    """Exact clean head with optional zeroing of unsupported local static logits.

    This is a functional diagnostic override, not a parameter modification.
    Zero is not a final probability of 0.5, and dynamic history is retained.
    """
    alpha=1+state.positive.clamp_min(0)
    beta=1+state.negative.clamp_min(0)
    mean=alpha/(alpha+beta)
    base=model.student_mastery_logit(u)
    if unsupported is not None:
        base=torch.where(unsupported.unsqueeze(-1)&q.bool(),torch.zeros_like(base),base)
    base=base+F.softplus(model.raw_dynamic_scale)*torch.logit(mean.clamp(1e-5,1-1e-5))
    mastery=torch.sigmoid(base)
    difficulty=torch.sigmoid(model.item_difficulty_logit(item))
    discrimination=F.softplus(model.item_discrimination_raw(item)).squeeze(-1)+1e-4
    interaction=discrimination.unsqueeze(-1)*(mastery-difficulty)*q
    logit=(model.item_bias(item).squeeze(-1)+F.softplus(model.raw_direct_scale)*interaction.sum(-1)/q.sum(-1).clamp_min(1)
           +model.ncd(interaction).squeeze(-1))
    return torch.sigmoid(logit)


@torch.inference_mode()
def predict(frame,model,State,device="cpu",batch_size=128,bridge=True):
    require(batch_size>0 and model.variant=="unit_write" and not model.training, "Frozen unit writer/batch required")
    require(not any(p.requires_grad for p in model.parameters()), "Trainable model rejected")
    before=parameter_digest(model)
    out={m:np.empty(len(frame),np.float64) for m in MODES}
    gate={"native_vs_head":0., "native_vs_a1":0., "supported_readout_difference":0., "atol":1e-6}
    for start in range(0,len(frame),batch_size):
        b=frame.iloc[start:start+batch_size]
        def tensor(values,dtype):
            return torch.tensor(np.asarray(values).copy(),dtype=dtype,device=device)
        u=tensor(b.student_idx,torch.long)
        item=tensor(b.item_idx,torch.long)
        kc=tensor(b.kc,torch.long)
        q=torch.zeros(len(b),model.num_knowledges,device=device)
        q[torch.arange(len(b),device=device),kc]=1
        unsupported=tensor(~b.train_supported,torch.bool)
        for policy in POLICIES:
            pos=tensor(b[policy+"_positive"],torch.float32)
            neg=tensor(b[policy+"_negative"],torch.float32)
            state=State(pos.unsqueeze(-1)*q,neg.unsqueeze(-1)*q)
            native=model.predict(state,u,item,q)["probability"]
            alternate=readout(model,state,u,item,q)
            zero=readout(model,state,u,item,q,unsupported)
            gate["native_vs_head"]=max(gate["native_vs_head"],float((native-alternate).abs().max()))
            if (~unsupported).any():
                gate["supported_readout_difference"]=max(gate["supported_readout_difference"],float((native[~unsupported]-zero[~unsupported]).abs().max()))
            if policy=="unit":
                reference=tensor(b.u0_probability,torch.float32)
                gate["native_vs_a1"]=max(gate["native_vs_a1"],float((native-reference).abs().max()))
            for r,prob in (("original",native),("zero_unsupported",zero)):
                out[r+"__"+policy][start:start+len(b)]=prob.cpu().numpy()
    require(gate["native_vs_head"]<=1e-6 and gate["supported_readout_difference"]<=1e-6,"Head equivalence failed")
    if bridge:
        require(gate["native_vs_a1"]<=1e-6,"A1 baseline bridge failed")
    require(parameter_digest(model)==before,"Model parameter mutation")
    for name,p in out.items():
        require(np.isfinite(p).all() and ((p>=0)&(p<=1)).all(),"Invalid probabilities")
        frame[name+"_probability"]=p
    gate.update(success=True,parameters_unchanged=True)
    return frame,gate


def summarize(frame,metrics,reps=1000):
    groups={"all":np.ones(len(frame),bool),"nonfirst_kc":frame.kc_count_before.gt(0).to_numpy(),
            "train_supported":frame.train_supported.to_numpy(),"train_unsupported":~frame.train_supported.to_numpy(),
            "not_tied":~frame.same_time.to_numpy(),"after_early_negative":frame.after_early_negative.to_numpy()}
    y=frame.label.to_numpy(float)
    probs={m:frame[m+"_probability"].to_numpy() for m in MODES}
    losses={m:-y*np.log(np.clip(p,1e-7,1-1e-7))-(1-y)*np.log1p(-np.clip(p,1e-7,1-1e-7)) for m,p in probs.items()}
    result={"scope":"frozen validation-only deployment; original unit-write train warm-start; exploratory",
            "bootstrap_reps":reps,"bootstrap_seed":20261022,
            "intervals":"pointwise paired student-cluster; not training-seed uncertainty; no multiple-testing adjustment", "groups":{}}
    rng=np.random.default_rng(20261022)
    for name,mask in groups.items():
        _,inv=np.unique(frame.student_idx.to_numpy()[mask],return_inverse=True)
        counts=np.bincount(inv)
        entry={"n":int(mask.sum()),"students":len(counts),"metrics":{},"comparisons":{}}
        for m in MODES:
            met=metrics(y[mask],probs[m][mask])
            met["student_macro_nll"]=float(np.mean(np.bincount(inv,weights=losses[m][mask])/counts)) if len(counts) else None
            entry["metrics"][m]=met
        if len(counts):
            totals=np.stack([np.bincount(inv,weights=(losses[a]-losses[b])[mask]) for a,b in PAIRS])
            event,macro=[],[]
            for _ in range(reps):
                w=np.bincount(rng.integers(len(counts),size=len(counts)),minlength=len(counts))
                # Elementwise sums avoid small-vector BLAS thread startup overhead.
                event.append(np.sum(totals*w,axis=1)/np.sum(counts*w))
                macro.append(np.sum((totals/counts)*w,axis=1)/w.sum())
            event=np.asarray(event); macro=np.asarray(macro)
            for i,(a,b) in enumerate(PAIRS):
                entry["comparisons"][a+"_minus_"+b]={"delta_nll":float(np.sum(totals[i])/counts.sum()),
                    "delta_student_macro_nll":float(np.mean(totals[i]/counts)),
                    "event_ci95":np.quantile(event[:,i],[.025,.975]).tolist(),
                    "macro_ci95":np.quantile(macro[:,i],[.025,.975]).tolist()}
        result["groups"][name]=entry
    return result
