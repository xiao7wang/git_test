"""Run tests, reference/batch gates, then four frozen A3 validation jobs."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile
import json

sys.dont_write_bytecode=True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import numpy as np
import torch
from core import (JOBS,MODES,A1_SHA,MODEL_SHA,METRIC_SHA,require,sha,save,verify_archive,
                  read_job,policy_states,load_clean,load_checkpoint,predict,summarize)

ROOT=Path(__file__).resolve().parent
DEFAULT_PROJECT="/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research"
DEFAULT_A1="/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_02/a1_results.zip"


def verify_package():
    manifest=json.loads((ROOT/"PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    for name,h in manifest["files"].items():
        require(sha(ROOT/name)==h,"Package changed: "+name)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir",default=DEFAULT_PROJECT)
    p.add_argument("--a1-archive",default=DEFAULT_A1)
    p.add_argument("--output-root",required=True)
    p.add_argument("--device",choices=("cpu","cuda"),default="cpu")
    p.add_argument("--ack-row-feedback",action="store_true")
    p.add_argument("--preflight-only",action="store_true")
    args=p.parse_args()
    verify_package()
    require(args.ack_row_feedback,"Explicit row-immediate feedback acknowledgment required")
    require(args.device=="cpu" or torch.cuda.is_available(),"CUDA unavailable")
    root=Path(args.output_root).resolve()
    allowed=(ROOT/"outputs").resolve()
    require(root!=allowed and root.is_relative_to(allowed) and not root.exists(),"Output must be a NEW child under package outputs; no overwrite/resume")
    root.mkdir(parents=True)
    started=time.perf_counter()
    status={"status":"running","active_job":"input_checks","pid":os.getpid(),"jobs":[],"trained":False,"test_evaluated":False}
    save(root/"suite_status.json",status)
    try:
        torch.set_num_threads(4)
        torch.manual_seed(20261022)
        torch.use_deterministic_algorithms(True)
        torch.backends.cudnn.benchmark=False
        torch.backends.cudnn.allow_tf32=False
        torch.backends.cuda.matmul.allow_tf32=False
        checked=verify_archive(args.a1_archive)
        module,metric=load_clean(args.project_dir)
        save(root/"suite_config.json",{"args":vars(args),"a1":checked,"branches":list(MODES),
            "deployment":"policies start at validation boundary; train writes unchanged",
            "readout":"zero unsupported static student-KC logit throughout valid, not just first row",
            "feedback_boundaries_verified":False,"trained":False,"test_evaluated":False,
            "bootstrap_reps":1000,"thresholds_fixed":[1,4],"factor_fixed":0.5})
        for device in dict.fromkeys(("cpu",args.device)):
            name="tests_"+device
            status["active_job"]=name; save(root/"suite_status.json",status)
            with (root/(name+".log")).open("x",encoding="utf-8") as log:
                proc=subprocess.run([sys.executable,"-B",str(ROOT/"test_core.py"),"--project-dir",args.project_dir,"--device",device],stdout=log,stderr=subprocess.STDOUT,cwd=ROOT)
            require(proc.returncode==0,"Tests failed; read "+name+".log")
            status["jobs"].append({"name":name,"returncode":0})
        for job in JOBS:
            print("START",job,flush=True)
            t0=time.perf_counter()
            status["active_job"]=job; save(root/"suite_status.json",status)
            folder=root/job; folder.mkdir()
            save(folder/"status.json",{"status":"running","job":job})
            frame,cfg=read_job(args.a1_archive,job)
            frame=policy_states(frame)
            expected_after=15353 if job.startswith("assist") else 3213
            require(int(frame.after_early_negative.sum())==expected_after,"A2 subgroup identity/count changed")
            model=load_checkpoint(module,cfg,args.device)
            selected=np.sort(frame.student_idx.unique())[:32]
            pre=frame[frame.student_idx.isin(selected)].reset_index(drop=True).copy()
            left,gate=predict(pre.copy(),model,module.State,args.device,128)
            right,_=predict(pre.copy(),model,module.State,args.device,17)
            diffs={m:float(np.max(np.abs(left[m+"_probability"]-right[m+"_probability"]))) for m in MODES}
            require(max(diffs.values())<=1e-6,"Batch 17 equivalence failed")
            save(folder/"preflight.json",{"success":True,"n":len(pre),"reference_gate":gate,"batch_difference":diffs})
            if args.preflight_only:
                save(folder/"status.json",{"status":"preflight_complete","job":job,"seconds":time.perf_counter()-t0})
                status["jobs"].append({"name":job+"_preflight","returncode":0})
                continue
            predicted,gate=predict(frame,model,module.State,args.device,128)
            print("PREDICTED",job,"n=",len(predicted),"computing paired summaries",flush=True)
            summary=summarize(predicted,metric.compute_metrics,1000)
            keep=["record_idx","student_idx","item_idx","timestamp","label","kc","same_time","split",
                  "kc_count_before","train_kc_count","train_supported","after_early_negative"]+[m+"_probability" for m in MODES]
            predicted[keep].to_csv(folder/"predictions.csv.gz",index=False,float_format="%.17g",compression="gzip")
            save(folder/"summary.json",summary)
            save(folder/"reference_gate.json",gate)
            save(folder/"run_config.json",{"source_job":cfg["job"],"a1_sha256":A1_SHA,"source_model_sha256":MODEL_SHA,
                "source_metrics_sha256":METRIC_SHA,"device":args.device,"batch_size":128,"trained":False,
                "test_evaluated":False,"feedback_boundaries_verified":False,"parameters_changed":False})
            require(sha(cfg["job"]["checkpoint"])==cfg["job"]["checkpoint_sha256"],"Checkpoint changed during job")
            result={"status":"complete","job":job,"n":len(predicted),"seconds":time.perf_counter()-t0,"parameters_changed":False}
            save(folder/"status.json",result)
            status["jobs"].append({"name":job,"returncode":0})
            print("COMPLETE",json.dumps(result),flush=True)
        require(sha(args.a1_archive)==A1_SHA,"A1 changed during run")
        require(sha(Path(args.project_dir)/"src/model.py")==MODEL_SHA and sha(Path(args.project_dir)/"src/metrics.py")==METRIC_SHA,"Source changed during run")
        status.update(status="preflight_complete" if args.preflight_only else "complete",active_job=None,
                      full_jobs=0 if args.preflight_only else 4,seconds=time.perf_counter()-started)
        save(root/"suite_status.json",status)
        files=sorted(x for x in root.rglob("*") if x.is_file())
        save(root/"results_manifest.json",{"files":{x.relative_to(root).as_posix():sha(x) for x in files}})
        files.append(root/"results_manifest.json")
        with zipfile.ZipFile(root/"a3_results.zip","x",compression=zipfile.ZIP_DEFLATED) as z:
            for file in files:
                z.write(file,file.relative_to(root).as_posix())
        with zipfile.ZipFile(root/"a3_results.zip") as z:
            require(z.testzip() is None,"Result ZIP CRC")
        print("PREFLIGHT_COMPLETED" if args.preflight_only else "ALL_RUNS_COMPLETED",flush=True)
        print("Results archive:",root/"a3_results.zip",flush=True)
    except BaseException as exc:
        active=status.get("active_job")
        if active in JOBS and (root/active).is_dir():
            save(root/active/"status.json",{"status":"failed","job":active,"error":repr(exc)})
        status.update(status="failed",active_job=status.get("active_job"),error=repr(exc),seconds=time.perf_counter()-started)
        save(root/"suite_status.json",status)
        raise


if __name__=="__main__":
    main()
