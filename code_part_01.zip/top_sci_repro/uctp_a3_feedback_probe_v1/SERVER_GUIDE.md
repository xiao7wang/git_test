# A3 服务器操作步骤

日期：2026-10-22。不重新训练，不更换原项目，不使用原来的 run_baselines.py。只上传本包，默认 CPU 4 线程。A0/A2 结果不需要再次上传或重跑。

## 1. 上传

将桌面的 `uctp_a3_feedback_probe_v1.zip` 上传到 VS Code Remote SSH 中：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1.zip`

不用在编辑器中打开 ZIP。下列操作全部在服务器终端执行。

## 2. 安全解压与输入预检

先执行 `sha256sum /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1.zip`，与交付消息给出的哈希核对。

然后完整复制：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python - <<'PY'
from pathlib import Path, PurePosixPath
import zipfile

parent = Path('/home/wangxiao/QCCDM/top_sci_repro').resolve()
target = parent / 'uctp_a3_feedback_probe_v1'
archive = parent / 'uctp_a3_feedback_probe_v1.zip'
a1 = parent / 'uctp_update_scale_probe_v1/outputs/server_a1_02/a1_results.zip'
if target.exists():
    raise SystemExit('目标目录已存在：停止，不覆盖；若此前已成功解压，请直接检查后再启动。')
if not a1.is_file():
    raise SystemExit(f'缺少已验收 A1 文件：{a1}')
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise SystemExit('ZIP CRC 检查失败')
    for name in z.namelist():
        relative = PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or '\\' in name or relative.parts[0] != target.name:
            raise SystemExit(f'不安全的包内路径：{name}')
        if not (parent / name).resolve().is_relative_to(target):
            raise SystemExit(f'越界路径：{name}')
    z.extractall(parent)
print('解压完成：', target)
print('A1 文件存在；运行时还会核验其完整 SHA-256。')
PY
```

出现异常时停止，把原报错发回；不要执行删除、覆盖、chmod 777 或重装环境。

## 3. 一条命令在 tmux 后台跑完

```bash
tmux new-session -d -s a3probe "bash /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/run_server.sh"
```

没有报错通常意味着成功创建会话，不等于四个作业已完成。若提示 duplicate session，不要重复启动：先查看已有会话和日志。

脚本会顺序运行输入核验、18 项 CPU 测试、四组批大小/原预测预检和四个完整 validation 作业，然后生成结果 ZIP。所有 checkpoint 都冻结，没有训练 epoch。

关闭 SSH/VS Code 不会停止 tmux 内的作业。想进入查看可运行 `tmux attach -t a3probe`；退出观察用 Ctrl+B，松开后按 D。不要用 Ctrl+C 代替复制，Ctrl+C 会中断作业。

预计是分钟到几十分钟量级的诊断，不能用之前训练一天半的耗时估算；实际由服务器 CPU、负载和存储决定。日志每个 COMPLETE 会给出该作业 seconds。没有本服务器 A3 实测前不保证具体时长。

## 4. 查看是否完成

```bash
tail -n 60 /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/suite_server_a3_01.log
```

最终成功标记：`ALL_RUNS_COMPLETED`。

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -m json.tool /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/outputs/server_a3_01/suite_status.json
```

应看到 `status: complete`、`full_jobs: 4`、`trained: false`、`test_evaluated: false`。最后得到 ZIP 才算整套结束。

保存的 running 状态不证明进程仍活着。若日志长期不变，检查：

```bash
pgrep -a -u wangxiao -f 'uctp_a3_feedback_probe_v1|run_suite[.]py'
tmux ls
```

任务正常结束后 tmux 会话会自动退出，所以之后找不到 a3probe 也可能是完成，应以状态文件和日志为准。

如要打印完整比较表：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/show_results.py --run-root /home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/outputs/server_a3_01
```

正的 delta_nll 是变差，不是提升。不要只截取一个最好的切片。

## 5. 下载这一个结果包

`/home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1/outputs/server_a3_01/a3_results.zip`

直接下载发回即可。无需下载新 checkpoint，因为本轮不生成 checkpoint。

## 出错怎么办

保留当前目录和日志。发送 `suite_status.json`、总日志末尾，以及报错所指 tests_cpu.log。不要再运行同一命令覆盖结果。本脚本有拒绝覆盖保护，旧输出存在时再次启动会停止；如需修复后重跑，应使用明确的新运行目录和日志名。

若 CPU 原预测桥接失败，不要改 1e-6 容差或擅自换 checkpoint；先返回完整差异与日志。若要改用 CUDA，应确认空闲 GPU，并在新的输出目录按审核后的命令运行，不与当前 CPU 作业重复启动。
