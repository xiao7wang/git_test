"""Synthetic A3 tests: no real checkpoint or dataset required."""
import argparse
import copy
import sys
import unittest
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from core import (POLICIES,MODES,policy_states,load_clean,predict,parameter_digest,summarize)


def fixture(labels=None):
    events=[(0,0),(0,1),(0,0),(0,0),(0,1),(0,0),(0,0),(0,0),
            (1,0),(1,0),(1,1),(1,0),(1,1),(1,1)]
    labels=[0,1,0,1,0,0,0,1,0,0,1,1,0,0] if labels is None else labels
    history={(0,0):[2,1],(0,1):[0,0],(1,0):[0,0],(1,1):[1,0]}
    rows=[]
    for i,((u,k),y) in enumerate(zip(events,labels)):
        p,n=history[(u,k)]
        rows.append(dict(record_idx=i,student_idx=u,item_idx=k,timestamp=100+i*10,kc=k,label=y,split=1,
                         positive=p,negative=n,kc_count_before=p+n,same_time=False,u0_probability=.5))
        history[(u,k)]=[p+y,n+1-y]
    return pd.DataFrame(rows)


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.module,cls.metrics=load_clean(PROJECT)
        torch.manual_seed(20261022)
        cls.model=cls.module.CleanCD(2,2,2,variant="unit_write",ncd_hidden_dim=8).eval().requires_grad_(False).to(DEVICE)

    def test_unit_prefix_reconstruction(self):
        f=policy_states(fixture())
        np.testing.assert_array_equal(f.unit_positive,f.positive)
        np.testing.assert_array_equal(f.unit_negative,f.negative)

    def test_exact_sequential_policy_replay(self):
        f=policy_states(fixture())
        for policy in POLICIES:
            h={}
            for _,r in f.iterrows():
                key=(r.student_idx,r.kc)
                p,n=h.setdefault(key,(r.train_positive,r.train_negative))
                self.assertEqual(p,r[policy+"_positive"])
                self.assertEqual(n,r[policy+"_negative"])
                w=.5 if r.label==0 and (policy=="negative_half" or (policy=="early_negative_half" and 1<=r.kc_count_before<=4)) else 1.
                h[key]=(p+w*r.label,n+w*(1-r.label))

    def test_current_and_future_response_not_in_current_state(self):
        original=fixture()
        before=policy_states(original)
        for index in range(len(original)):
            changed=original.label.tolist()
            changed[index:]=[1-y for y in changed[index:]]
            after=policy_states(fixture(changed))
            for policy in POLICIES:
                for suffix in ("positive","negative"):
                    col=policy+"_"+suffix
                    np.testing.assert_array_equal(before[col].iloc[:index+1],after[col].iloc[:index+1])

    def test_prefix_truncation(self):
        before=policy_states(fixture())
        for end in range(1,len(before)+1):
            after=policy_states(fixture().iloc[:end])
            for policy in POLICIES:
                for suffix in ("positive","negative"):
                    np.testing.assert_array_equal(before[policy+"_"+suffix].iloc[:end],after[policy+"_"+suffix])

    def test_train_prefix_is_unchanged(self):
        f=policy_states(fixture())
        first=f.groupby(["student_idx","kc"]).head(1)
        for policy in POLICIES:
            np.testing.assert_array_equal(first[policy+"_positive"],first.train_positive)
            np.testing.assert_array_equal(first[policy+"_negative"],first.train_negative)

    def test_count_boundaries_and_positive_write(self):
        f=policy_states(fixture())
        row=f[f.student_idx.eq(0)&f.kc.eq(0)]
        self.assertEqual(row.kc_count_before.tolist(),[3,4,5,6,7,8])
        self.assertEqual(row.early_negative_half_negative.tolist(),[1,1.5,2,2,3,4])
        np.testing.assert_array_equal(f.early_negative_half_positive,f.positive)

    def test_unsupported_flag_persists_after_first_response(self):
        f=policy_states(fixture())
        self.assertTrue((~f.loc[f.student_idx.eq(1)&f.kc.eq(0),"train_supported"]).all())
        self.assertTrue(f.loc[f.student_idx.eq(0)&f.kc.eq(0),"train_supported"].all())

    def test_reject_bad_order(self):
        with self.assertRaises(ValueError): policy_states(fixture().iloc[::-1])

    def test_reject_duplicate(self):
        f=fixture(); f.loc[1,"record_idx"]=0
        with self.assertRaises(ValueError): policy_states(f)

    def test_reject_gap_in_export(self):
        with self.assertRaises(ValueError): policy_states(fixture().drop(index=2))

    def test_reject_test_rows(self):
        f=fixture(); f.loc[0,"split"]=2
        with self.assertRaises(ValueError): policy_states(f)

    def test_prediction_native_head_and_batch_equivalence(self):
        f=policy_states(fixture())
        a,gate=predict(f.copy(),self.model,self.module.State,DEVICE,2,bridge=False)
        b,_=predict(f.copy(),self.model,self.module.State,DEVICE,17,bridge=False)
        self.assertLessEqual(gate["native_vs_head"],1e-6)
        for m in MODES:
            np.testing.assert_allclose(a[m+"_probability"],b[m+"_probability"],atol=1e-6,rtol=0)

    def test_target_labels_not_used_in_predict(self):
        f=policy_states(fixture())
        a,_=predict(f.copy(),self.model,self.module.State,DEVICE,128,bridge=False)
        f["label"]=1-f.label
        b,_=predict(f,self.model,self.module.State,DEVICE,128,bridge=False)
        for m in MODES:
            np.testing.assert_array_equal(a[m+"_probability"],b[m+"_probability"])

    def test_full_prediction_causality(self):
        a,_=predict(policy_states(fixture()),self.model,self.module.State,DEVICE,128,bridge=False)
        labels=fixture().label.tolist(); labels[3:]=[1-y for y in labels[3:]]
        b,_=predict(policy_states(fixture(labels)),self.model,self.module.State,DEVICE,128,bridge=False)
        for m in MODES:
            np.testing.assert_array_equal(a[m+"_probability"].iloc[:4],b[m+"_probability"].iloc[:4])

    def test_zero_matches_explicit_copy_without_mutating_original(self):
        f=policy_states(fixture())
        before=parameter_digest(self.model)
        out,_=predict(f.copy(),self.model,self.module.State,DEVICE,128,bridge=False)
        changed=copy.deepcopy(self.model)
        with torch.no_grad():
            changed.student_mastery_logit.weight[0,1]=0
            changed.student_mastery_logit.weight[1,0]=0
        expected,_=predict(f.copy(),changed,self.module.State,DEVICE,128,bridge=False)
        for p in POLICIES:
            np.testing.assert_array_equal(out["zero_unsupported__"+p+"_probability"],expected["original__"+p+"_probability"])
        self.assertEqual(before,parameter_digest(self.model))

    def test_original_reference_gate_rejects_mismatch(self):
        with self.assertRaisesRegex(ValueError,"A1 baseline bridge"):
            predict(policy_states(fixture()),self.model,self.module.State,DEVICE,128,bridge=True)

    def test_zero_does_not_erase_dynamic_history(self):
        f=policy_states(fixture())
        out,_=predict(f,self.model,self.module.State,DEVICE,128,bridge=False)
        rows=out[out.student_idx.eq(1)&out.kc.eq(0)]
        self.assertGreater(rows.zero_unsupported__unit_probability.nunique(),1)

    def test_summary_zero_difference_and_empty_group(self):
        f=policy_states(fixture())
        for mode in MODES: f[mode+"_probability"]=.6
        f["after_early_negative"]=False
        s=summarize(f,self.metrics.compute_metrics,reps=10)
        self.assertEqual(s["groups"]["after_early_negative"]["n"],0)
        for c in s["groups"]["all"]["comparisons"].values():
            self.assertEqual(c["delta_nll"],0)
            self.assertEqual(c["event_ci95"],[0,0])


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--project-dir",required=True)
    parser.add_argument("--device",choices=("cpu","cuda"),default="cpu")
    args=parser.parse_args()
    PROJECT=Path(args.project_dir); DEVICE=args.device
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32=False
    unittest.main(argv=[sys.argv[0]],verbosity=2)
