"""Read A3 saved progress/results; saved running status is not process liveness."""
import argparse
import json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument("--run-root",required=True)
args=p.parse_args()
root=Path(args.run_root)
status=json.loads((root/"suite_status.json").read_text(encoding="utf-8"))
print("Suite:",status["status"],"Active:",status.get("active_job"),"Seconds:",status.get("seconds"))
if status.get("error"): print("Error:",status["error"])
for dataset in ("assist","ednet"):
    for seed in (1,2):
        name=f"{dataset}_unit_write_seed{seed}"
        folder=root/name
        if not (folder/"status.json").exists():
            print(name,"not_started"); continue
        s=json.loads((folder/"status.json").read_text(encoding="utf-8"))
        print("\n",name,s["status"])
        if s["status"]!="complete": continue
        summary=json.loads((folder/"summary.json").read_text(encoding="utf-8"))
        for group in ("all","train_supported","train_unsupported","after_early_negative"):
            g=summary["groups"][group]
            print(" ",group,"n=",g["n"])
            for key,value in g["comparisons"].items():
                print("   ",key,"event_delta=",f"{value['delta_nll']:+.7f}","macro_delta=",f"{value['delta_student_macro_nll']:+.7f}","event_ci95=",value["event_ci95"])
print("\nPositive delta means worse. Running is a saved status, not proof of a live process.")
