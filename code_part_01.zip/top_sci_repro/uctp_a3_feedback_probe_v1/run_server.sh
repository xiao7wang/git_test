#!/usr/bin/env bash
set -euo pipefail

PACKAGE=/home/wangxiao/QCCDM/top_sci_repro/uctp_a3_feedback_probe_v1
PYTHON=/home/wangxiao/miniconda3/envs/yydw/bin/python
OUT="$PACKAGE/outputs/server_a3_01"
LOG="$PACKAGE/suite_server_a3_01.log"

if [ -e "$OUT" ] || [ -e "$LOG" ]; then
  printf '%s\n' 'Output or log already exists. Stop: do not overwrite or launch a duplicate run.'
  exit 2
fi
cd "$PACKAGE"
export OMP_NUM_THREADS=4
export OPENBLAS_NUM_THREADS=4
export MKL_NUM_THREADS=4
export CUBLAS_WORKSPACE_CONFIG=:4096:8

# CPU is deliberate: frozen batched inference, not long training; no GPU contention.
"$PYTHON" -B -u run_suite.py \
  --output-root "$OUT" \
  --device cpu \
  --ack-row-feedback 2>&1 | tee "$LOG"
