"""Compare vectorized/grouped features to a simple timestamp-by-timestamp replay."""
import math
import unittest

import numpy as np

from feedback_guard.core import block_features, select_and_filter
from session_control.features import build


def reference_replay(features):
    """Naive per-student dictionaries: predict a whole time block, then update."""
    u, k, t, y = (features[name] for name in ('student', 'kc', 'timestamp', 'label'))
    n = len(u)
    output = np.zeros((n, 5), dtype=float)
    states = {}
    previous_user = None
    previous_timestamp = None
    session = 0
    begin = 0
    while begin < n:
        end = begin + 1
        while end < n and u[end] == u[begin] and t[end] == t[begin]:
            end += 1
        user, timestamp = int(u[begin]), float(t[begin])
        if user != previous_user:
            states = {}
            session = 0
        elif timestamp - previous_timestamp > 10 * 3600:
            session += 1
        pending = {}
        counts = {}
        for i in range(begin, end):
            concept = int(k[i])
            if concept not in pending:
                state = states.get(concept)
                if state is None:
                    ss = sf = ts = tf = 0.
                    prior = 0
                else:
                    ss, sf, ts, tf, prior, last_time, last_session = state
                    sd = .5 ** (session - last_session)
                    td = math.exp(-math.log(2) * (timestamp-last_time) / (168*3600))
                    ss, sf, ts, tf = ss*sd, sf*sd, ts*td, tf*td
                pending[concept] = (ss, sf, ts, tf, prior)
                counts[concept] = [0, 0]
            ss, sf, ts, tf, prior = pending[concept]
            output[i] = [ss, sf, ts, tf, prior]
            counts[concept][int(y[i])] += 1
        for concept, (ss, sf, ts, tf, prior) in pending.items():
            failure, success = counts[concept]
            states[concept] = (ss+success, sf+failure, ts+success, tf+failure,
                               prior+success+failure, timestamp, session)
        previous_user, previous_timestamp = user, timestamp
        begin = end
    return output


class RandomizedReferenceTest(unittest.TestCase):
    def test_random_timestamp_blocks_match_independent_replay(self):
        for random_seed in range(30):
            rng = np.random.default_rng(random_seed)
            users, items, times, labels, splits = [], [], [], [], []
            for user in range(4):
                clock = 0
                for j in range(24):
                    clock += int(rng.choice([0, 0, 3600, 36000, 36001, 604800]))
                    users.append(user)
                    items.append(int(rng.integers(0, 4)))
                    times.append(clock)
                    labels.append(int(rng.integers(0, 2)))
                    splits.append(0 if j < 14 else (1 if j < 22 else 2))
            arrays = {'student_idx': np.array(users), 'item_idx': np.array(items),
                      'timestamp': np.array(times, dtype=float), 'label': np.array(labels, dtype=float),
                      'split': np.array(splits), 'item_q': np.eye(4, dtype=int)}
            selected, original, _ = select_and_filter(arrays, {0, 1, 2, 3})
            row = build(selected, {0, 1, 2, 3}, threshold_hours=10., retention=.5)
            row['record_idx'] = original[row['record_idx']]
            blocked = block_features(row)
            expected = reference_replay(row)
            actual = np.column_stack((*blocked['session_states'], *blocked['states']['C_real_time'],
                                      blocked['prior_kc_count']))
            np.testing.assert_allclose(actual, expected, atol=1e-11, rtol=0,
                                       err_msg=f'random fixture seed {random_seed}')


if __name__ == '__main__':
    unittest.main()
