import copy
import unittest

import numpy as np

from feedback_guard.core import block_features, select_and_filter
from session_control.features import build


def fixture():
    return {
        'student_idx': np.array([0]*9 + [1]*3),
        'item_idx': np.array([0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 1]),
        'split': np.array([0, 0, 0, 0, 1, 1, 1, 1, 2, 0, 1, 2]),
        'timestamp': np.array([0, 0, 7200, 180000, 180000, 183600, 183600, 187200, 190800,
                               0, 3600, 7200], dtype=float),
        'label': np.array([1, 0, 1, 0, 1, 0, 1, 1, np.nan, 1, np.nan, np.nan]),
        'item_q': np.eye(2, dtype=int),
    }


def prepared(arrays=None):
    arrays = fixture() if arrays is None else arrays
    a, original, report = select_and_filter(arrays, {0})
    f = build(a, {0}, threshold_hours=10., retention=.5)
    f['record_idx'] = original[f['record_idx']]
    return f, report


class SelectionContracts(unittest.TestCase):
    def test_cross_split_group_removed_from_both_sides_and_history(self):
        reduced, orig, report = select_and_filter(fixture(), {0})
        self.assertEqual(orig.tolist(), [0, 1, 2, 5, 6, 7, 9])
        self.assertEqual(report['excluded_mixed_timestamp_groups'], 1)
        self.assertEqual(report['excluded_mixed_timestamp_train_events'], 1)
        self.assertEqual(report['excluded_mixed_timestamp_development_events'], 1)
        self.assertTrue(np.isfinite(reduced['label']).all())

    def test_unselected_labels_never_influence_outputs(self):
        a = fixture()
        f1, r1 = prepared(a)
        a['label'][8:] = [1., 1., 1., 0.]
        f2, r2 = prepared(a)
        self.assertEqual(r1, r2)
        self.assertTrue(np.array_equal(f1['label'], f2['label']))
        for mode in ('A_none', 'C_real_time'):
            for v1, v2 in zip(f1['states'][mode], f2['states'][mode]):
                np.testing.assert_array_equal(v1, v2)

    def test_same_time_split_group_must_be_filtered_before_blocking(self):
        a = fixture()
        # Deliberately bypass filter for selected rows to check the block guard.
        take = np.array([0,1,2,3,4,5,6,7,9])
        x = {k: (v if k == 'item_q' else v[take]) for k,v in a.items()}
        f = build(x, {0}, threshold_hours=10., retention=.5)
        with self.assertRaises(ValueError):
            block_features(f)


class BlockContracts(unittest.TestCase):
    def test_same_second_uses_only_past_answers(self):
        f, _ = prepared()
        b = block_features(f)
        original = f['record_idx']
        i5, i6, i7 = [int(np.flatnonzero(original == i)[0]) for i in (5,6,7)]
        s, n = b['session_states']
        self.assertAlmostEqual(s[i5], 1.)
        self.assertAlmostEqual(n[i5], .5)
        self.assertAlmostEqual(s[i6], s[i5])
        self.assertAlmostEqual(n[i6], n[i5])
        self.assertAlmostEqual(s[i7], 2.)
        self.assertAlmostEqual(n[i7], 1.5)
        self.assertEqual(b['prior_kc_count'][i5], 3)
        self.assertEqual(b['prior_kc_count'][i6], 3)
        self.assertEqual(b['same_time_kc_group_size'][i5], 2)

    def test_timed_history_has_correct_group_decay(self):
        f, _ = prepared()
        b = block_features(f)
        i = int(np.flatnonzero(f['record_idx'] == 5)[0])
        f2 = 2**(-2/168)
        f49 = 2**(-49/168)
        self.assertAlmostEqual(b['states']['C_real_time'][0][i], (f2+1)*f49, places=11)
        self.assertAlmostEqual(b['states']['C_real_time'][1][i], f2*f49, places=11)

    def test_no_current_or_peer_answer_visible_in_block(self):
        a = fixture()
        f1, _ = prepared(a)
        a['label'][5:7] = [1, 0]
        f2, _ = prepared(a)
        b1, b2 = block_features(f1), block_features(f2)
        for orig in (5, 6):
            i = int(np.flatnonzero(f1['record_idx'] == orig)[0])
            for key in ('session_states',):
                self.assertEqual(b1[key][0][i], b2[key][0][i])
                self.assertEqual(b1[key][1][i], b2[key][1][i])
            for j in (0, 1):
                self.assertEqual(b1['states']['C_real_time'][j][i], b2['states']['C_real_time'][j][i])

    def test_no_same_time_same_kc_collisions_match_original(self):
        a = fixture()
        a['timestamp'][1] = 3600
        a['timestamp'][6] = 185400
        f, _ = prepared(a)
        b = block_features(f)
        for mode in ('session_states',):
            for before, after in zip(f[mode], b[mode]):
                np.testing.assert_allclose(before, after, atol=1e-12, rtol=0)
        for before, after in zip(f['states']['C_real_time'], b['states']['C_real_time']):
            np.testing.assert_allclose(before, after, atol=1e-12, rtol=0)

    def test_label_permutation_inside_a_group_preserves_block_features(self):
        a = fixture()
        f1, _ = prepared(a)
        a['label'][5], a['label'][6] = a['label'][6], a['label'][5]
        f2, _ = prepared(a)
        b1, b2 = block_features(f1), block_features(f2)
        for before, after in zip(b1['session_states'], b2['session_states']):
            np.testing.assert_allclose(before, after, atol=1e-12, rtol=0)
        for before, after in zip(b1['states']['C_real_time'], b2['states']['C_real_time']):
            np.testing.assert_allclose(before, after, atol=1e-12, rtol=0)


if __name__ == '__main__':
    unittest.main()

