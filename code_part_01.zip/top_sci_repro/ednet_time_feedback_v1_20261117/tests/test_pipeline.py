import gzip
import hashlib
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np

from feedback_guard.analysis import MODES, analyze
from feedback_guard.inventory import collect
from feedback_guard.runner import run
from test_core import fixture


class EndToEndTests(unittest.TestCase):
    def test_twelve_models_partial_and_final_archives(self):
        with tempfile.TemporaryDirectory(prefix='ednet_feedback_synthetic_') as temp:
            out = Path(temp) / 'output'
            archive = run(fixture(), {0}, out, metadata={'synthetic': True}, qccdm_root=Path(temp) / 'missing',
                          device='cpu', epochs=2, patience=2, batch_size=4, repetitions=20)
            status = json.loads((out / 'status.json').read_text(encoding='utf-8'))
            self.assertEqual(status['status'], 'complete')
            self.assertEqual(len(status['completed_jobs']), 12)
            with zipfile.ZipFile(archive) as z:
                self.assertIsNone(z.testzip())
                hashes = json.loads(z.read('manifest.json'))['files']
                self.assertEqual(set(z.namelist()), set(hashes) | {'manifest.json'})
                for name, expected in hashes.items():
                    self.assertEqual(hashlib.sha256(z.read(name)).hexdigest(), expected)
                config, summary = (json.loads(z.read(name)) for name in ('config.json', 'summary.json'))
                self.assertEqual(config['selection']['excluded_mixed_timestamp_groups'], 1)
                self.assertEqual(config['population']['development_events'], 3)
                self.assertEqual(config['population']['development_events_same_timestamp_same_kc_group'], 2)
                self.assertEqual(summary['status'], 'complete')
                self.assertFalse(summary['test_evaluated'])
                self.assertEqual(set(summary['analysis']['groups']['all_development']['models']), set(MODES))
                self.assertTrue(all(v['initial_state_matches'] for v in summary['pairing'].values()))
                self.assertFalse(any(name.endswith('best_model.pt') for name in z.namelist()))
                events = gzip.decompress(z.read('event_features.csv.gz')).decode().splitlines()
                self.assertEqual(len(events), 4)
            with zipfile.ZipFile(out / 'partial_seed0.zip') as z:
                self.assertIsNone(z.testzip())
                self.assertEqual(sum(name.startswith('predictions/') for name in z.namelist()), 4)
            with self.assertRaises(FileExistsError):
                run(fixture(), {0}, out, metadata={}, qccdm_root=temp, device='cpu', epochs=1, repetitions=1)

    def test_reported_contrast_is_average_of_seed_losses(self):
        f = {'split': np.array([0, 1, 1, 1]), 'student': np.array([0, 0, 0, 1]),
             'label': np.array([1, 0, 1, 1]), 'same_time_kc_group_size': np.array([1, 1, 2, 2])}
        predictions = {mode: {seed: np.array([.2, .8, .6]) for seed in range(3)} for mode in MODES}
        predictions['block_time'] = {seed: np.array([.3, .9, .7]) for seed in range(3)}
        result = analyze(f, predictions, repetitions=10)
        p = result['groups']['all_development']['paired']['block_time_minus_block_session']
        manual = np.mean([(-np.log(1-.3) + np.log(1-.2)), (-np.log(.9) + np.log(.8)),
                          (-np.log(.7) + np.log(.6))])
        self.assertAlmostEqual(p['event_delta'], manual)

    def test_raw_inventory_is_bounded_and_aggregate_only(self):
        with tempfile.TemporaryDirectory(prefix='ednet_raw_sample_') as temp:
            d = Path(temp) / 'qccdm改进代码' / 'data_raw' / 'ednet' / 'KT1' / 'KT1'
            d.mkdir(parents=True)
            (d / 'u1.csv').write_text('timestamp,solving_id,question_id,user_answer\n'
                                       '1000,42,q1,a\n2000,42,q2,b\n3000,43,q3,c\n', encoding='utf-8')
            report = collect(temp)
            sample = report['raw_kt1_convenience_sample']
            self.assertEqual(sample['files_read'], 1)
            self.assertEqual(sample['multi_question_groups'], 1)
            self.assertEqual(sample['multi_groups_spanning_integer_seconds'], 1)
            self.assertFalse(sample['mapping_to_prepared_events_verified'])
            text = json.dumps(sample)
            self.assertNotIn('q1', text)
            self.assertNotIn('1000', text)


if __name__ == '__main__':
    unittest.main()
