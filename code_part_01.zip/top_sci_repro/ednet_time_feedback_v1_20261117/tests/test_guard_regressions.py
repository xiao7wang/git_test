import unittest
import numpy as np

from feedback_guard.core import select_and_filter
from session_control.features import build


class FurtherGuards(unittest.TestCase):
    def test_mixed_student_timestamp_removed_even_when_kcs_differ(self):
        arrays = {'student_idx': np.array([0, 0, 0, 0, 0]),
                  'item_idx': np.array([0, 0, 1, 1, 0]),
                  'split': np.array([0, 0, 1, 1, 2]),
                  'timestamp': np.array([0., 3600., 3600., 7200., 10800.]),
                  'label': np.array([1., 0., 1., 0., np.nan]), 'item_q': np.eye(2, dtype=int)}
        reduced, idx, report = select_and_filter(arrays, {0})
        self.assertEqual(idx.tolist(), [0, 3])
        self.assertEqual(report['excluded_mixed_timestamp_groups'], 1)
        self.assertEqual(reduced['label'].tolist(), [1., 0.])

    def test_exactly_ten_hours_is_not_a_new_boundary(self):
        arrays = {'student_idx': np.array([0, 0, 0]), 'item_idx': np.array([0, 0, 0]),
                  'split': np.array([0, 0, 1]),
                  'timestamp': np.array([0., 36000., 72001.]),
                  'label': np.array([1., 1., 0.]), 'item_q': np.ones((1, 1), dtype=int)}
        f = build(arrays, {0})
        self.assertEqual(f['starts_session'].tolist(), [False, False, True])
        self.assertAlmostEqual(f['session_states'][0][2], 1.)


if __name__ == '__main__':
    unittest.main()
