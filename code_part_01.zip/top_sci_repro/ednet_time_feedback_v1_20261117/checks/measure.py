"""Stable synthetic guard metric; final stdout line is failures/errors."""
import sys
import unittest
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src'))
suite = unittest.defaultTestLoader.discover(str(root / 'tests'), pattern='test_core.py')
result = unittest.TextTestRunner(stream=sys.stderr, verbosity=1).run(suite)
print(len(result.failures) + len(result.errors))

