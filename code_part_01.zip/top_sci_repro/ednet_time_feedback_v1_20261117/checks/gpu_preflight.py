"""Exercise the GPU before full-data loading."""
import json
import torch

if not torch.cuda.is_available():
    raise RuntimeError('CUDA unavailable; no automatic CPU fallback')
torch.use_deterministic_algorithms(True)
x = torch.tensor([[1., 2.], [3., 4.]], device='cuda', requires_grad=True)
loss = (x @ x).sum()
loss.backward()
torch.cuda.synchronize()
if not torch.isfinite(loss).item() or not torch.isfinite(x.grad).all().item():
    raise RuntimeError('non-finite GPU preflight')
print(json.dumps({'phase': 'gpu_preflight_ok', 'gpu': torch.cuda.get_device_name(0),
                  'torch': str(torch.__version__)}), flush=True)
