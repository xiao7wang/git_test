"""Release and hardware checks."""
