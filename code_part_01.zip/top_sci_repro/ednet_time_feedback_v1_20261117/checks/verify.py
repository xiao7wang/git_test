"""Verify delivered release files without importing code from the release."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def verify_release():
    manifest_path = ROOT / 'release_manifest.json'
    raw = manifest_path.read_bytes()
    files = json.loads(raw)['files']
    required = {'README.md', 'run_server.sh', 'checks/verify.py', 'checks/gpu_preflight.py',
                'tests/test_core.py', 'tests/test_pipeline.py', 'src/feedback_guard/core.py',
                'src/feedback_guard/server.py', 'src/feedback_guard/runner.py',
                'src/feedback_guard/analysis.py', 'src/feedback_guard/inventory.py',
                'src/count_time/features.py', 'src/session_control/features.py', 'src/session_control/train.py'}
    if not isinstance(files, dict) or not required.issubset(files):
        raise ValueError('release manifest missing required files')
    for name, expected in files.items():
        path = (ROOT / name).resolve()
        if not path.is_relative_to(ROOT) or not path.is_file():
            raise ValueError(f'unsafe or missing release file: {name}')
        if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            raise ValueError(f'release file changed: {name}')
    return {'manifest_sha256': hashlib.sha256(raw).hexdigest(), 'file_count': len(files)}


if __name__ == '__main__':
    print(json.dumps({'phase': 'release_verified', **verify_release()}))
