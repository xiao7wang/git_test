# EDNet time-rule and feedback-timestamp sensitivity experiment

This release is exploratory on the previously used EDNet prepared dataset. It
is **not** an independent blind test. It compares session retention 0.5 and
elapsed-time half-life 168h on the same selected development events under
row-immediate and same-timestamp-block feedback policies. Both sides of a
student/timestamp group spanning train and development are removed before
feature construction, training and scoring; 10h stage boundaries are then
recomputed from retained events. A same-timestamp block is not a
verified solving bundle or true feedback boundary, and distinct-timestamp
items in one real bundle are not protected by this proxy.

The primary outcome is event NLL: block time minus block session, with the
student-cluster bootstrap conditional on the selected fitted models. Three
paired seeds share initialization and training-order checks; the selected
development data are reused, and test/holdout are not evaluated. The prepared
NPZ label array includes test labels and is loaded as a whole before filtering.
The prepared vocabulary was built from a label-free union of train, valid, and
test IDs; `holdout_evaluated=false` refers to the complement under this run's
own student partition, not a guarantee about overlap with old holdouts.

Run `bash run_server.sh server_ednet_01` from the provided server package. The
script refuses to overwrite existing logs or output. The result ZIP contains
only development predictions and aggregate diagnostic/lineage information;
it does not contain the model checkpoints or original raw KT1 events.

The source inventory examines up to `u1.csv` through `u128.csv` if present; it
is a convenience sample and cannot verify mapping to the prepared data. The
bounded source-code scan does not establish a negative result outside its scope.
