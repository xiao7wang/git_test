"""EDNet exploratory, same-event 2x2 feedback/time-rule experiment."""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import time
import zipfile
from pathlib import Path

import numpy as np

from count_time.common import sha256_file, write_json
from count_time.features import check_legacy_counts
from session_control.features import build
from session_control.train import fit
from .analysis import MODES, analyze
from .core import block_features, select_and_filter
from .inventory import collect


def _write_events(path, f):
    valid = np.flatnonzero(f['split'] == 1)
    with gzip.open(path, 'wt', encoding='utf-8', newline='') as handle:
        writer = csv.writer(handle)
        writer.writerow(('record_idx', 'student_idx', 'label', 'kc_idx', 'prior_kc_count_block',
                         'same_time_kc_group_size', 'starts_session'))
        for i in valid:
            writer.writerow((int(f['record_idx'][i]), int(f['student'][i]), int(f['label'][i]),
                             int(f['kc'][i]), int(f['prior_kc_count'][i]),
                             int(f['same_time_kc_group_size'][i]), int(f['starts_session'][i])))


def _protocol_check(row, block):
    singleton = block['same_time_kc_group_size'] == 1
    checks = {}
    for name, a, b in (
        ('session_success', row['session_states'][0], block['session_states'][0]),
        ('session_failure', row['session_states'][1], block['session_states'][1]),
        ('time_success', row['states']['C_real_time'][0], block['states']['C_real_time'][0]),
        ('time_failure', row['states']['C_real_time'][1], block['states']['C_real_time'][1]),
    ):
        err = np.abs(np.asarray(a) - np.asarray(b))
        maximum = float(np.max(err[singleton], initial=0.))
        if maximum > 1e-8:
            raise ValueError(f'singleton history unexpectedly differs for {name}: {maximum}')
        checks[name] = {'singleton_max_abs_difference': maximum,
                        'all_events_changed_above_1e-9': int((err > 1e-9).sum())}
    return {'singleton_checks': checks, 'undiscounted_row_count': check_legacy_counts(row)}


def _package(out, archive, names):
    pending, final = out / (archive + '.pending'), out / archive
    if pending.exists() or final.exists():
        raise FileExistsError('refusing to overwrite existing archive')
    hashes = {name: sha256_file(out / name) for name in names}
    if len(hashes) != len(names):
        raise ValueError('duplicate archive member')
    with zipfile.ZipFile(pending, 'x', compression=zipfile.ZIP_STORED, allowZip64=True) as z:
        for name in names:
            z.write(out / name, arcname=name)
        z.writestr('manifest.json', json.dumps({'format': 1, 'files': hashes}, indent=2) + '\n')
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or set(z.namelist()) != set(hashes) | {'manifest.json'}:
            raise ValueError('archive CRC or members differ')
        for name, digest in hashes.items():
            if hashlib.sha256(z.read(name)).hexdigest() != digest:
                raise ValueError(f'archive hash mismatch: {name}')
    pending.replace(final)
    return str(final)


def run(arrays, development_users, output, *, metadata, qccdm_root, device='cuda', epochs=20,
        patience=5, batch_size=8192, repetitions=2000):
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    status = {'status': 'running', 'phase': 'select_and_filter', 'completed_jobs': [],
              'test_evaluated': False, 'holdout_evaluated': False}
    write_json(out / 'status.json', status)
    try:
        print(json.dumps({'phase': status['phase']}), flush=True)
        reduced, original, selection = select_and_filter(arrays, development_users)
        row = build(reduced, development_users, threshold_hours=10., retention=.5)
        row['record_idx'] = original[row['record_idx']]
        status['phase'] = 'block_features'
        write_json(out / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        block = block_features(row)
        check = _protocol_check(row, block)
        if not check['undiscounted_row_count']['match']:
            raise ValueError('independent undiscounted count check failed')
        dev = np.flatnonzero(block['split'] == 1)
        train = np.flatnonzero(block['split'] == 0)
        if len(dev) != len(np.unique(block['record_idx'][dev])):
            raise ValueError('development event IDs are duplicated')
        group = block['same_time_kc_group_size']
        population = {'training_events': len(train), 'development_events': len(dev),
                      'development_students': int(np.unique(block['student'][dev]).size),
                      'development_events_same_timestamp_same_kc_group': int((group[dev] > 1).sum()),
                      'training_events_same_timestamp_same_kc_group': int((group[train] > 1).sum())}
        identity = np.column_stack((block['record_idx'][dev], block['student'][dev],
                                    block['label'][dev].astype(np.int64))).astype('<i8', copy=False)
        event_sha = hashlib.sha256(identity.tobytes()).hexdigest()
        config = {'protocol': 'ednet_phase_time_timestamp_sensitivity_v1_exploratory',
                  'dataset_status': 'historically used EDNet; not an independent or blind dataset',
                  'primary': 'block_time minus block_session event NLL',
                  'population': population, 'selection': selection,
                  'development_identity_sha256': event_sha,
                  'same_time_block_policy': 'all same-student/timestamp events predicted before their labels update histories',
                  'cross_split_policy': 'drop every selected train or development row in student/timestamp groups spanning both splits',
                  'boundary_recomputation': '10h student-event boundaries are recomputed after mixed-group removal',
                  'holdout_scope': 'the valid-student complement under this run partition; no claim about older historical holdout identities',
                  'vocabulary_policy': 'prepared vocabularies were constructed from label-free train/valid/test ID union',
                  'time_rules': {'session': 'adjacent student timestamps >10h; retain 0.5 per boundary',
                                 'time': 'same-KC elapsed time half-life 168h'},
                  'model': 'same PFA-inspired count model; student, item, KC biases and two KC log-count coefficients',
                  'seeds': [0, 1, 2], 'max_epochs': epochs, 'patience': patience, 'batch_size': batch_size,
                  'optimizer': 'AdamW lr=.01 weight_decay=1e-5 clip=5',
                  'checkpoint_selection': 'development event NLL per model and seed',
                  'bootstrap_repetitions': repetitions,
                  'limitations': ['previously examined EDNet; exploratory, not independent confirmation',
                                  'same timestamp is a proxy, not true solving_id or verified feedback boundary',
                                  'grouped questions spanning distinct timestamps may still reveal answers too early',
                                  'events sharing a timestamp may come from different real groups',
                                  'models independently retrained and selected; bootstrap omits full selection uncertainty',
                                  'test label array is loaded from prepared NPZ but excluded from histories and scoring',
                                  'removing mixed timestamp groups can change adjacent-event stage boundaries',
                                  'source Q is a single-KC mapping; original full multi-tag structure is not represented'],
                  'test_evaluated': False, 'holdout_evaluated': False, 'metadata': metadata}
        write_json(out / 'config.json', config)
        write_json(out / 'feature_checks.json', check)
        status['phase'] = 'bounded_lineage_inventory'
        write_json(out / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        write_json(out / 'lineage_inventory.json', collect(qccdm_root))
        _write_events(out / 'event_features.csv.gz', block)
        (out / 'predictions').mkdir(exist_ok=False)
        predictions = {name: {} for name in MODES}
        jobs, pairing = {}, {}
        specification = {'row_session': (row, 'S_session'), 'row_time': (row, 'T_time'),
                         'block_session': (block, 'S_session'), 'block_time': (block, 'T_time')}
        for seed in (0, 1, 2):
            histories, initials = [], set()
            for name in MODES:
                status.update(phase='training', seed=seed, model=name)
                write_json(out / 'status.json', status)
                print(json.dumps({'phase': 'training', 'model': name, 'seed': seed}), flush=True)
                f, mode = specification[name]
                job_name = f'{name}_seed{seed}'
                result = fit(f, mode, seed, out / 'jobs' / job_name, device=device,
                             epochs=epochs, patience=patience, batch_size=batch_size)
                predictions[name][seed] = result['probability']
                jobs[job_name] = result['summary']
                initials.add(result['summary']['initial_state_sha256'])
                histories.append(result['history'])
                raw = (out / 'jobs' / job_name / 'dev_predictions.csv.gz').read_bytes()
                (out / 'predictions' / f'{job_name}.csv.gz').write_bytes(raw)
                status['completed_jobs'].append(job_name)
                write_json(out / 'status.json', status)
            if len(initials) != 1:
                raise ValueError(f'four initial states differ for seed {seed}')
            common = min(len(h) for h in histories)
            if not common or any(len({h[i]['train_order_sha256'] for h in histories}) != 1 for i in range(common)):
                raise ValueError(f'paired training orders differ for seed {seed}')
            pairing[str(seed)] = {'initial_state_matches': True, 'common_epoch_orders_match': common}
            write_json(out / 'pairing.json', pairing)
            if seed == 0:
                partial_names = ['config.json', 'feature_checks.json', 'lineage_inventory.json',
                                 'event_features.csv.gz', 'pairing.json']
                partial_names += [f'predictions/{name}_seed0.csv.gz' for name in MODES]
                partial_names += [f'jobs/{name}_seed0/{file}' for name in MODES
                                  for file in ('summary.json', 'history.json')]
                partial = _package(out, 'partial_seed0.zip', partial_names)
                print(json.dumps({'phase': 'seed0_complete', 'partial_archive': partial}), flush=True)
        status.update(phase='paired_analysis', seed=None, model=None)
        write_json(out / 'status.json', status)
        print(json.dumps({'phase': status['phase']}), flush=True)
        summary = {'status': 'complete', 'jobs': jobs, 'pairing': pairing,
                   'analysis': analyze(block, predictions, repetitions=repetitions),
                   'seconds_before_packaging': time.monotonic()-start,
                   'test_evaluated': False, 'holdout_evaluated': False}
        write_json(out / 'summary.json', summary)
        names = ['config.json', 'feature_checks.json', 'lineage_inventory.json', 'event_features.csv.gz',
                 'pairing.json', 'summary.json']
        names += [f'predictions/{name}_seed{seed}.csv.gz' for name in MODES for seed in (0, 1, 2)]
        names += [f'jobs/{name}_seed{seed}/{file}' for name in MODES for seed in (0, 1, 2)
                  for file in ('summary.json', 'history.json')]
        archive = _package(out, 'ednet_time_feedback_results.zip', names)
        status.update(status='complete', phase='complete', result_archive=archive,
                      seconds=time.monotonic()-start)
        write_json(out / 'status.json', status)
        print(json.dumps({'phase': 'complete', 'archive': archive}), flush=True)
        return archive
    except BaseException as exc:
        status.update(status='failed', phase='failed', error=repr(exc), seconds=time.monotonic()-start)
        write_json(out / 'status.json', status)
        raise
