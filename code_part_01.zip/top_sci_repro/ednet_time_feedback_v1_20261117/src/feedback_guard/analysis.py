"""Paired analysis for two time rules under two feedback assumptions."""
import numpy as np

from count_time.analysis import _intervals
from count_time.common import binary_losses, metrics

MODES = ('row_session', 'row_time', 'block_session', 'block_time')


def _group(labels, students, group_size, predictions, mask, *, repetitions, seed):
    idx = np.flatnonzero(mask)
    if not len(idx):
        return {'events': 0, 'students': 0, 'models': {}, 'paired': {}}
    y, user = labels[idx], students[idx]
    losses, models = {}, {}
    for mode in MODES:
        losses[mode], per_seed = [], []
        for seed_id in (0, 1, 2):
            p = np.asarray(predictions[mode][seed_id], dtype=np.float64)[idx]
            if not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError('invalid predicted probability')
            losses[mode].append(binary_losses(y, p)[0])
            per_seed.append(metrics(y, p, user))
        keys = ('nll', 'student_macro_nll', 'auc', 'brier')
        models[mode] = {
            'per_seed': per_seed,
            'mean': {key: (None if any(row[key] is None for row in per_seed)
                           else float(np.mean([row[key] for row in per_seed]))) for key in keys},
        }
    d = {name: np.stack(values).mean(axis=0) for name, values in losses.items()}
    columns = np.stack((d['block_time'] - d['block_session'],
                        d['row_time'] - d['row_session'],
                        d['block_session'] - d['row_session'],
                        d['block_time'] - d['row_time'],
                        (d['block_time'] - d['block_session']) - (d['row_time'] - d['row_session'])), axis=1)
    names = ('block_time_minus_block_session', 'row_time_minus_row_session',
             'block_session_minus_row_session', 'block_time_minus_row_time',
             'interaction_block_minus_row')
    intervals = _intervals(user, columns, repetitions, seed)
    paired = dict(zip(names, intervals))
    for j in range(3):
        each = {name: losses[name][j] for name in MODES}
        contrast = ((each['block_time'] - each['block_session']),
                    (each['row_time'] - each['row_session']),
                    (each['block_session'] - each['row_session']),
                    (each['block_time'] - each['row_time']),
                    (each['block_time'] - each['block_session']) - (each['row_time'] - each['row_session']))
        for name, values in zip(names, contrast):
            paired[name].setdefault('per_seed_event_delta', []).append(float(values.mean()))
    return {'events': len(idx), 'students': int(np.unique(user).size), 'models': models, 'paired': paired}


def analyze(features, predictions, *, repetitions=2000, seed=20261117):
    if repetitions < 1 or set(predictions) != set(MODES):
        raise ValueError('invalid models or bootstrap count')
    dev = np.flatnonzero(features['split'] == 1)
    if not len(dev):
        raise ValueError('no permitted development events')
    for name in MODES:
        if set(predictions[name]) != {0, 1, 2}:
            raise ValueError(f'missing seed in {name}')
        if any(np.asarray(p).shape != (len(dev),) for p in predictions[name].values()):
            raise ValueError(f'prediction dimensions mismatch in {name}')
    y, user = features['label'][dev], features['student'][dev]
    group_size = features['same_time_kc_group_size'][dev]
    groups = {'all_development': np.ones(len(dev), dtype=bool),
              'same_time_same_kc_group': group_size > 1,
              'other_events': group_size == 1}
    return {
        'scope': 'previously used EDNet development; exploratory; not independent confirmation',
        'primary': 'block_time minus block_session, event-weighted NLL, mean of 3 paired seed losses',
        'secondary_interaction': '(block_time - block_session) - (row_time - row_session)',
        'bootstrap': {'unit': 'student', 'repetitions': repetitions, 'seed': seed,
                      'scope': 'conditional on selected fitted models; no training or selection uncertainty'},
        'group_note': 'same timestamp/same KC groups are descriptive proxies, not verified solving bundles',
        'groups': {name: _group(y, user, group_size, predictions, mask, repetitions=repetitions, seed=seed+i)
                   for i, (name, mask) in enumerate(groups.items())},
    }
