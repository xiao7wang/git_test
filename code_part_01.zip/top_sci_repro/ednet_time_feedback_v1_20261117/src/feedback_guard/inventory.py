"""Bounded read-only lineage and raw-KT1 convenience sample; aggregate only."""
from __future__ import annotations

import csv
import hashlib
import os
from pathlib import Path


def _header(path):
    try:
        with path.open('r', encoding='utf-8-sig', errors='replace', newline='') as handle:
            return next(csv.reader(handle), [])[:60]
    except (OSError, csv.Error):
        return None


def _known(path):
    info = {'path': str(path), 'exists': path.is_file()}
    if info['exists']:
        info.update(resolved_path=str(path.resolve()), bytes=path.stat().st_size)
        if path.suffix.lower() == '.csv':
            info['header'] = _header(path)
    return info


def _raw_sample(root):
    # Fixed numeric candidates: convenient and repeatable, not a random sample.
    directory = root / 'qccdm改进代码' / 'data_raw' / 'ednet' / 'KT1' / 'KT1'
    report = {'candidate_rule': 'u1.csv through u128.csv, if present; not a random sample',
              'directory_exists': directory.is_dir(), 'candidates': 128, 'files_read': 0,
              'files_absent': 0, 'files_skipped_large_or_invalid': 0, 'rows': 0,
              'solving_groups': 0, 'multi_question_groups': 0, 'multi_question_rows': 0,
              'multi_groups_spanning_integer_seconds': 0,
              'timestamp_assumption': 'raw KT1 timestamp interpreted as milliseconds for this descriptive sample',
              'mapping_to_prepared_events_verified': False,
              'feedback_availability_verified': False}
    for number in range(1, 129):
        path = directory / f'u{number}.csv'
        if not path.is_file():
            report['files_absent'] += 1
            continue
        try:
            if path.stat().st_size > 8 * 1024 * 1024:
                raise ValueError('file is beyond the sample file size limit')
            groups = {}
            rows = 0
            with path.open('r', encoding='utf-8-sig', newline='') as handle:
                reader = csv.DictReader(handle)
                if not {'timestamp', 'solving_id', 'question_id'}.issubset(reader.fieldnames or []):
                    raise ValueError('raw KT1 header differs')
                for row in reader:
                    timestamp = int(row['timestamp'])
                    solving = row['solving_id'].strip()
                    if not solving or not row['question_id'].strip():
                        raise ValueError('invalid raw row')
                    g = groups.setdefault(solving, [0, timestamp, timestamp])
                    g[0] += 1
                    g[1] = min(g[1], timestamp)
                    g[2] = max(g[2], timestamp)
                    rows += 1
            multi = [v for v in groups.values() if v[0] > 1]
            report['files_read'] += 1
            report['rows'] += rows
            report['solving_groups'] += len(groups)
            report['multi_question_groups'] += len(multi)
            report['multi_question_rows'] += sum(v[0] for v in multi)
            report['multi_groups_spanning_integer_seconds'] += sum(v[1] // 1000 != v[2] // 1000 for v in multi)
        except (OSError, ValueError, KeyError, TypeError, csv.Error):
            report['files_skipped_large_or_invalid'] += 1
    return report


def _source_candidates(root):
    repo = root / 'top_sci_repro' / 'repos' / 'HyperCDM'
    terms = ('solving_id', 'ednet_time_oursTotalData_time', 'raw_user_map', 'raw_item_map')
    report = {'repository': str(repo), 'repository_exists': repo.is_dir(), 'files_checked': 0,
              'budget_files': 2000, 'budget_hit': False, 'matches': [],
              'scope': 'Python files up to 1 MiB; no symlink traversal; skips data, output and hidden directories'}
    if not repo.is_dir():
        return report
    for current, directories, files in os.walk(repo, followlinks=False):
        directories[:] = sorted(d for d in directories if not d.startswith('.') and d.lower() not in
                                {'data', 'output', 'outputs', 'results', '__pycache__', 'checkpoints'})
        for name in sorted(files):
            path = Path(current) / name
            if not name.endswith('.py') or path.is_symlink():
                continue
            if report['files_checked'] >= report['budget_files']:
                report['budget_hit'] = True
                return report
            try:
                if path.stat().st_size > 1024 * 1024:
                    continue
                raw = path.read_bytes()
                lines = raw.decode('utf-8', errors='replace').splitlines()
                matches = {term: [i+1 for i, line in enumerate(lines) if term in line][:20] for term in terms}
                matches = {key: value for key, value in matches.items() if value}
                report['files_checked'] += 1
                if matches:
                    report['matches'].append({'path': str(path), 'sha256': hashlib.sha256(raw).hexdigest(),
                                              'line_numbers': matches})
            except OSError:
                continue
    return report


def collect(qccdm_root):
    root = Path(qccdm_root)
    unified = root / 'top_sci_repro' / 'unified_experiments' / 'data' / 'ednet'
    hyper = root / 'top_sci_repro' / 'repos' / 'HyperCDM' / 'data' / 'ednet_time_ours'
    paths = [unified / 'interactions_raw.csv', unified / 'config.json',
             hyper / 'ednet_time_oursTotalData_time.csv', hyper / 'q.csv']
    return {'known_sources': [_known(path) for path in paths],
            'raw_kt1_convenience_sample': _raw_sample(root),
            'source_code_scan': _source_candidates(root),
            'limits': ['No raw event IDs, answers, or timestamps are exported.',
                       'A matching filename or header does not prove ancestry or identity mapping.',
                       'Same timestamp is not a verified solving_id or feedback boundary.',
                       'No negative result establishes absence outside the bounded scope.']}
