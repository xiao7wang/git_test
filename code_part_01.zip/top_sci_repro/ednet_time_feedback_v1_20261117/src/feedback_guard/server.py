"""Server entry with pinned EDNet prepared-data provenance and GPU guard."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
from pathlib import Path

import numpy as np
import torch

from count_time.common import sha256_file
from .runner import run

ROOT = Path(__file__).resolve().parents[2]
DATA_MANIFEST_SHA = 'fa8198274d35d980169ba71acf3792cdd2e9892eb28504fc1081a4ae6179da09'
RECORDS_SHA = 'f2f1d1d36e6c0c63f63d7fb72667e034b5e21482d9f80330c4e1508ac73c1c36'
SALT = 'decision-v1-20261105:'


def development_users(values):
    return {int(v) for v in np.unique(values)
            if hashlib.sha256((SALT + str(int(v))).encode()).digest()[-1] % 2 == 0}


def load_prepared(path):
    path = Path(path).resolve()
    manifest_path, records_path = path / 'manifest.json', path / 'records.npz'
    if sha256_file(manifest_path) != DATA_MANIFEST_SHA:
        raise ValueError('EDNet prepared-data manifest differs from previously audited source')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    if (manifest.get('dataset') != 'ednet' or manifest.get('records_sha256') != RECORDS_SHA or
        manifest.get('feedback_boundaries_verified') is not False):
        raise ValueError('unexpected EDNet manifest fields')
    if sha256_file(records_path) != RECORDS_SHA:
        raise ValueError('EDNet records hash differs from pinned manifest')
    names = ('student_idx', 'item_idx', 'label', 'split', 'timestamp', 'item_q')
    with np.load(records_path, allow_pickle=False) as data:
        if any(name not in data.files for name in names):
            raise ValueError('required prepared arrays missing')
        arrays = {name: data[name] for name in names}
    counts = tuple(int(np.sum(arrays['split'] == i)) for i in range(3))
    if len(arrays['split']) != 2118984 or counts != (1479693, 209028, 430263):
        raise ValueError(f'EDNet split sizes differ: {counts}')
    if arrays['item_q'].shape != (12196, 140):
        raise ValueError(f'EDNet prepared Q dimensions differ: {arrays["item_q"].shape}')
    return arrays


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--qccdm-root', default='/home/wangxiao/QCCDM')
    args = parser.parse_args(argv)
    from checks.verify import verify_release
    release = verify_release()
    output = Path(args.output_dir).resolve()
    allowed = (ROOT / 'outputs').resolve()
    if output == allowed or not output.is_relative_to(allowed) or output.exists():
        raise ValueError('output must be a new child under this release outputs directory')
    free = shutil.disk_usage(allowed).free
    if free < 1073741824:
        raise OSError(f'free disk is below 1 GiB: {free}')
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; no automatic CPU fallback')
    print(json.dumps({'phase': 'loading_pinned_ednet', 'manifest_sha256': DATA_MANIFEST_SHA}), flush=True)
    arrays = load_prepared(args.data_dir)
    users = development_users(arrays['student_idx'][arrays['split'] == 1])
    metadata = {'release': release, 'dataset_manifest_sha256': DATA_MANIFEST_SHA,
                'records_sha256': RECORDS_SHA, 'prepared_data_dir': str(Path(args.data_dir).resolve()),
                'development_partition_salt': SALT, 'python': platform.python_version(),
                'numpy': np.__version__, 'torch': str(torch.__version__),
                'gpu': torch.cuda.get_device_name(0), 'cuda_visible_devices': os.getenv('CUDA_VISIBLE_DEVICES'),
                'free_bytes_at_start': free}
    archive = run(arrays, users, output, metadata=metadata, qccdm_root=args.qccdm_root, device='cuda')
    print(json.dumps({'status': 'complete', 'archive': archive}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
