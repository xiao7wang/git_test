"""Causal train/dev selection and same-timestamp feedback blocking.

This is a timestamp sensitivity policy, not an assertion that timestamp groups
are genuine exercise bundles or that feedback becomes available immediately
after a timestamp group.
"""
from __future__ import annotations

import math
import numpy as np


def _group_starts(users, times):
    if not len(users):
        return np.empty(0, dtype=np.int64)
    return np.flatnonzero(np.r_[True, (users[1:] != users[:-1]) | (times[1:] != times[:-1])])


def _validate_order(users, times):
    if not np.isfinite(times).all():
        raise ValueError('selected timestamps must be finite')
    if np.any(users[1:] < users[:-1]):
        raise ValueError('events must be grouped by student')
    if np.any((users[1:] == users[:-1]) & (times[1:] < times[:-1])):
        raise ValueError('events must be chronological within student')


def select_and_filter(arrays, development_users):
    """Exclude test/other development users and mixed train/dev timestamp groups.

    Any student+timestamp group containing both train and selected development
    rows is removed in its entirety from features, training, and scoring.
    """
    required = ('student_idx', 'item_idx', 'split', 'timestamp', 'label', 'item_q')
    if any(name not in arrays for name in required):
        raise ValueError('missing required prepared arrays')
    user = np.asarray(arrays['student_idx'])
    n = len(user)
    if n == 0 or any(np.asarray(arrays[k]).ndim != 1 or len(arrays[k]) != n for k in required[:-1]):
        raise ValueError('prepared record arrays must have the same nonzero length')
    split = np.asarray(arrays['split'])
    if not np.isin(split, [0, 1, 2]).all():
        raise ValueError('unknown split code')
    dev_users = np.asarray(sorted({int(x) for x in development_users}), dtype=np.int64)
    chosen = (split == 0) | ((split == 1) & np.isin(user, dev_users))
    original = np.flatnonzero(chosen).astype(np.int64)
    if not len(original):
        raise ValueError('no permitted train/development records')
    selected_user = user[original].astype(np.int64, copy=False)
    selected_time = np.asarray(arrays['timestamp'])[original].astype(np.float64, copy=False)
    selected_split = split[original].astype(np.int8, copy=False)
    _validate_order(selected_user, selected_time)
    if np.any((selected_user[1:] == selected_user[:-1]) & (selected_split[1:] < selected_split[:-1])):
        raise ValueError('train/development splits interleave in a student history')
    starts = _group_starts(selected_user, selected_time)
    ends = np.r_[starts[1:], len(original)]
    mixed = np.minimum.reduceat(selected_split, starts) != np.maximum.reduceat(selected_split, starts)
    remove = np.repeat(mixed, ends - starts)
    report = {
        'selected_train_before_filter': int(np.sum(selected_split == 0)),
        'selected_development_before_filter': int(np.sum(selected_split == 1)),
        'excluded_mixed_timestamp_groups': int(mixed.sum()),
        'excluded_mixed_timestamp_train_events': int(np.sum(remove & (selected_split == 0))),
        'excluded_mixed_timestamp_development_events': int(np.sum(remove & (selected_split == 1))),
        'filter_rule': 'drop all rows in any selected student+timestamp group spanning train/development',
    }
    original = original[~remove]
    reduced = {k: np.asarray(arrays[k])[original] for k in required[:-1]}
    reduced['item_q'] = np.asarray(arrays['item_q'])
    if not np.isin(reduced['label'], [0, 1]).all():
        raise ValueError('permitted labels must be binary')
    if not np.any(reduced['split'] == 0) or not np.any(reduced['split'] == 1):
        raise ValueError('filter left an empty train or development set')
    return reduced, original, report


def block_features(features):
    """Delay each timestamp group's same-KC labels until all group predictions.

    Both temporal and stage histories are replayed from scratch, while a group
    updates the state once after its last prediction. The same student may have
    other KCs at that timestamp; per-KC states are independent.
    """
    u, k, t, y, split, idx = (np.asarray(features[name]) for name in
                               ('student', 'kc', 'timestamp', 'label', 'split', 'record_idx'))
    n = len(u)
    if not n or any(len(x) != n for x in (k, t, y, split, idx)):
        raise ValueError('feature arrays do not align')
    _validate_order(u, t)
    if not np.isin(y, [0, 1]).all() or not np.isin(split, [0, 1]).all():
        raise ValueError('block replay accepts selected binary train/development only')
    starts = _group_starts(u, t)
    if np.any(np.minimum.reduceat(split, starts) != np.maximum.reduceat(split, starts)):
        raise ValueError('mixed train/development timestamp group must be filtered first')
    session = np.cumsum(np.asarray(features['starts_session'], dtype=np.int64))
    order = np.lexsort((idx, t, k, u))
    su, sk, st = u[order], k[order], t[order]
    group_start = np.flatnonzero(np.r_[True, (su[1:] != su[:-1]) | (sk[1:] != sk[:-1]) |
                                         (st[1:] != st[:-1])])
    group_end = np.r_[group_start[1:], n]
    stage_s, stage_f, timed_s, timed_f = (np.empty(n, dtype=np.float64) for _ in range(4))
    prior = np.empty(n, dtype=np.int64)
    gap = np.full(n, np.nan, dtype=np.float64)
    crossings = np.zeros(n, dtype=np.int64)
    group_size = np.empty(n, dtype=np.int64)
    last_key = None
    prev_time = 0.0
    prev_session = 0
    seen = 0
    ss = sf = ts = tf = 0.0
    coefficient = math.log(2.0) / (168.0 * 3600.0)
    for begin, end in zip(group_start, group_end):
        first = int(order[begin])
        key = (int(u[first]), int(k[first]))
        now = float(t[first])
        current_session = int(session[first])
        if key != last_key:
            last_key, seen = key, 0
            ss = sf = ts = tf = 0.0
            prev_session = current_session
        else:
            dt = now - prev_time
            steps = current_session - prev_session
            if dt < 0 or steps < 0:
                raise ValueError('same-KC ordering or session count decreased')
            stage_discount = .5 ** steps
            time_discount = math.exp(-coefficient * dt)
            ss, sf = ss * stage_discount, sf * stage_discount
            ts, tf = ts * time_discount, tf * time_discount
        members = order[begin:end]
        stage_s[members], stage_f[members] = ss, sf
        timed_s[members], timed_f[members] = ts, tf
        prior[members] = seen
        group_size[members] = end - begin
        if seen:
            gap[members] = (now - prev_time) / 3600.0
            crossings[members] = current_session - prev_session
        positive = float(y[first]) if end - begin == 1 else float(np.sum(y[members], dtype=np.float64))
        negative = (end - begin) - positive
        ss, sf = ss + positive, sf + negative
        ts, tf = ts + positive, tf + negative
        seen += end - begin
        prev_time, prev_session = now, current_session
    result = dict(features)
    result['session_states'] = (stage_s, stage_f)
    # Do not leave row-immediate A/B states under a blocked-protocol label.
    result['states'] = {'C_real_time': (timed_s, timed_f)}
    result['prior_kc_count'] = prior
    result['gap_hours'] = gap
    result['session_crossings'] = crossings
    result['same_time_kc_group_size'] = group_size
    return result

