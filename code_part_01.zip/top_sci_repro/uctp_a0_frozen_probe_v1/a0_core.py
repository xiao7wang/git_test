"""Frozen first-KC probes. No optimizer, training, checkpoint writes or label input to predict."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import torch

ARMS = ("original", "zero", "kc_share")
ATOL = 1e-6
REPS = 2000
RNG_SEED = 20260929
META = ("record_idx", "student_idx", "item_idx", "source_row", "split", "timestamp", "label", "kc_count_before", "student_count_before")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    p = Path(path)
    pending = p.with_name(p.name + ".pending")
    pending.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    pending.replace(p)


def model_class(project):
    """Import only verified model.py; do not import train.py or change project files."""
    name = "a0_verified_clean_model"
    spec = importlib.util.spec_from_file_location(name, Path(project)/"src/model.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module.CleanCD


def model_digest(model):
    h = hashlib.sha256()
    for name, tensor in sorted(model.state_dict().items()):
        h.update(name.encode()); h.update(tensor.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def prefix(key):
    order = np.argsort(key, kind="stable")
    first = np.r_[True, key[order][1:] != key[order][:-1]]
    start = np.maximum.accumulate(np.where(first, np.arange(len(key)), 0))
    count = np.empty(len(key), dtype=np.int64)
    count[order] = np.arange(len(key))-start
    return count


def context_from_arrays(a, num_students):
    q = a["item_q"]
    require(q.ndim == 2 and np.isin(q, [0,1]).all() and np.all(q.sum(1) == 1), "A0 requires exactly one binary KC per item; STOP")
    sp = a["split"]
    require(np.isin(sp, [0,1,2]).all(), "Invalid split")
    ix = np.flatnonzero(sp <= 1)  # test rows are not used for history/support/scoring
    u, it, t = [a[k][ix] for k in ("student_idx", "item_idx", "timestamp")]
    require(len(ix)>0 and np.isfinite(t).all(), "Empty/nonfinite train+valid context")
    require(np.issubdtype(u.dtype,np.integer) and np.issubdtype(it.dtype,np.integer), "IDs must be integer")
    require(np.all((u>=0)&(u<num_students)) and np.all((it>=0)&(it<len(q))), "ID out of bounds")
    require(np.all(np.diff(u)>=0), "Students not ordered")
    same = u[1:] == u[:-1]
    require(np.all((~same)|(np.diff(t)>=0)), "Backward timestamps")
    require(np.all((~same)|(np.diff(sp[ix].astype(int))>=0)), "Interleaved splits")
    k = q.argmax(1)[it]
    pair = u.astype(np.int64)*q.shape[1]+k
    count = prefix(pair)
    student_count = prefix(u)
    require(np.array_equal(count,a["kc_count_before"][ix]), "KC prefix metadata mismatch")
    require(np.array_equal(student_count,a["student_count_before"][ix]), "Student prefix metadata mismatch")
    donor_pairs = np.unique(pair[sp[ix]==0])
    cold_local = np.flatnonzero((sp[ix]==1)&(count==0))
    require(not np.isin(pair[cold_local],donor_pairs).any(), "Cold target unexpectedly present in training donors")
    ties_left = np.r_[False, same & (np.diff(t)==0)]
    tied = ties_left | np.r_[ties_left[1:],False]
    train_support = np.bincount(it[sp[ix]==0],minlength=len(q))
    cold = ix[cold_local]
    frame = pd.DataFrame({"record_idx":cold, **{key:a[key][cold] for key in META if key!="record_idx"}})
    require(np.isin(frame.label,[0,1]).all(), "Invalid validation label")
    frame["kc_idx"] = k[cold_local]
    frame["same_time_group"] = tied[cold_local]
    frame["item_train_support"] = train_support[it[cold_local]]
    return {"frame":frame, "q":q, "donor_pairs":donor_pairs,
            "num_students":num_students, "num_kcs":q.shape[1], "valid_n":int((sp==1).sum())}


def load_context(path, expected):
    path = Path(path)
    manifest = read_json(path/"manifest.json")
    require(digest(path/"manifest.json")==expected["fingerprint"], "Manifest fingerprint changed")
    for name,key in (("records.npz","records_sha256"),("vocabulary.json","vocabulary_sha256")):
        require(digest(path/name)==expected[key]==manifest[key], f"Prepared data changed: {name}")
    # NPZ columns contain all splits in memory. Only train+valid indices enter context.
    with np.load(path/"records.npz",allow_pickle=False) as z:
        fields = set(META)-{"record_idx"}
        a = {k:z[k] for k in fields|{"item_q"}}
    c = context_from_arrays(a,manifest["summary"]["students"])
    require(c["valid_n"]==expected["n"] and len(c["frame"])==expected["cold_n"], "Unexpected validation/cold counts")
    c["manifest"] = manifest
    return c


def shared_reference(model, donor_pairs):
    e = model.student_mastery_logit.weight.detach().cpu().numpy()
    K = e.shape[1]
    pairs = np.asarray(donor_pairs,dtype=np.int64)
    require(np.array_equal(pairs,np.unique(pairs)), "Donor pairs must be unique sorted student-KC keys")
    require(np.all((pairs>=0)&(pairs<e.size)), "Donor index out of bounds")
    counts = np.bincount(pairs%K,minlength=K)
    sums = np.bincount(pairs%K,weights=e[pairs//K,pairs%K].astype(np.float64),minlength=K)
    mu = np.divide(sums,counts,out=np.zeros(K,np.float64),where=counts>0).astype(e.dtype)
    require(np.isfinite(mu).all(), "Nonfinite shared reference")
    return mu, counts


@torch.no_grad()
def probe_predict(model,state,students,items,q,cold_mask,arm,shared):
    """Cold mask is computed before feedback; no label argument exists.

    A temporary embedding output hook changes only the requested readout, never
    embedding weights, model state or observe(). Always removed even on error.
    """
    require(arm in ARMS,"Unknown probe arm")
    if arm=="original":
        return model.predict(state,students,items,q)
    def replace(_module,_inputs,base):
        value = torch.zeros_like(base) if arm=="zero" else shared[None,:].expand_as(base)
        return torch.where(cold_mask[:,None] & (q>0),value,base)
    handle = model.student_mastery_logit.register_forward_hook(replace)
    try:
        return model.predict(state,students,items,q)
    finally:
        handle.remove()


@torch.no_grad()
def fast_predict(model,context,device,batch_size=8):
    require(batch_size>0,"Invalid batch size")
    model.eval()
    before = model_digest(model)
    f = context["frame"]
    mu, counts = shared_reference(model,context["donor_pairs"])
    share = torch.as_tensor(mu,device=device)
    predictions = {arm:[] for arm in ARMS}
    output = {"uncertainty":[],"evidence":[]}
    for start in range(0,len(f),batch_size):
        part = f.iloc[start:start+batch_size]
        u = torch.as_tensor(part.student_idx.to_numpy().copy(),dtype=torch.long,device=device)
        it = torch.as_tensor(part.item_idx.to_numpy().copy(),dtype=torch.long,device=device)
        q = torch.as_tensor(context["q"][part.item_idx.to_numpy()].astype(np.float32),device=device)
        state = model.init_state(len(part),device)
        cold = torch.ones(len(part),dtype=torch.bool,device=device)
        for arm in ARMS:
            r = probe_predict(model,state,u,it,q,cold,arm,share)
            predictions[arm].append(r["probability"].cpu().numpy())
            if arm=="original":
                for key in output: output[key].append(r[key].cpu().numpy())
        if start and start%8000==0: print(f"  cold rows {start}/{len(f)}",flush=True)
    require(before==model_digest(model),"In-memory model weights changed")
    result = f.copy()
    result["donor_students"] = counts[f.kc_idx.to_numpy()]
    result["shared_logit"] = mu[f.kc_idx.to_numpy()]
    for arm,parts in predictions.items(): result[arm] = np.concatenate(parts) if parts else np.array([],dtype=np.float32)
    for key,parts in output.items(): result[key] = np.concatenate(parts) if parts else np.array([],dtype=np.float32)
    return result,{"mu":mu,"donor_students":counts},before


def verify_reference(frame,path):
    with np.load(path,allow_pickle=False) as ref:
        require(len(frame)==len(ref["record_idx"]),"Reference row count mismatch")
        for key in META:
            require(np.array_equal(frame[key].to_numpy(),ref[key]),f"Reference alignment mismatch: {key}")
        errors={}
        for new,old in (("original","probability"),("uncertainty","uncertainty"),("evidence","evidence")):
            arr=frame[new].to_numpy(np.float64)
            require(np.isfinite(arr).all(),f"Nonfinite output: {new}")
            errors[new]=float(np.max(np.abs(arr-ref[old]))) if len(arr) else 0.0
            require(errors[new]<=ATOL,f"Original/reference mismatch: {new}, max={errors[new]:.12g}, atol={ATOL}; STOP, do not relax tolerance")
    return errors


def losses(y,p):
    p=np.clip(np.asarray(p,np.float64),1e-7,1-1e-7)
    return -(y*np.log(p)+(1-y)*np.log1p(-p))


def metrics(frame,p):
    if not len(frame): return {"n":0,"students":0,"auc":None,"nll":None,"brier":None,"student_macro_nll":None,"student_macro_brier":None,"ece15":None,"observed_rate":None,"mean_probability":None}
    y=frame.label.to_numpy(np.float64); p=np.asarray(p,np.float64)
    require(np.isfinite(p).all() and ((p>=0)&(p<=1)).all(),"Invalid probability")
    inv=np.unique(frame.student_idx,return_inverse=True)[1]; counts=np.bincount(inv)
    l=losses(y,p); b=(p-y)**2; positives=y.sum()
    auc=None if positives in (0,len(y)) else float((pd.Series(p).rank(method="average").to_numpy()[y==1].sum()-positives*(positives+1)/2)/(positives*(len(y)-positives)))
    bins=np.minimum((p*15).astype(int),14)
    return {"n":len(frame),"students":len(counts),"auc":auc,"nll":float(l.mean()),"brier":float(b.mean()),
            "student_macro_nll":float((np.bincount(inv,weights=l)/counts).mean()),
            "student_macro_brier":float((np.bincount(inv,weights=b)/counts).mean()),
            "ece15":float(np.abs(np.bincount(bins,weights=p-y,minlength=15)).sum()/len(y)),
            "observed_rate":float(y.mean()),"mean_probability":float(p.mean())}


def groups(f):
    s=f.item_train_support.to_numpy(); d=f.donor_students.to_numpy(); n=f.student_count_before.to_numpy()
    return {"all_cold":np.ones(len(f),bool),"student_lt50":n<50,"student_ge50":n>=50,
            "donors0":d==0,"donors1_4":(d>=1)&(d<=4),"donors_ge5":d>=5,
            "item_train0":s==0,"item_train1_5":(s>=1)&(s<=5),"item_train6_20":(s>=6)&(s<=20),"item_train_gt20":s>20,
            "not_current_same_time_group":~f.same_time_group.to_numpy(bool)}


def grouped_metrics(f):
    return {name:{"n":int(mask.sum()),"coverage":float(mask.mean()) if len(mask) else 0.,
            "arms":{arm:metrics(f.loc[mask],f.loc[mask,arm]) for arm in ARMS}} for name,mask in groups(f).items()}


def paired_bootstrap(frames,reps=REPS,seed=RNG_SEED):
    """Whole-student paired bootstrap for fixed checkpoints; all seeds share weights."""
    keys=list(frames); first=frames[keys[0]]
    require(len(first)>0,"Empty bootstrap population")
    for f in frames.values(): require(first[list(META)].equals(f[list(META)]),"Seed alignment failed in summary")
    u=np.unique(first.student_idx,return_inverse=True)[1]; counts=np.bincount(u); ns=len(counts)
    comparisons=(("kc_share","zero"),("kc_share","original"),("zero","original"))
    cols=[]; sums=[]
    for key,f in frames.items():
        y=f.label.to_numpy(np.float64)
        for a,b in comparisons:
            for m,delta in (("nll",losses(y,f[a])-losses(y,f[b])),("brier",(f[a].to_numpy()-y)**2-(f[b].to_numpy()-y)**2)):
                cols.append((key,a+"_minus_"+b,m))
                sums.append(np.bincount(u,weights=delta,minlength=ns))
    sums=np.column_stack(sums); means=sums/counts[:,None]
    be=np.empty((reps,len(cols))); bm=np.empty_like(be); rng=np.random.default_rng(seed)
    for start in range(0,reps,16):
        take=min(16,reps-start)
        sampled=rng.integers(0,ns,(take,ns))
        be[start:start+take]=sums[sampled].sum(1)/counts[sampled].sum(1)[:,None]
        bm[start:start+take]=means[sampled].mean(1)
    result={"repetitions":reps,"rng_seed":seed,"n":len(first),"students":ns,
            "interval_scope":"pointwise student-cluster sampling conditional on fixed checkpoints, not training/selection uncertainty", "runs":{},"seed_means":{}}
    ep=sums.sum(0)/counts.sum(); mp=means.mean(0)
    for i,(key,contrast,m) in enumerate(cols):
        result["runs"].setdefault(key,{}).setdefault(contrast,{})[m]={
            "event":float(ep[i]),"event_ci95":np.quantile(be[:,i],[.025,.975]).tolist(),
            "student_macro":float(mp[i]),"student_macro_ci95":np.quantile(bm[:,i],[.025,.975]).tolist()}
    for variant in ("dynamic_only","unit_write"):
        for a,b in comparisons:
            for m in ("nll","brier"):
                take=[i for i,c in enumerate(cols) if c[0].startswith(variant+"_seed") and c[1:]==(a+"_minus_"+b,m)]
                if len(take)!=3: continue
                result["seed_means"].setdefault(variant,{}).setdefault(a+"_minus_"+b,{})[m]={
                    "event_mean":float(ep[take].mean()),"event_seed_sd":float(ep[take].std(ddof=1)),
                    "event_conditional_ci95":np.quantile(be[:,take].mean(1),[.025,.975]).tolist(),
                    "student_macro_mean":float(mp[take].mean()),"student_macro_seed_sd":float(mp[take].std(ddof=1)),
                    "student_macro_conditional_ci95":np.quantile(bm[:,take].mean(1),[.025,.975]).tolist()}
    return result
