# A0 独立诊断工具：实现与核验记录

日期：2026-10-05。范围：按已确认的“三种冻结读出、首次 KC、已有 checkpoint、只看 valid”方案实现。没有修改原 clean/temporal 源码、训练入口、旧实验结果或 checkpoint。

## 新增内容

| 文件 | 作用 |
| --- | --- |
| a0_core.py | 单 KC/预测前计数检查，训练曝光学生去重，KC 参照，冻结三分支，逐行等价核验，固定分组与配对统计 |
| run_a0_suite.py | 12 个 checkpoint 的强指纹预检、串行运行、独立状态/attempt、输入复检、结果 ZIP |
| test_a0.py | 45 项 CPU/CUDA 可执行测试；服务器运行时自动执行 |
| expected_sources.json | 固定已验收 clean 源码、数据、原 run 元数据、checkpoint、参照的来源哈希 |
| references/*.npz | 12 份既有验证预测的首次 KC 子集，不含新方法的预测 |
| SERVER_TEST_GUIDE.md | 上传、安全解压、tmux、CPU 一键全套、可选 CUDA、失败/续跑与下载说明 |
| PACKAGE_MANIFEST.json | 工具分发文件 SHA-256 清单；运行前核对 |
| LOCAL_VALIDATION.json | 本地测试、四个真实 smoke checkpoint 和 full 上下文核对记录 |

## 数据流和没有做的事

训练曝光集合与每个冻结 checkpoint → 该 checkpoint 的 KC-share 静态 logit → 预测前目标 KC 计数为零的验证行 → Original/Zero/KC-share → 核验 Original → 使用当前标签计算误差。

三个分支共用相同题目参数、NCD 头和所有其余参数。通过临时 embedding 输出 hook 只替换目标静态读出，finally 移除 hook，不原地修改权重。没有 optimizer、backward、训练入口调用、修改后的 checkpoint 保存。

当前已核对数据每题一个编码 KC。该 KC 首次出现时 P=N=0，其他 KC 在读出前被 Q 屏蔽，因此可以直接计算该条预测，不必递归回放数百万历史。该性质依赖当前模型和数据条件，多 KC、历史计数或来源不一致即拒绝执行。

快捷路径只导出首次组，不冒称已经重新推理全部非首次记录。合成序列验证了替代读出不改变 observe 后的状态和非首次预测。真实 smoke 通过原评测引擎验证快捷结果；正式 full 上必须再次逐行验收。

两个数据集预期首次 valid 样本量分别为 27,998 和 21,201。ASSIST 无训练 KC 参照的 2 条记录固定回退 zero 并保留；EDNet 为 0 条。KC-share 按曝光学生等权，重复作答不重复加权；不从 valid/test 补支持。

## 来源与统计边界

seeds 1/2 的参照来自已验收的同一 clean checkpoint 验证导出；seed0 来自已有兼容 temporal-none 的首次子集。后者仅检验该子集的桥接，不能冒称整个 clean-seed0 序列已重验。

原 NPZ 包含全部划分，读取相关列后，test 行不进入支持集合、历史选择、预测或评分。当前标签不进入 shared_reference/probe_predict；标签用于指标。沿用已披露的离线训练、逐行反馈假设，不改反馈边界。

主对照为 KC-share−Zero；同时完整报告 KC-share−Original 与 Zero−Original。报告事件 NLL/Brier、学生宏平均 NLL/Brier、AUC、ECE、实际正确率、平均概率。固定敏感性覆盖总历史、训练曝光学生数、题目训练支持和排除当前同时间评分行；空组也保留。

每数据集 2000 次学生簇配对 bootstrap，固定 seed=20260929，同次抽样共享给全部种子/分支。提供逐 seed 结果和三 seed 均值、样本标准差与条件区间。区间以固定 checkpoint 为条件，不覆盖训练选择或方向探索的不确定性；敏感性组是描述性结果，不把多个探索性对照当作预注册显著结论。

## 本地实际验收

- 45 项 CPU 单元/合同测试通过，包括标签隔离、回退、学生去重、单 KC 限制、当前计数、真实写入顺序、跨 chunk、非首次不变、权重与 hook 不变、参照破坏拒绝、配对 bootstrap 显式重采样复核、指标独立公式复核、输出/锁/续跑/压缩包保护和 CLI help 正常退出。
- 4 个真实 smoke checkpoint：ASSIST dynamic_only/unit_write、EDNet dynamic_only/unit_write。
- 原始 `engine.evaluate(view=valid)`，batch=8，chunk=100 和 17：两数据集 valid 数量 338/601、首次组 42/75。首次 Original 快捷值与真实递归结果的 probability/uncertainty/evidence 最大绝对差均为 0；全 valid 的两个 chunk 结果也为 0。
- 四次真实 checkpoint 加载、run_job、逐条原始预测核验、输出文件和完成记录校验通过。
- 全量 train+valid 的学生/题目/时间/划分/Q 和原始记录位置，与已验收服务器 pilot 上下文数组完全一致；12 份首次参照元数据完全一致。ASSIST 11,929 名学生、EDNet 7,899 名学生。服务器 exact-file-hash 守卫保持严格。
- 本地 GPU 未运行；full checkpoint 不在本地，因此没有 full A0 结果或收益结论。运行与数值环境记录见 LOCAL_VALIDATION.json。

本地首次 QA 因“本地重生成 NPZ 文件 SHA 与服务器不相同”而停止，未改服务器指纹规则。后续本地 QA 改为检查已验收 server context 的数组内容，并明确区分文件级哈希与数组级相等；全部本地尝试保留在独立设计目录中。

## 研究方向受到什么影响

此实现不提前认定应该改模型。它将“首次 KC 的静态读出可能欠缺个体监督”转成三个明确可证伪的冻结对照，用 Zero 区分去随机/位置变化与共享参照的额外价值。这一轮不是 reliability 写入或时间巩固的有效性测试。

只有拿回服务器 ZIP 后，才能决定：继续初始静态参照/跨 KC 共享的受控设计，收窄到特定数据条件，或停止这条简单探针。即使有收益，也仍需整体偏移等混淆控制、合适外部基线和独立最终测试，不能直接包装成已发表级创新。
