"""Run an isolated, validation-only A0 suite. Existing artifacts are never overwritten."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import zipfile
sys.dont_write_bytecode=True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import numpy as np
import pandas as pd
import torch
from a0_core import (require,digest,read_json,write_json,model_class,load_context,
                     fast_predict,verify_reference,grouped_metrics,paired_bootstrap)

HERE=Path(__file__).resolve().parent


def preflight(project,output,expected,device):
    project=Path(project).resolve(); output=Path(output).resolve()
    require(project.is_dir(),f"Missing clean project: {project}")
    require(not HERE.is_relative_to(project),"Keep this tool outside the original project")
    require(output.is_relative_to(HERE/"outputs") and output!=HERE/"outputs","Output must be a new subdirectory of this tool's outputs")
    for name,sha in expected["core_sources"].items():
        require(digest(project/name)==sha,f"Original source mismatch: {name}")
    for ds,d in expected["data"].items():
        root=project/"data"/(ds+"_full")
        require(digest(root/"manifest.json")==d["fingerprint"],f"Wrong {ds} data manifest")
        for name,key in (("records.npz","records_sha256"),("vocabulary.json","vocabulary_sha256")):
            require(digest(root/name)==d[key],f"Data changed: {root/name}")
    jobs=[]
    for job in expected["jobs"]:
        run=project/job["run_relative"]
        for name,sha in job["metadata_hashes"].items():
            require(digest(run/name)==sha,f"Original run metadata changed: {run/name}")
        cfg,st,history=[read_json(run/(x+".json")) for x in ("run_config","status","history")]
        require(st["status"]=="complete",f"Incomplete training run: {run}")
        best=max(history,key=lambda r:r["valid"]["auc"] if r["valid"]["auc"] is not None else -r["valid"]["nll"])
        require(best["epoch"]==st["best_epoch"]==job["best_epoch"],"Best-epoch mismatch")
        require(cfg["args"]["seed"]==job["seed"] and cfg["model_config"]==job["model_config"],"Training seed/model mismatch")
        require(cfg["data_fingerprint"]==expected["data"][job["dataset"]]["fingerprint"],"Run data fingerprint mismatch")
        for key,val in expected["training_settings"][job["dataset"]].items(): require(cfg["args"][key]==val,f"Training setting mismatch: {key}")
        require(cfg["args"]["ack_row_feedback"] and cfg["args"]["eval_update_targets"]==1,"Feedback permission mismatch")
        ck=run/"best_model.pt"
        require(digest(ck)==job["checkpoint_sha256"]==st["checkpoint_sha256"],f"Checkpoint changed: {ck}")
        require(digest(HERE/job["reference_file"])==job["reference_sha256"],"Packaged cold reference changed")
        jobs.append({**job,"checkpoint":str(ck)})
    return {"version":1,"project":str(project),"output":str(output),"device":device,"cuda_visible_devices":os.environ.get("CUDA_VISIBLE_DEVICES"),
            "batch_size":8,"atol":1e-6,"training_performed":False,"test_evaluated":False,
            "package_manifest_sha256":digest(HERE/"PACKAGE_MANIFEST.json"),"jobs":jobs}


def verify_package():
    m=read_json(HERE/"PACKAGE_MANIFEST.json")
    for name,sha in m["files"].items():
        path=(HERE/name).resolve()
        require(path.is_relative_to(HERE),"Unsafe package path")
        require(digest(path)==sha,f"Tool package changed: {name}")


def load_model(job,project,device,expected):
    checkpoint=Path(job["checkpoint"])
    require(digest(checkpoint)==job["checkpoint_sha256"],"Checkpoint changed after preflight")
    ck=torch.load(checkpoint,map_location="cpu",weights_only=True)
    require(ck.get("model_family") in (None,"clean"),"Not a clean checkpoint; do not fabricate model_family")
    require(ck["epoch"]==job["best_epoch"] and ck["model_config"]==job["model_config"],"Checkpoint payload metadata mismatch")
    require(ck["data_fingerprint"]==expected["data"][job["dataset"]]["fingerprint"],"Checkpoint payload data mismatch")
    for key,sha in expected["core_sources"].items(): require(ck["source_code"].get(key)==sha,f"Checkpoint source mismatch: {key}")
    model=model_class(project)(**ck["model_config"])
    model.load_state_dict(ck["model_state"],strict=True)
    del ck  # optimizer tensors remain on CPU and are discarded, never used
    model.requires_grad_(False)
    return model.to(device).eval()


def run_job(job,project,context,device,target,expected):
    target.mkdir(parents=True,exist_ok=False)
    start=time.perf_counter()
    model=load_model(job,project,device,expected)
    frame,shared,model_sha=fast_predict(model,context,device,8)
    errors=verify_reference(frame,HERE/job["reference_file"])
    require(int((frame.donor_students==0).sum())==expected["data"][job["dataset"]]["cold_donorless_n"],"Unexpected donorless count")
    # Save only AFTER original-vs-reference checks pass. No test or full predictions.
    frame.to_csv(target/"cold_predictions.csv",index=False)
    np.savez_compressed(target/"shared_reference.npz",**shared)
    write_json(target/"metrics.json",grouped_metrics(frame))
    require(digest(job["checkpoint"])==job["checkpoint_sha256"],"Checkpoint changed during probe")
    for key,sha in expected["core_sources"].items(): require(digest(Path(project)/key)==sha,"Original source changed during probe")
    status={"status":"complete","job":job["name"],"n":len(frame),"best_epoch":job["best_epoch"],
            "checkpoint_sha256":job["checkpoint_sha256"],"model_parameters_sha256_before_after":model_sha,
            "reference_kind":job["reference_kind"],"max_absolute_difference":errors,"atol":1e-6,
            "seconds":time.perf_counter()-start,"training_performed":False,"test_evaluated":False,
            "mode":"direct first-KC readout; no full replay; non-cold predictions not exported",
            "environment":{"python":sys.version,"torch":str(torch.__version__),"numpy":np.__version__,"pandas":pd.__version__,"device":str(device)}}
    write_json(target/"status.json",status)
    return {"files":{p.name:digest(p) for p in sorted(target.iterdir()) if p.is_file()},"seconds":status["seconds"],"n":len(frame)}


def verify_completed(output,entry):
    target=(output/entry["directory"]).resolve()
    require(target.is_relative_to(output),"Unsafe saved output path")
    for name,sha in entry["files"].items(): require(digest(target/name)==sha,f"Completed result changed: {target/name}")
    require(read_json(target/"status.json")["status"]=="complete","Saved result not complete")


def summarize(output,completed,jobs):
    summary={"scope":"first-KC validation records only, paired frozen readout probes","datasets":{}}
    for ds in ("assist","ednet"):
        frames={}
        for job in jobs:
            if job["dataset"]!=ds: continue
            entry=completed[job["name"]]; verify_completed(output,entry)
            frames[f"{job['variant']}_seed{job['seed']}"]=pd.read_csv(output/entry["directory"]/"cold_predictions.csv")
        print(f"SUMMARY {ds}: paired student bootstrap (2000)",flush=True)
        summary["datasets"][ds]=paired_bootstrap(frames)
    write_json(output/"summary.json",summary)
    lines=["# A0 frozen first-KC probes", "", "No training. No test evaluation. Negative NLL differences favor the first named arm.",
           "Student-cluster intervals condition on the fixed checkpoints; not full training/selection uncertainty.","",
           "| Dataset | Original variant | Contrast | Event NLL mean | Student macro NLL mean |", "| --- | --- | --- | ---: | ---: |"]
    for ds,r in summary["datasets"].items():
        for variant,c in r["seed_means"].items():
            for contrast,m in c.items(): lines.append(f"| {ds} | {variant} | {contrast} | {m['nll']['event_mean']:+.6f} | {m['nll']['student_macro_mean']:+.6f} |")
    (output/"RESULTS.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def archive(output,completed):
    final=output/"a0_results.zip"
    if final.exists():
        require(digest(final)==read_json(output/"archive.json")["sha256"],"Existing archive changed")
        return final
    k=1
    while (output/f"package_attempt_{k:03}.zip").exists(): k+=1
    pending=output/f"package_attempt_{k:03}.zip"
    files=[output/name for name in ("suite_plan.json","completed.json","summary.json","RESULTS.md","suite_status.json")]
    files+=list(output.glob("tests_*.log"))
    for entry in completed.values():
        verify_completed(output,entry)
        files += [output/entry["directory"]/name for name in entry["files"]]
    with zipfile.ZipFile(pending,"x",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in files: z.write(f,f.relative_to(output).as_posix())
        z.write(HERE/"expected_sources.json","expected_sources.json")
        z.write(HERE/"PACKAGE_MANIFEST.json","tool_package_manifest.json")
    with zipfile.ZipFile(pending) as z: require(z.testzip() is None,"Result ZIP CRC failed")
    pending.rename(final)
    write_json(output/"archive.json",{"sha256":digest(final),"bytes":final.stat().st_size,"file":str(final)})
    return final


def execute(plan,expected,resume):
    output=Path(plan["output"])
    if output.exists():
        require(resume,"Output exists; preserve it. Use --resume for the identical suite, or a NEW output-root")
        require(read_json(output/"suite_plan.json")==plan,"Resume settings/source/checkpoint differ; use a new output-root")
    else:
        output.mkdir(parents=True,exist_ok=False); write_json(output/"suite_plan.json",plan)
    lock=output/".a0_lock"
    require(not lock.exists(),f"Lock exists: {lock}. Do not delete blindly; check running process first.")
    lock.mkdir(); write_json(lock/"owner.json",{"pid":os.getpid(),"started_unix":time.time()})
    completed={}
    try:
        completed=read_json(output/"completed.json") if (output/"completed.json").exists() else {}
        require(set(completed).issubset({j["name"] for j in plan["jobs"]}),"Unknown completed job")
        for device in (["cpu","cuda"] if plan["device"]=="cuda" else ["cpu"]):
            number=1
            while (output/f"tests_{device}_{number:03}.log").exists(): number+=1
            log=output/f"tests_{device}_{number:03}.log"
            write_json(output/"suite_status.json",{"status":"testing","device":device,"completed":len(completed),"total":12,"log":str(log)})
            print(f"TESTS {device}; log: {log}",flush=True)
            with log.open("x",encoding="utf-8") as fh:
                rc=subprocess.run([sys.executable,"-B",str(HERE/"test_a0.py"),"--project-dir",plan["project"],"--device",device],stdout=fh,stderr=subprocess.STDOUT).returncode
            require(rc==0,f"Tests failed: {log}")
        dev=torch.device(plan["device"]); contexts={}
        for job in plan["jobs"]:
            name=job["name"]
            if name in completed:
                verify_completed(output,completed[name]); print(f"SKIP verified {name}",flush=True); continue
            ds=job["dataset"]
            if ds not in contexts: contexts[ds]=load_context(Path(plan["project"])/"data"/(ds+"_full"),expected["data"][ds])
            attempt=1
            while (output/name/f"attempt_{attempt:03}").exists(): attempt+=1
            target=output/name/f"attempt_{attempt:03}"
            write_json(output/"suite_status.json",{"status":"running","current":name,"completed":len(completed),"total":12})
            print(f"START {name}; completed={len(completed)}/12",flush=True)
            entry=run_job(job,plan["project"],contexts[ds],dev,target,expected)
            entry["directory"]=target.relative_to(output).as_posix()
            completed[name]=entry; write_json(output/"completed.json",completed)
            print(f"DONE {name}; n={entry['n']}; seconds={entry['seconds']:.1f}; completed={len(completed)}/12",flush=True)
        # A second read-only preflight checks all source/data/checkpoints stayed unchanged.
        require(preflight(plan["project"],output,expected,plan["device"])==plan,"Inputs changed during suite")
        summarize(output,completed,plan["jobs"])
        write_json(output/"suite_status.json",{"status":"complete","completed":12,"total":12,"training_performed":False,"test_evaluated":False,"archive":"a0_results.zip"})
        path=archive(output,completed)
        print("ALL_A0_PROBES_COMPLETED\n"+str(path),flush=True)
    except BaseException as exc:
        write_json(output/"suite_status.json",{"status":"failed","completed":len(completed),"total":12,"error":repr(exc)})
        raise
    finally:
        # Only our own newly acquired lock; no recursive cleanup or result deletion.
        (lock/"owner.json").unlink(); lock.rmdir()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir",required=True); p.add_argument("--output-root",required=True)
    p.add_argument("--device",choices=("cpu","cuda"),default="cuda")
    p.add_argument("--ack-row-feedback",action="store_true"); p.add_argument("--resume",action="store_true")
    p.add_argument("--check-only",action="store_true")
    a=p.parse_args()
    require(a.ack_row_feedback,"Explicit --ack-row-feedback required; feedback boundaries unverified")
    verify_package()
    torch.set_num_threads(4); torch.manual_seed(0)
    torch.use_deterministic_algorithms(True); torch.backends.cudnn.benchmark=False; torch.backends.cudnn.deterministic=True
    if a.device=="cuda": require(torch.cuda.is_available(),"CUDA unavailable; use the yydw Python and check selected GPU")
    expected=read_json(HERE/"expected_sources.json")
    print("Checking 12 EXISTING checkpoints and data/source hashes. No training.",flush=True)
    plan=preflight(a.project_dir,a.output_root,expected,a.device)
    print("PREFLIGHT_OK: 12 checkpoints; 3 frozen arms; validation first-KC only.",flush=True)
    if not a.check_only: execute(plan,expected,a.resume)


if __name__=="__main__":
    try: main()
    except KeyboardInterrupt:
        print("Interrupted; completed results preserved. Check processes before resuming.",file=sys.stderr)
        sys.exit(130)
    except Exception:
        traceback.print_exc(); sys.exit(1)
