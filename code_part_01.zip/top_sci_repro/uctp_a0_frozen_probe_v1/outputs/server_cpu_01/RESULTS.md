# A0 frozen first-KC probes

No training. No test evaluation. Negative NLL differences favor the first named arm.
Student-cluster intervals condition on the fixed checkpoints; not full training/selection uncertainty.

| Dataset | Original variant | Contrast | Event NLL mean | Student macro NLL mean |
| --- | --- | --- | ---: | ---: |
| assist | dynamic_only | kc_share_minus_zero | -0.001428 | -0.001104 |
| assist | dynamic_only | kc_share_minus_original | -0.002967 | -0.002513 |
| assist | dynamic_only | zero_minus_original | -0.001539 | -0.001408 |
| assist | unit_write | kc_share_minus_zero | +0.000454 | +0.000919 |
| assist | unit_write | kc_share_minus_original | -0.001090 | -0.000477 |
| assist | unit_write | zero_minus_original | -0.001544 | -0.001396 |
| ednet | dynamic_only | kc_share_minus_zero | +0.002461 | +0.003207 |
| ednet | dynamic_only | kc_share_minus_original | -0.000499 | +0.000352 |
| ednet | dynamic_only | zero_minus_original | -0.002960 | -0.002854 |
| ednet | unit_write | kc_share_minus_zero | +0.001392 | +0.001740 |
| ednet | unit_write | kc_share_minus_original | +0.000223 | +0.000744 |
| ednet | unit_write | zero_minus_original | -0.001168 | -0.000996 |
