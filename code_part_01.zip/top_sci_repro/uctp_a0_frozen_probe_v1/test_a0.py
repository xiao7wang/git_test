"""CPU/CUDA synthetic contract tests; never train or modify the original project."""
import argparse
import copy
import inspect
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import unittest
from unittest.mock import patch
sys.dont_write_bytecode=True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG",":4096:8")
import numpy as np
import pandas as pd
import torch
import a0_core as c

PROJECT=None
DEVICE="cpu"
MODEL=None


def arrays():
    u=np.array([0]*5+[1]*5+[2]*2,np.int32)
    item=np.array([0,0,1,1,2,0,1,2,2,1,1,2],np.int32)
    split=np.array([0,0,1,1,2,0,1,1,1,2,0,1],np.int32)
    times=np.array([0,1,2,2,3,0,1,2,3,4,0,1],np.float64)
    counts=[]; students=[]; kcseen={}; useen={}
    for s,k in zip(u,item):
        counts.append(kcseen.get((s,k),0)); students.append(useen.get(s,0))
        kcseen[(s,k)]=kcseen.get((s,k),0)+1; useen[s]=useen.get(s,0)+1
    return {"student_idx":u,"item_idx":item,"split":split,"timestamp":times,
            "item_q":np.eye(3,dtype=bool),"source_row":np.arange(12,dtype=np.int64),
            "kc_count_before":np.array(counts,np.float32),"student_count_before":np.array(students,np.int32),
            "label":np.array([0,1,1,0,1,1,0,1,0,1,1,0],np.float32)}


def model(variant="unit_write"):
    torch.manual_seed(123)
    m=MODEL(3,3,3,variant=variant,ncd_hidden_dim=8).to(DEVICE).eval()
    with torch.no_grad(): m.student_mastery_logit.weight.copy_(torch.tensor([[.2,.4,.6],[.8,1.,1.2],[1.4,1.6,1.8]],device=DEVICE))
    return m


class A0Tests(unittest.TestCase):
    def test_context_excludes_test_and_current(self):
        ctx=c.context_from_arrays(arrays(),3)
        self.assertEqual(ctx["frame"].record_idx.tolist(),[2,6,7,11])
        self.assertEqual(ctx["donor_pairs"].tolist(),[0,3,7])
        self.assertTrue((ctx["frame"].kc_count_before==0).all())

    def test_donor_student_not_frequency_weighted(self):
        ctx=c.context_from_arrays(arrays(),3); m=model(); mu,n=c.shared_reference(m,ctx["donor_pairs"])
        np.testing.assert_allclose(mu,[.5,1.6,0],atol=1e-7); np.testing.assert_array_equal(n,[2,1,0])

    def test_empty_donors_zero_fallback(self):
        mu,n=c.shared_reference(model(),np.array([],np.int64)); self.assertTrue((mu==0).all() and (n==0).all())

    def test_duplicate_donors_rejected(self):
        with self.assertRaises(RuntimeError): c.shared_reference(model(),np.array([0,0]))

    def test_training_support_excludes_valid_and_test(self):
        a=arrays(); a["label"][:]=1-a["label"]
        x=c.context_from_arrays(arrays(),3); y=c.context_from_arrays(a,3)
        np.testing.assert_array_equal(x["donor_pairs"],y["donor_pairs"])
        self.assertEqual(x["frame"].item_train_support.tolist(),[1,1,0,0])

    def test_multikc_rejected(self):
        a=arrays(); a["item_q"][0,1]=1
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_empty_q_rejected(self):
        a=arrays(); a["item_q"][0]=0
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_bad_count_rejected(self):
        a=arrays(); a["kc_count_before"][2]=1
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_future_timestamp_reversal_rejected(self):
        a=arrays(); a["timestamp"][3]=-1
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_missing_timestamp_rejected(self):
        a=arrays(); a["timestamp"][2]=np.nan
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_test_label_not_scored_or_validated(self):
        a=arrays(); a["label"][a["split"]==2]=np.nan
        ctx=c.context_from_arrays(a,3); self.assertTrue(np.isfinite(ctx["frame"].label).all())

    def test_same_timestamp_group_preserved(self):
        f=c.context_from_arrays(arrays(),3)["frame"]
        self.assertEqual(f.same_time_group.tolist(),[True,False,False,False])

    def test_invalid_active_label_rejected(self):
        a=arrays(); a["label"][2]=np.nan
        with self.assertRaises(RuntimeError): c.context_from_arrays(a,3)

    def test_no_label_argument(self):
        self.assertNotIn("label",inspect.signature(c.probe_predict).parameters)

    def test_label_changes_do_not_change_predictions(self):
        a=arrays(); b=copy.deepcopy(a); b["label"]=1-b["label"]
        m=model(); fa=c.fast_predict(m,c.context_from_arrays(a,3),DEVICE)[0]; fb=c.fast_predict(m,c.context_from_arrays(b,3),DEVICE)[0]
        for arm in c.ARMS: np.testing.assert_array_equal(fa[arm],fb[arm])

    def test_model_weights_and_hooks_unchanged(self):
        m=model(); before=c.model_digest(m); ctx=c.context_from_arrays(arrays(),3)
        c.fast_predict(m,ctx,DEVICE)
        self.assertEqual(c.model_digest(m),before); self.assertEqual(len(m.student_mastery_logit._forward_hooks),0)

    def test_hook_removed_on_exception(self):
        m=model(); state=m.init_state(1,DEVICE); idx=torch.tensor([0],device=DEVICE); q=torch.tensor([[1.,0.,0.]],device=DEVICE)
        with patch.object(m.ncd,"forward",side_effect=ValueError("deliberate")):
            with self.assertRaises(ValueError): c.probe_predict(m,state,idx,idx,q,torch.tensor([True],device=DEVICE),"zero",torch.zeros(3,device=DEVICE))
        self.assertEqual(len(m.student_mastery_logit._forward_hooks),0)

    def test_zero_does_not_force_half_probability(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        self.assertTrue(np.any(np.abs(f.zero.to_numpy()-.5)>1e-3))

    def test_only_selected_cold_dimensions_overridden(self):
        m=model(); idx=torch.tensor([0,1],device=DEVICE); it=torch.tensor([1,2],device=DEVICE)
        q=torch.eye(3,device=DEVICE)[it]; state=m.init_state(2,DEVICE)
        cold=torch.tensor([True,False],device=DEVICE); share=torch.ones(3,device=DEVICE)
        original=c.probe_predict(m,state,idx,it,q,cold,"original",share)
        changed=c.probe_predict(m,state,idx,it,q,cold,"zero",share)
        self.assertEqual(original["probability"][1],changed["probability"][1])

    def replay_check(self,variant):
        a=arrays(); ctx=c.context_from_arrays(a,3); m=model(variant); mu,_=c.shared_reference(m,ctx["donor_pairs"])
        share=torch.as_tensor(mu,device=DEVICE); fast=c.fast_predict(m,ctx,DEVICE)[0].set_index("record_idx")
        for u in range(3):
            states={arm:m.init_state(1,DEVICE) for arm in c.ARMS}; seen=np.zeros(3,int)
            for i in np.flatnonzero((a["student_idx"]==u)&(a["split"]<=1)):
                idx=torch.tensor([u],device=DEVICE); it=torch.tensor([int(a["item_idx"][i])],device=DEVICE)
                q=torch.eye(3,device=DEVICE)[it]; cold=torch.tensor([bool(seen[it.item()]==0)],dtype=torch.bool,device=DEVICE)
                y=torch.tensor([float(a["label"][i])],device=DEVICE); active=torch.tensor([True],device=DEVICE)
                predictions={}
                for arm in c.ARMS:
                    p=c.probe_predict(m,states[arm],idx,it,q,cold,arm,share); predictions[arm]=p["probability"].item()
                    states[arm]=m.observe(states[arm],q,y,p["difficulty_scalar"],active).detach()
                    if i in fast.index: self.assertLessEqual(abs(predictions[arm]-fast.loc[i,arm]),1e-6)
                if not cold.item():
                    self.assertEqual(predictions["original"],predictions["zero"]); self.assertEqual(predictions["original"],predictions["kc_share"])
                for arm in c.ARMS:
                    self.assertTrue(torch.equal(states[arm].positive,states["original"].positive))
                    self.assertTrue(torch.equal(states[arm].negative,states["original"].negative))
                seen[it.item()]+=1

    def test_unit_replay_vs_fast_and_future_invariant(self): self.replay_check("unit_write")
    def test_dynamic_replay_vs_fast_and_future_invariant(self): self.replay_check("dynamic_only")

    def chunk_check(self,variant):
        a=arrays(); ctx=c.context_from_arrays(a,3); m=model(variant)
        fast=c.fast_predict(m,ctx,DEVICE)[0].set_index("record_idx")
        for u in range(3):
            ix=np.flatnonzero((a["student_idx"]==u)&(a["split"]<=1))
            idx=torch.tensor([u],device=DEVICE)
            it=torch.as_tensor(a["item_idx"][ix].astype(np.int64),device=DEVICE)[None,:]
            q=torch.eye(3,device=DEVICE)[it]
            label=torch.as_tensor(a["label"][ix],device=DEVICE)[None,:]
            active=torch.ones_like(label,dtype=torch.bool)
            whole,state_w=m.forward_chunk(m.init_state(1,DEVICE),idx,it,q,label,active)
            state=m.init_state(1,DEVICE); parts=[]
            for start in range(0,len(ix),2):
                end=start+2
                out,state=m.forward_chunk(state,idx,it[:,start:end],q[:,start:end],label[:,start:end],active[:,start:end])
                parts.append(out["probability"])
            self.assertTrue(torch.equal(whole["probability"],torch.cat(parts,1)))
            self.assertTrue(torch.equal(state.positive,state_w.positive))
            self.assertTrue(torch.equal(state.negative,state_w.negative))
            for local,record in enumerate(ix):
                if record in fast.index:
                    self.assertLessEqual(abs(whole["probability"][0,local].item()-fast.loc[record,"original"]),1e-6)

    def test_unit_chunk_two_vs_whole_vs_fast(self): self.chunk_check("unit_write")
    def test_dynamic_chunk_two_vs_whole_vs_fast(self): self.chunk_check("dynamic_only")

    def test_batch_partition_invariance(self):
        ctx=c.context_from_arrays(arrays(),3); m=model()
        a=c.fast_predict(m,ctx,DEVICE,1)[0]; b=c.fast_predict(m,ctx,DEVICE,3)[0]
        np.testing.assert_allclose(a[list(c.ARMS)],b[list(c.ARMS)],rtol=0,atol=1e-6)

    def reference(self,f,path):
        values={k:f[k].to_numpy() for k in c.META}
        values.update(probability=f.original.to_numpy(),uncertainty=f.uncertainty.to_numpy(),evidence=f.evidence.to_numpy())
        np.savez_compressed(path,**values)

    def test_reference_success(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"ref.npz"; self.reference(f,p); self.assertTrue(all(x==0 for x in c.verify_reference(f,p).values()))

    def test_reference_probability_corruption_stops(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"ref.npz"; self.reference(f,p)
            f["original"]=f.original.astype(np.float64)+.01
            with self.assertRaises(RuntimeError): c.verify_reference(f,p)

    def test_reference_label_mismatch_stops(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"ref.npz"; self.reference(f,p); f["label"]=1-f.label
            with self.assertRaises(RuntimeError): c.verify_reference(f,p)

    def test_reference_order_mismatch_stops(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/"ref.npz"; self.reference(f,p)
            with self.assertRaises(RuntimeError): c.verify_reference(f.iloc[::-1],p)

    def test_single_class_auc_null(self):
        f=pd.DataFrame({"student_idx":[0,0,1],"label":[1,1,1]})
        self.assertIsNone(c.metrics(f,[.1,.5,.9])["auc"])

    def test_empty_group_retained(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        m=c.grouped_metrics(f)["student_ge50"]
        self.assertEqual(m["n"],0); self.assertIsNone(m["arms"]["original"]["nll"])

    def test_bootstrap_paired_identity(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        for arm in c.ARMS: f[arm]=f.original
        b=c.paired_bootstrap({"unit_write_seed0":f},reps=20)
        for contrast,m in b["runs"]["unit_write_seed0"].items():
            self.assertEqual(m["nll"]["event_ci95"],[0.,0.]); self.assertEqual(m["nll"]["student_macro_ci95"],[0.,0.])

    def test_bootstrap_matches_explicit_student_sampling(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        b=c.paired_bootstrap({"unit_write_seed0":f},reps=30,seed=4)
        y=f.label.to_numpy(); delta=c.losses(y,f.kc_share)-c.losses(y,f.zero)
        users=np.unique(f.student_idx); rng=np.random.default_rng(4); vals=[]; macro=[]
        for _ in range(30):
            sampled=rng.choice(users,len(users)); rows=[np.flatnonzero(f.student_idx==u) for u in sampled]
            vals.append(delta[np.concatenate(rows)].mean()); macro.append(np.mean([delta[ix].mean() for ix in rows]))
        r=b["runs"]["unit_write_seed0"]["kc_share_minus_zero"]["nll"]
        np.testing.assert_allclose(r["event_ci95"],np.quantile(vals,[.025,.975]),atol=1e-14)
        np.testing.assert_allclose(r["student_macro_ci95"],np.quantile(macro,[.025,.975]),atol=1e-14)

    def test_summary_bad_alignment_rejected(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]
        with self.assertRaises(RuntimeError): c.paired_bootstrap({"unit_write_seed0":f,"unit_write_seed1":f.iloc[::-1]},reps=2)

    def test_auc_ties_matches_pairwise_definition(self):
        f=pd.DataFrame({"student_idx":[0,0,1,1,1],"label":[1,0,1,0,1]})
        p=np.array([.8,.8,.3,.1,.3]); y=f.label.to_numpy()
        pairs=[float(a>b)+.5*float(a==b) for a in p[y==1] for b in p[y==0]]
        self.assertAlmostEqual(c.metrics(f,p)["auc"],np.mean(pairs),14)

    def test_event_and_student_macro_are_distinct_correct_means(self):
        f=pd.DataFrame({"student_idx":[0,0,0,1],"label":[1,0,1,0]}); p=np.array([.9,.2,.8,.9])
        l=-np.log([.9,.8,.8,.1]); m=c.metrics(f,p)
        self.assertAlmostEqual(m["nll"],l.mean(),14)
        self.assertAlmostEqual(m["student_macro_nll"],(l[:3].mean()+l[3])/2,14)
        self.assertNotAlmostEqual(m["nll"],m["student_macro_nll"],5)

    def test_three_seed_summary_mean_and_sd(self):
        f=c.fast_predict(model(),c.context_from_arrays(arrays(),3),DEVICE)[0]; frames={}; values=[]
        for seed in range(3):
            g=f.copy(); g["kc_share"]=np.clip(g.kc_share.astype(np.float64)+seed*.01,1e-6,1-1e-6)
            frames[f"unit_write_seed{seed}"]=g
            values.append(float((c.losses(g.label,g.kc_share)-c.losses(g.label,g.zero)).mean()))
        r=c.paired_bootstrap(frames,reps=20)["seed_means"]["unit_write"]["kc_share_minus_zero"]["nll"]
        self.assertAlmostEqual(r["event_mean"],np.mean(values),14)
        self.assertAlmostEqual(r["event_seed_sd"],np.std(values,ddof=1),14)

    def test_unsafe_output_rejected(self):
        import run_a0_suite as run
        with self.assertRaises(RuntimeError): run.preflight(PROJECT,PROJECT,{"core_sources":{}},"cpu")

    def test_cli_help_exit_zero_without_evaluation(self):
        result=subprocess.run([sys.executable,"-B",str(Path(__file__).resolve().parent/"run_a0_suite.py"),"--help"],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertIn("--check-only",result.stdout)
        self.assertNotIn("Traceback",result.stderr)

    def test_changed_original_source_rejected(self):
        import run_a0_suite as run
        with self.assertRaises(RuntimeError): run.preflight(PROJECT,run.HERE/"outputs"/"synthetic",{"core_sources":{"src/model.py":"wrong"}},"cpu")

    def test_existing_output_refused_without_resume(self):
        import run_a0_suite as run
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaisesRegex(RuntimeError,"Output exists"):
                run.execute({"output":d},{},False)

    def test_resume_changed_plan_refused(self):
        import run_a0_suite as run
        with tempfile.TemporaryDirectory() as d:
            c.write_json(Path(d)/"suite_plan.json",{"output":d,"device":"cuda"})
            with self.assertRaisesRegex(RuntimeError,"Resume settings"):
                run.execute({"output":d,"device":"cpu"},{},True)

    def test_existing_lock_preserved(self):
        import run_a0_suite as run
        with tempfile.TemporaryDirectory() as d:
            plan={"output":d}; c.write_json(Path(d)/"suite_plan.json",plan)
            (Path(d)/".a0_lock").mkdir()
            with self.assertRaisesRegex(RuntimeError,"Lock exists"): run.execute(plan,{},True)
            self.assertTrue((Path(d)/".a0_lock").is_dir())

    def test_corrupt_completed_file_releases_own_lock(self):
        import run_a0_suite as run
        with tempfile.TemporaryDirectory() as d:
            plan={"output":d}; c.write_json(Path(d)/"suite_plan.json",plan)
            (Path(d)/"completed.json").write_text("not json",encoding="utf-8")
            with self.assertRaises(json.JSONDecodeError): run.execute(plan,{},True)
            self.assertFalse((Path(d)/".a0_lock").exists())
            self.assertEqual(c.read_json(Path(d)/"suite_status.json")["status"],"failed")

    def test_modified_completed_result_rejected(self):
        import run_a0_suite as run
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); folder=root/"job"; folder.mkdir()
            c.write_json(folder/"status.json",{"status":"complete"})
            entry={"directory":"job","files":{"status.json":c.digest(folder/"status.json")}}
            run.verify_completed(root,entry)
            c.write_json(folder/"status.json",{"status":"failed"})
            with self.assertRaises(RuntimeError): run.verify_completed(root,entry)

    def test_archive_integrity_and_repeat(self):
        import run_a0_suite as run
        import zipfile
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); target=root/"job"; target.mkdir()
            for name in ("suite_plan.json","completed.json","summary.json","suite_status.json"):
                c.write_json(root/name,{})
            (root/"RESULTS.md").write_text("synthetic QA",encoding="utf-8")
            c.write_json(target/"status.json",{"status":"complete"})
            completed={"job":{"directory":"job","files":{"status.json":c.digest(target/"status.json")}}}
            # Package manifest does not exist until distribution is built; mock only its archive source.
            original_write=zipfile.ZipFile.write
            def safe_write(z,filename,arcname=None,*args,**kwargs):
                if Path(filename)==run.HERE/"PACKAGE_MANIFEST.json":
                    return z.writestr(arcname,"{}")
                return original_write(z,filename,arcname,*args,**kwargs)
            with patch.object(zipfile.ZipFile,"write",safe_write): path=run.archive(root,completed)
            sha=c.digest(path)
            with zipfile.ZipFile(path) as z:
                self.assertIsNone(z.testzip()); self.assertIn("job/status.json",z.namelist())
                self.assertFalse(any(n.endswith(".pt") for n in z.namelist()))
            self.assertEqual(run.archive(root,completed),path); self.assertEqual(sha,c.digest(path))


def main():
    global PROJECT,DEVICE,MODEL
    p=argparse.ArgumentParser(); p.add_argument("--project-dir",required=True); p.add_argument("--device",choices=("cpu","cuda"),default="cpu")
    a=p.parse_args(); PROJECT=Path(a.project_dir).resolve(); DEVICE=a.device
    expected=c.read_json(Path(__file__).resolve().parent/"expected_sources.json")
    for name,sha in expected["core_sources"].items(): c.require(c.digest(PROJECT/name)==sha,"Test project source mismatch")
    if DEVICE=="cuda": c.require(torch.cuda.is_available(),"CUDA unavailable")
    torch.set_num_threads(4); torch.use_deterministic_algorithms(True)
    MODEL=c.model_class(PROJECT)
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(A0Tests))
    print(json.dumps({"success":result.wasSuccessful(),"tests_run":result.testsRun,"device":DEVICE,"torch":str(torch.__version__),"skipped":result.skipped}),flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__=="__main__": main()
