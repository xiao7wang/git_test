# A0 首次知识点冻结读出：服务器操作指南

版本日期：2026-10-05。这是一个独立诊断包，不是新的训练版本。

## 这次到底跑什么

一句话：学生第一次在平台上做某个知识点时，原模型的学生–知识点静态值是否合适？换成零值或训练期的 KC 共享参照，会不会更好？

固定使用已训练完成的 12 个 clean checkpoint：2 个数据集 × dynamic_only/unit_write × seeds 0/1/2。每个 checkpoint 同时计算三个冻结读出：Original、Zero、KC-share。只评价首次 KC 的验证记录，不训练、不改状态写入、不计算 test 指标。

这是 12 个 checkpoint 的推理诊断，不是 12 次多 epoch 训练。本轮没有新增 time、reliability 或 consolidation 模块。KC-share 只是当前待检验的固定参照，尚不能称为有效创新。

### 安全边界

- 所有新文件都在 `uctp_a0_frozen_probe_v1` 下；不改 clean、temporal、V1–V7、旧结果或 checkpoint。
- 数据沿用原来的 `uctp_cd_clean_research/data/assist_full` 和 `ednet_full`。不要重新 prepare_data。
- 原验证预测的首次子集已经包含在压缩包中，不用再上传 seed12/pilot 结果 ZIP。
- 检查原源码、数据、checkpoint 和元数据 SHA-256；不匹配就停止，不自动放宽。
- Original 必须逐条对上已有参照，概率/uncertainty/evidence 的绝对误差 ≤ 1e-6；不通过就停止。
- 固定 batch=8；CPU 线程数=4。不要自行改 batch、dtype、容差或模型 family。
- 原 NPZ 物理文件包含全部划分；读取列后只让 train+valid 行进入历史和支持量计算，只有首次 valid 行进入本次预测和评分。不是 test 文件物理隔离，也不使用 test 指标。
- 保留 row-immediate feedback assumption；不声称解决了真实反馈边界问题。

## 1. 上传 ZIP

把 `uctp_a0_frozen_probe_v1.zip` 上传到服务器这个位置：

```text
/home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1.zip
```

ZIP 在 VS Code 文本编辑器中不能显示属于正常现象，不需要点“仍然打开”。使用终端解压。

## 2. 安全解压：不会覆盖已有同名目录

在服务器终端复制以下整段，不要复制 `(base) [...]$` 这样的提示符：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B - <<'PY'
from pathlib import Path
from zipfile import ZipFile

base = Path('/home/wangxiao/QCCDM/top_sci_repro').resolve()
archive = base / 'uctp_a0_frozen_probe_v1.zip'
target = base / 'uctp_a0_frozen_probe_v1'
if target.exists():
    raise SystemExit(f'停止：目录已存在，不覆盖。请先确认是不是本次已解压的包：{target}')
with ZipFile(archive) as z:
    if z.testzip() is not None:
        raise SystemExit('停止：ZIP 校验失败，请重新上传')
    for name in z.namelist():
        if not (base / name).resolve().is_relative_to(target):
            raise SystemExit(f'停止：压缩包路径越界：{name}')
    z.extractall(base)
print('EXTRACT_OK:', target)
PY
```

看到 `EXTRACT_OK` 再继续。若同名目录已经存在，不要删除或重新覆盖；先确认其来源。

## 3. 建立 tmux 会话

```bash
tmux new -s a0_probe
```

若提示 `duplicate session`，使用下面命令进入已有会话，不要重复启动同一套任务：

```bash
tmux attach -t a0_probe
```

如果本来就在 tmux 中，不要嵌套启动；可先按 Ctrl+B，松开，再按 D 分离，然后创建/进入 a0_probe。

## 4. 推荐先用 CPU 一次跑完

这次不是训练，只计算首次 KC 的小型读出；工具支持 CPU，不必等空闲显卡，也不会占用你当前实验的 GPU。CPU 和 CUDA 使用相同的 1e-6 验收标准。若 CPU 对服务器原 CUDA 预测的核对失败，停止诊断，不要放宽阈值；把日志发来再决定是否改用 CUDA 的新输出目录。

进入 tmux 后复制整个代码块：

```bash
set -o pipefail
CUDA_VISIBLE_DEVICES="" /home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/run_a0_suite.py \
  --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/outputs/server_cpu_01 \
  --device cpu \
  --ack-row-feedback \
  2>&1 | tee -a /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/server_cpu_01.console.log
```

使用绝对的 yydw Python，因此终端显示 `(base)` 不影响这条命令；不要换成 base 环境里的裸 `python`。不需要另装或降级依赖。

自动顺序如下：

1. 检查全部 12 个已存在的 checkpoint、原模型/数据/元数据指纹。
2. 跑 45 项 CPU 合同测试。
3. 按数据集、writer、seed 串行计算三分支，并逐条核验 Original。
4. 保存每个 checkpoint 的首次记录预测和预先固定的分组指标。
5. 对两个数据集分别做 2000 次学生簇配对 bootstrap，输出每 seed 及三 seed 汇总。
6. 检查输入未变化，打包结果为 `a0_results.zip`。

每完成一个 checkpoint 会看到类似：

```text
DONE assist_dynamic_only_seed0; n=27998; seconds=...; completed=1/12
```

这里的 seconds 是该 job 的计算与输出时间，不包括最前面的全部文件预检，也不包括最后的 bootstrap。尚无本机服务器实测全套耗时，不承诺“几分钟”；计算量比之前反复训练/全序列回放小得多，通常不应按原先一天半的训练时长估算。

### 启动后可以关闭 SSH

按 **Ctrl+B，松开，再按 D**，回到普通 shell。tmux 会继续运行。

不要用 Ctrl+C 分离；Ctrl+C 会中断前台任务。复制终端文字优先用 Ctrl+Shift+C。不要 kill 进程、删除输出或反复启动相同任务。

## 5. 怎么看进度和成功

任何新终端执行：

```bash
cat /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/outputs/server_cpu_01/suite_status.json
tail -n 40 /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/server_cpu_01.console.log
pgrep -afu wangxiao 'uctp_a0_frozen_probe_v1/(run_a0_suite|test_a0)[.]py'
```

状态文件里的 `running` 是保存状态，不单独证明进程仍活着；结合最后日志与 pgrep。预检还没结束时，可能尚未创建 suite_status.json，先看 console.log。

最终正常完成应同时看到：

- 日志最后 `ALL_A0_PROBES_COMPLETED`；
- suite_status.json 中 `status: complete`、`completed: 12`、`total: 12`；
- 同目录有 `a0_results.zip` 和 `archive.json`。

只看到 `PREFLIGHT_OK` 或测试 `OK`，不代表整套结果已经完成。输出 JSON 是数据文件，需要 `cat 路径` 查看，不能把其路径直接当命令执行。

## 6. 跑完发哪个文件

下载并发回这一个 ZIP：

```text
/home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/outputs/server_cpu_01/a0_results.zip
```

不必发送 checkpoint、不必发送全量原始数据。ZIP 包含完整的首次子集逐条预测、共享参照、分组指标、bootstrap 汇总、参数来源和测试日志。

主要读数：`KC-share − Zero` 的 NLL、`KC-share − Original` 的 NLL，同时必须看 `Zero − Original`。负数表示前一个分支更好。记录等权和学生等权都要看；不能只挑某个数据集、种子或更有利的口径。

若共享优于原值但不优于零值，不能声称“共享认知信息”有效。若两种对照都稳定改善，也只支持继续研究，不等于论文创新已经成立；还要检查简单整体偏移能否解释收益，之后才考虑独立新模型和最终测试。

## 7. 失败或中断怎么办

先发最后 60 行 console.log 和 suite_status.json。如日志指向 `tests_cpu_001.log`，再把该文件末尾也发来。工具失败会保留旧输入和已完成 job，不会自动重训。

常见情况：

- `Output exists`：防覆盖保护，不是模型坏了。不要删除目录，检查原任务是否完成/仍运行。
- `Original/reference mismatch`：停止；不要自行提高 atol、切换精度、修改参照或跳过检查。
- `Original source/metadata/checkpoint changed`：先核对服务器是否还是原验收版本，不要修改 expected_sources.json 来绕过。
- `Lock exists`：可能仍有任务或曾被强制终止。先看进程和 `.a0_lock/owner.json`；不要盲目删锁。
- 缺少具体 checkpoint/文件：把完整 FileNotFoundError 发来，不用重下载整个旧项目。

如果确认没有运行中的任务，且只是正常捕获的中断/临时故障，允许使用同一命令追加 `--resume`。必须保持原 device、CUDA_VISIBLE_DEVICES、参数与输入不变。已完成 job 会校验后跳过；失败 job 创建新的 attempt 子目录，旧 attempt 保留。

```bash
set -o pipefail
CUDA_VISIBLE_DEVICES="" /home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/run_a0_suite.py \
  --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/outputs/server_cpu_01 \
  --device cpu \
  --ack-row-feedback \
  --resume \
  2>&1 | tee -a /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/server_cpu_01.console.log
```

对于 package/source/对齐错误，不要先机械 resume；先定位原因。本指南不授权清理旧实验目录。

## 8. 可选：确认有空闲 GPU 才使用 CUDA

不需要 CPU 和 CUDA 全套各跑一次；CPU 核验通过即可接收本轮诊断。CUDA 是可选执行设备，不是新的实验臂。

先检查：

```bash
nvidia-smi --query-gpu=index,uuid,name,memory.used,memory.total,utilization.gpu --format=csv
nvidia-smi --query-compute-apps=gpu_uuid,pid,process_name,used_memory --format=csv
```

利用率为 0 不代表无人使用，还要看显存、进程和共享服务器约定。不要停掉别人或自己现有的实验。不能确定时继续使用上面的 CPU 命令。

确认空闲后，复制该卡完整 UUID。在下面变量赋值处把示例替换成真实 UUID，不要原样运行 `GPU-替换成...`。

```bash
A0_GPU_UUID='GPU-替换成已经确认空闲的真实UUID'
set -o pipefail
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="$A0_GPU_UUID" \
  /home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/run_a0_suite.py \
  --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/outputs/server_cuda_01 \
  --device cuda \
  --ack-row-feedback \
  2>&1 | tee -a /home/wangxiao/QCCDM/top_sci_repro/uctp_a0_frozen_probe_v1/server_cuda_01.console.log
```

CUDA 模式会先跑 CPU 和 CUDA 两组测试，再做相同的 12 个 job。进度、ZIP 路径中的 `server_cpu_01` 相应改为 `server_cuda_01`。CPU 与 CUDA 切换不能复用一个 suite 的输出目录。

## 已完成的本地验收与局限

本地 CPU（PyTorch 2.7.1+cpu）45 项测试全部通过；两个数据集 × 两种 writer 的真实 smoke checkpoint 已完成 Original 快捷路径与原始 valid 递归评测核对，chunk 100/17 也核对，最大误差均为 0。原模型及四个 checkpoint 哈希未变化。

还核对了两个 full 数据集的训练/验证上下文内容、全部 12 份首次参照的行级元数据与预计回退数量。本地重生成 NPZ 的文件哈希不同于服务器，但读取后的已核对 train+valid 上下文数组一致；服务器工具不会因此放松文件哈希要求。

本地没有这 12 个 full checkpoint，也没有可用 CUDA，因此尚未得出 full A0 效果，尚未验收服务器 PyTorch 2.11.0 / CUDA 12.8 下的新工具运行。服务器本次执行就是补齐这一步，不能把本地 smoke 通过当作科学假设通过。
