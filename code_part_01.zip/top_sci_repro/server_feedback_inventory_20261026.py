"""Bounded read-only EDNet file/schema inventory. Standard library only.

Does not train, load checkpoints, alter source data, extract archives or print
student response values. Writes one NEW JSON report and refuses overwrite.
"""
import argparse
import csv
import json
import os
from pathlib import Path
import time

SKIP = {".git", "__pycache__", "node_modules", ".venv", "venv", "envs",
        "outputs", "logs", "results", "wandb", "checkpoints", ".cache"}
KNOWN = [
    "top_sci_repro/uctp_cd_clean_research/data/ednet_full/manifest.json",
    "top_sci_repro/uctp_cd_clean_research/data/ednet_full/vocabulary.json",
    "top_sci_repro/unified_experiments/splits/ednet/train.csv",
    "top_sci_repro/unified_experiments/splits/ednet/valid.csv",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet/item_mapping.json",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet/user_mapping.json",
    "top_sci_repro/work_support_20260912/ednet_scripts",
]


def csv_header(path):
    # No data values are returned. 64 KiB ceiling protects against malformed CSVs.
    with path.open("rb") as stream:
        raw = stream.read(65536)
    first_line = raw.decode("utf-8-sig", errors="replace").splitlines()[0]
    return next(csv.reader([first_line]))


def inventory(root, max_files=100000, max_seconds=90):
    root = root.resolve()
    if not root.is_dir() or root == Path(root.anchor):
        raise ValueError("A concrete existing project directory is required")
    started = time.monotonic()
    report = {"scope_root": str(root), "read_only_sources": True, "trained": False,
              "response_values_exported": False, "known_paths": [], "csv_candidates": [],
              "upstream_script_candidates": [], "metadata_candidates": [], "archives": [],
              "errors": [], "scan_complete": True, "scanned_files": 0,
              "notes": ["No candidate does not establish absence: bounded scan, excluded outputs, links not followed.",
                        "CSV candidates are header samples, not an event identity or feedback timing verification."]}
    for rel in KNOWN:
        path = root/rel
        record = {"path": str(path), "exists": path.exists()}
        if path.is_file() and path.suffix.lower() == ".csv":
            try:
                record["header"] = csv_header(path)
            except Exception as exc:
                record["error"] = str(exc)
        report["known_paths"].append(record)
    headers_per_dir = {}
    def onerror(err):
        if len(report["errors"]) < 30:
            report["errors"].append(str(err))
    for current, dirs, files in os.walk(root, topdown=True, followlinks=False, onerror=onerror):
        here = Path(current)
        depth = len(here.relative_to(root).parts)
        dirs[:] = sorted(d for d in dirs if d not in SKIP and not d.startswith(".")
                         and not (here/d).is_symlink()) if depth < 12 else []
        if depth >= 12:
            report["scan_complete"] = False
        for name in sorted(files):
            report["scanned_files"] += 1
            if report["scanned_files"] > max_files or time.monotonic()-started > max_seconds:
                report["scan_complete"] = False
                report["stop_reason"] = "file/time budget"
                report["seconds"] = time.monotonic()-started
                return report
            path = here/name
            if path.is_symlink():
                continue
            lower = str(path.relative_to(root)).lower()
            relevant = "ednet" in lower or "kt1" in lower or "kt2" in lower or "kt3" in lower
            try:
                if name.lower().endswith(".csv") and (relevant or name.lower() == "questions.csv"):
                    count = headers_per_dir.get(str(here), 0)
                    if count < 3 and len(report["csv_candidates"]) < 80:
                        headers_per_dir[str(here)] = count+1
                        head = csv_header(path)
                        record = {"path": str(path), "bytes": path.stat().st_size, "header": head,
                                  "kind": "other_ednet_csv"}
                        fields = set(head)
                        if {"timestamp", "question_id", "solving_id", "user_answer"} <= fields:
                            record["kind"] = "raw_kt1_candidate"
                        elif {"timestamp", "action_type", "item_id"} <= fields:
                            record["kind"] = "action_log_candidate"
                        elif {"question_id", "bundle_id", "correct_answer"} <= fields:
                            record["kind"] = "question_content_candidate"
                        report["csv_candidates"].append(record)
                elif name.lower() in {"user_mapping.json", "item_mapping.json", "config.json"} and relevant:
                    if len(report["metadata_candidates"]) < 60:
                        report["metadata_candidates"].append({"path": str(path), "bytes": path.stat().st_size})
                elif path.suffix.lower() in {".py", ".sh"} and any(w in name.lower() for w in ("ednet", "preprocess", "prepare", "unified", "convert", "split")):
                    if path.stat().st_size <= 500000 and len(report["upstream_script_candidates"]) < 50:
                        body = path.read_text(encoding="utf-8", errors="replace")
                        hits = [w for w in ("solving_id", "question_id", "elapsed_time", "bundle_id", "user_mapping", "item_mapping") if w in body]
                        if "ednet" in body.lower() and hits:
                            report["upstream_script_candidates"].append({"path": str(path), "field_terms": hits,
                                "line_numbers": {w: [i for i, line in enumerate(body.splitlines(), 1) if w in line][:12] for w in hits}})
                elif relevant and name.lower().endswith((".zip", ".tar.gz", ".tgz")) and len(report["archives"]) < 20:
                    # Listing potentially huge raw archives is unnecessary; report their locations only.
                    report["archives"].append({"path": str(path), "bytes": path.stat().st_size})
            except (OSError, ValueError, IndexError, csv.Error) as exc:
                if len(report["errors"]) < 30:
                    report["errors"].append({"path": str(path), "error": str(exc)})
    report["seconds"] = time.monotonic()-started
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default="/home/wangxiao/QCCDM")
    p.add_argument("--output", required=True)
    args = p.parse_args()
    out = Path(args.output)
    if out.exists():
        raise SystemExit("Output already exists: refusing overwrite. Send the existing inventory or use a new report name.")
    if not out.parent.is_dir():
        raise SystemExit("Output parent must already exist.")
    report = inventory(Path(args.root))
    with out.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
    print("INVENTORY_COMPLETE", out)
    print(json.dumps({k: report[k] for k in ("scanned_files", "scan_complete", "seconds")}, ensure_ascii=False))
    print("No model training; no source files changed. Download this JSON report.")


if __name__ == "__main__":
    main()
