from __future__ import annotations

import math
import unittest

import numpy as np

from count_time import features
from helpers import multi_student_data, small_data


class CountFeatureTests(unittest.TestCase):
    def setUp(self):
        self.arrays = small_data()

    def test_selected_ids_and_event_identity(self):
        got = features.construct(self.arrays, {0})
        np.testing.assert_array_equal(got["record_idx"], [0, 1, 2, 3, 4, 6])
        np.testing.assert_array_equal(got["student"], [0, 0, 0, 0, 0, 1])
        np.testing.assert_array_equal(got["kc"], [0, 1, 0, 0, 0, 0])
        np.testing.assert_array_equal(got["split"], [0, 0, 0, 1, 1, 0])

    def test_hand_calculation_and_same_timestamp(self):
        got = features.construct(self.arrays, {0})
        first_hour = math.exp(-math.log(2) / 168)
        np.testing.assert_allclose(got["states"]["A_none"][0], [0, 0, 1, 1, 2, 0])
        np.testing.assert_allclose(got["states"]["A_none"][1], [0, 0, 0, 1, 1, 0])
        np.testing.assert_allclose(got["states"]["B_fixed"][0], [0, 0, .8, .64, 1.312, 0])
        np.testing.assert_allclose(got["states"]["B_fixed"][1], [0, 0, 0, .8, .64, 0])
        np.testing.assert_allclose(got["states"]["C_real_time"][0],
                                   [0, 0, first_hour, first_hour, (first_hour + 1) / 2, 0])
        np.testing.assert_allclose(got["states"]["C_real_time"][1], [0, 0, 0, 1, .5, 0])
        self.assertTrue(np.isnan(got["gap_hours"][0]))
        self.assertEqual(got["gap_hours"][3], 0)
        self.assertEqual(got["gap_hours"][4], 168)

    def test_future_and_forbidden_labels_cannot_leak(self):
        original = features.construct(self.arrays, {0})
        changed = {key: value.copy() for key, value in self.arrays.items()}
        changed["label"][[5, 7, 8]] = -1
        other = features.construct(changed, {0})
        for mode in original["states"]:
            for x, y in zip(original["states"][mode], other["states"][mode]):
                np.testing.assert_array_equal(x, y)
        changed["label"][3] = 0
        other = features.construct(changed, {0})
        for mode in original["states"]:
            for x, y in zip(original["states"][mode], other["states"][mode]):
                np.testing.assert_array_equal(x[:4], y[:4])
        self.assertNotEqual(original["states"]["B_fixed"][0][4],
                            other["states"]["B_fixed"][0][4])

    def test_invalid_input_is_rejected(self):
        for field, index, value in [("label", 0, -1), ("timestamp", 2, -1),
                                     ("timestamp", 2, np.nan), ("split", 1, 1)]:
            changed = {key: value0.copy() for key, value0 in self.arrays.items()}
            changed[field][index] = value
            with self.subTest(field=field, value=value), self.assertRaises(ValueError):
                features.construct(changed, {0})
        changed = {key: value.copy() for key, value in self.arrays.items()}
        changed["item_q"][0] = [1, 1]
        with self.assertRaises(ValueError):
            features.construct(changed, {0})
        with self.assertRaises(ValueError):
            features.construct(self.arrays, {0}, fixed_discount=1.1)
        with self.assertRaises(ValueError):
            features.construct(self.arrays, {0}, half_life_hours=0)

    def test_against_quadratic_oracle_and_legacy_counts(self):
        arrays = multi_student_data()
        got = features.construct(arrays, {0, 1, 2})
        self.assertTrue(features.check_legacy_counts(got)["match"])
        for i in range(len(got["record_idx"])):
            previous = [j for j in range(i) if got["student"][j] == got["student"][i]
                        and got["kc"][j] == got["kc"][i]]
            for mode in got["states"]:
                expected = [0.0, 0.0]
                for position, j in enumerate(previous):
                    if mode == "A_none": weight = 1.0
                    elif mode == "B_fixed": weight = .8 ** (len(previous) - position)
                    else: weight = 2 ** (-(got["timestamp"][i] - got["timestamp"][j]) / 3600 / 168)
                    expected[int(1 - got["label"][j])] += weight
                for observed, reference in zip(got["states"][mode], expected):
                    self.assertAlmostEqual(float(observed[i]), reference, places=10)

    def test_no_shared_features_mutation(self):
        got = features.construct(self.arrays, {0})
        self.assertFalse(np.shares_memory(got["states"]["A_none"][0], got["states"]["B_fixed"][0]))
        self.assertTrue(all(np.isfinite(v).all() for pair in got["states"].values() for v in pair))
