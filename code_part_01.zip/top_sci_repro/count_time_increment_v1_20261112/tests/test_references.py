from __future__ import annotations

import csv
import gzip
import hashlib
import io
import tempfile
import unittest
import zipfile
from pathlib import Path

import numpy as np

from count_time import features, references
from helpers import multi_student_data


class ReferenceTests(unittest.TestCase):
    def test_reference_identity_and_hash_locked(self):
        data = features.construct(multi_student_data(), {0, 1, 2, 3, 4})
        idx = np.flatnonzero(data["split"] == 1)
        with tempfile.TemporaryDirectory() as temp:
            archive = Path(temp) / "reference.zip"
            output = io.StringIO(newline="")
            writer = csv.writer(output)
            writer.writerow(["record_idx", "student_idx", "label", "probability"])
            for i in idx:
                writer.writerow([data["record_idx"][i], data["student"][i], data["label"][i], .6])
            with zipfile.ZipFile(archive, "w") as bundle:
                bundle.writestr("dev.csv.gz", gzip.compress(output.getvalue().encode()))
            digest = hashlib.sha256(archive.read_bytes()).hexdigest()
            result = references.validate_reference(data, archive, "dev.csv.gz", digest)
            np.testing.assert_array_equal(result["probability"], np.full(len(idx), .6))
            with self.assertRaises(ValueError):
                references.validate_reference(data, archive, "dev.csv.gz", "0" * 64)
            altered = dict(data)
            altered["label"] = data["label"].copy()
            altered["label"][idx[0]] = 1 - altered["label"][idx[0]]
            with self.assertRaises(ValueError):
                references.validate_reference(altered, archive, "dev.csv.gz", digest)
