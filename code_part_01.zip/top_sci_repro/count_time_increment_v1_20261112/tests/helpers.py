from __future__ import annotations

import numpy as np


def small_data():
    return {
        "student_idx": np.array([0, 0, 0, 0, 0, 0, 1, 1, 1], dtype=np.int64),
        "item_idx": np.array([0, 1, 0, 0, 0, 0, 0, 0, 0], dtype=np.int64),
        "label": np.array([1, 1, 0, 1, 0, 1, 1, 0, 1], dtype=np.float32),
        "split": np.array([0, 0, 0, 1, 1, 2, 0, 1, 2], dtype=np.int8),
        "timestamp": np.array([0, 3600, 3600, 3600, 608400, 610000, 0, 7200, 7500], dtype=np.float64),
        "item_q": np.array([[1, 0], [0, 1]], dtype=np.int8),
    }


def multi_student_data():
    rows = []
    for student in range(5):
        for step in range(12):
            rows.append((student, step % 2, (student + step) % 2,
                         0 if step < 8 else (1 if step < 11 else 2),
                         float(step * 3600)))
    return {
        "student_idx": np.array([r[0] for r in rows], dtype=np.int64),
        "item_idx": np.array([r[1] for r in rows], dtype=np.int64),
        "label": np.array([r[2] for r in rows], dtype=np.float32),
        "split": np.array([r[3] for r in rows], dtype=np.int8),
        "timestamp": np.array([r[4] for r in rows], dtype=np.float64),
        "item_q": np.array([[1, 0], [0, 1]], dtype=np.int8),
    }
