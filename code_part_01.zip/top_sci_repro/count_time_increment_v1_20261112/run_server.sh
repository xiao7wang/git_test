#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_count_time_01}"
[[ "$NAME" =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'Invalid output name' >&2; exit 2; }
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
OUT="$DIR/outputs/$NAME"
LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]]; then
  echo "Existing run or log is preserved: $OUT / $LOG" >&2
  exit 2
fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
export PYTHONPATH="$DIR/src${PYTHONPATH:+:$PYTHONPATH}"
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
echo "Launcher log: $LOG"
echo 'Verifying release and synthetic tests; no production training has started.'
"$PY" -B -m count_time.server --verify-only
"$PY" -B "$DIR/checks/verify.py" --strict
"$PY" -B -u -m count_time.server --project-dir "$PROJECT" --data-dir "$DATA" \
  --reference-dir "$DIR/references" --output-dir "$OUT" --device cuda \
  --ack-row-feedback --ack-time-proxy
echo "SUCCESS: $OUT/count_time_increment_results.zip"
