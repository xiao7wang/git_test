# UCTP mechanism diagnostic — fix02

Independent diagnostic package. No training model edits, optimizers, test-set evaluation or old-result overwrites.

Start with `SERVER_GUIDE.md`. `run_server.sh` runs the original-server suite sequentially in the yydw interpreter: CPU/GPU tests → EDNet record 1562284 regression → both 32-user preflights → chunk-17 checks → both full validation diagnostics → accepted results ZIP. Any failed job stops the suite. GPU defaults to 0, respecting an explicitly set CUDA_VISIBLE_DEVICES.

## What changed

- Capture raw float32 P/N, not just rounded `1+P,1+N`.
- Independently replay each selected window from that raw snapshot, with the original companion batch shape. Predict first; then independently apply feedback. Never copy original probabilities.
- Maintain another float64 accumulator and frozen float64 head in that original batch context, independent of the six branches.
- Use original-context float32 write increments, consumed only AFTER the current prediction, for all six independent float64 branches. This removes a second avoidable source of numerical difference: recomputing the write MLP at a different branch batch size.
- Gate original float32 probabilities at the same `1e-6`, original P/N before/after EXACTLY, independent float64 NONE reconstruction at `1e-6` and state at `1e-12`, plus all prior mathematical equivalences.
- Retain the old cast-of-promoted-state discrepancy as an explicit audit; it is not renamed a passing original-path check. fix01 results are not retroactively accepted.

This is protocol `raw_pn_reference_and_independent_float64_v2`. Write increments use the same learned model and formula but the original replay batch context; tiny rounding changes from fix01 are possible. Compare all methods under fix02, not a mixture of fix01 and fix02 scores.

## Scope and limitations

The original source/checkpoint/data fingerprints remain enforced. Single-KC, state-independent writing and single-anchor intervention remain required. Row-immediate feedback and event-time proxy assumptions remain unverified. All metric comparisons use independent float64 readouts of frozen parameters, not retrained float64 models or original float32 test metrics. The equivalence of mass scaling and proportional write rescaling is not evidence of novelty or educational efficacy.

Read-only legacy `inspect_precision.py` is retained for historical numerical analysis, not used by the fix02 acceptance suite. Use `run_suite.py --regression-only` for the new targeted regression.
