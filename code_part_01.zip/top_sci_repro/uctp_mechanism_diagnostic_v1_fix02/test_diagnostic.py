"""Synthetic unit/integration tests; no model training and no server data needed."""
import argparse
import contextlib
import io
import json
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
import numpy as np
import pandas as pd
import torch
from run_diagnostic import import_project, check_reference, parser, save, ROOT
from mechanism_core import (MODES, interventions, plan_windows, snapshot_model_class,
    replay_reference, branch_predictions, check_invariants, parameter_digest, bootstrap_pairs,
    precision_model_copy, precision_audit, PRECISION_PROTOCOL)

PROJECT = None
DEVICE = torch.device("cpu")


def fixture():
    # student, item, label, elapsed hours, split (test deliberately included).
    rows = [(0,0,1,0,0),(0,0,1,1,0),(0,1,0,2,0),
            (0,0,0,200,1),(0,1,1,201,1),(0,2,1,202,1),
            (0,0,0,203,1),(0,2,1,204,1),(0,0,1,205,1),(0,2,1,206,1),(0,0,0,300,2),
            (1,1,1,0,0),(1,1,0,1,0),(1,1,1,400,1),(1,1,0,400,1),(1,1,1,401,1),(1,1,0,600,2)]
    a = np.asarray(rows)
    x = {"student_idx": a[:,0].astype(np.int32), "item_idx": a[:,1].astype(np.int32),
         "label": a[:,2].astype(np.float32), "timestamp": (1700000000+a[:,3]*3600).astype(np.float64),
         "split": a[:,4].astype(np.int32), "user_offsets": np.array([0,11,17]),
         "item_q": np.array([[1,0],[0,1],[1,0]], bool)}
    for k in ("delta_t_hours", "delta_t_k_hours", "kc_count_before", "student_count_before"):
        x[k] = np.zeros(len(a), np.float32)
    x.update(source_row=np.arange(len(a)), response_time=np.ones(len(a)), rt_valid=np.ones(len(a), bool))
    return x


class DiagnosticTests(unittest.TestCase):
    def setUp(self):
        self.Data, self.Temporal, self.metrics, set_seed, _ = import_project(PROJECT)
        set_seed(9)
        self.data = self.Data.__new__(self.Data)
        self.data.arrays = fixture()
        self.users = np.array([0,1])
        self.plan = plan_windows(self.data.arrays, self.users)

    def make_model(self, variant="unit_write"):
        m = snapshot_model_class(self.Temporal)(2,3,2, variant=variant, ncd_hidden_dim=8,
                                               time_mode="none", decay_rate_per_hour=0).to(DEVICE)
        m.eval().requires_grad_(False)
        return m

    def run_fixture(self, variant="unit_write", batch=2, chunk=100):
        m = self.make_model(variant)
        ref, ab = replay_reference(m, self.data, self.users, self.plan, DEVICE, batch, chunk)
        frame = branch_predictions(m, self.data.arrays, self.plan, ab, DEVICE)
        return m, ref, ab, frame

    def test_hand_calculated_four_interventions_and_scales(self):
        values, scales = interventions(np.array([[9.,1.]]), np.array([2.]), 1.)
        np.testing.assert_allclose(values[0,:4], [[9,1],[3.6,.4],[7.5,2.5],[3,1]])
        np.testing.assert_allclose(scales[0], [1,1,1,1,2.5,2.5])

    def test_zero_gap_identity(self):
        ab = np.array([[9.,1.],[2.,4.]])
        values, scales = interventions(ab, np.zeros(2), 168)
        for j in range(len(MODES)):
            np.testing.assert_allclose(values[:,j], ab)
        np.testing.assert_array_equal(scales, 1.)

    def test_large_gap_mass_not_clamped(self):
        values, _ = interventions(np.array([[999.,1.]]), np.array([1e9]), 168)
        self.assertAlmostEqual(values[0,1].sum(), 2)
        self.assertLess(values[0,1,1], 1)
        self.assertAlmostEqual(values[0,1,0]/values[0,1].sum(), .999)

    def test_invalid_intervention_inputs(self):
        for rate in (0,-1,float("inf"),float("nan")):
            with self.assertRaises(ValueError):
                interventions(np.array([[2.,1.]]), np.array([200.]), rate)
        with self.assertRaises(ValueError):
            interventions(np.array([[2.,1.]]), np.array([-1.]), 168.)

    def test_anchor_ids_real_kc_history(self):
        np.testing.assert_array_equal(self.plan["anchor"], [3,4,13])
        np.testing.assert_allclose(self.plan["gap_hours"], [199,199,399])
        np.testing.assert_array_equal(self.plan["prior_count"], [2,1,2])

    def test_same_kc_paths_skip_other_kcs_not_feedback(self):
        np.testing.assert_array_equal(self.plan["paths"][0], [3,5,6,7,8,9])

    def test_tied_next_kc_stops_window_not_skipped(self):
        np.testing.assert_array_equal(self.plan["paths"][2], [13,-1,-1,-1,-1,-1])
        self.assertTrue(self.plan["anchor_tied"][2])

    def test_first_kc_is_not_a_long_gap(self):
        x = fixture()
        x["timestamp"][2] = x["timestamp"][0]+180*3600
        plan = plan_windows(x, self.users)
        self.assertNotIn(2, plan["anchor"])
        self.assertNotIn(4, plan["anchor"])

    def test_exact_gap_boundary_not_eligible(self):
        x = fixture()
        x["timestamp"][3] = x["timestamp"][1]+168*3600
        self.assertNotIn(3, plan_windows(x, self.users)["anchor"])

    def test_multi_kc_rejected(self):
        x = fixture()
        x["item_q"][0] = True
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)

    def test_float32_and_backward_time_rejected(self):
        x = fixture()
        x["timestamp"] = x["timestamp"].astype(np.float32)
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)
        x = fixture()
        x["timestamp"][1] = x["timestamp"][0]-1
        with self.assertRaises(ValueError):
            plan_windows(x, self.users)

    def test_test_events_not_used_even_when_poisoned(self):
        x = fixture()
        test = x["split"] == 2
        x["timestamp"][test] = np.nan
        x["label"][test] = np.nan
        plan = plan_windows(x, self.users)
        np.testing.assert_array_equal(plan["paths"], self.plan["paths"])
        self.data.arrays = x
        self.run_fixture()

    def test_original_forward_predictions_not_changed(self):
        from src.engine import evaluate
        m, ref, _, _ = self.run_fixture("dynamic_only")
        original = self.Temporal(2,3,2,variant="dynamic_only",ncd_hidden_dim=8,time_mode="none").to(DEVICE)
        original.load_state_dict(m.state_dict())
        _, expected, _ = evaluate(original,self.data,DEVICE,"valid",2,100,True)
        for key in ("record_idx", "probability", "uncertainty", "evidence"):
            np.testing.assert_array_equal(ref[key], expected[key])

    def test_snapshot_and_branch_none_match_both_writing_rules(self):
        for variant in ("dynamic_only", "unit_write"):
            with self.subTest(variant=variant):
                _, ref, _, frame = self.run_fixture(variant)
                report = check_invariants(frame, ref)
                self.assertTrue(report["success"], report)

    def test_chunk_size_does_not_change_snapshots_or_predictions(self):
        m = self.make_model("dynamic_only")
        a, ab1 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,1)
        b, ab2 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,17)
        pd.testing.assert_frame_equal(a,b)
        np.testing.assert_array_equal(ab1,ab2)

    def test_student_batch_size_invariant(self):
        m = self.make_model("dynamic_only")
        a, ab1 = replay_reference(m,self.data,self.users,self.plan,DEVICE,1,17)
        b, ab2 = replay_reference(m,self.data,self.users,self.plan,DEVICE,2,17)
        np.testing.assert_allclose(a.probability,b.probability,rtol=0,atol=1e-6)
        np.testing.assert_allclose(ab1,ab2,rtol=0,atol=1e-6)

    def test_branch_batch_size_invariant(self):
        m, _, ab, a = self.run_fixture("dynamic_only")
        b = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,batch_size=1)
        for mode in MODES:
            np.testing.assert_allclose(a[f"{mode}_probability"],b[f"{mode}_probability"],rtol=0,atol=1e-6)

    def test_selected_users_keep_original_batch_but_exclude_companion_outputs(self):
        m, full, _, _ = self.run_fixture("dynamic_only")
        users = np.array([0])
        plan = plan_windows(self.data.arrays,users)
        selected, _ = replay_reference(m,self.data,users,plan,DEVICE,2,100)
        expected = full.loc[full.record_idx < 11].reset_index(drop=True)
        pd.testing.assert_frame_equal(selected,expected)

    def test_current_response_does_not_enter_current_prediction(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        self.data.arrays["label"][3] = 1-self.data.arrays["label"][3]
        new = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        ix = (old.anchor_record_idx == 3) & (old.horizon == 0)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[ix,f"{mode}_probability"],new.loc[ix,f"{mode}_probability"])
        self.assertNotEqual(float(old.loc[ix,"mass_mean_after"].iloc[0]),float(new.loc[ix,"mass_mean_after"].iloc[0]))

    def test_future_response_does_not_enter_earlier_predictions(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        self.data.arrays["label"][7] = 1-self.data.arrays["label"][7]
        new = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        ix = (old.anchor_record_idx == 3) & (old.horizon <= 3)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[ix,f"{mode}_probability"],new.loc[ix,f"{mode}_probability"])

    def test_future_window_change_does_not_change_anchor_forecast(self):
        m, _, ab, old = self.run_fixture()
        plan = {k: v.copy() for k,v in self.plan.items()}
        plan["paths"][:,1:] = -1
        new = branch_predictions(m,self.data.arrays,plan,ab,DEVICE)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[old.horizon==0,f"{mode}_probability"],new[f"{mode}_probability"])

    def test_parameters_and_snapshot_inputs_immutable(self):
        m = self.make_model("dynamic_only")
        before = parameter_digest(m)
        _, ab = replay_reference(m,self.data,self.users,self.plan,DEVICE)
        original = ab.copy()
        branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE)
        np.testing.assert_array_equal(ab,original)
        self.assertEqual(before,parameter_digest(m))
        self.assertTrue(all(p.grad is None and not p.requires_grad for p in m.parameters()))

    def test_independent_anchors_not_contaminated_by_other_branches(self):
        m, _, ab, old = self.run_fixture("dynamic_only")
        take = np.array([1,2])
        plan = {k: (v[take] if k != "validation_records" else v) for k,v in self.plan.items()}
        new = branch_predictions(m,self.data.arrays,plan,ab[take],DEVICE)
        for mode in MODES:
            np.testing.assert_array_equal(old.loc[old.anchor_record_idx!=3,f"{mode}_probability"],new[f"{mode}_probability"])

    def test_invariants_detect_probability_corruption(self):
        _, ref, _, f = self.run_fixture()
        f.loc[0,"write_rescale_probability"] = np.float32(float(f.loc[0,"write_rescale_probability"])+.01)
        self.assertFalse(check_invariants(f,ref)["success"])

    def test_reference_identity_guard(self):
        _, ref, _, _ = self.run_fixture()
        ids = ref.record_idx.to_numpy()
        old = ref.copy()
        for k in ("student_idx","item_idx","label","split","timestamp"):
            old[k] = self.data.arrays[k][ids]
        self.assertTrue(check_reference(ref,old,self.data.arrays,ids,1e-6)["success"])
        old.loc[0,"label"] = 1-old.loc[0,"label"]
        with self.assertRaises(AssertionError):
            check_reference(ref,old,self.data.arrays,ids,1e-6)

    def test_bootstrap_identical_predictions_zero(self):
        _, _, _, f = self.run_fixture()
        for mode in MODES:
            f[f"{mode}_probability"] = .5
        for result in bootstrap_pairs(f,100):
            self.assertEqual(result["delta_nll"],0)
            self.assertEqual(result["ci95"],[0,0])

    def test_csv_short_decimal_roundtrip_is_compared_in_original_precision(self):
        _, ref, _, _ = self.run_fixture()
        ids = ref.record_idx.to_numpy()
        ref["evidence"] = np.float32(12345.678)
        old = pd.read_csv(io.StringIO(ref.to_csv(index=False)))
        for k in ("student_idx","item_idx","label","split","timestamp"):
            old[k] = self.data.arrays[k][ids]
        report = check_reference(ref,old,self.data.arrays,ids,1e-6)
        self.assertTrue(report["success"])
        self.assertGreater(report["raw_float64_vs_csv_decimal_difference"]["evidence"],1e-6)

    def test_no_test_view_option(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            parser().parse_args(["--project-dir","x","--checkpoint","x","--data-dir","x","--output-dir","x","--view","test"])

    def test_empty_anchor_subset_supported(self):
        self.data.arrays["timestamp"] = 1700000000 + np.arange(len(self.data.arrays["label"]),dtype=np.float64)
        plan = plan_windows(self.data.arrays,self.users)
        self.assertEqual(len(plan["anchor"]),0)
        m = self.make_model()
        ref, ab = replay_reference(m,self.data,self.users,plan,DEVICE)
        f = branch_predictions(m,self.data.arrays,plan,ab,DEVICE)
        self.assertTrue(f.empty)
        self.assertTrue(check_invariants(f,ref)["success"])

    def precise_fixture(self, variant="dynamic_only"):
        m, ref, ab, raw = self.run_fixture(variant)
        precise = precision_model_copy(m)
        frame = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,precision_model=precise)
        return m, precise, ref, ab, raw, frame

    def test_precision_copy_preserves_original_parameters_and_frozen_values(self):
        m = self.make_model("dynamic_only")
        before = parameter_digest(m)
        precise = precision_model_copy(m)
        self.assertEqual(before,parameter_digest(m))
        self.assertIsNot(m,precise)
        for name,value in m.state_dict().items():
            self.assertEqual(value.dtype,torch.float32)
            self.assertEqual(precise.state_dict()[name].dtype,torch.float64)
            self.assertTrue(torch.equal(value.double(),precise.state_dict()[name]))
        self.assertFalse(precise.training)
        self.assertTrue(all(not p.requires_grad for p in precise.parameters()))

    def test_precision_copy_rejects_trainable_or_training_model(self):
        m = self.make_model()
        m.train()
        with self.assertRaises(ValueError):
            precision_model_copy(m)
        m.eval().requires_grad_(True)
        with self.assertRaises(ValueError):
            precision_model_copy(m)

    def test_precision_protocol_passes_both_writing_rules(self):
        for variant in ("dynamic_only","unit_write"):
            with self.subTest(variant=variant):
                _,_,ref,_,_,f = self.precise_fixture(variant)
                report = check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)
                self.assertTrue(report["success"],report)
                self.assertEqual(report["atol"],1e-6)
                self.assertEqual(report["state_atol"],1e-12)

    def test_original_float32_branch_values_and_writes_remain_exact(self):
        _,_,_,_,raw,f = self.precise_fixture()
        for mode in MODES:
            np.testing.assert_array_equal(raw[f"{mode}_probability"],f[f"{mode}_probability_float32"])
            self.assertEqual(f[f"{mode}_probability"].dtype,np.dtype("float64"))
            self.assertEqual(f[f"{mode}_probability_float32"].dtype,np.dtype("float32"))
            for field in ("mean_before","mean_after","support_before","support_after","write_gain"):
                np.testing.assert_array_equal(raw[f"{mode}_{field}"],f[f"{mode}_{field}"])

    def test_each_precision_branch_calls_head_on_own_state(self):
        m,_,ab,_ = self.run_fixture()
        precise = precision_model_copy(m)
        calls = []
        original = precise.predict_from_beta
        def traced(alpha,beta,student,item,q):
            self.assertEqual(alpha.dtype,torch.float64)
            self.assertEqual(beta.dtype,torch.float64)
            calls.append((alpha.clone(),beta.clone()))
            return original(alpha,beta,student,item,q)
        precise.predict_from_beta = traced
        f = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,precision_model=precise)
        self.assertEqual(len(calls),len(MODES)*len(f.horizon.unique()))
        self.assertFalse(torch.equal(calls[0][0],calls[1][0]))
        self.assertTrue(torch.equal(calls[0][0],calls[4][0]))

    def test_precision_detects_independent_control_probability_corruption(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f.loc[0,"write_rescale_probability"] = float(f.loc[0,"write_rescale_probability"])+.01
        r = check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)
        self.assertFalse(r["success"])
        self.assertFalse(r["gates"]["independent_float64_probability_equivalence"])

    def test_precision_detects_state_corruption_even_if_probabilities_match(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f.loc[0,"write_rescale_mean_after"] = float(f.loc[0,"write_rescale_mean_after"])+.001
        r = check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)
        self.assertFalse(r["success"])
        self.assertFalse(r["gates"]["float64_state_and_gain_equivalence"])

    def test_none_float32_reference_gate_is_not_relaxed(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f.loc[0,"none_probability_float32"] = np.float32(float(f.loc[0,"none_probability_float32"])+.001)
        r = check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)
        self.assertFalse(r["success"])
        self.assertFalse(r["gates"]["none_float32_matches_original_window"])
        self.assertEqual(r["atol"],1e-6)

    def test_float32_equivalence_warning_is_visible_not_relabelled_passed(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f.loc[0,"write_rescale_probability_float32"] = np.float32(float(f.loc[0,"write_rescale_probability_float32"])+.001)
        audit = precision_audit(f,ref)
        self.assertFalse(audit["float32_equivalence_within_original_atol"])
        self.assertGreater(audit["float64_vs_float32_by_mode"]["write_rescale"]["rows_gt_original_atol"],0)
        self.assertTrue(check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)["success"])

    def test_nonfinite_precision_values_fail_gate(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f.loc[0,"none_support_after"] = np.nan
        self.assertFalse(check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)["success"])

    def test_server_near_one_scaled_pairs_float64_regression(self):
        m = self.make_model("dynamic_only")
        precise = precision_model_copy(m)
        pair = np.array([14802.99193503768,1.],np.float64)
        r = 377.5203327159716/pair.sum()
        states = np.stack((pair*r,pair))
        q = torch.tensor([[1.,0.],[1.,0.]],device=DEVICE)
        ids = torch.zeros(2,dtype=torch.long,device=DEVICE)
        with torch.no_grad():
            for dtype,model in ((torch.float32,m),(torch.float64,precise)):
                vals = torch.tensor(states,dtype=dtype,device=DEVICE)
                mask = q.to(dtype)
                alpha = torch.where(mask>0,vals[:,0,None],torch.ones_like(mask))
                beta = torch.where(mask>0,vals[:,1,None],torch.ones_like(mask))
                means = alpha[:,0]/(alpha[:,0]+beta[:,0])
                probability = model.predict_from_beta(alpha,beta,ids,ids,mask)["probability"]
                if dtype == torch.float64:
                    self.assertLessEqual(abs(float(means[0]-means[1])),1e-15)
                    self.assertLessEqual(abs(float(probability[0]-probability[1])),1e-10)
                else:
                    # Confirm this stress input exercises rounding, not just small ordinary states.
                    self.assertGreater(abs(float(means[0]-means[1])),0)

    def test_large_support_near_zero_and_one_all_horizons(self):
        m = self.make_model("dynamic_only")
        precise = precision_model_copy(m)
        ab = np.array([[14802.99193503768,1.],[1e6,1.],[1.,1e6]],np.float64)
        plan = {k:v.copy() for k,v in self.plan.items()}
        plan["gap_hours"] = np.array([890.,3000.,3000.])
        f = branch_predictions(m,self.data.arrays,plan,ab,DEVICE,precision_model=precise)
        # The synthetic NONE reference has the identical supplied synthetic state.
        ref = f[["record_idx","none_probability_float32"]].rename(columns={"none_probability_float32":"probability"})
        r = check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)
        self.assertTrue(r["success"],r)
        self.assertGreater(f.mass_mean_before.max(),.9999)
        self.assertLess(f.mass_mean_before.min(),.0001)
        self.assertEqual(f.horizon.max(),5)

    def test_precision_current_and_future_response_causality(self):
        m,precise,_,ab,_,old = self.precise_fixture()
        labels = self.data.arrays["label"]
        original = labels.copy()
        for record,max_h in ((3,0),(7,3)):
            labels[:] = original
            labels[record] = 1-labels[record]
            new = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,precision_model=precise)
            ix = (old.anchor_record_idx == 3)&(old.horizon <= max_h)
            for mode in MODES:
                np.testing.assert_array_equal(old.loc[ix,f"{mode}_probability"],new.loc[ix,f"{mode}_probability"])

    def test_precision_branch_batch_size_consistency(self):
        m,precise,_,ab,_,a = self.precise_fixture()
        b = branch_predictions(m,self.data.arrays,self.plan,ab,DEVICE,batch_size=1,precision_model=precise)
        for mode in MODES:
            for suffix in ("probability","probability_float32"):
                np.testing.assert_allclose(a[f"{mode}_{suffix}"],b[f"{mode}_{suffix}"],rtol=0,atol=1e-6)

    def test_precision_mode_requires_all_audit_columns(self):
        _,_,ref,_,_,f = self.precise_fixture()
        f = f.drop(columns=["mass_probability_float32"])
        with self.assertRaises(KeyError):
            check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)

    def test_precision_summary_uses_float64_for_all_modes(self):
        from mechanism_core import summarize
        _,_,_,_,_,f = self.precise_fixture()
        seen = []
        def metric(y,probability):
            seen.append(probability.dtype)
            return {}
        summarize(f,metric,repetitions=10)
        self.assertTrue(seen)
        self.assertTrue(all(dtype == np.dtype("float64") for dtype in seen))

    def test_failed_status_does_not_advertise_an_archive(self):
        from show_results import archive_message
        text = archive_message(ROOT,{"status":"failed"})
        self.assertIn("FAILED",text)
        self.assertNotIn("Results archive ready",text)
        self.assertNotIn("diagnostic_results.zip",text)

    def test_complete_status_without_zip_reports_missing(self):
        from show_results import archive_message
        import tempfile
        with tempfile.TemporaryDirectory() as directory:
            text = archive_message(Path(directory),{"status":"complete"})
            self.assertIn("missing",text)
            self.assertNotIn("Results archive ready",text)

    def test_running_status_does_not_advertise_an_archive(self):
        from show_results import archive_message
        self.assertIn("not ready",archive_message(ROOT,{"status":"running"}))

    def test_precision_empty_frame_is_explicitly_unexercised(self):
        r = check_invariants(pd.DataFrame(),pd.DataFrame(),precision_mode=PRECISION_PROTOCOL)
        self.assertTrue(r["success"])
        self.assertEqual(r["n"],0)
        self.assertIn("No anchor",r["note"])

    def native_fixture(self, variant='dynamic_only', chunk=100, users=None):
        from original_replay import join_original_windows
        torch.manual_seed(9)
        m = self.make_model(variant)
        precise = precision_model_copy(m)
        users = self.users if users is None else users
        plan = plan_windows(self.data.arrays,users)
        ref,ab = replay_reference(m,self.data,users,plan,DEVICE,2,chunk,window_precision_model=precise)
        trace = m.original_window_frame
        f = branch_predictions(m,self.data.arrays,plan,ab,DEVICE,precision_model=precise,write_tape=trace)
        return m,precise,plan,ref,ab,join_original_windows(f,trace)

    def test_fix02_both_writing_rules_and_exact_raw_states(self):
        from mechanism_core import check_fix02_invariants
        for variant in ('dynamic_only','unit_write'):
            m,_,_,ref,ab,f = self.native_fixture(variant)
            r = check_fix02_invariants(f,ref)
            self.assertTrue(r['success'],r)
            self.assertEqual(r['atol'],1e-6)
            self.assertEqual(r['state_atol'],1e-12)
            np.testing.assert_array_equal(1+m.raw_anchor_pn,ab)
            self.assertTrue(r['gates']['original_raw_pn_before_and_after_exact'])

    def test_fix02_raw_probability_corruption_fails(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        f.loc[0,'original_probability_float32'] += .001
        r = check_fix02_invariants(f,ref)
        self.assertFalse(r['success'])
        self.assertFalse(r['gates']['original_float32_window_probability'])

    def test_fix02_raw_state_corruption_cannot_hide_behind_same_probability(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        f.loc[0,'original_after_positive'] += 1e-8
        r = check_fix02_invariants(f,ref)
        self.assertFalse(r['success'])
        self.assertFalse(r['gates']['original_raw_pn_before_and_after_exact'])

    def test_fix02_independent_float64_probability_corruption_fails(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        f.loc[0,'reconstructed_probability_float64'] += .001
        self.assertFalse(check_fix02_invariants(f,ref)['success'])

    def test_fix02_independent_float64_state_corruption_fails(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        f.loc[0,'reconstructed_support_after'] += .001
        self.assertFalse(check_fix02_invariants(f,ref)['success'])

    def test_fix02_cast_discrepancy_is_disclosed_not_fake_pass(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        f.loc[0,'none_probability_float32'] = np.float32(float(f.loc[0,'none_probability_float32'])+.001)
        r=check_fix02_invariants(f,ref)
        self.assertTrue(r['success'])
        self.assertFalse(r['legacy_promoted_state_float32_cast_audit']['within_original_atol'])
        self.assertFalse(r['legacy_promoted_state_float32_cast_audit']['used_for_acceptance'])
        self.assertFalse(check_invariants(f,ref,precision_mode=PRECISION_PROTOCOL)['success'])

    def test_fix02_cannot_relax_tolerance(self):
        from mechanism_core import check_fix02_invariants
        with self.assertRaises(ValueError):
            check_fix02_invariants(pd.DataFrame(),pd.DataFrame(),1.01e-6)

    def test_fix02_missing_native_trace_rejected(self):
        from mechanism_core import check_fix02_invariants
        _,_,_,ref,_,f = self.native_fixture()
        with self.assertRaises((KeyError,AttributeError)):
            check_fix02_invariants(f.drop(columns=['original_probability_float32']),ref)

    def test_fix02_chunk17_and_one_are_exact(self):
        *_,a = self.native_fixture(chunk=1)
        *_,b = self.native_fixture(chunk=17)
        pd.testing.assert_frame_equal(a,b)

    def test_fix02_subset_keeps_companion_batch(self):
        *_,a = self.native_fixture()
        *_,b = self.native_fixture(users=np.array([0]))
        pd.testing.assert_frame_equal(a.loc[a.student_idx==0].reset_index(drop=True),b)

    def test_fix02_branch_batch_uses_same_original_write_tape(self):
        from mechanism_core import check_fix02_invariants
        from original_replay import join_original_windows
        m,precise,plan,ref,ab,f = self.native_fixture()
        small=branch_predictions(m,self.data.arrays,plan,ab,DEVICE,batch_size=1,
                                  precision_model=precise,write_tape=m.original_window_frame)
        self.assertTrue(check_fix02_invariants(join_original_windows(small,m.original_window_frame),ref)['success'])
        for mode in MODES:
            np.testing.assert_array_equal(small[f'{mode}_support_after'],f[f'{mode}_support_after'])

    def test_fix02_current_label_causality(self):
        *_,before = self.native_fixture()
        self.data.arrays['label'][3]=1-self.data.arrays['label'][3]
        *_,after = self.native_fixture()
        mask=(before.anchor_record_idx==3)&(before.horizon==0)
        for col in ['original_probability_float32','reconstructed_probability_float64']+[f'{m}_probability' for m in MODES]:
            np.testing.assert_array_equal(before.loc[mask,col],after.loc[mask,col])
        self.assertNotEqual(before.loc[mask,'original_after_positive'].iloc[0],after.loc[mask,'original_after_positive'].iloc[0])

    def test_fix02_future_label_causality(self):
        *_,before = self.native_fixture()
        self.data.arrays['label'][7]=1-self.data.arrays['label'][7]
        *_,after = self.native_fixture()
        mask=(before.anchor_record_idx==3)&(before.horizon<=3)
        for col in ['original_probability_float32','reconstructed_probability_float64']+[f'{m}_probability' for m in MODES]:
            np.testing.assert_array_equal(before.loc[mask,col],after.loc[mask,col])

    def test_fix02_test_labels_and_timestamps_unused(self):
        *_,before = self.native_fixture()
        test=self.data.arrays['split']==2
        self.data.arrays['label'][test]=np.nan
        self.data.arrays['timestamp'][test]=np.nan
        *_,after = self.native_fixture()
        pd.testing.assert_frame_equal(before,after)

    def test_fix02_window_identity_corruption_rejected(self):
        from original_replay import join_original_windows
        m,_,_,_,_,f=self.native_fixture()
        trace=m.original_window_frame.copy()
        trace.loc[0,'record_idx'] += 1
        with self.assertRaises(AssertionError):
            join_original_windows(f,trace)

    def test_fix02_duplicate_tape_rejected(self):
        m,precise,plan,_,ab,_=self.native_fixture()
        tape=pd.concat([m.original_window_frame,m.original_window_frame.iloc[:1]])
        with self.assertRaises(ValueError):
            branch_predictions(m,self.data.arrays,plan,ab,DEVICE,precision_model=precise,write_tape=tape)

    def test_fix02_raw_pn_not_recoverable_by_subtracting_one(self):
        raw=np.float32(.19267550110816956)
        recovered=np.float32(np.float32(1)+raw)-np.float32(1)
        self.assertNotEqual(raw,recovered)
        self.assertEqual(float(np.float32(1)+raw),1.1926754713058472)

    def test_fix02_server_1562284_rounding_stress(self):
        # Recorded failure inputs, independent of any checkpoint or GPU model.
        a=torch.tensor(323.9233703613281,dtype=torch.float32,device=DEVICE)
        b=torch.tensor([1.196731448173523,1.1967315673828125],dtype=torch.float32,device=DEVICE)
        means=a/(a+b)
        self.assertGreater(abs(float(means[0]-means[1])),0)
        logits=torch.logit(means)
        self.assertGreater(abs(float(logits[0]-logits[1])),abs(float(means[0]-means[1])))

    def test_fix02_live_shadow_corruption_is_not_overwritten_from_reference(self):
        from unittest.mock import patch
        from original_replay import OriginalWindows
        from mechanism_core import check_fix02_invariants
        original=OriginalWindows.before_feedback
        def corrupt(self,*args,**kwargs):
            for slot in self.slots.values():
                slot['pn'][0] += .125
            return original(self,*args,**kwargs)
        with patch.object(OriginalWindows,'before_feedback',corrupt):
            _,_,_,ref,_,f=self.native_fixture()
        self.assertFalse(check_fix02_invariants(f,ref)['success'])

    def test_fix02_empty_windows_supported(self):
        from mechanism_core import check_fix02_invariants
        self.data.arrays['timestamp']=1700000000+np.arange(len(self.data.arrays['label']),dtype=np.float64)
        _,_,_,ref,_,f=self.native_fixture()
        self.assertTrue(f.empty)
        self.assertTrue(check_fix02_invariants(f,ref)['success'])


def main():
    global PROJECT, DEVICE
    p = argparse.ArgumentParser()
    p.add_argument("--project-dir", required=True)
    p.add_argument("--device", choices=("cpu","cuda"), default="cpu")
    p.add_argument("--report", required=True)
    a = p.parse_args()
    PROJECT, DEVICE = a.project_dir, torch.device(a.device)
    if DEVICE.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    report = Path(a.report).resolve()
    if not report.is_relative_to(ROOT/"outputs") or report.exists():
        raise ValueError("Report must be a NEW file inside package outputs")
    import os
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(4)
    report.parent.mkdir(parents=True, exist_ok=True)
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(DiagnosticTests))
    summary = {"success":result.wasSuccessful(),"tests_run":result.testsRun,"device":str(DEVICE),"torch":str(torch.__version__),
               "failures":[(str(t),e) for t,e in result.failures],"errors":[(str(t),e) for t,e in result.errors],"skipped":result.skipped}
    save(report,summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ("failures","errors")}),flush=True)
    raise SystemExit(0 if result.wasSuccessful() else 1)


if __name__ == "__main__":
    main()
