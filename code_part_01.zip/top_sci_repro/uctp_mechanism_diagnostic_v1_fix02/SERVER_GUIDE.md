# fix02 服务器运行指南

这次只跑诊断和推理，不重新训练 baseline，不加入新模型模块。旧 fix01、server_03 和旧 checkpoint 全部保留。

## 1. 上传与解压

上传 `uctp_mechanism_diagnostic_v1_fix02.zip` 到：

```text
/home/wangxiao/QCCDM/top_sci_repro/
```

在服务器终端执行以下整段。不要复制终端提示符，不要给行尾反斜杠后面加空格。

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
if [ -e uctp_mechanism_diagnostic_v1_fix02 ]; then
  printf '%s\n' 'fix02 目录已存在，请停止，不要覆盖。'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_mechanism_diagnostic_v1_fix02.zip .
fi
```

如果提示目录已存在，先确认是否是之前已解压的同一个包。不要删除它，不要在正在运行的目录中覆盖文件。VS Code 打开 ZIP 显示二进制文件属于正常现象，不需要“仍然打开”。

## 2. 一条命令在 tmux 后台运行全部检查

确认没有同名任务正在运行后，执行：

```bash
tmux new-session -d -s mechanism_fix02 'bash /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/run_server.sh; exec bash'
```

命令返回提示符表示 tmux 已启动，不表示所有检查成功。若提示 duplicate session，不要再建第二份训练/诊断进程，直接进入已有会话。

查看 tmux 中正在做什么：

```bash
tmux attach -t mechanism_fix02
```

暂时离开而不中断程序：先按 `Ctrl+B`，松开，再按 `D`。复制文字用 VS Code 的复制功能或 `Ctrl+Shift+C`；不要按 `Ctrl+C`，它会中断前台程序。断开 SSH 后 tmux 内任务通常会继续，但服务器重启/进程被杀不受 tmux 保护。

脚本使用绝对路径的 yydw Python，所以外部提示符是 `(base)` 也不会误用 base 环境。GPU 默认 0；若需其他 GPU，在新 tmux 会话的启动命令内明确设置 CUDA_VISIBLE_DEVICES。

### 自动执行顺序

1. CPU 单元测试。
2. CUDA 单元测试。
3. EDNet 真正出过问题的 student_idx=7466、record_idx=1562284 定点回归，保留其原始批次同伴；若该记录未被实际检查则报错。
4. ASSIST / EDNet 各 32 学生 preflight。
5. 两数据集 chunk=17 检查；比较 14 列预测（六分支 float64、六分支 float32 审计、原 float32 重放、独立 float64 重建）。
6. ASSIST full / EDNet full 验证集机制诊断。
7. 只有全部通过后生成 `diagnostic_results.zip`。

任何一步失败都会停止后续任务。无需手动依次启动 9 个任务，也不要在旁边重复运行原 fix01。

## 3. 查看进度和结果

在另一个服务器终端执行：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/show_results.py \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/outputs/server_04
```

成功应看到 `Suite status: complete`，9 项作业的 returncode 都为 0，以及真实存在的结果 ZIP。定点回归也算一项作业。保存的 running 状态不是活进程证明。

如果失败，show_results 会给出具体日志路径。不要盲目等待或重跑；对该路径执行 `tail -n 120`，将输出发回。

查看 full 阶段日志的例子（还没开始对应任务时文件可能不存在）：

```bash
tail -n 60 /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/outputs/server_04/ednet_full.log
```

成功后下载并发回：

```text
/home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/outputs/server_04/diagnostic_results.zip
```

不用再次下载原始数据和 checkpoint。不要直接在 Bash 中输入 JSON 文件路径当命令；阅读 JSON 应使用 `cat 路径`。

## 4. 耗时和验收边界

旧 server_03 两项 full 诊断合计约 39 分钟；新版增加独立重放检查，耗时可能增加，不能承诺一定一小时完成。它不是之前耗时一两天的 18 组训练。GPU 占用、CPU 负载、磁盘和数据长度都会影响速度。

本地 CPU 测试不能替代服务器 CUDA 验收。数值审计仍可能显示旧的“float64 累加后转 float32”差异；这不会被伪称为精确相等。应看新的原路径重放、独立 float64 重建以及数学关系 gates 是否全部通过。

## 5. 如只想先做最小服务器验收

不要与上面的全套任务并行启动。若尚未启动全套任务，可以改为：

```bash
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=0 \
/home/wangxiao/miniconda3/envs/yydw/bin/python -B -u \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/run_suite.py \
  --project-dir /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_temporal_v1 \
  --data-root /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_mechanism_diagnostic_v1_fix02/outputs/regression_01 \
  --device cuda --regression-only --ack-row-feedback --ack-time-proxy
```

这只跑 CPU/GPU 测试和 EDNet 定点回归，不是全量验收。正常情况下推荐第 2 节的一键顺序任务，它本来就会先过定点检查才继续。

输出目录已经存在时程序拒绝覆盖。若确需保留旧运行并另启一轮，可以在确认没有旧进程运行后使用新名字，例如 `bash /完整路径/run_server.sh server_05`，不要删除 server_04。
