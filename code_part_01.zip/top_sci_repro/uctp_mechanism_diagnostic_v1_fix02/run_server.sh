#!/usr/bin/env bash
set -euo pipefail

task_python=/home/wangxiao/miniconda3/envs/yydw/bin/python
task_base=/home/wangxiao/QCCDM/top_sci_repro
task_package="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
task_run_name="${1:-server_04}"
if [[ ! "$task_run_name" =~ ^[A-Za-z0-9][A-Za-z0-9_-]*$ ]]; then
  printf '%s\n' 'Invalid run name. Use letters, digits, underscores or hyphens.' >&2
  exit 2
fi
if [[ ! -x "$task_python" ]]; then
  printf '%s\n' "Missing interpreter: $task_python" >&2
  exit 2
fi
if [[ -e "$task_package/outputs/$task_run_name" ]]; then
  printf '%s\n' "Output already exists; preserved: $task_package/outputs/$task_run_name" >&2
  exit 2
fi
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTHONDONTWRITEBYTECODE=1
export CUBLAS_WORKSPACE_CONFIG=:4096:8
exec "$task_python" -B -u "$task_package/run_suite.py" \
  --project-dir "$task_base/uctp_cd_temporal_v1" \
  --data-root "$task_base/uctp_cd_clean_research/data" \
  --output-root "$task_package/outputs/$task_run_name" \
  --device cuda --full --ack-row-feedback --ack-time-proxy
