"""Independent raw-P/N windows in the ORIGINAL replay batch context.

No probability is copied from the historical prediction. Each window is seeded
once from raw float32 P/N, predicts before feedback, then independently observes
feedback. Companion rows keep the original batch shape (no cross-row operations
exist in the pinned model). A separate float64 accumulator/head is also replayed.
"""
import copy
import numpy as np
import pandas as pd
import torch

IDENTITY = ["anchor_record_idx", "horizon", "record_idx"]
PROTOCOL = "raw_pn_reference_and_independent_float64_v2"


class OriginalWindows:
    def __init__(self, plan, precise):
        self.precise = precise
        self.events = {}
        self.slots = {}
        self.rows = []
        self.pending = []
        self.raw_anchors = {}
        for anchor, path in zip(plan["anchor"], plan["paths"]):
            for h, rec in enumerate(path):
                if rec >= 0:
                    self.events.setdefault(int(rec), []).append((int(anchor), h))

    def before_feedback(self, state, student, item, q, ids, predict):
        if self.pending:
            raise AssertionError("Previous prediction has not received feedback")
        tasks = [self.events.get(int(rec), []) for rec in ids]
        for group in range(max(map(len, tasks), default=0)):
            active = [(row, entries[group]) for row, entries in enumerate(tasks) if len(entries) > group]
            shadow = copy.copy(state)
            shadow.evidence = copy.copy(state.evidence)
            shadow.evidence.positive = state.evidence.positive.clone()
            shadow.evidence.negative = state.evidence.negative.clone()
            if shadow.evidence.positive.dtype != torch.float32:
                raise ValueError("Original state must remain float32")
            alpha64 = (1 + state.evidence.positive).double()
            beta64 = (1 + state.evidence.negative).double()
            entries = []
            for row, (anchor, h) in active:
                kc = int(q[row].argmax())
                if q[row].sum() != 1:
                    raise ValueError("Original windows require one-hot active Q")
                original = torch.stack((state.evidence.positive[row,kc], state.evidence.negative[row,kc]))
                if h == 0:
                    if anchor in self.slots:
                        raise AssertionError("Anchor initialized twice")
                    self.slots[anchor] = {"pn": original.clone(), "ab64": (1+original).double(),
                                          "next_h": 0, "student": int(student[row]), "kc": kc}
                    self.raw_anchors[anchor] = original.clone()
                slot = self.slots[anchor]
                if slot['next_h'] != h or slot['student'] != int(student[row]) or slot['kc'] != kc:
                    raise AssertionError("Window identity/order changed")
                shadow.evidence.positive[row,kc], shadow.evidence.negative[row,kc] = slot['pn'].unbind()
                alpha64[row,kc], beta64[row,kc] = slot['ab64'].unbind()
                entries.append((row, kc, anchor, h, int(ids[row]), original.clone(), slot['pn'].clone(), slot['ab64'].clone()))
            # Two independent head evaluations; neither receives a current label.
            pred = predict(shadow, student, item, q)
            pred64 = self.precise.predict_from_beta(alpha64,beta64,student,item,q.double())
            self.pending.append((shadow, pred, entries, pred64, item.clone()))

    def after_feedback(self, q, label, mask, original_after, observe, increment):
        for shadow, pred, entries, pred64, items in self.pending:
            # Same original batch shape/difficulty, independently computed writes.
            inc = increment(q,label,pred['difficulty_scalar'],mask)
            updated = observe(shadow,q,label,pred['difficulty_scalar'],mask)
            for row,kc,anchor,h,rec,ref_before,pn_before,ab_before in entries:
                delta = torch.stack((inc.positive[row,kc],inc.negative[row,kc]))
                pn_after = torch.stack((updated.evidence.positive[row,kc],updated.evidence.negative[row,kc]))
                ref_after = torch.stack((original_after.evidence.positive[row,kc],original_after.evidence.negative[row,kc]))
                ab_after = ab_before + delta.double()
                slot = self.slots[anchor]
                slot.update(pn=pn_after.clone(), ab64=ab_after.clone(), next_h=h+1)
                output = dict(anchor_record_idx=anchor,horizon=h,record_idx=rec,
                    student_idx=slot['student'],item_idx=int(items[row]),
                    original_probability_float32=float(pred['probability'][row]),
                    reconstructed_probability_float64=float(pred64['probability'][row]),
                    reconstructed_mean_before=float(ab_before[0]/ab_before.sum()),
                    reconstructed_support_before=float(ab_before.sum()),
                    reconstructed_mean_after=float(ab_after[0]/ab_after.sum()),
                    reconstructed_support_after=float(ab_after.sum()),
                    increment_positive=float(delta[0]),increment_negative=float(delta[1]))
                for name, values in (('original_before',pn_before),('original_after',pn_after),
                                     ('reference_before',ref_before),('reference_after',ref_after)):
                    for j, part in enumerate(('positive','negative')):
                        output[f'{name}_{part}'] = float(values[j])
                self.rows.append(output)
        self.pending = []

    def finish(self, plan):
        expected = sorted((int(a),h,int(r)) for a,path in zip(plan['anchor'],plan['paths'])
                          for h,r in enumerate(path) if r>=0)
        frame = pd.DataFrame(self.rows)
        if not expected:
            return pd.DataFrame(columns=IDENTITY), np.empty((0,2),np.float32)
        frame = frame.sort_values(IDENTITY).reset_index(drop=True)
        actual = list(frame[IDENTITY].itertuples(index=False,name=None))
        if actual != expected or self.pending:
            raise AssertionError("Incomplete or duplicate original window replay")
        raw = torch.stack([self.raw_anchors[int(a)] for a in plan['anchor']]).cpu().numpy()
        return frame, raw


def join_original_windows(frame, trace):
    if frame.empty and trace.empty:
        return frame
    if frame[IDENTITY].duplicated().any() or trace[IDENTITY].duplicated().any():
        raise ValueError("Duplicate window identity")
    left, right = frame.sort_values(IDENTITY), trace.sort_values(IDENTITY)
    for col in IDENTITY + ['student_idx','item_idx']:
        np.testing.assert_array_equal(left[col].to_numpy(), right[col].to_numpy())
    return frame.merge(trace.drop(columns=['student_idx','item_idx']),on=IDENTITY,validate='one_to_one',sort=False)


def original_window_checks(frame, reference, atol=1e-6):
    if not np.isfinite(atol) or atol < 0 or atol > 1e-6:
        raise ValueError("Reference tolerance may not exceed 1e-6")
    if reference.record_idx.duplicated().any() or frame[IDENTITY].duplicated().any():
        raise ValueError("Duplicate reference/window identity")
    ref = reference.set_index('record_idx').loc[frame.record_idx,'probability'].to_numpy(dtype=np.float32).astype(float)
    original = frame.original_probability_float32.to_numpy(dtype=np.float32).astype(float)
    errors = {'original_float32_probability': float(np.max(abs(original-ref))),
              'independent_none_float64_probability': float(np.max(abs(frame.none_probability-frame.reconstructed_probability_float64)))}
    for when in ('before','after'):
        for part in ('positive','negative'):
            errors[f'raw_pn_{when}_{part}'] = float(np.max(abs(frame[f'original_{when}_{part}']-frame[f'reference_{when}_{part}'])))
        for field in ('mean','support'):
            errors[f'independent_none_{field}_{when}'] = float(np.max(abs(frame[f'none_{field}_{when}']-frame[f'reconstructed_{field}_{when}'])))
    gates = {'original_float32_window_probability': np.isfinite(errors['original_float32_probability']) and errors['original_float32_probability']<=atol,
             'original_raw_pn_before_and_after_exact': all(np.isfinite(v) and v==0 for k,v in errors.items() if k.startswith('raw_pn_')),
             'independent_none_float64_probability': np.isfinite(errors['independent_none_float64_probability']) and errors['independent_none_float64_probability']<=atol,
             'independent_none_float64_state': all(np.isfinite(v) and v<=1e-12 for k,v in errors.items() if k.startswith(('independent_none_mean','independent_none_support')))}
    valid=True
    for col in ('original_probability_float32','reconstructed_probability_float64',
                'reconstructed_mean_before','reconstructed_mean_after'):
        values=frame[col].to_numpy()
        valid &= bool(np.isfinite(values).all() and ((values>=0)&(values<=1)).all())
    for col in ('increment_positive','increment_negative') + tuple(
            f'{path}_{when}_{part}' for path in ('original','reference')
            for when in ('before','after') for part in ('positive','negative')):
        values=frame[col].to_numpy()
        valid &= bool(np.isfinite(values).all() and (values>=0).all())
    gates['finite_valid_original_window_trace']=valid
    return {'gates':{k:bool(v) for k,v in gates.items()},'errors':errors}
