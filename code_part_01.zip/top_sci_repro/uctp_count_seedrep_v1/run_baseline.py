"""ASSIST PFA-inspired count baseline, train + development only."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from cross_core import import_project,read,sha,write,model_digest
from count_core import CountModel,dev_users,prior_count_features,SALT
from review_stats import metrics

ROOT=Path(__file__).resolve().parent

def main():
 p=argparse.ArgumentParser()
 for n in ('project-dir','data-dir','output-dir','reference-dev'):p.add_argument('--'+n,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--ack-row-feedback',action='store_true')
 p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--seed',type=int,default=0)
 a=p.parse_args()
 if not a.ack_row_feedback:p.error('Acknowledge row-immediate feedback assumption')
 if min(a.epochs,a.patience)<1:p.error('Invalid training settings')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
 status={'status':'running','phase':'audit','test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
  Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint']:raise ValueError('Data fingerprint mismatch')
  data=Data(a.data_dir);u=data.arrays['student_idx'][data.arrays['split']==1];dev=dev_users(u)
  status['phase']='feature_construction';write(out/'status.json',status);print('START feature construction',flush=True)
  f=prior_count_features(data.arrays,dev);train=np.flatnonzero(f['split']==0);valid=np.flatnonzero(f['split']==1)
  if not len(train) or not len(valid):raise ValueError('Empty train or development')
  if not set(f['student'][valid]).issubset(dev):raise AssertionError('Nondevelopment event scored')
  reference=pd.read_csv(a.reference_dev,compression='gzip',float_precision='round_trip')
  if not np.array_equal(reference.record_idx.to_numpy(),f['record_idx'][valid]) or not np.array_equal(reference.student_idx.to_numpy(),f['student'][valid]) or not np.array_equal(reference.label.to_numpy(),f['label'][valid]):
   raise ValueError('Baseline development events differ from A reference')
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(a.seed)
  if device.type=='cuda':torch.cuda.manual_seed_all(a.seed)
  torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.use_deterministic_algorithms(True)
  tensor={k:torch.as_tensor(f[k],dtype=torch.long if k in ('student','item','kc') else torch.float32,device=device)
          for k in ('student','item','kc','success','failure','label')}
  tr=torch.as_tensor(train,dtype=torch.long,device=device);va=torch.as_tensor(valid,dtype=torch.long,device=device)
  dims=data.manifest['summary'];model=CountModel(dims['students'],dims['items'],dims['knowledges']).to(device)
  optimizer=torch.optim.AdamW(model.parameters(),lr=.01,weight_decay=1e-5)
  config={'model':'PFA-inspired log-count logistic with student/item/KC biases; not canonical PFA',
          'feature_protocol':'prior same-student/KC correct and incorrect counts; log1p; current answer excluded',
          'data_fingerprint':data.fingerprint,'project_source':spec['source'],
          'code_sha256':{n:sha(ROOT/n) for n in ('run_baseline.py','count_core.py','cross_core.py','review_stats.py')},
          'seed':a.seed,'epochs_max':a.epochs,'patience':a.patience,'learning_rate':.01,'batch_size':8192,'optimizer':'AdamW',
          'weight_decay':1e-5,'student_partition_salt':SALT,'evaluation':'development only; NLL selects epoch',
          'feedback':'row immediate assumption','time_features_used':False,'test_evaluated':False,'holdout_evaluated':False,
          'device':a.device,'gpu':torch.cuda.get_device_name(device) if device.type=='cuda' else None,
          'torch':str(torch.__version__),'python':platform.python_version(),
          'train_rows':len(train),'dev_rows':len(valid),'dev_students':len(dev),
          'reference_dev_sha256':sha(Path(a.reference_dev)), 'reference_identity_check':'record_idx,student_idx,label exact'}
  write(out/'config.json',config);history=[];best=float('inf');best_epoch=None;stale=0
  def logits(ix):return model(*(tensor[k][ix] for k in ('student','item','kc','success','failure')))
  for epoch in range(1,a.epochs+1):
   t=time.monotonic();status.update(phase='train',epoch=epoch);write(out/'status.json',status);model.train()
   perm=tr[torch.randperm(len(tr),device=device)];total=0.0
   for start_idx in range(0,len(tr),8192):
    ix=perm[start_idx:start_idx+8192];optimizer.zero_grad(set_to_none=True)
    loss=F.binary_cross_entropy_with_logits(logits(ix),tensor['label'][ix])
    if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite loss')
    loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);optimizer.step()
    total+=float(loss.detach())*len(ix)
   model.eval()
   with torch.no_grad():prob=torch.sigmoid(logits(va)).cpu().numpy()
   valid_metrics=metrics(f['label'][valid],prob);nll=float(valid_metrics['nll'])
   if not np.isfinite(nll):raise ValueError('Nonfinite validation NLL')
   history.append({'epoch':epoch,'train_bce':total/len(tr),'dev':valid_metrics,'seconds':time.monotonic()-t});write(out/'history.json',history)
   print(json.dumps({'epoch':epoch,'train_bce':total/len(tr),'dev_nll':nll,'dev_auc':valid_metrics['auc'],'seconds':history[-1]['seconds']}),flush=True)
   if nll<best:
    best,best_epoch,stale=nll,epoch,0
    tmp=out/'best_model.pending.pt';torch.save({'model_state':model.state_dict(),'epoch':epoch,'dev_nll':nll,'data_fingerprint':data.fingerprint,'model':'pfa_inspired_log_count','seed':a.seed},tmp);tmp.replace(out/'best_model.pt')
   else:stale+=1
   if stale>=a.patience:break
  ckpt=torch.load(out/'best_model.pt',map_location=device,weights_only=True);model.load_state_dict(ckpt['model_state']);model.eval()
  with torch.no_grad():prob=torch.sigmoid(logits(va)).cpu().numpy()
  final=metrics(f['label'][valid],prob)
  if abs(final['nll']-best)>1e-7:raise AssertionError('Checkpoint NLL mismatch')
  pd.DataFrame({'record_idx':f['record_idx'][valid],'student_idx':f['student'][valid],'label':f['label'][valid],'probability':prob}).to_csv(out/'dev_predictions.csv.gz',index=False,compression='gzip')
  summary={'status':'complete','model':config['model'],'epochs':len(history),'best_epoch':best_epoch,'dev':final,
           'checkpoint_sha256':sha(out/'best_model.pt'),'checkpoint_model_state_sha256':model_digest(model.state_dict()),
           'test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-start}
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-start);write(out/'status.json',status)
  print('BASELINE COMPLETE',flush=True)
 except BaseException as exc:
  status.update(status='failed',error=repr(exc),seconds=time.monotonic()-start);write(out/'status.json',status);raise

if __name__=='__main__':main()
