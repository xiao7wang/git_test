import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);d=Path(p.parse_args().output_dir)
if not (d/'status.json').exists():print('Not started, or preflight tests failed; inspect launch log.')
else:
 s=read(d/'status.json');print('Suite:',s['status'],'active:',s.get('active'),'completed:',s.get('complete'),'error:',s.get('error','-'))
 print('A saved running status does not establish a live process.')
 if (d/'summary.json').exists():
  q=read(d/'summary.json')
  for name,r in q['rows'].items():print(name,'dev NLL=',round(r['nll'],6),'AUC=',round(r['auc'],6),'best epoch=',r['best_epoch'],'epochs=',r['epochs'])
  print('Three-seed development NLL mean:',round(q['dev_nll_mean'],6))
  print('Zero initialization: seeds mainly vary shuffle order. No holdout or test evaluated.')
 if (d/'count_seedrep_results.zip').exists():print('Results archive:',d/'count_seedrep_results.zip')
