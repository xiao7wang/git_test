#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_countseed_01}"
[[ "$NAME" =~ ^[A-Za-z0-9_-]+$ ]] || { echo 'Invalid output name' >&2; exit 2; }
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
REFERENCE=/home/wangxiao/QCCDM/top_sci_repro/uctp_retrain_screen_v1/outputs/server_screen_01
COUNT=/home/wangxiao/QCCDM/top_sci_repro/uctp_count_baseline_v1/outputs/server_count_01
OUT="$DIR/outputs/$NAME";LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]]; then echo 'Output exists; preserved' >&2; exit 2; fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" CUBLAS_WORKSPACE_CONFIG=:4096:8 PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$DIR/verify_package.py"
"$PY" -B "$DIR/check_reference.py" "$REFERENCE"
for DEVICE in cpu cuda; do "$PY" -B "$DIR/test_core.py" --device "$DEVICE"; done
"$PY" -B -u "$DIR/run_suite.py" --project-dir "$PROJECT" --data-dir "$DATA" --reference-dir "$REFERENCE" --count-dir "$COUNT" --output-dir "$OUT" --device cuda --ack-row-feedback
