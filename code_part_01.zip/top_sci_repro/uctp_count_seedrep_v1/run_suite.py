"""Reproduce the fixed log-count development protocol for shuffle seeds 1 and 2."""
import argparse, hashlib, json, os, subprocess, sys, time, zipfile
from pathlib import Path
from cross_core import read, sha, write

ROOT = Path(__file__).resolve().parent
LOCK = json.loads((ROOT/'locked_seed0.json').read_text(encoding='utf8'))

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','reference-dir','count-dir','output-dir'): p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--ack-row-feedback',action='store_true')
 a=p.parse_args()
 if not a.ack_row_feedback: p.error('Row-immediate feedback acknowledgement required')
 count=Path(a.count_dir)
 for name,digest in LOCK['files'].items():
  if sha(count/name)!=digest: raise ValueError('Existing seed0 artifact differs: '+name)
 cfg=read(count/'config.json');old=read(count/'summary.json')
 if cfg['seed']!=0 or old['status']!='complete' or cfg['test_evaluated'] or cfg['holdout_evaluated']:
  raise ValueError('Existing seed0 protocol differs')
 output=Path(a.output_dir).resolve();output.mkdir(parents=True,exist_ok=False)
 start=time.monotonic();status={'status':'running','active':None,'complete':[],'test_evaluated':False,'holdout_evaluated':False}
 write(output/'status.json',status)
 try:
  rows={'seed0':old['dev']|{'best_epoch':old['best_epoch'],'epochs':old['epochs'],'seconds':old['seconds'],'checkpoint_sha256':old['checkpoint_sha256']}}
  for seed in (1,2):
   status['active']='seed'+str(seed);write(output/'status.json',status)
   print('Starting seed',seed,flush=True)
   cmd=[sys.executable,'-B','-u',str(ROOT/'run_baseline.py'),'--project-dir',a.project_dir,'--data-dir',a.data_dir,
        '--reference-dev',str(Path(a.reference_dir)/'A_none/dev_predictions.csv.gz'),'--output-dir',str(output/('seed'+str(seed))),
        '--device',a.device,'--epochs','20','--patience','5','--seed',str(seed),'--ack-row-feedback']
   subprocess.run(cmd,check=True)
   sub=output/('seed'+str(seed));newcfg=read(sub/'config.json');result=read(sub/'summary.json')
   keys=('data_fingerprint','project_source','epochs_max','patience','learning_rate','batch_size','optimizer','weight_decay',
         'student_partition_salt','evaluation','feedback','time_features_used','test_evaluated','holdout_evaluated','reference_dev_sha256')
   for key in keys:
    if cfg[key]!=newcfg[key]:raise ValueError('Protocol changed for seed '+str(seed)+': '+key)
   if newcfg['seed']!=seed or result['status']!='complete':raise ValueError('Seed result incomplete')
   rows['seed'+str(seed)]=result['dev']|{'best_epoch':result['best_epoch'],'epochs':result['epochs'],'seconds':result['seconds'],'checkpoint_sha256':result['checkpoint_sha256']}
   status['complete'].append(seed);write(output/'status.json',status)
  summary={'status':'complete','scope':'exploratory development; zero initialization; seeds vary shuffle order; no holdout/test',
           'rows':rows,'dev_nll_mean':sum(rows['seed'+str(i)]['nll'] for i in range(3))/3,
           'seed0_config_sha256':LOCK['files']['config.json'],'seed0_summary_sha256':LOCK['files']['summary.json'],
           'test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-start}
  write(output/'summary.json',summary);status.update(status='complete',active=None,seconds=time.monotonic()-start);write(output/'status.json',status)
  names=['status.json','summary.json']+[f'seed{seed}/{name}' for seed in (1,2) for name in ('status.json','config.json','summary.json','history.json','dev_predictions.csv.gz')]
  manifest={name:sha(output/name) for name in names};archive=output/'count_seedrep_results.zip'
  with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
   for name in names:z.write(output/name,name)
   z.writestr('manifest.json',json.dumps(manifest,indent=2))
  with zipfile.ZipFile(archive) as z:
   if z.testzip() is not None or any(hashlib.sha256(z.read(n)).hexdigest()!=h for n,h in manifest.items()):raise ValueError('Archive verification failed')
  print('RESULTS READY:',archive,flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-start);write(output/'status.json',status);raise

if __name__=='__main__':main()
