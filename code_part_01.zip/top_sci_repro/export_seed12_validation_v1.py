"""Export existing clean-baseline seed1/2 VALID predictions. Never train.

Run this standalone file outside the model project. Outputs are new directories.
The project's original evaluate.py is used with an explicit --view valid.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

VERSION = 1
EXPECTED = {
    "assist": {"fingerprint": "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e", "n": 255916},
    "ednet": {"fingerprint": "fa8198274d35d980169ba71acf3792cdd2e9892eb28504fc1081a4ae6179da09", "n": 209028},
}
DEFAULT_ROOTS = {
    "assist": "server_assist_baselines_e20_p5_v1_rerun01",
    "ednet": "server_ednet_baselines_e20_p5_v1",
}
CORE = ("src/model.py", "src/data.py", "src/engine.py", "src/metrics.py")
METADATA = ("run_config.json", "status.json", "history.json")
EVAL_FILES = ("predictions.csv", "metrics.json", "subgroup_metrics.json", "evaluation.json")
SIGNATURE_ARGS = ("epochs", "patience", "batch_size", "chunk_size", "eval_chunk_size", "ncd_hidden_dim", "lr", "weight_decay", "eval_update_targets")


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for part in iter(lambda: f.read(1024*1024), b""):
            h.update(part)
    return h.hexdigest()


def read_json(path):
    with Path(path).open(encoding="utf-8") as f:
        return json.load(f)


def write_json(path, value):
    path = Path(path)
    pending = path.with_name(path.name + ".pending")
    with pending.open("w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
    pending.replace(path)


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


def best_validation(run, seed, variant):
    cfg, status, history = [read_json(run / n) for n in METADATA]
    check(status.get("status") == "complete", f"Original run is not complete: {run}")
    check(cfg["args"]["seed"] == seed, f"Wrong training seed: {run}")
    check(cfg["model_config"]["variant"] == variant, f"Wrong model variant: {run}")
    check(cfg["args"].get("eval_update_targets") == 1, f"Different feedback/update protocol: {run}")
    records = [x for x in history if x["epoch"] == status["best_epoch"]]
    check(len(records) == 1, f"Missing/duplicate best-epoch validation record: {run}")
    selected = max(history, key=lambda x: x["valid"]["auc"] if x["valid"]["auc"] is not None else -x["valid"]["nll"])
    check(selected["epoch"] == status["best_epoch"], f"Best checkpoint does not match original validation selection: {run}")
    return cfg, status, records[0]["valid"]


def preflight(project, roots, output, device, expected=None):
    expected = EXPECTED if expected is None else expected
    project, output = project.resolve(), output.resolve()
    check(output.is_relative_to(project / "outputs") and output != project / "outputs", "Output must be a new subdirectory of project/outputs")
    check(not Path(__file__).resolve().is_relative_to(project), "Keep the exporter OUTSIDE the project to preserve project source inventory")
    for run_root in roots.values():
        check(not output.is_relative_to(run_root.resolve()), "Output cannot be inside existing training results")
    check((project / "evaluate.py").is_file(), f"Missing evaluator: {project / 'evaluate.py'}")
    source = {name: digest(project / name) for name in CORE}
    jobs, data_info, seed0_metadata = [], {}, []
    signatures = {}
    for ds in ("assist", "ednet"):
        data = project / "data" / (ds + "_full")
        manifest_path = data / "manifest.json"
        manifest = read_json(manifest_path)
        fingerprint = digest(manifest_path)
        check(fingerprint == expected[ds]["fingerprint"], f"{ds}: data fingerprint differs from existing diagnostic context; STOP, do not rebuild data")
        check(manifest["summary"]["split_rows"]["valid"] == expected[ds]["n"], f"{ds}: unexpected validation row count")
        for fn, key in (("records.npz", "records_sha256"), ("vocabulary.json", "vocabulary_sha256")):
            check(digest(data / fn) == manifest[key], f"Data integrity mismatch: {data / fn}")
        data_info[ds] = {"dir": str(data), "fingerprint": fingerprint, "n": expected[ds]["n"],
                         "records_sha256": manifest["records_sha256"], "vocabulary_sha256": manifest["vocabulary_sha256"]}
        for variant in ("dynamic_only", "unit_write"):
            # Metadata only. Do not evaluate seed0 and never open test metrics.
            seed0 = roots[ds] / (variant + "_seed0")
            if all((seed0 / f).is_file() for f in METADATA):
                c0, s0, v0 = best_validation(seed0, 0, variant)
                seed0_metadata.append({"dataset": ds, "variant": variant, "run": str(seed0),
                    "best_epoch": s0["best_epoch"], "validation": v0,
                    "data_fingerprint": c0["data_fingerprint"],
                    "files": {f: digest(seed0 / f) for f in METADATA}})
            for seed in (1, 2):
                run = roots[ds] / f"{variant}_seed{seed}"
                for f in (*METADATA, "best_model.pt"):
                    check((run / f).is_file(), f"Missing required file: {run / f}")
                cfg, status, valid = best_validation(run, seed, variant)
                check(cfg["data_fingerprint"] == fingerprint, f"Checkpoint run/data mismatch: {run}")
                check(valid["n"] == expected[ds]["n"], f"Stored validation count mismatch: {run}")
                for fn in CORE:
                    check(cfg["source_code"].get(fn) == source[fn], f"Current code differs from training: {fn}; run={run}; do not bypass the hash check")
                checkpoint_hash = digest(run / "best_model.pt")
                check(status.get("checkpoint_sha256") == checkpoint_hash, f"Checkpoint differs from original completion record: {run}")
                signature = {k: cfg["args"][k] for k in SIGNATURE_ARGS}
                if ds not in signatures:
                    signatures[ds] = signature
                check(signature == signatures[ds], f"Mixed training/evaluation settings within {ds}: {run}")
                jobs.append({"name": f"{ds}_{variant}_seed{seed}", "dataset": ds, "variant": variant, "seed": seed,
                    "run": str(run), "checkpoint": str(run / "best_model.pt"), "checkpoint_sha256": checkpoint_hash,
                    "data_dir": str(data), "data_fingerprint": fingerprint, "best_epoch": status["best_epoch"],
                    "expected_validation": valid, "n": expected[ds]["n"],
                    "batch_size": cfg["args"]["batch_size"], "chunk_size": cfg["args"]["eval_chunk_size"],
                    "threads": cfg["args"].get("threads", 4),
                    "metadata_hashes": {f: digest(run / f) for f in METADATA}})
    return {"schema_version": VERSION, "project_dir": str(project), "output_root": str(output), "device": device,
            "python": str(Path(sys.executable).resolve()), "exporter_sha256": digest(__file__),
            "evaluator_sha256": digest(project / "evaluate.py"), "core_sources": source,
            "view": "valid", "update_targets": 1, "data": data_info,
            "training_settings": signatures, "seed0_reference_metadata": seed0_metadata, "jobs": jobs}


def command_for(plan, job, destination):
    return [sys.executable, "-B", "-u", str(Path(plan["project_dir"]) / "evaluate.py"),
        "--checkpoint", job["checkpoint"], "--data-dir", job["data_dir"], "--output-dir", str(destination),
        "--view", "valid", "--batch-size", str(job["batch_size"]), "--chunk-size", str(job["chunk_size"]),
        "--update-targets", "1", "--device", plan["device"], "--threads", str(job["threads"]), "--ack-row-feedback"]


def verify_export(path, job):
    for f in EVAL_FILES:
        check((path / f).is_file(), f"Missing exported file: {path / f}")
    ev, metrics = read_json(path / "evaluation.json"), read_json(path / "metrics.json")
    check(ev["args"]["view"] == "valid" and ev["args"]["update_targets"] == 1, "Export is not the requested validation protocol")
    check(ev["data_fingerprint"] == job["data_fingerprint"], "Export data fingerprint mismatch")
    check(ev["checkpoint_sha256"] == job["checkpoint_sha256"], "Export checkpoint mismatch")
    check(ev["epoch"] == job["best_epoch"], "Export is not the selected checkpoint")
    check(metrics["n"] == job["n"] and metrics["update_targets"] is True, "Export count/update mismatch")
    errors = {}
    for key in ("auc", "nll", "brier"):
        old, new = job["expected_validation"][key], metrics[key]
        if old is None or new is None:
            check(old is None and new is None, f"Unavailable metric mismatch: {key}")
            errors[key] = 0.
        else:
            check(math.isfinite(new), f"Non-finite metric: {key}")
            errors[key] = abs(old-new)
            check(errors[key] <= 1e-6, f"Validation did not reproduce best epoch: {key}, delta={errors[key]}")
    total, last = 0, -1
    with (path / "predictions.csv").open(encoding="utf-8", newline="") as f:
        rows = csv.DictReader(f)
        required = {"record_idx", "student_idx", "item_idx", "label", "split", "timestamp", "probability", "kc_count_before", "student_count_before"}
        check(required.issubset(rows.fieldnames or []), "Missing prediction columns")
        for row in rows:
            idx = int(row["record_idx"])
            check(idx > last, "Prediction IDs are duplicated or not ordered")
            last = idx
            check(float(row["split"]) == 1, "NON-VALIDATION ROW DETECTED; refuse packaging")
            check(float(row["label"]) in (0.,1.), "Invalid validation label")
            p = float(row["probability"])
            check(math.isfinite(p) and 0 <= p <= 1, "Invalid prediction")
            total += 1
    check(total == job["n"], f"CSV row count mismatch: {total}")
    return {"rows": total, "metric_absolute_errors": errors,
            "files": {f: digest(path / f) for f in EVAL_FILES}}


def make_archive(plan, completed, output):
    archive = output / "seed12_validation_export.zip"
    if archive.exists():
        known = read_json(output / "package_manifest.json")
        check(digest(archive) == known["sha256"], "Existing archive changed")
        return archive
    n = 1
    pending = output / f"package_attempt_{n:03d}.zip"
    while pending.exists():
        n += 1
        pending = output / f"package_attempt_{n:03d}.zip"
    with zipfile.ZipFile(pending, "x", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(output / "export_plan.json", "export_plan.json")
        z.write(output / "completed.json", "completed.json")
        for job in plan["jobs"]:
            entry = completed[job["name"]]
            evaluation = output / entry["evaluation_dir"]
            prefix = f"{job['dataset']}/{job['variant']}_seed{job['seed']}"
            for fn in EVAL_FILES:
                check(digest(evaluation / fn) == entry["verification"]["files"][fn], "Evaluation output changed before packaging")
                z.write(evaluation / fn, prefix + "/evaluation/" + fn)
            for fn in METADATA:
                source = Path(job["run"]) / fn
                check(digest(source) == job["metadata_hashes"][fn], f"Original metadata changed: {source}")
                z.write(source, prefix + "/training/" + fn)
        for ref in plan["seed0_reference_metadata"]:
            for fn in METADATA:
                source = Path(ref["run"]) / fn
                check(digest(source) == ref["files"][fn], f"Seed0 reference changed: {source}")
                z.write(source, f"seed0_reference/{ref['dataset']}/{ref['variant']}/" + fn)
    with zipfile.ZipFile(pending) as z:
        check(z.testzip() is None, "Archive CRC failure")
        check(not any("test" in Path(name).name.lower() for name in z.namelist()), "Unexpected test artifact in package")
        check(not any(name.endswith(".pt") for name in z.namelist()), "Checkpoint must not be packaged")
    pending.rename(archive)
    write_json(output / "package_manifest.json", {"file": archive.name, "sha256": digest(archive), "bytes": archive.stat().st_size})
    return archive


def execute(plan, resume=False):
    output = Path(plan["output_root"])
    if output.exists():
        check(resume, "Output exists. Do not overwrite. Use --resume for this exact suite, or choose a NEW output root")
        check(read_json(output / "export_plan.json") == plan, "Resume plan/source/checkpoint differs. Preserve this export and use a new output root")
    else:
        output.mkdir(parents=True, exist_ok=False)
        write_json(output / "export_plan.json", plan)
    # Atomic directory lock. Never remove another process's lock automatically.
    lock = output / ".export_lock"
    lock.mkdir()
    write_json(lock / "owner.json", {"pid": os.getpid(), "started_unix": time.time()})
    complete_path = output / "completed.json"
    completed = read_json(complete_path) if complete_path.exists() else {}
    try:
        for position, job in enumerate(plan["jobs"], 1):
            name = job["name"]
            if name in completed:
                v = verify_export(output / completed[name]["evaluation_dir"], job)
                check(v == completed[name]["verification"], f"Completed files changed: {name}")
                print(f"SKIP verified {name} ({position}/8)", flush=True)
                continue
            job_dir = output / name
            job_dir.mkdir(exist_ok=True)
            attempt = 1
            while (job_dir / f"attempt_{attempt:03d}").exists() or (job_dir / f"attempt_{attempt:03d}.log").exists():
                attempt += 1
            target = job_dir / f"attempt_{attempt:03d}"
            log = job_dir / f"attempt_{attempt:03d}.log"
            command = command_for(plan, job, target)
            write_json(output / "suite_status.json", {"status": "running", "completed": len(completed), "total":8, "current":name,"log":str(log)})
            print(f"START {name} ({position}/8); log: {log}", flush=True)
            start = time.perf_counter()
            with log.open("x", encoding="utf-8") as f:
                proc = subprocess.run(command, cwd=plan["project_dir"], stdout=f, stderr=subprocess.STDOUT)
            check(proc.returncode == 0, f"{name} failed with code {proc.returncode}; read {log}; old results preserved")
            verification = verify_export(target, job)
            check(digest(job["checkpoint"]) == job["checkpoint_sha256"], "Original checkpoint changed during evaluation")
            completed[name] = {"evaluation_dir": target.relative_to(output).as_posix(), "verification": verification,
                               "seconds": time.perf_counter()-start}
            write_json(complete_path, completed)
            print(f"DONE {name}; n={verification['rows']}; seconds={completed[name]['seconds']:.1f}; completed={len(completed)}/8", flush=True)
        archive = make_archive(plan, completed, output)
        write_json(output / "suite_status.json", {"status":"complete","completed":8,"total":8,"archive":str(archive),
                   "training_performed":False,"test_evaluated":False,"validation_only_exports":True})
        print("ALL_VALIDATION_EXPORTS_COMPLETED\n"+str(archive), flush=True)
        return archive
    except BaseException as exc:
        write_json(output / "suite_status.json", {"status":"failed","completed":len(completed),"total":8,"error":repr(exc)})
        raise
    finally:
        (lock / "owner.json").unlink()
        lock.rmdir()


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", required=True)
    p.add_argument("--output-root", required=True)
    p.add_argument("--assist-root")
    p.add_argument("--ednet-root")
    p.add_argument("--device", choices=("cpu","cuda"), default="cuda")
    p.add_argument("--ack-row-feedback", action="store_true")
    p.add_argument("--check-only", action="store_true")
    p.add_argument("--resume", action="store_true")
    a=p.parse_args()
    check(a.ack_row_feedback, "Explicit --ack-row-feedback required; actual feedback groups are still unverified")
    project=Path(a.project_dir).resolve()
    roots={ds:Path(getattr(a,ds+"_root")).resolve() if getattr(a,ds+"_root") else project/"outputs"/DEFAULT_ROOTS[ds]
           for ds in ("assist","ednet")}
    print("Checking all 8 existing checkpoints, source hashes, data and metadata. No training.", flush=True)
    plan=preflight(project,roots,Path(a.output_root),a.device)
    print("PREFLIGHT_OK: 8 validation-only jobs. batch/chunk copied from original training config.", flush=True)
    if not a.check_only:
        execute(plan,a.resume)


if __name__=="__main__":
    main()
