import copy
import unittest

import torch

from dkvmn_ref.bias import BiasDKVMN
from dkvmn_ref.streaming import initial_memory
from dkvmn_ref.upstream import DKVMN
from overnight.model import CountHybrid


class HybridTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(23)
        base = DKVMN(num_c=3, dim_s=5, size_m=4, dropout=.2)
        self.original = BiasDKVMN(copy.deepcopy(base), 6, 3).eval()
        self.hybrid = CountHybrid(copy.deepcopy(base), 6, 3).eval()
        self.kc = torch.tensor([[0, 1, 2, 1, 0, 2], [1, 0, 2, 1, 0, 0]])
        self.item = self.kc.clone()
        self.users = torch.tensor([0, 1])
        self.label = torch.tensor([[0, 1, 1, 0, 0, 1], [1, 1, 0, 0, 0, 0]])
        self.active = torch.tensor([[1, 1, 1, 1, 1, 1], [1, 1, 1, 1, 0, 0]], dtype=torch.bool)
        self.pos = torch.rand(2, 6)
        self.neg = torch.rand(2, 6)

    def call(self, model, a=0, b=6, state=None, labels=None):
        if state is None:
            state = initial_memory(model.base, 2)
        return model.forward_chunk(self.users, self.item[:, a:b], self.kc[:, a:b],
                                   (self.label if labels is None else labels)[:, a:b],
                                   self.active[:, a:b], self.active[:, a:b], state,
                                   self.pos[:, a:b], self.neg[:, a:b])

    def test_zero_history_bridge_to_prior_bias_dkvmn(self):
        with torch.no_grad():
            expected, expected_state = self.original.forward_chunk(self.users, self.item, self.kc, self.label,
                                            self.active, self.active, initial_memory(self.original.base, 2))
            actual, state = self.call(self.hybrid)
        torch.testing.assert_close(actual, expected, atol=1e-7, rtol=0)
        torch.testing.assert_close(state, expected_state, atol=1e-7, rtol=0)

    def test_chunk_and_current_answer_mask(self):
        with torch.no_grad():
            self.hybrid.history_weights[:] = torch.tensor([[.2, -.1], [.4, .05], [-.2, .3]])
            whole, whole_state = self.call(self.hybrid)
            left, state = self.call(self.hybrid, 0, 3)
            right, state = self.call(self.hybrid, 3, 6, state)
            torch.testing.assert_close(torch.cat([left, right], dim=1), whole, atol=1e-7, rtol=0)
            torch.testing.assert_close(state, whole_state, atol=1e-7, rtol=0)
            changed = self.label.clone()
            changed[:, 2] = 1 - changed[:, 2]
            future, _ = self.call(self.hybrid, labels=changed)
            torch.testing.assert_close(whole[:, :3], future[:, :3], atol=1e-7, rtol=0)

