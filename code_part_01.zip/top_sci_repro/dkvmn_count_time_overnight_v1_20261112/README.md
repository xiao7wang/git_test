# Night experiment: matched DKVMN + count-history controls

This package runs **exploratory development-only** comparisons on the same
ASSIST dataset and development students used before. It never scores test or
the prior internal holdout. Loading prepared `records.npz` loads all arrays,
including test labels, but feature construction and evaluation exclude test
rows. Platform feedback timing remains unverified. The assumed protocol is to
predict each row before immediately incorporating its response. Event time is
only a proxy and cannot by itself establish actual forgetting.

## Why this experiment

The previous log-count model favored time half-life 168h over tested fixed
discounts (including 0.8). We ask whether the distinction persists when the
same kind of per-KC count history is added to an independently trained,
stronger DKVMN backbone. Both hybrid variants use the **same** DKVMN model,
student/item bias parameters, a two-parameter per-KC log-count readout, Adam
optimizer, feature and label permissions, and training schedule. The only
difference between the paired variants is their count-history rule:

* `fixed_08`: discount previous same-KC success and failure counts by 0.8
  before each repeat of that KC, including zero-gap repeats.
* `time_168h`: discount them by `2^(-gap_hours/168)` before each repeat.

The underlying DKVMN memory update remains the earlier pyKT-derived row-wise
update and is not directly time-decayed. Both count-readout coefficients start
at zero without consuming RNG. There are two paired training-order seeds, 1
and 2, for four full jobs. All jobs early-stop separately on the **same reused
development set**, with maximum 20 epochs and patience 5. The zero-weight
bridge is tested against the earlier student/item-bias DKVMN at startup;
initial hashes and common-epoch student permutation hashes are checked
between the two new hybrid jobs for each seed. The prior DKVMN output is
included as a contextual comparison; its archived job did not record an
initial-state hash, so the new-to-old initial state is not claimed verified.

The primary comparison is hybrid time minus hybrid fixed per-event NLL, first
averaging the two paired per-event seed losses, then resampling whole students
2,000 times. A negative difference favors the time hybrid. The fixed-model
interval does not cover training, tuning, stopping, or model-selection
uncertainty. The two seeds are not independent datasets. Comparisons against
the previous DKVMN-only and count-only models change architecture and cannot
isolate the role of time.

## Pseudo-gap negative control

Before the long jobs, the suite creates three pseudo-gap maps (seeds 11, 29,
47) and trains three count models per map (training seeds 0, 1, 2). It
permutes only the pool of same-KC repeated **training** gaps when creating
training histories, and samples evaluation replacement gaps from that
training pool only. It keeps original chronological events, labels, and
feedback order. It does not use evaluation response labels or evaluation
timestamps to draw a replacement gap. This is an intentionally noisy,
train-derived control, not a formal exchangeability-based permutation test;
the replacement development gap distribution may differ from the true one.
Gap summaries are reported so that difference is visible. It tests association
with the observed gap under these settings, not a causal time intervention.

All comparisons involve the repeatedly inspected development group, and the
previous results motivated these choices. Do not present the results as an
independent confirmatory test or general performance claim. Gap and activity
subgroups are exploratory; no adjustment for multiple comparisons is made.
EDNet is not used, and existing unresolved split/feedback concerns remain.

## Running and recovery

Run `bash run_server.sh server_overnight_01` on the original server. It creates
a launch log before preflight, verifies source and reference hashes, runs
synthetic tests, and starts the suite. No existing log or output is overwritten
and no automatic retry or CPU fallback is performed. A failed preflight can
leave a launch log without a status file. Output progress has the active job,
epoch, and completed jobs; the launch log includes batch progress.

`partial_negative_controls.zip` is written after the nine negative-control
jobs. Each completed hybrid job produces a cumulative `partial_<job>.zip`
containing the negative results and all completed hybrid jobs to that point.
`overnight_results.zip` is written and verified after all four finish. A
partial archive is a snapshot, not the complete suite. Checkpoints remain in
the server output job directories and are excluded from all result ZIPs. If a
job fails, preserve the log and output, including completed partials; there is
no automatic resume implementation.

The server verifies the previously returned archive SHA-256 values and checks
that every scoring record aligns. The program writes only new files in its own
output directory; the prepared data and earlier project files are read-only.
