"""Numeric contract-failure metric; strict mode blocks a server run."""
import argparse
import os
import sys
import unittest
from pathlib import Path

os.environ.setdefault("MKL_THREADING_LAYER", "SEQUENTIAL")
os.environ.setdefault("OMP_NUM_THREADS", "1")
ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "contract_tests")]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.discover(str(ROOT / "contract_tests"), pattern="test_*.py")
    result = unittest.TextTestRunner(verbosity=1).run(suite)
    failed = len(result.errors) + len(result.failures) + len(result.unexpectedSuccesses)
    print(failed, flush=True)
    return 1 if args.strict and failed else 0

if __name__ == "__main__":
    sys.exit(main())
