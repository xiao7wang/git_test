"""Prevent modifications to the exact previous scientific source."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    expected = json.loads((ROOT / "contracts/vendor_hashes.json").read_text(encoding="utf-8"))
    files = set()
    for folder in ("src/count_time", "src/fixed_controls", "src/dkvmn_ref", "src/overnight", "src/lagprobe", "vendor"):
        files.update(p.relative_to(ROOT).as_posix() for p in (ROOT / folder).rglob("*")
                     if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    if files != set(expected):
        raise ValueError("protected source inventory changed")
    for name, digest in expected.items():
        if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest:
            raise ValueError(f"protected source changed: {name}")
    print(f"Protected prior source: {len(expected)} files verified")

if __name__ == "__main__":
    main()
