"""One-event gap replacement while every prior state stays on the real path."""
from __future__ import annotations

import math
import numpy as np


def one_step_states(features, half_life_hours=168.0):
    half_life_hours = float(half_life_hours)
    if not math.isfinite(half_life_hours) or half_life_hours <= 0:
        raise ValueError("invalid half-life")
    names = ("record_idx", "student", "kc", "label", "prior_kc_count", "gap_hours")
    if any(k not in features for k in names) or "C_real_time" not in features.get("states", {}):
        raise ValueError("missing required true-history arrays")
    record, student, kc, label, prior, gap = (np.asarray(features[k]) for k in names)
    positive, negative = (np.asarray(x, dtype=np.float64) for x in features["states"]["C_real_time"])
    n = len(record)
    if not n or any(x.ndim != 1 or len(x) != n for x in (record, student, kc, label, prior, gap, positive, negative)):
        raise ValueError("history dimensions differ")
    if (np.diff(record) <= 0).any() or (student < 0).any() or (kc < 0).any() or (prior < 0).any():
        raise ValueError("invalid record ordering or identity")
    if not np.isin(label, [0, 1]).all() or not np.equal(prior, np.floor(prior)).all():
        raise ValueError("invalid response or past count")
    if not np.array_equal(np.isnan(gap), prior == 0):
        raise ValueError("first encounter and missing gap disagree")
    if not np.isfinite(gap[prior > 0]).all() or (gap[prior > 0] < 0).any():
        raise ValueError("repeated gaps must be finite and nonnegative")
    if not np.isfinite(positive).all() or not np.isfinite(negative).all() or (positive < 0).any() or (negative < 0).any():
        raise ValueError("true historical counts must be finite and nonnegative")
    local_positive, local_negative = positive.copy(), negative.copy()
    previous_gap = np.full(n, np.nan, dtype=np.float64)
    order = np.lexsort((record, kc, student))
    group, previous, seen = None, None, 0
    for index in order:
        current = (int(student[index]), int(kc[index]))
        if current != group:
            group, previous, seen = current, None, 0
        if int(prior[index]) != seen:
            raise ValueError("prior count does not match same-KC event order")
        if seen >= 2:
            old_gap = float(gap[previous])
            if not math.isfinite(old_gap) or old_gap < 0:
                raise ValueError("preceding same-KC gap is invalid")
            previous_gap[index] = old_gap
            discount = math.exp(-math.log(2.0) * old_gap / half_life_hours)
            # Use the previous real-path state and previous answer, never current answer.
            local_positive[index] = (positive[previous] + int(label[previous])) * discount
            local_negative[index] = (negative[previous] + 1 - int(label[previous])) * discount
        previous, seen = index, seen + 1
    return {"success": local_positive, "failure": local_negative, "previous_gap_hours": previous_gap}
