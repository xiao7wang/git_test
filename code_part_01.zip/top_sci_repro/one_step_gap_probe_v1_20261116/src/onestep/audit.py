"""Bounded read-only EdNet lineage metadata; no rows, scripts or pickle files."""
from __future__ import annotations

import json
import os
import re
from pathlib import Path

NAMES = ("config.json", "interactions_raw.csv", "ednet_time_oursTotalData.csv", "q.csv")
ALLOWED_KEYS = ("kind", "dataset", "timestamp_unit", "response_time_unit", "student_col", "item_col",
                "label_col", "timestamp_col", "knowledge_col", "response_time_col", "split_dir", "meta_dir")
REDACT = re.compile(r"token|password|secret|authorization|bearer|api[_-]?key|://|\?", re.IGNORECASE)


def inspect_ednet(project_root, link_dir):
    root = Path(project_root).resolve()
    directory = Path(os.path.abspath(link_dir))
    report = {"project_root": str(root), "directory": str(directory), "files": {},
              "scope": "fixed directory metadata and allowlisted config fields only; no raw rows or pickle"}
    if not directory.is_relative_to(root):
        report["state"] = "directory_outside_project_scope"
        return report
    if not directory.is_dir():
        report["state"] = "directory_missing_or_unreadable"
        return report
    if not directory.resolve().is_relative_to(root):
        report["state"] = "directory_resolves_outside_project_scope"
        return report
    report["state"] = "directory_found"
    for name in NAMES:
        p = directory / name
        item = {"is_symlink": p.is_symlink(), "exists": p.exists()}
        if item["is_symlink"]:
            try:
                item["link_text"] = os.readlink(p)
            except OSError as exc:
                item["link_error"] = type(exc).__name__
        if item["exists"]:
            try:
                resolved = p.resolve(strict=True)
                item.update(resolved_path=str(resolved), inside_project=resolved.is_relative_to(root),
                            size_bytes=p.stat().st_size, file=p.is_file())
            except OSError as exc:
                item["stat_error"] = type(exc).__name__
        report["files"][name] = item
    config = directory / "config.json"
    meta = report["files"]["config.json"]
    if meta.get("exists") and meta.get("file") and meta.get("inside_project") and Path(meta.get("resolved_path", "")).suffix.lower() == ".json":
        try:
            if config.stat().st_size > 1024 * 1024:
                report["config_status"] = "too_large_not_read"
            else:
                value = json.loads(config.read_text(encoding="utf-8"))
                if not isinstance(value, dict):
                    report["config_status"] = "not_an_object"
                else:
                    allowed = {}
                    for key in ALLOWED_KEYS:
                        v = value.get(key)
                        if isinstance(v, (str, int, float, bool)) and (not isinstance(v, str) or
                           (len(v) <= 512 and not REDACT.search(v) and "\n" not in v and "\r" not in v)):
                            allowed[key] = v
                    report["config_status"] = "allowlisted_fields_only"
                    report["config_fields"] = allowed
        except (OSError, ValueError, UnicodeError) as exc:
            report["config_status"] = "unreadable_or_invalid"
            report["config_error_type"] = type(exc).__name__
    elif meta.get("exists") and not meta.get("inside_project"):
        report["config_status"] = "outside_project_scope_not_read"
    elif meta.get("exists") and meta.get("file"):
        report["config_status"] = "not_json_extension_not_read"
    else:
        report["config_status"] = "missing_or_not_file"
    return report
