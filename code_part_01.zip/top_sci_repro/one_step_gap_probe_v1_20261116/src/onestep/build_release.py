"""Build and verify an immutable release with no datasets or checkpoints."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def build(destination):
    destination = Path(destination).resolve()
    if destination.suffix.lower() != ".zip" or destination.exists():
        raise FileExistsError(f"destination must be a new ZIP: {destination}")
    names = ("src/count_time", "src/fixed_controls", "src/dkvmn_ref", "src/overnight", "src/lagprobe",
             "src/onestep", "contract_tests", "checks", "contracts", "vendor")
    paths = [ROOT / "run_server.sh", ROOT / "README.md"]
    for name in names:
        paths.extend(p for p in (ROOT / name).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    files = {}
    for path in paths:
        name, payload = path.relative_to(ROOT).as_posix(), path.read_bytes()
        if name in files or (name.endswith(".sh") and b"\r" in payload):
            raise ValueError(f"duplicate member or shell CRLF: {name}")
        files[name] = payload
    vendor = json.loads(files["contracts/vendor_hashes.json"])
    for name, digest in vendor.items():
        if name not in files or hashlib.sha256(files[name]).hexdigest() != digest:
            raise ValueError(f"protected source differs: {name}")
    manifest = {"format": 1, "files": {k: hashlib.sha256(v).hexdigest() for k,v in sorted(files.items())}}
    files["release_manifest.json"] = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode()
    pending = destination.with_suffix(destination.suffix + ".pending")
    if pending.exists():
        raise FileExistsError(f"preserving unfinished release: {pending}")
    with zipfile.ZipFile(pending, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, payload in sorted(files.items()):
            z.writestr(name, payload)
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or set(z.namelist()) != set(files):
            raise ValueError("release ZIP inventory or CRC failure")
        for name, expected in files.items():
            if z.read(name) != expected:
                raise ValueError(f"release member mismatch: {name}")
    pending.replace(destination)
    return {"path": str(destination), "bytes": destination.stat().st_size,
            "sha256": hashlib.sha256(destination.read_bytes()).hexdigest(), "members": len(files)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(json.dumps(build(args.output), ensure_ascii=False, indent=2))
