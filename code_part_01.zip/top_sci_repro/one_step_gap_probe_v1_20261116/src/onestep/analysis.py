"""Event-weighted paired NLL and student-cluster intervals on reused development."""
from __future__ import annotations

import numpy as np
from overnight.analysis import _group


def summarize(events, previous_gap_hours, predictions, *, repetitions=2000, seed=20261116):
    y, student, prior, current_gap = (np.asarray(events[k]) for k in
                                      ("label", "student_idx", "prior_kc_count", "same_kc_gap_hours"))
    previous_gap = np.asarray(previous_gap_hours, dtype=np.float64)
    if y.ndim != 1 or not len(y) or any(x.shape != y.shape for x in (student, prior, current_gap, previous_gap)):
        raise ValueError("analysis inputs do not align")
    if repetitions < 1 or set(predictions) != {"real", "one_step", "recursive"}:
        raise ValueError("unexpected models or bootstrap settings")
    for name, seed_map in predictions.items():
        if set(seed_map) != {1, 2}:
            raise ValueError(f"two seeds are required: {name}")
        for p in seed_map.values():
            p = np.asarray(p)
            if p.shape != y.shape or not np.isfinite(p).all() or ((p < 0) | (p > 1)).any():
                raise ValueError(f"invalid probabilities: {name}")
    eligible = prior >= 2
    if not eligible.any() or not np.isfinite(current_gap[eligible]).all() or not np.isfinite(previous_gap[eligible]).all():
        raise ValueError("eligible rows or gaps missing")
    if (current_gap[eligible] < 0).any() or (previous_gap[eligible] < 0).any():
        raise ValueError("negative gap in eligible rows")
    contrasts = {"real_minus_one_step": ("real", "one_step"), "real_minus_recursive": ("real", "recursive")}
    def bins(values):
        return {"zero": values == 0, "0_to_24h": (values > 0) & (values <= 24),
                "24_to_168h": (values > 24) & (values <= 168), "over_168h": values > 168}
    cur, prev = bins(current_gap), bins(previous_gap)
    groups = {}
    for i, (cname, cmask) in enumerate(cur.items()):
        for j, (pname, pmask) in enumerate(prev.items()):
            groups[f"current_{cname}__previous_{pname}"] = _group(
                events, predictions, contrasts, eligible & cmask & pmask, repetitions, seed + 100 + i*4 + j)
    if sum(value["n"] for value in groups.values()) != int(np.sum(eligible)):
        raise ValueError("cross-gap groups do not partition eligible rows")
    real_gap, lag_gap = current_gap[eligible], previous_gap[eligible]
    def desc(a):
        return {"quantiles_hours_10_50_90": np.quantile(a, [.1,.5,.9]).tolist(),
                "zero_fraction": float(np.mean(a == 0)), "over_168h_fraction": float(np.mean(a > 168))}
    return {"primary": _group(events, predictions, contrasts, eligible, repetitions, seed),
            "overall": _group(events, predictions, contrasts, np.ones(len(y), dtype=bool), repetitions, seed + 1),
            "cross_gap_groups": groups,
            "gap_marginals": {"current": desc(real_gap), "previous": desc(lag_gap),
                              "log1p_hours_wasserstein_1": float(np.mean(np.abs(np.sort(np.log1p(real_gap)) - np.sort(np.log1p(lag_gap)))))},
            "primary_outcome": "event-weighted mean of seed-paired NLL real minus one-step on prior_count >= 2",
            "bootstrap": {"repetitions": repetitions, "seed": seed, "unit": "student",
                          "scope": "fixed selected models only; no training or selection uncertainty"},
            "scope": "reused development; exploratory model-input sensitivity, not causal learning effect"}
