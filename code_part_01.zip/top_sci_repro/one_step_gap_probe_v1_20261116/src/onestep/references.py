"""Pinned previous gap-control archive and row-aligned replay probabilities."""
from __future__ import annotations

import json
import numpy as np

from fixed_controls.references import (_verified_members, _csv, _identity, _integer_column,
                                       _check_identity, _check_probabilities, DATA_FINGERPRINT)

PRIOR_ARCHIVE = "115a3ddf9cda66d88a8e1aa66e1c41793d3ffa0bbc0349d7c3bb6198ae75745c"
PRIOR_RELEASE = "080bacd578829fc4d9f36fe409fbe2799438dbfa13a213e5c416b86908c970f2"


def load_reference(path, expected_hash):
    files = _verified_members(path, expected_hash)
    required = {"status.json", "config.json", "events.csv.gz", "old_provenance.json", "analysis_replay.json",
                "analysis_retrained.json", "pairing.json"}
    required.update(f"replay_{mode}_seed{seed}.csv.gz" for mode in ("true", "lag") for seed in (1,2))
    if not required.issubset(files):
        raise ValueError("previous result missing required scientific members")
    status, config = (json.loads(files[k]) for k in ("status.json", "config.json"))
    metadata = config.get("metadata", {})
    if (status.get("replay_completed_seeds") != [1,2] or status.get("retraining_completed_seeds") != [1,2] or
            status.get("test_evaluated") is not False or status.get("holdout_evaluated") is not False or
            config.get("test_evaluated") is not False or config.get("holdout_evaluated") is not False or
            config.get("protocol") != "lagged_same_kc_interval_v1_exploratory" or config.get("seeds") != [1,2] or
            metadata.get("data_fingerprint") != DATA_FINGERPRINT or
            metadata.get("previous_archive_sha256") != PRIOR_ARCHIVE or
            metadata.get("release", {}).get("manifest_sha256") != PRIOR_RELEASE):
        raise ValueError("previous result protocol or completed jobs differ")
    rows = _csv(files["events.csv.gz"])
    if not rows:
        raise ValueError("previous event list is empty")
    events = _identity(rows)
    for key in ("kc_idx", "prior_kc_count", "prior_student_count_selected_history"):
        events[key] = _integer_column(rows, key)
    events["same_kc_gap_hours"] = np.asarray([float(r["same_kc_gap_hours"]) if r["same_kc_gap_hours"] else np.nan
                                               for r in rows], dtype=np.float64)
    past, gap = events["prior_kc_count"], events["same_kc_gap_hours"]
    if (np.diff(events["record_idx"]) <= 0).any() or not np.isin(events["label"], [0,1]).all():
        raise ValueError("previous events are not strictly ordered binary data")
    if (past < 0).any() or not np.array_equal(np.isnan(gap), past == 0):
        raise ValueError("previous event gaps or counts differ")
    if not np.isfinite(gap[past > 0]).all() or (gap[past > 0] < 0).any():
        raise ValueError("previous repeated gaps are invalid")
    result = {"events": events, "events_bytes": files["events.csv.gz"], "true": {}, "recursive": {},
              "config": config, "previous_status_snapshot": status, "archive_sha256": expected_hash,
              "previous_analysis_replay": json.loads(files["analysis_replay.json"]),
              "previous_analysis_retrained": json.loads(files["analysis_retrained.json"]),
              "previous_pairing": json.loads(files["pairing.json"])}
    provenance = json.loads(files["old_provenance.json"])
    result["jobs"] = provenance["jobs"]
    for seed in (1,2):
        name = f"time_168h_seed{seed}"
        summary = result["jobs"][name]
        if summary.get("status") != "complete" or summary.get("mode") != "time_168h" or summary.get("seed") != seed:
            raise ValueError(f"invalid previous model summary: {name}")
        for member, condition in (("true", "true"), ("lag", "recursive")):
            pred = _csv(files[f"replay_{member}_seed{seed}.csv.gz"])
            _check_identity(_identity(pred), events)
            values = np.asarray([float(r["probability"]) for r in pred], dtype=np.float32)
            result[condition][seed] = _check_probabilities(values, len(rows))
    return result
