"""Single-step historical-gap sensitivity checks."""
