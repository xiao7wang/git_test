"""Read-only inputs, verified one-step sensitivity and result snapshots."""
from __future__ import annotations

import csv
import gzip
import hashlib
import json
import shutil
import time
from pathlib import Path

import numpy as np
import torch

from count_time.common import binary_losses, model_digest, sha256_file, write_json
from count_time.features import check_legacy_counts, construct
from dkvmn_ref.upstream import DKVMN
from fixed_controls.references import validate_features
from lagprobe.features import gap_diagnostics, lag_states
from overnight.model import CountHybrid
from overnight.package import package_results
from overnight.train import dense_history, evaluate
from .analysis import summarize
from .audit import inspect_ednet
from .features import one_step_states
from .predict import adjusted_probability


def _check_free(path, minimum):
    free = shutil.disk_usage(path).free
    print(json.dumps({"phase": "disk_check", "free_bytes": free, "minimum_free_bytes": minimum}), flush=True)
    if free < minimum:
        raise OSError(f"insufficient disk space: {free}; required {minimum}")
    return free


def _load_model(data, path, summary, seed, device):
    if sha256_file(path) != summary["best_checkpoint_sha256"]:
        raise ValueError(f"checkpoint SHA-256 mismatch for seed {seed}")
    ckpt = torch.load(path, map_location=device, weights_only=True)
    if (ckpt.get("mode") != "time_168h" or ckpt.get("seed") != seed or
            ckpt.get("epoch") != summary["best_epoch"] or
            abs(float(ckpt["dev_nll"]) - float(summary["dev"]["nll"])) > 1e-7):
        raise ValueError(f"checkpoint metadata mismatch for seed {seed}")
    dimensions = data.manifest["summary"]
    model = CountHybrid(DKVMN(num_c=int(dimensions["knowledges"]), dim_s=32, size_m=20, dropout=.2),
                        int(dimensions["students"]), int(dimensions["items"])).to(device)
    model.load_state_dict(ckpt["model_state"], strict=True)
    if model_digest(model.state_dict()) != summary["best_model_state_sha256"]:
        raise ValueError(f"model state digest mismatch for seed {seed}")
    return model


def _nll_difference(y, actual, expected):
    first = float(binary_losses(y, actual)[0].mean())
    second = float(binary_losses(y, expected)[0].mean())
    return abs(first - second)


def _write_event_features(path, events, dev, features, local, recursive):
    names = ("record_idx", "student_idx", "label", "kc_idx", "prior_kc_count", "same_kc_gap_hours",
             "previous_gap_hours", "real_success", "real_failure", "one_success", "one_failure",
             "recursive_success", "recursive_failure")
    real_s, real_f = features["states"]["C_real_time"]
    columns = (events["record_idx"], events["student_idx"], events["label"], events["kc_idx"],
               events["prior_kc_count"], events["same_kc_gap_hours"], local["previous_gap_hours"][dev],
               real_s[dev], real_f[dev], local["success"][dev], local["failure"][dev],
               recursive["success"][dev], recursive["failure"][dev])
    with gzip.open(path, "wt", encoding="utf-8", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(names)
        for i in range(len(dev)):
            writer.writerow([("" if np.isnan(x[i]) else format(float(x[i]), ".17g")) if j >= 5 else int(x[i])
                             for j, x in enumerate(columns)])


def _write_predictions(path, events, real, one, recursive, positive_change, negative_change):
    with gzip.open(path, "wt", encoding="utf-8", newline="") as out:
        writer = csv.writer(out)
        writer.writerow(("record_idx", "student_idx", "label", "real_probability", "one_step_probability",
                         "recursive_probability", "positive_logit_change", "negative_logit_change"))
        for i in range(len(real)):
            writer.writerow((int(events["record_idx"][i]), int(events["student_idx"][i]), int(events["label"][i]),
                             *(format(float(a[i]), ".17g") for a in (real, one, recursive, positive_change, negative_change))))


def run_in_memory(data, development_users, output_dir, reference, checkpoints, *, device="cpu",
                  repetitions=2000, sample_students=16, expected_population=None, project_root=None,
                  ednet_dir=None, min_free=0, run_metadata=None):
    output = Path(output_dir).resolve()
    if output.exists():
        raise FileExistsError(f"output already exists: {output}")
    if not development_users or device != "cpu" or min(repetitions, sample_students) < 1:
        raise ValueError("invalid development users, CPU device or analysis size")
    if project_root is None or ednet_dir is None:
        raise ValueError("bounded EDNet audit paths are required")
    output.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    path_status = output / "status.json"
    status = {"status": "running", "phase": "audit_and_features", "active_seed": None,
              "bridge_completed_seeds": [], "test_evaluated": False, "holdout_evaluated": False}
    write_json(path_status, status)
    try:
        _check_free(output, min_free)
        torch.set_num_threads(4)
        torch.use_deterministic_algorithms(True)
        try:
            audit = inspect_ednet(project_root, ednet_dir)
        except (OSError, RuntimeError, ValueError) as exc:
            audit = {"state": "audit_error_nonfatal", "error_type": type(exc).__name__,
                     "scope": "metadata only; audit failure does not change ASSIST analysis"}
        write_json(output / "ednet_audit.json", audit)
        print(json.dumps({"phase": "ednet_audit_complete", "state": audit["state"]}, ensure_ascii=False), flush=True)
        print(json.dumps({"phase": "features_start"}), flush=True)
        features = construct(data.arrays, development_users, fixed_discount=.8, half_life_hours=168.)
        legacy = check_legacy_counts(features)
        if not legacy["match"]:
            raise ValueError("undiscounted history audit failed")
        identity = validate_features(features, reference["events"])
        local, recursive = one_step_states(features), lag_states(features)
        write_json(output / "gap_diagnostics.json", gap_diagnostics(features, recursive))
        dev = np.flatnonzero(features["split"] == 1)
        prior = features["prior_kc_count"]
        eligible_all = prior >= 2
        eligible = dev[eligible_all[dev]]
        population = {"train": int(np.sum(features["split"] == 0)), "development": len(dev),
                      "development_students": int(len(np.unique(features["student"][dev]))),
                      "eligible": len(eligible), "eligible_students": int(len(np.unique(features["student"][eligible])))}
        if expected_population is not None and population != expected_population:
            raise ValueError(f"population mismatch: {population} != {expected_population}")
        if not np.array_equal(local["previous_gap_hours"][eligible_all], recursive["gap_hours"][eligible_all]):
            raise ValueError("previous same-KC gap differs from prior validated lag construction")
        actual_s, actual_f = features["states"]["C_real_time"]
        for name, actual in (("success", actual_s), ("failure", actual_f)):
            if not np.array_equal(local[name][prior <= 1], actual[prior <= 1]):
                raise ValueError(f"warm-up features differ for {name}")
        extended = dict(features)
        extended["states"] = dict(features["states"])
        extended["states"]["one_step"] = (local["success"], local["failure"])
        actual_history = dense_history(extended, "C_real_time", len(data.arrays["student_idx"]))
        local_history = dense_history(extended, "one_step", len(data.arrays["student_idx"]))
        events, ids = reference["events"], reference["events"]["record_idx"]
        sample_users = np.unique(events["student_idx"][events["prior_kc_count"] >= 2])[:sample_students]
        if not len(sample_users):
            raise ValueError("no eligible students for direct model bridge")
        sample_mask = np.isin(events["student_idx"], sample_users)
        sample_ids = ids[sample_mask]
        if not len(sample_ids):
            raise ValueError("direct model bridge has no development events")
        sample_hash = hashlib.sha256(np.asarray(sample_users, dtype="<i8").tobytes()).hexdigest()
        info = {"protocol": "one_step_previous_gap_input_sensitivity_v1_exploratory",
                "population": population, "identity": identity, "undiscounted_audit": legacy,
                "sample": {"rule": "first sorted eligible student IDs", "students": len(sample_users),
                           "events": len(sample_ids), "student_ids_sha256": sample_hash, "device": device},
                "half_life_hours": 168., "seeds": [1,2], "bootstrap_repetitions": repetitions,
                "bootstrap_seed": 20261116, "feedback": "predict before row-immediate feedback; platform timing unverified",
                "scope": "reused development; fixed models; exploratory and not a causal learning effect",
                "test_label_note": "prepared arrays include test labels; feature selection and scoring exclude test rows",
                "metadata": run_metadata or {}, "test_evaluated": False, "holdout_evaluated": False}
        write_json(output / "config.json", info)
        print(json.dumps({"phase": "features_complete", "population": population}), flush=True)
        predictions = {"real": {}, "one_step": {}, "recursive": {}}
        bridge, decomposition, contributions = {}, {}, {}
        weights_by_seed = {}
        for seed in (1,2):
            status.update(phase="analytic_and_direct_bridge", active_seed=seed)
            write_json(path_status, status)
            print(json.dumps({"phase": "bridge_start", "seed": seed, "sample_students": len(sample_users)}), flush=True)
            summary = reference["jobs"][f"time_168h_seed{seed}"]
            model = _load_model(data, checkpoints[seed], summary, seed, device)
            weights = model.history_weights.detach().cpu().numpy().copy()
            weights_by_seed[seed] = weights
            actual = np.asarray(reference["true"][seed], dtype=np.float64)
            old_recursive = np.asarray(reference["recursive"][seed], dtype=np.float64)
            args = (actual, events["kc_idx"], actual_s[dev], actual_f[dev])
            rec = adjusted_probability(*args, recursive["success"][dev], recursive["failure"][dev], weights)
            one = adjusted_probability(*args, local["success"][dev], local["failure"][dev], weights)
            old_probability_error = float(np.max(np.abs(rec["probability"] - old_recursive), initial=0.))
            old_nll_error = _nll_difference(events["label"], rec["probability"], old_recursive)
            old_real_nll_error = abs(float(binary_losses(events["label"], actual)[0].mean()) - float(summary["dev"]["nll"]))
            if old_probability_error > 1e-5 or old_nll_error > 1e-6 or old_real_nll_error > 1e-6:
                raise ValueError(f"full prior replay bridge failed for seed {seed}: {old_probability_error}, {old_nll_error}, {old_real_nll_error}")
            direct_true, _ = evaluate(model, data, sample_users, actual_history, device, 50, 8, sample_ids)
            direct_one, _ = evaluate(model, data, sample_users, local_history, device, 50, 8, sample_ids)
            true_error = float(np.max(np.abs(direct_true - actual[sample_mask]), initial=0.))
            one_error = float(np.max(np.abs(direct_one - one["probability"][sample_mask]), initial=0.))
            sample_y = np.asarray(events["label"])[sample_mask]
            true_nll_error = _nll_difference(sample_y, direct_true, actual[sample_mask])
            one_nll_error = _nll_difference(sample_y, direct_one, one["probability"][sample_mask])
            if max(true_error, one_error) > 1e-5 or max(true_nll_error, one_nll_error) > 1e-6:
                raise ValueError(f"direct CPU bridge failed for seed {seed}: {true_error}, {one_error}, {true_nll_error}, {one_nll_error}")
            warm = events["prior_kc_count"] <= 1
            warm_error = float(np.max(np.abs(one["probability"][warm] - actual[warm]), initial=0.))
            matching_gap = (events["prior_kc_count"] >= 2) & (events["same_kc_gap_hours"] == local["previous_gap_hours"][dev])
            matching_error = float(np.max(np.abs(one["probability"][matching_gap] - actual[matching_gap]), initial=0.))
            if max(warm_error, matching_error) > 1e-5:
                raise ValueError("warm-up or identical-gap prediction mismatch")
            predictions["real"][seed], predictions["one_step"][seed] = actual, one["probability"]
            predictions["recursive"][seed] = old_recursive
            contributions[seed] = one
            active = np.asarray(events["prior_kc_count"]) >= 2
            decomposition[str(seed)] = {"mean_positive_logit_change": float(np.mean(one["positive_logit_change"][active])),
                 "mean_negative_logit_change": float(np.mean(one["negative_logit_change"][active])),
                 "mean_abs_positive_logit_change": float(np.mean(np.abs(one["positive_logit_change"][active]))),
                 "mean_abs_negative_logit_change": float(np.mean(np.abs(one["negative_logit_change"][active]))),
                 "note": "descriptive model readout terms, not causal feedback effects"}
            bridge[str(seed)] = {"checkpoint_sha256": sha256_file(checkpoints[seed]),
                "probability_range": [float(actual.min()), float(actual.max())],
                "full_recursive_max_abs": old_probability_error, "full_recursive_nll_abs": old_nll_error,
                "old_real_nll_abs": old_real_nll_error, "sample_true_max_abs": true_error,
                "sample_one_step_max_abs": one_error, "sample_true_nll_abs": true_nll_error,
                "sample_one_step_nll_abs": one_nll_error, "warmup_max_abs": warm_error,
                "identical_gap_events": int(matching_gap.sum()), "identical_gap_max_abs": matching_error}
            status["bridge_completed_seeds"].append(seed)
            write_json(path_status, status)
            del model
        write_json(output / "bridge.json", bridge)
        write_json(output / "logit_contributions.json", decomposition)
        status.update(phase="bridge_complete", active_seed=None)
        write_json(path_status, status)
        _check_free(output, min_free)
        partial_files = ["status.json", "config.json", "ednet_audit.json", "gap_diagnostics.json", "bridge.json", "logit_contributions.json"]
        partial = package_results(output, "partial_bridge.zip", partial_files)
        print(json.dumps({"phase": "bridge_complete", "partial_archive": partial}, ensure_ascii=False), flush=True)
        status.update(phase="analysis", active_seed=None)
        write_json(path_status, status)
        result = summarize(events, local["previous_gap_hours"][dev], predictions, repetitions=repetitions)
        write_json(output / "analysis.json", result)
        _write_event_features(output / "event_features.csv.gz", events, dev, features, local, recursive)
        for seed in (1,2):
            one = contributions[seed]
            _write_predictions(output / f"predictions_seed{seed}.csv.gz", events, predictions["real"][seed],
                               predictions["one_step"][seed], predictions["recursive"][seed],
                               one["positive_logit_change"], one["negative_logit_change"])
        with (output / "readout_weights.csv").open("w", encoding="utf-8", newline="") as out:
            writer=csv.writer(out); writer.writerow(("seed","kc_idx","weight_success","weight_failure"))
            for seed in (1,2):
                for kc, (wp,wn) in enumerate(weights_by_seed[seed]):
                    writer.writerow((seed,kc,format(float(wp),".9g"),format(float(wn),".9g")))
        status.update(phase="packaging_final", active_seed=None)
        write_json(path_status, status)
        _check_free(output, min_free)
        files = partial_files + ["analysis.json", "event_features.csv.gz", "predictions_seed1.csv.gz",
                                 "predictions_seed2.csv.gz", "readout_weights.csv"]
        archive = package_results(output, "one_step_results.zip", files)
        status.update(status="complete", phase="complete", seconds=time.monotonic()-start, result_archive=archive)
        write_json(path_status, status)
        print(json.dumps({"phase": "complete", "archive": archive}, ensure_ascii=False), flush=True)
        return {"status": "complete", "archive": archive}
    except BaseException as exc:
        status.update(status="failed", error=repr(exc), seconds=time.monotonic()-start)
        write_json(path_status, status)
        raise
