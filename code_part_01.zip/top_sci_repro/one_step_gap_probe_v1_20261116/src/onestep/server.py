"""Production entry point; no training and no test/holdout scoring."""
from __future__ import annotations

import argparse
import json
import platform
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from lagprobe.references import load_legacy
from lagprobe.server import verify_previous_config
from .references import load_reference
from .runner import run_in_memory

ROOT = Path(__file__).resolve().parents[2]
LAST_SHA = "696d05378f1bf1e8bc4a93aaaf52384f4e4e6a656c73fd65ced16a14bbcfe950"
OLD_SHA = "115a3ddf9cda66d88a8e1aa66e1c41793d3ffa0bbc0349d7c3bb6198ae75745c"
LAST_RELEASE = "080bacd578829fc4d9f36fe409fbe2799438dbfa13a213e5c416b86908c970f2"
CHECKPOINTS = {1: "e1ca9aaaf7e9ee13919c35c16ebf37b5d4a899fa8b2c3c54b2040e5fedf41bc6",
               2: "69f091b28524b24da35f72519df23b4069c8ad12834f3b90bf7551877ac46c24"}
POPULATION = {"train": 1847688, "development": 126854, "development_students": 10036,
              "eligible": 101427, "eligible_students": 9116}


def verify_release():
    path = ROOT / "release_manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8"))
    entries = manifest.get("files")
    required = {"run_server.sh", "README.md", "contracts/protocol.json", "contracts/vendor_hashes.json",
                "checks/guard.py", "checks/verify.py", "contract_tests/fixture.py", "src/onestep/server.py",
                "src/onestep/runner.py", "src/onestep/features.py", "src/onestep/predict.py",
                "src/onestep/analysis.py", "src/onestep/references.py", "src/onestep/audit.py",
                "src/overnight/model.py", "src/overnight/train.py", "src/lagprobe/features.py", "vendor/pykt_LICENSE.txt"}
    if not isinstance(entries, dict) or not required.issubset(entries):
        raise ValueError("release manifest missing required entries")
    for name, expected in entries.items():
        candidate = (ROOT / name).resolve()
        if not candidate.is_relative_to(ROOT) or not candidate.is_file() or sha256_file(candidate) != expected:
            raise ValueError(f"release file is missing, unsafe or modified: {name}")
    vendor = json.loads((ROOT / "contracts/vendor_hashes.json").read_text(encoding="utf-8"))
    if any(entries.get(name) != digest for name, digest in vendor.items()):
        raise ValueError("protected previous source differs")
    return {"manifest_sha256": sha256_file(path), "file_count": len(entries)}


def protocol():
    p = json.loads((ROOT / "contracts/protocol.json").read_text(encoding="utf-8"))
    if (p["protocol"] != "one_step_previous_gap_input_sensitivity_v1_exploratory" or
            p["previous_result_sha256"] != LAST_SHA or p["original_result_sha256"] != OLD_SHA or
            p["previous_release_manifest_sha256"] != LAST_RELEASE or p["dataset_manifest_sha256"] != DATA_FINGERPRINT or
            p["checkpoint_sha256"] != {str(k): v for k,v in CHECKPOINTS.items()} or
            p["half_life_hours"] != 168. or p["population"] != POPULATION or p["seeds"] != [1,2] or
            p["bootstrap_repetitions"] != 2000 or p["bootstrap_seed"] != 20261116 or
            p["sample_first_eligible_students"] != 16 or p["cpu_batch_size"] != 8 or p["cpu_chunk_size"] != 50 or
            p["max_probability_bridge_difference"] != 1e-5 or p["max_nll_bridge_difference"] != 1e-6 or
            p["minimum_free_bytes"] != 1073741824 or p["test_evaluated"] is not False or p["holdout_evaluated"] is not False):
        raise ValueError("frozen protocol differs from implementation")
    return p


def validate_previous_pair(reference, original):
    if reference["events_bytes"] != original["events_bytes"]:
        raise ValueError("previous result and original model archive have different development event files")
    for seed in (1,2):
        name = f"time_168h_seed{seed}"
        if reference["jobs"][name] != original["jobs"][name]:
            raise ValueError(f"prior model summaries differ: {name}")
        if reference["jobs"][name]["best_checkpoint_sha256"] != CHECKPOINTS[seed]:
            raise ValueError(f"frozen checkpoint digest differs: {name}")
        if not np.array_equal(reference["true"][seed], original["predictions"]["time_168h"][seed]):
            raise ValueError(f"prior factual predictions differ: {name}")
    return {"event_file_match": True, "factual_predictions_match": [1,2],
            "source_hashes": SOURCE_HASHES}


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true")
    for name in ("project-dir", "data-dir", "previous-output-dir", "original-output-dir", "output-dir", "ednet-root", "ednet-dir"):
        parser.add_argument("--" + name)
    parser.add_argument("--ack-row-feedback", action="store_true")
    parser.add_argument("--ack-time-proxy", action="store_true")
    args = parser.parse_args(argv)
    release, p = verify_release(), protocol()
    print(json.dumps({"phase": "release_verified", **release}), flush=True)
    if args.verify_only:
        return 0
    required = (args.project_dir, args.data_dir, args.previous_output_dir, args.original_output_dir,
                args.output_dir, args.ednet_root, args.ednet_dir)
    if not all(required):
        parser.error("all source and output directories are required")
    if not args.ack_row_feedback or not args.ack_time_proxy:
        parser.error("row feedback and time proxy assumptions must be acknowledged")
    output, allowed = Path(args.output_dir).resolve(), (ROOT / "outputs").resolve()
    if not output.is_relative_to(allowed) or output == allowed or output.exists():
        raise ValueError("output must be a new subdirectory of this package's outputs")
    free = shutil.disk_usage(allowed).free
    if free < p["minimum_free_bytes"]:
        raise OSError(f"insufficient free space: {free}; required {p['minimum_free_bytes']}")
    previous, original = Path(args.previous_output_dir).resolve(), Path(args.original_output_dir).resolve()
    reference = load_reference(previous / "lag_gap_results.zip", LAST_SHA)
    old = load_legacy(original / "overnight_results.zip", OLD_SHA)
    versions = verify_previous_config(old)
    consistency = validate_previous_pair(reference, old)
    checkpoints = {s: original / "jobs" / f"time_168h_seed{s}" / "best_model.pt" for s in (1,2)}
    for seed, path in checkpoints.items():
        if not path.is_file() or sha256_file(path) != CHECKPOINTS[seed]:
            raise ValueError(f"previous checkpoint missing or hash mismatch: {seed}: {path}")
    print(json.dumps({"phase": "previous_sources_verified", "events": len(reference["events"]["label"])}), flush=True)
    data = load_prepared(args.project_dir, args.data_dir)
    arrays = data.arrays
    dev_users = development_users(arrays["student_idx"][arrays["split"] == 1])
    metadata = {"release": release, "prior_consistency": consistency, "previous_result_sha256": LAST_SHA,
                "original_result_sha256": OLD_SHA, "data_fingerprint": data.fingerprint, "versions": versions,
                "python": platform.python_version(), "torch": str(torch.__version__), "numpy": np.__version__,
                "pandas": pd.__version__, "device": "cpu", "free_bytes_at_start": free,
                "project_dir": str(Path(args.project_dir).resolve()), "data_dir": str(Path(args.data_dir).resolve())}
    result = run_in_memory(data, dev_users, output, reference, checkpoints, device="cpu",
                           repetitions=p["bootstrap_repetitions"], sample_students=p["sample_first_eligible_students"],
                           expected_population=p["population"], project_root=args.ednet_root, ednet_dir=args.ednet_dir,
                           min_free=p["minimum_free_bytes"], run_metadata=metadata)
    print(json.dumps({"status": result["status"], "archive": result["archive"]}, ensure_ascii=False), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
