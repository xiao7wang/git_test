"""Recover candidate model predictions from a fixed additive logit readout."""
from __future__ import annotations

import numpy as np


def adjusted_probability(actual_prob, kc, real_success, real_failure, alt_success, alt_failure, weights):
    p = np.asarray(actual_prob, dtype=np.float64)
    k = np.asarray(kc)
    vectors = [np.asarray(x, dtype=np.float32) for x in (real_success, real_failure, alt_success, alt_failure)]
    w = np.asarray(weights, dtype=np.float32)
    if p.ndim != 1 or not len(p) or k.shape != p.shape or any(x.shape != p.shape for x in vectors):
        raise ValueError("prediction, KC and count arrays do not align")
    if not np.isfinite(p).all() or ((p <= 0) | (p >= 1)).any():
        raise ValueError("saved probability is nonfinite or saturated; cannot invert sigmoid")
    if (w.ndim != 2 or w.shape[1] != 2 or not np.isfinite(w).all() or
            not np.equal(k, np.floor(k)).all() or (k < 0).any() or (k >= len(w)).any()):
        raise ValueError("invalid per-KC weights or indices")
    if any(not np.isfinite(x).all() or (x < 0).any() for x in vectors):
        raise ValueError("count values must be finite and nonnegative")
    wp, wn = w[k.astype(np.int64), 0], w[k.astype(np.int64), 1]
    rp, rn, ap, an = vectors
    rp_term, rn_term = wp * np.log1p(rp), wn * np.log1p(rn)
    ap_term, an_term = wp * np.log1p(ap), wn * np.log1p(an)
    # Match the original float32 addition of the two count contributions.
    old_correction = rp_term + rn_term
    new_correction = ap_term + an_term
    delta = new_correction.astype(np.float64) - old_correction.astype(np.float64)
    z = np.log(p) - np.log1p(-p) + delta
    exp_abs = np.exp(-np.abs(z))
    result = np.where(z >= 0, 1 / (1 + exp_abs), exp_abs / (1 + exp_abs))
    if not np.isfinite(result).all() or ((result < 0) | (result > 1)).any():
        raise ValueError("nonfinite adjusted probabilities")
    return {"probability": result,
            "positive_logit_change": ap_term.astype(np.float64) - rp_term.astype(np.float64),
            "negative_logit_change": an_term.astype(np.float64) - rn_term.astype(np.float64),
            "total_logit_change": delta}
