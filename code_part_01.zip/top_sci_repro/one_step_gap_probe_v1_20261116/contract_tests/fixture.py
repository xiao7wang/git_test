"""Complete synthetic reference, checkpoint, bridge and result packaging exercise."""
import copy
import csv
import gzip
import io
import json
from pathlib import Path

import numpy as np
import torch

from helpers import FakeData
from count_time.common import model_digest, sha256_file, write_json
from count_time.features import construct
from dkvmn_ref.upstream import DKVMN
from overnight.model import CountHybrid
from overnight.package import package_results
from overnight.train import dense_history, evaluate, _write_predictions
from lagprobe.features import lag_states


def make_reference(root):
    from onestep.references import load_reference
    data, users = FakeData(), set(range(6))
    f = construct(data.arrays, users)
    dev = np.flatnonzero(f["split"] == 1)
    students=f["student"]
    starts=np.r_[True,students[1:]!=students[:-1]]
    begin=np.maximum.accumulate(np.where(starts,np.arange(len(students)),0))
    events={"record_idx":f["record_idx"][dev],"student_idx":students[dev],
            "label":f["label"][dev].astype(np.int64),"kc_idx":f["kc"][dev],
            "prior_kc_count":f["prior_kc_count"][dev],
            "prior_student_count_selected_history":(np.arange(len(students))-begin)[dev],
            "same_kc_gap_hours":f["gap_hours"][dev]}
    old=root/"synthetic_prior"; old.mkdir(parents=True)
    buffer=io.StringIO(newline=""); writer=csv.writer(buffer); writer.writerow(events)
    for i in range(len(dev)):
        writer.writerow(["" if isinstance(events[k][i],(float,np.floating)) and np.isnan(events[k][i]) else events[k][i] for k in events])
    (old/"events.csv.gz").write_bytes(gzip.compress(buffer.getvalue().encode()))
    write_json(old/"status.json",{"status":"running","phase":"packaging_final", "replay_completed_seeds":[1,2],
                                  "retraining_completed_seeds":[1,2],"test_evaluated":False,"holdout_evaluated":False})
    write_json(old/"config.json",{"protocol":"lagged_same_kc_interval_v1_exploratory","seeds":[1,2],
             "test_evaluated":False,"holdout_evaluated":False,
             "metadata":{"data_fingerprint":"18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e",
                         "previous_archive_sha256":"115a3ddf9cda66d88a8e1aa66e1c41793d3ffa0bbc0349d7c3bb6198ae75745c",
                         "release":{"manifest_sha256":"080bacd578829fc4d9f36fe409fbe2799438dbfa13a213e5c416b86908c970f2"}}})
    recursive=lag_states(f); f["states"]["recursive"]=(recursive["success"],recursive["failure"])
    jobs={}; checkpoints={}
    torch.set_num_threads(1)
    for seed in (1,2):
        torch.manual_seed(seed)
        model=CountHybrid(DKVMN(num_c=3,dim_s=32,size_m=20,dropout=.2),6,3)
        with torch.no_grad(): model.history_weights.copy_(torch.tensor([[.4,-.2],[.2,-.1],[-.15,.3]]))
        values={}
        for mode, source in (("true","C_real_time"),("lag","recursive")):
            history=dense_history(f,source,len(data.arrays["student_idx"]))
            p,met=evaluate(model,data,np.array(sorted(users)),history,"cpu",5,3,events["record_idx"])
            _write_predictions(old/f"replay_{mode}_seed{seed}.csv.gz",events["record_idx"],data,p)
            values[mode]=(p,met)
        checkpoint=old/f"model_seed{seed}.pt"
        torch.save({"model_state":model.state_dict(),"epoch":3,"mode":"time_168h","seed":seed,
                    "dev_nll":values["true"][1]["nll"]},checkpoint)
        checkpoints[seed]=checkpoint
        jobs[f"time_168h_seed{seed}"]={"status":"complete","mode":"time_168h","seed":seed,"best_epoch":3,
              "dev":values["true"][1],"best_checkpoint_sha256":sha256_file(checkpoint),
              "best_model_state_sha256":model_digest(model.state_dict())}
    write_json(old/"old_provenance.json",{"jobs":jobs})
    for name in ("analysis_replay.json","analysis_retrained.json","pairing.json"):
        write_json(old/name,{})
    files=["status.json","config.json","events.csv.gz","old_provenance.json","analysis_replay.json",
           "analysis_retrained.json","pairing.json"]
    files += [f"replay_{mode}_seed{seed}.csv.gz" for mode in ("true","lag") for seed in (1,2)]
    package=package_results(old,"reference.zip",files)
    ref=load_reference(Path(package["path"]),package["sha256"])
    try:
        load_reference(Path(package["path"]),"0"*64)
        raise AssertionError("wrong archive digest passed")
    except ValueError:
        pass
    return data, users, ref, checkpoints


def exercise_full_run(root):
    from onestep.runner import run_in_memory
    data,users,ref,checkpoints=make_reference(root)
    out=root/"result"
    result=run_in_memory(data,users,out,ref,checkpoints,device="cpu",repetitions=20,
                         sample_students=6,expected_population=None,project_root=root,
                         ednet_dir=root/"missing_ednet",min_free=0)
    assert result["status"]=="complete"
    assert json.loads((out/"status.json").read_text(encoding="utf-8"))["status"]=="complete"
    assert (out/"partial_bridge.zip").is_file()
    try:
        run_in_memory(data,users,out,ref,checkpoints,device="cpu",repetitions=20,
                      sample_students=6,expected_population=None,project_root=root,ednet_dir=root/"missing_ednet",min_free=0)
        raise AssertionError("existing output unexpectedly overwritten")
    except FileExistsError:
        pass
    damaged=copy.deepcopy(ref)
    damaged["recursive"][1]=ref["recursive"][1].copy(); damaged["recursive"][1][0]=.001
    bad=root/"bad_reference"
    try:
        run_in_memory(data,users,bad,damaged,checkpoints,device="cpu",repetitions=20,
                      sample_students=6,expected_population=None,project_root=root,ednet_dir=root/"missing_ednet",min_free=0)
        raise AssertionError("damaged replay reference unexpectedly passed")
    except ValueError:
        assert json.loads((bad/"status.json").read_text(encoding="utf-8"))["status"]=="failed"
        assert not (bad/"partial_bridge.zip").exists()
    low=root/"insufficient_disk"
    try:
        run_in_memory(data,users,low,ref,checkpoints,device="cpu",repetitions=20,
                      sample_students=6,expected_population=None,project_root=root,ednet_dir=root/"missing_ednet",min_free=10**30)
        raise AssertionError("disk guard unexpectedly passed")
    except OSError:
        assert json.loads((low/"status.json").read_text(encoding="utf-8"))["status"]=="failed"
    return out
