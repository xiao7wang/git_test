import json
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np

from count_time.features import construct
from lagprobe.features import lag_states
from onestep.features import one_step_states
from onestep.predict import adjusted_probability
from onestep.analysis import summarize
from onestep.audit import inspect_ednet
from helpers import sample_arrays


def toy():
    return {"student_idx": np.array([0,0,0,0]), "item_idx": np.array([0,0,0,0]),
            "label": np.array([1.,0.,1.,0.]), "split": np.array([0,0,0,1]),
            "timestamp": np.array([0.,24.,192.,384.])*3600., "item_q": np.ones((1,1), dtype=np.int8)}


class StateContract(unittest.TestCase):
    def test_one_step_same_real_history_distinct_from_recursive(self):
        f = construct(toy(), {0})
        o, recursive = one_step_states(f), lag_states(f)
        rp, rn = f["states"]["C_real_time"]
        self.assertAlmostEqual(rp[3], .6579456711338628, places=11)
        self.assertAlmostEqual(rn[3], .22643091606597668, places=11)
        self.assertAlmostEqual(o["success"][3], .7264309160659767, places=11)
        self.assertAlmostEqual(o["failure"][3], .25, places=11)
        self.assertAlmostEqual(recursive["success"][3], .910167678003819, places=11)
        self.assertAlmostEqual(recursive["failure"][3], .45286183213195336, places=11)
        np.testing.assert_allclose(o["success"][:2], rp[:2], atol=0, rtol=0)
        np.testing.assert_allclose(o["failure"][:2], rn[:2], atol=0, rtol=0)
        self.assertTrue(np.isnan(o["previous_gap_hours"][:2]).all())
        np.testing.assert_array_equal(o["previous_gap_hours"][2:], [24.,168.])

    def test_no_current_or_future_label_or_future_time(self):
        base=toy(); old=one_step_states(construct(base,{0}))
        for i in range(len(base["label"])):
            changed={k:v.copy() for k,v in base.items()}; changed["label"][i]=1-changed["label"][i]
            new=one_step_states(construct(changed,{0}))
            for key in ("success","failure"):
                np.testing.assert_array_equal(old[key][:i+1],new[key][:i+1])
        changed={k:v.copy() for k,v in base.items()}; changed["timestamp"][-1]+=3600.
        new=one_step_states(construct(changed,{0}))
        np.testing.assert_array_equal(old["success"],new["success"])
        np.testing.assert_array_equal(old["failure"],new["failure"])

    def test_warmup_multigroup_zero_gap_and_invalid(self):
        a=sample_arrays(); f=construct(a,{0,1,2}); o=one_step_states(f)
        self.assertFalse(np.any(a["split"][f["record_idx"]]==2))
        warm=f["prior_kc_count"]<=1
        for name, real in zip(("success","failure"),f["states"]["C_real_time"]):
            np.testing.assert_array_equal(o[name][warm],real[warm])
        for badval in (-1.,float('nan')):
            bad=dict(f); bad["gap_hours"]=f["gap_hours"].copy()
            bad["gap_hours"][np.flatnonzero(f["prior_kc_count"]>0)[0]]=badval
            with self.assertRaises(ValueError):one_step_states(bad)
        z=toy(); z["timestamp"][:]=0
        rz=construct(z,{0}); oz=one_step_states(rz)
        np.testing.assert_array_equal(oz["success"],rz["states"]["C_real_time"][0])
        np.testing.assert_array_equal(oz["failure"],rz["states"]["C_real_time"][1])


class PredictionContract(unittest.TestCase):
    def test_formula_and_no_clipping_saturated_probabilities(self):
        p=np.array([.25,.75]); kc=np.array([0,0]); weights=np.array([[.4,-.2]])
        rp=np.array([1.,2.]); rn=np.array([3.,1.]); ap=np.array([2.,1.]); an=np.array([1.,3.])
        out=adjusted_probability(p,kc,rp,rn,ap,an,weights)
        dz=weights[0,0]*(math.log1p(2)-math.log1p(1))+weights[0,1]*(math.log1p(1)-math.log1p(3))
        expected=1/(1+math.exp(-(math.log(.25/.75)+dz)))
        self.assertAlmostEqual(out["probability"][0],expected,places=6)
        for invalid in (0.,1.,float('nan')):
            q=p.copy(); q[0]=invalid
            with self.assertRaises(ValueError):adjusted_probability(q,kc,rp,rn,ap,an,weights)
        r=rp.copy();r[0]=-1
        with self.assertRaises(ValueError):adjusted_probability(p,kc,r,rn,ap,an,weights)


class AnalysisAndAuditContract(unittest.TestCase):
    def test_paired_group_coverage(self):
        events={"label":np.array([1,0,1,0]),"student_idx":np.array([0,0,1,2]),
                "prior_kc_count":np.array([2,2,2,1]), "same_kc_gap_hours":np.array([0.,12.,200.,10.])}
        prev=np.array([0.,200.,12.,np.nan]); good=np.array([.8,.2,.8,.5]); weak=np.array([.4,.6,.4,.5])
        pred={"real":{1:good,2:good},"one_step":{1:weak,2:weak},"recursive":{1:weak,2:weak}}
        a=summarize(events,prev,pred,repetitions=20,seed=7)
        self.assertEqual(a["primary"]["n"],3)
        self.assertLess(a["primary"]["paired"]["real_minus_one_step"]["event_delta"],0)
        self.assertEqual(len(a["cross_gap_groups"]),16)
        self.assertEqual(sum(x["n"] for x in a["cross_gap_groups"].values()),3)

    def test_ednet_audit_reports_metadata_only_and_missing_is_nonfatal(self):
        with tempfile.TemporaryDirectory(prefix="ednet_meta_") as tmp:
            root=Path(tmp); target=root/"unified_experiments"/"data"/"ednet"; target.mkdir(parents=True)
            (target/"config.json").write_text(json.dumps({"kind":"ednet","timestamp_unit":"ms","access_token":"TOP_SECRET_9173"}),encoding="utf-8")
            (target/"interactions_raw.csv").write_text("CONFIDENTIAL_RAW_RESPONSE\n",encoding="utf-8")
            report=inspect_ednet(root,target)
            text=json.dumps(report,ensure_ascii=False)
            self.assertIn("timestamp_unit",text)
            self.assertNotIn("TOP_SECRET_9173",text)
            self.assertNotIn("CONFIDENTIAL_RAW_RESPONSE",text)
            missing=inspect_ednet(root,root/"missing_ednet")
            self.assertIsInstance(missing,dict)

