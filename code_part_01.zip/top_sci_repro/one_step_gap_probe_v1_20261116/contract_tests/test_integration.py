import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from fixture import exercise_full_run


class IntegrationContract(unittest.TestCase):
    def test_complete_synthetic_pipeline_and_archive(self):
        with tempfile.TemporaryDirectory(prefix="onestep_cpu_") as temp:
            output=exercise_full_run(Path(temp))
            with zipfile.ZipFile(output/"one_step_results.zip") as z:
                self.assertIsNone(z.testzip())
                self.assertIn("analysis.json",z.namelist())
                self.assertIn("ednet_audit.json",z.namelist())
                self.assertFalse(any(n.endswith(".pt") for n in z.namelist()))
                summary=json.loads(z.read("analysis.json"))
                self.assertEqual(summary["primary"]["n"],24)
