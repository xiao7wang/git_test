# Training-calibrated session control — exploratory ASSIST development

This project asks whether the previous session-versus-time comparison changes when the **mean one-transition retention coefficient** is matched on training events only. This is an exploratory check on an already repeatedly used development set, not causal inference or independent confirmation.

## Calibration

For each selected **training** row with prior same-KC history, let `g` be the same-KC elapsed hours and `k` the number of session boundaries crossed since that KC's prior event. Boundaries are still adjacent-student-event timestamp gaps greater than 10 hours. Find a scalar `0 < r <= 1` solving

`mean_train(r ** k) = mean_train(2 ** (-g / 168))`.

The calibration function receives only crossing counts, gaps, split codes, and prior counts. It does not receive answer labels and masks to `split == 0` before computing the target. It does not use any development or test time intervals to select `r`. If no repeated training KC events exist, if there are no crossings, or the target is infeasible, it fails and records the reason instead of silently changing the rule. Only the one-transition mean is matched; distributions, cumulative historical weights, and students' exposures may still differ. Training quantiles and the zero-crossing fraction are reported.

## Models and evaluation

* `S_calibrated`: three new seeds 0, 1, 2 using calibrated session retention `r`.
* `S_session`: the previous fixed session retention 0.5 predictions.
* `T_time`: the previous 168-hour continuous elapsed-time predictions.

All are the same PFA-inspired count model with student/item/KC biases and two effective KC count coefficients. New training uses the same epochs, early stopping, optimizer, batch size and selection protocol as the prior experiment. The previous ZIP is pinned by SHA-256; development event identities, timestamp-derived features, initial states and common-epoch training-order hashes must match. Previous models are reused as saved predictions, not silently retrained or replaced.

The primary exploratory contrast is `S_calibrated - T_time` on all development events, event NLL averaged over the three seeds. Secondary comparisons include calibrated versus fixed-0.5 S, each seed, student-macro NLL, AUC, Brier, and previously defined crossing groups. Intervals use paired student bootstrap and condition on selected fixed models; they omit training and model-selection uncertainty. The idea was chosen after examining development results, so this is not an independent preregistration.

The prepared-data loader reads stored arrays including test labels, but this run excludes test/holdout rows from feature construction, calibration, selection and scoring. Event timestamps proxy timing; immediate row feedback is assumed but not verified. This is not HiTSKT or evidence that a waiting-time intervention changes human forgetting.

## Execution and outputs

`bash run_server.sh server_calibrated_01` verifies the release and old results, checks at least 1 GiB disk space, performs synthetic CPU contracts, and requires CUDA for real data. It refuses existing output/log names, and does not delete, retry, install packages, or silently fall back to CPU. Source data and prior outputs are read only.

The final `calibrated_session_results.zip` contains calibration diagnostics, configuration, aggregate results, pseudonymous development event/student identities, labels, and all three groups of predictions. It excludes checkpoints and test predictions. Send it only in the intended research context. The archive's status is a packaging snapshot; check the external status and launch-log SUCCESS line.

The previous nine-model experiment reported 67.85 seconds from feature construction through analysis, excluding startup checks, data loading and final packaging. This one fits only three new models but rebuilds features twice and reuses two sets of prior predictions. Two to eight minutes is a rough estimate, not measured end-to-end; busy hardware or slower I/O may require more time.
