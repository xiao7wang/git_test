"""Pinned server entry: calibration on training and scoring on reused development only."""
import argparse
import json
import platform
import shutil
from pathlib import Path
import numpy as np
import torch
from count_time.common import sha256_file
from count_time.server import DATA_FINGERPRINT, SOURCE_HASHES, development_users, load_prepared
from .runner import run

ROOT=Path(__file__).resolve().parents[2]
REFERENCE_SHA="5201ed70314c5833bce1ad08410936e5f54b708ea02d913cbea8a0ad32e1fb4c"
POPULATION={"train":1847688,"development":126854,"development_students":10036,
            "eligible":101427,"eligible_students":9116}


def verify_release():
    path=ROOT/"release_manifest.json"
    entries=json.loads(path.read_text(encoding="utf-8"))["files"]
    required={"README.md","run_server.sh","tests/test_calibration.py","src/calibration_control/server.py",
              "src/calibration_control/calibrate.py","src/calibration_control/runner.py",
              "src/calibration_control/reference.py","src/calibration_control/analysis.py",
              "src/session_control/features.py","src/session_control/train.py",
              "references/session_control_results.zip"}
    if not required.issubset(entries) or entries["references/session_control_results.zip"]!=REFERENCE_SHA:
        raise ValueError("release manifest missing files or previous reference digest differs")
    for name,expected in entries.items():
        p=(ROOT/name).resolve()
        if not p.is_relative_to(ROOT) or not p.is_file() or sha256_file(p)!=expected:
            raise ValueError(f"missing, unsafe or modified release file: {name}")
    return {"manifest_sha256":sha256_file(path),"file_count":len(entries)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--verify-only",action="store_true")
    p.add_argument("--project-dir");p.add_argument("--data-dir");p.add_argument("--output-dir")
    args=p.parse_args()
    release=verify_release()
    print(json.dumps({"phase":"release_verified",**release}),flush=True)
    if args.verify_only:
        return 0
    if not all((args.project_dir,args.data_dir,args.output_dir)):
        p.error("project, data and output directories are required")
    output,allowed=Path(args.output_dir).resolve(),(ROOT/"outputs").resolve()
    if not output.is_relative_to(allowed) or output==allowed or output.exists():
        raise ValueError("output must be a new child of this package's outputs directory")
    free=shutil.disk_usage(allowed).free
    if free<1073741824:
        raise OSError(f"free disk space {free} bytes below 1 GiB")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA unavailable; no automatic fallback")
    reference=ROOT/"references"/"session_control_results.zip"
    if sha256_file(reference)!=REFERENCE_SHA:
        raise ValueError("previous result archive changed")
    data=load_prepared(args.project_dir,args.data_dir)
    users=development_users(data.arrays["student_idx"][data.arrays["split"]==1])
    metadata={"release":release,"dataset_manifest_sha256":DATA_FINGERPRINT,"source_sha256":SOURCE_HASHES,
              "previous_result_sha256":REFERENCE_SHA,"python":platform.python_version(),"numpy":np.__version__,
              "torch":str(torch.__version__),"gpu":torch.cuda.get_device_name(),"free_bytes":free}
    result=run(data.arrays,users,output,reference=reference,reference_sha=REFERENCE_SHA,device="cuda",
               expected_population=POPULATION,metadata=metadata)
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return 0


if __name__=="__main__":
    raise SystemExit(main())
