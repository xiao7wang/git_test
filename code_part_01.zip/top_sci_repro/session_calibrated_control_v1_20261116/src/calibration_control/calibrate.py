"""Match mean one-transition retention using training timestamps only."""
from __future__ import annotations
import math
import numpy as np


def calibrate(crossings, gap_hours, split, prior, half_life=168.):
    """Select r without outcomes or development rows; solve E_train[r**k]=E_train[2**(-gap/H)]."""
    crossings, gap, split, prior = map(np.asarray, (crossings, gap_hours, split, prior))
    if not crossings.ndim == gap.ndim == split.ndim == prior.ndim == 1:
        raise ValueError("features must be one-dimensional")
    if not (len(crossings) == len(gap) == len(split) == len(prior)):
        raise ValueError("features have different lengths")
    if not math.isfinite(float(half_life)) or half_life <= 0:
        raise ValueError("invalid time half-life")
    chosen = (split == 0) & (prior > 0)
    k = crossings[chosen]
    g = gap[chosen].astype(np.float64)
    if len(k) == 0 or not np.isfinite(k).all() or (k < 0).any() or (k != np.floor(k)).any():
        raise ValueError("no valid repeated-KC training crossings")
    if not np.isfinite(g).all() or (g < 0).any():
        raise ValueError("invalid training gap")
    k = k.astype(np.int64)
    if not (k > 0).any():
        raise ValueError("training set contains no repeated-KC session crossings")
    time_factor = np.exp2(-g / float(half_life))
    target = float(time_factor.mean())
    values, counts = np.unique(k, return_counts=True)
    floor = float(np.mean(k == 0))
    # r must be >0 and <=1, as required by the history builder.
    if target <= floor + 1e-12 or target > 1. + 1e-12:
        raise ValueError(f"training target {target} outside feasible interval ({floor}, 1]")
    if target >= 1. - 1e-15:
        r = 1.
    else:
        low, high = 0., 1.
        for _ in range(80):
            mid = (low + high) / 2.
            current = float(np.dot(counts, np.power(mid, values)) / len(k))
            if current < target:
                low = mid
            else:
                high = mid
        r = (low + high) / 2.
    session_factor = np.power(r, k)
    achieved = float(session_factor.mean())
    if not (0. < r <= 1.) or abs(achieved-target) > 1e-12:
        raise ArithmeticError("training mean calibration did not converge")
    q = [.0,.1,.25,.5,.75,.9,1.]
    return {"retention_per_session_boundary":r, "half_life_hours":float(half_life),
            "training_repeated_kc_events":len(k), "zero_crossing_fraction":floor,
            "target_mean_time_factor":target, "achieved_mean_session_factor":achieved,
            "absolute_mean_error":abs(achieved-target), "quantile_levels":q,
            "train_session_factor_quantiles":np.quantile(session_factor,q).tolist(),
            "train_time_factor_quantiles":np.quantile(time_factor,q).tolist(),
            "distinct_crossing_counts":len(values),
            "note":"train-only timestamps; matches mean one-transition factor, not distributions or full-history weights"}
