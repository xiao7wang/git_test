"""Seed-paired fixed-model student cluster analysis."""
import numpy as np
from count_time.analysis import _intervals
from count_time.common import binary_losses, metrics

MODES = ("S_calibrated", "S_session", "T_time")
CONTRASTS = {"S_calibrated_minus_T_time":("S_calibrated","T_time"),
             "S_calibrated_minus_S_fixed":("S_calibrated","S_session"),
             "T_time_minus_S_fixed":("T_time","S_session")}


def _group(y,students,preds,mask,repetitions,seed):
    ids=np.flatnonzero(mask)
    if not len(ids):
        return {"events":0,"students":0,"models":{},"paired":{}}
    y,students=y[ids],students[ids]
    losses,model_rows={},{}
    for mode in MODES:
        if set(preds[mode])!={0,1,2}:
            raise ValueError("missing prediction seed")
        ps=[np.asarray(preds[mode][s])[ids] for s in (0,1,2)]
        if any(not np.isfinite(p).all() or ((p<0)|(p>1)).any() for p in ps):
            raise ValueError("invalid probability")
        rows=[metrics(y,p,students) for p in ps]
        losses[mode]=[binary_losses(y,p)[0] for p in ps]
        model_rows[mode]={"per_seed":rows,"mean":{k:(None if any(r[k] is None for r in rows)
            else float(np.mean([r[k] for r in rows]))) for k in ("nll","student_macro_nll","auc","brier")}}
    means={m:np.mean(np.stack(losses[m]),axis=0) for m in MODES}
    columns=np.stack([means[a]-means[b] for a,b in CONTRASTS.values()],axis=1)
    intervals=_intervals(students,columns,repetitions,seed)
    paired={}
    for (name,(a,b)),entry in zip(CONTRASTS.items(),intervals):
        entry["per_seed_event_delta"]=[float(np.mean(losses[a][s]-losses[b][s])) for s in (0,1,2)]
        paired[name]=entry
    return {"events":len(ids),"students":len(np.unique(students)),"models":model_rows,"paired":paired}


def analyze(f,preds,repetitions=2000,seed=20261116):
    if set(preds)!=set(MODES) or repetitions<1:
        raise ValueError("invalid predictions or bootstrap count")
    dev=np.flatnonzero(f["split"]==1)
    y=f["label"][dev]; student=f["student"][dev]
    for mode in MODES:
        for p in preds[mode].values():
            if np.asarray(p).shape!=(len(dev),):
                raise ValueError("prediction length mismatch")
    prior,cross=f["prior_kc_count"][dev],f["session_crossings"][dev]
    groups={"all_development":np.ones(len(dev),dtype=bool),"prior_kc_at_least_2":prior>=2,
            "repeat_no_session_crossing":(prior>0)&(cross==0),
            "repeat_one_or_more_session_crossings":(prior>0)&(cross>0)}
    return {"scope":"previously used development set; exploratory",
            "primary":"S_calibrated_minus_T_time event NLL on all development, mean over 3 seeds",
            "bootstrap_repetitions":repetitions,"bootstrap_seed":seed,
            "uncertainty_note":"student bootstrap conditions on selected fixed models; selection not accounted for",
            "groups":{name:_group(y,student,preds,mask,repetitions,seed+i)
                      for i,(name,mask) in enumerate(groups.items())}}
