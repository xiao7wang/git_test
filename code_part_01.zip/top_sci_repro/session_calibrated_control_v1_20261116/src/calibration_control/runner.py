"""Train a training-calibrated session control and compare pinned prior predictions."""
import hashlib
import json
import time
import zipfile
from pathlib import Path
import numpy as np
from count_time.common import sha256_file, write_json
from session_control.features import build
from session_control.train import fit
from .analysis import analyze
from .calibrate import calibrate
from .reference import load_reference


def package(out):
    names=["status.json","config.json","calibration.json","summary.json","event_features.csv.gz"]
    for mode in ("S_calibrated","S_session","T_time"):
        for seed in (0,1,2):
            names.append(f"predictions/{mode}_seed{seed}.csv.gz")
    for seed in (0,1,2):
        names.extend([f"jobs/S_calibrated_seed{seed}/summary.json",f"jobs/S_calibrated_seed{seed}/history.json"])
    entries={n:sha256_file(out/n) for n in names}
    pending=out/"calibrated_session_results.zip.pending"; target=out/"calibrated_session_results.zip"
    if pending.exists() or target.exists():
        raise FileExistsError("result archive already exists")
    with zipfile.ZipFile(pending,"x",compression=zipfile.ZIP_STORED,allowZip64=True) as z:
        for name in names:
            z.write(out/name,arcname=name)
        z.writestr("manifest.json",json.dumps({"format":1,"files":entries},indent=2)+"\n")
    with zipfile.ZipFile(pending) as z:
        if z.testzip() is not None or len(z.namelist())!=len(entries)+1:
            raise ValueError("archive integrity check failed")
        for name,expected in entries.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=expected:
                raise ValueError(f"archive member mismatch: {name}")
    pending.replace(target)
    return {"path":str(target),"sha256":sha256_file(target),"members":len(names)+1}


def run(arrays,users,output,*,reference,reference_sha,strict_reference=True,device="cpu",
        epochs=20,patience=5,batch_size=8192,repetitions=2000,expected_population=None,metadata=None):
    out=Path(output)
    out.mkdir(parents=True,exist_ok=False)
    started=time.monotonic()
    status={"status":"running","phase":"features_and_calibration","test_evaluated":False,"holdout_evaluated":False}
    write_json(out/"status.json",status)
    try:
        baseline=build(arrays,users,threshold_hours=10.,retention=.5)
        dev=np.flatnonzero(baseline["split"]==1)
        observed={"train":int(np.sum(baseline["split"]==0)),"development":len(dev),
                  "development_students":len(np.unique(baseline["student"][dev])),
                  "eligible":int(np.sum(baseline["prior_kc_count"][dev]>=2)),
                  "eligible_students":len(np.unique(baseline["student"][dev][baseline["prior_kc_count"][dev]>=2]))}
        if expected_population is not None and observed!=expected_population:
            raise ValueError(f"population mismatch: {observed}")
        previous=load_reference(reference,reference_sha,baseline,strict=strict_reference)
        calibration=calibrate(baseline["session_crossings"],baseline["gap_hours"],baseline["split"],
                              baseline["prior_kc_count"],half_life=168.)
        write_json(out/"calibration.json",calibration)
        print(json.dumps({"phase":"calibration_complete",**calibration}),flush=True)
        f=build(arrays,users,threshold_hours=10.,retention=calibration["retention_per_session_boundary"])
        for name in ("record_idx","student","item","kc","label","split","timestamp","prior_kc_count",
                     "starts_session","session_crossings"):
            if not np.array_equal(f[name],baseline[name]):
                raise ValueError(f"calibrated feature identity differs: {name}")
        for a,b in zip(f["states"]["C_real_time"],baseline["states"]["C_real_time"]):
            if not np.array_equal(a,b):
                raise ValueError("continuous-time reference feature unexpectedly changed")
        del baseline
        config={"protocol":"training_mean_calibrated_session_control_v1_exploratory",
                "population":observed,"threshold_hours":10.,"half_life_hours":168.,
                "calibration_input":"only training timestamps, split membership, KC order and session boundaries; no labels",
                "calibration_equation":"mean_train(r**session_crossings)=mean_train(2**(-same_kc_gap_hours/168))",
                "chosen_retention_from_training":calibration["retention_per_session_boundary"],
                "modes":{"S_calibrated":"new training-calibrated session model",
                         "S_session":"previous fixed session retention 0.5 predictions",
                         "T_time":"previous continuous-time 168h predictions"},
                "model":"same PFA-inspired log-count architecture; same effective KC coefficient count",
                "seeds":[0,1,2],"max_epochs":epochs,"patience":patience,"batch_size":batch_size,
                "optimizer":"AdamW lr=.01 weight_decay=1e-5 clip=5","selection":"development event NLL",
                "primary":"S_calibrated minus T_time on all development event NLL, mean 3 seeds",
                "limitations":["matches only mean one-transition factor, not distributions or cumulative history weights",
                    "reused development set; exploratory", "event-time proxy; row-immediate feedback unverified",
                    "test arrays loaded but test labels excluded from features and scoring"],
                "test_evaluated":False,"holdout_evaluated":False,"metadata":metadata or {}}
        write_json(out/"config.json",config)
        (out/"event_features.csv.gz").write_bytes(previous["events_gz"])
        predictions={"S_calibrated":{},**previous["predictions"]}
        (out/"predictions").mkdir(exist_ok=False)
        for key,data in previous["prediction_files"].items():
            (out/"predictions"/f"{key}.csv.gz").write_bytes(data)
        jobs={}; pairing={}
        for seed in (0,1,2):
            status.update(phase="training",seed=seed)
            write_json(out/"status.json",status)
            result=fit(f,"S_calibrated",seed,out/"jobs"/f"S_calibrated_seed{seed}",device=device,
                       epochs=epochs,patience=patience,batch_size=batch_size)
            predictions["S_calibrated"][seed]=result["probability"]
            jobs[f"S_calibrated_seed{seed}"]=result["summary"]
            old_initial={previous["initial"][f"{mode}_{seed}"] for mode in ("S_session","T_time")}
            if old_initial!={result["summary"]["initial_state_sha256"]}:
                raise ValueError(f"seed {seed} initial state does not match previous models")
            lengths=[len(result["history"])] + [len(previous["histories"][m][seed]) for m in ("S_session","T_time")]
            for e in range(min(lengths)):
                values={result["history"][e]["train_order_sha256"]}
                values.update(previous["histories"][m][seed][e]["train_order_sha256"] for m in ("S_session","T_time"))
                if len(values)!=1:
                    raise ValueError(f"seed {seed} epoch {e+1} training order mismatch")
            pairing[str(seed)]={"initial_state_match":True,"common_epoch_orders_match":min(lengths)}
            source=out/"jobs"/f"S_calibrated_seed{seed}"/"dev_predictions.csv.gz"
            (out/"predictions"/f"S_calibrated_seed{seed}.csv.gz").write_bytes(source.read_bytes())
        status.update(phase="analysis",seed=None)
        write_json(out/"status.json",status)
        summary={"status":"complete","calibration":calibration,"jobs":jobs,"pairing":pairing,
                 "analysis":analyze(f,predictions,repetitions=repetitions),
                 "seconds_before_packaging":time.monotonic()-started,
                 "test_evaluated":False,"holdout_evaluated":False}
        write_json(out/"summary.json",summary)
        status.update(status="complete",phase="packaging_snapshot",seconds=time.monotonic()-started)
        write_json(out/"status.json",status)
        archive=package(out)
        status.update(phase="complete",archive=archive,seconds=time.monotonic()-started)
        write_json(out/"status.json",status)
        return {"status":"complete","archive":archive}
    except BaseException as exc:
        status.update(status="failed",phase="failed",error=repr(exc),seconds=time.monotonic()-started)
        write_json(out/"status.json",status)
        raise
