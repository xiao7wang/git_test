"""Verify the immediately preceding completed experiment and event identity."""
import gzip
import json
import zipfile
import numpy as np
import pandas as pd
from count_time.common import sha256_file


def _read_csv(z, name):
    with z.open(name) as raw, gzip.GzipFile(fileobj=raw) as stream:
        return pd.read_csv(stream, float_precision="round_trip")


def load_reference(path, expected_sha, f, *, strict=True):
    if sha256_file(path) != expected_sha:
        raise ValueError("previous result archive SHA-256 mismatch")
    with zipfile.ZipFile(path) as z:
        if z.testzip() is not None or len(z.namelist()) != len(set(z.namelist())):
            raise ValueError("previous result ZIP integrity failed")
        config = json.loads(z.read("config.json"))
        summary = json.loads(z.read("summary.json"))
        if (config.get("protocol") != "global_session_boundary_count_v1_exploratory" or
            config.get("session_threshold_hours") != 10. or config.get("session_retention_per_boundary") != .5 or
            config.get("time_half_life_hours") != 168. or config.get("seeds") != [0,1,2] or
            summary.get("status") != "complete" or summary.get("test_evaluated") is not False or
            summary.get("holdout_evaluated") is not False):
            raise ValueError("previous reference protocol differs")
        if strict:
            meta = config.get("metadata",{})
            if (meta.get("dataset_manifest_sha256") != "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e" or
                meta.get("release",{}).get("manifest_sha256") != "b7d5b562c1e90d17d9eb2f07106590baf3e5901516260c6286ba6ea35b3ccf53"):
                raise ValueError("previous source fingerprints differ")
        events = _read_csv(z,"event_features.csv.gz")
        dev = np.flatnonzero(f["split"] == 1)
        for column, name in (("record_idx","record_idx"),("student_idx","student"),("label","label"),
                             ("kc_idx","kc"),("prior_kc_count","prior_kc_count"),
                             ("starts_session","starts_session"),("same_kc_session_crossings","session_crossings")):
            if not np.array_equal(events[column].to_numpy(),f[name][dev]):
                raise ValueError(f"old development event identity differs: {column}")
        for column, name in (("same_kc_gap_hours","gap_hours"),
                             ("previous_global_event_gap_hours","global_gap_hours")):
            if not np.allclose(events[column].to_numpy(),f[name][dev],atol=1e-10,rtol=0,equal_nan=True):
                raise ValueError(f"old development event time differs: {column}")
        predictions, histories, initial, prediction_files = {}, {}, {}, {}
        for mode in ("S_session","T_time"):
            predictions[mode] = {}
            histories[mode] = {}
            for seed in (0,1,2):
                base = f"jobs/{mode}_seed{seed}"
                table = _read_csv(z,base+"/dev_predictions.csv.gz")
                for column,name in (("record_idx","record_idx"),("student_idx","student"),("label","label")):
                    if not np.array_equal(table[column].to_numpy(),f[name][dev]):
                        raise ValueError("previous prediction identity mismatch")
                p = table.probability.to_numpy(dtype=np.float64)
                if not np.isfinite(p).all() or ((p<0)|(p>1)).any():
                    raise ValueError("invalid previous predictions")
                predictions[mode][seed] = p
                prediction_files[f"{mode}_seed{seed}"] = z.read(base+"/dev_predictions.csv.gz")
                histories[mode][seed] = json.loads(z.read(base+"/history.json"))
                job = json.loads(z.read(base+"/summary.json"))
                if job.get("status") != "complete":
                    raise ValueError("previous model not complete")
                initial[f"{mode}_{seed}"] = job["initial_state_sha256"]
        return {"predictions":predictions,"histories":histories,"initial":initial,
                "prediction_files":prediction_files, "events_gz":z.read("event_features.csv.gz"),"config":config}
