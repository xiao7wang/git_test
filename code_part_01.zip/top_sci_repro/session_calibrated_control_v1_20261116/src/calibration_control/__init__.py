"""Exploratory training-only calibration for session-decay controls."""
