import copy
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
import numpy as np
from count_time.common import sha256_file
from calibration_control.calibrate import calibrate
from calibration_control.runner import run
from session_control.runner import run as previous_run


def toy():
    users,items,labels,splits,timestamps=[],[],[],[],[]
    for u in range(8):
        users += [u]*6
        items += [0,1,1,0,1,0]
        labels += [(u+1)%2,u%2,1,(u+1)%2,u%2,1]
        splits += [0,0,0,0,1,2]
        timestamps += [0,36000,72001,108002,108002,200000]
    return {"student_idx":np.array(users),"item_idx":np.array(items),"label":np.array(labels),
            "split":np.array(splits),"timestamp":np.array(timestamps,dtype=float),
            "item_q":np.array([[1,0],[0,1]])}


class CalibrationContracts(unittest.TestCase):
    def test_formula_and_no_development_dependence(self):
        k=np.array([0,1,2,12,100]); g=np.array([10.,50.,200.,60.,80.])
        split=np.array([0,0,0,1,2]); prior=np.ones(5,dtype=int)
        result=calibrate(k,g,split,prior)
        r=result["retention_per_session_boundary"]
        expected=np.exp2(-g[:3]/168.).mean()
        self.assertAlmostEqual(np.power(r,k[:3]).mean(),expected,places=12)
        k2=k.copy();k2[3:]=[0,0]
        g2=g.copy();g2[3:]=[1e8,1e8]
        self.assertEqual(result,calibrate(k2,g2,split,prior))
        self.assertEqual(result["training_repeated_kc_events"],3)

    def test_infeasible_and_missing_training_stop(self):
        with self.assertRaisesRegex(ValueError,"outside feasible interval"):
            calibrate(np.array([0,0,1]),np.array([10000.,10000.,10000.]),np.zeros(3),np.ones(3))
        with self.assertRaisesRegex(ValueError,"no valid"):
            calibrate(np.array([0]),np.array([0.]),np.array([1]),np.array([1]))
        with self.assertRaisesRegex(ValueError,"no repeated-KC session"):
            calibrate(np.array([0,0]),np.array([2.,3.]),np.array([0,0]),np.array([1,1]))

    def test_synthetic_prior_and_full_pipeline(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            old=previous_run(toy(),set(range(8)),root/"old",device="cpu",epochs=2,patience=3,batch_size=16,repetitions=10)
            ref=Path(old["archive"]["path"]); out=root/"new"
            result=run(toy(),set(range(8)),out,reference=ref,reference_sha=sha256_file(ref),strict_reference=False,
                       device="cpu",epochs=2,patience=3,batch_size=16,repetitions=10)
            self.assertEqual(result["status"],"complete")
            summary=json.loads((out/"summary.json").read_text())
            self.assertEqual(set(summary["jobs"]),{f"S_calibrated_seed{s}" for s in (0,1,2)})
            self.assertTrue(all(v["initial_state_match"] for v in summary["pairing"].values()))
            with zipfile.ZipFile(result["archive"]["path"]) as z:
                self.assertIsNone(z.testzip())
                self.assertIn("calibration.json",z.namelist())
                self.assertIn("predictions/T_time_seed0.csv.gz",z.namelist())
            with self.assertRaises(FileExistsError):
                run(toy(),set(range(8)),out,reference=ref,reference_sha=sha256_file(ref),strict_reference=False,
                    device="cpu",epochs=1,repetitions=1)
            bad=root/"bad"
            with self.assertRaisesRegex(ValueError,"SHA-256 mismatch"):
                run(toy(),set(range(8)),bad,reference=ref,reference_sha="0"*64,strict_reference=False,
                    device="cpu",epochs=1,repetitions=1)
            self.assertEqual(json.loads((bad/"status.json").read_text())["status"],"failed")
            self.assertFalse((bad/"calibrated_session_results.zip").exists())


if __name__=="__main__":
    unittest.main()
