"""Read-only CPU check of four pinned A1/factorial-none checkpoint pairs.

No project imports, model construction, data loading, forward pass, or training.
The only output is a NEW JSON report; existing reports are never overwritten.
"""
import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import torch

BASE = "/home/wangxiao/QCCDM/top_sci_repro"
FINGERPRINTS = {
    "assist": "18fc25062584667f96ace30d7baa2e548a7ab369574e56677df1cb92483d101e",
    "ednet": "fa8198274d35d980169ba71acf3792cdd2e9892eb28504fc1081a4ae6179da09",
}
# SHA256 pins copied from the two accepted result archives, not guessed names.
PINS = (
    ("assist", 1, 2, "6ec8f2212375edcf7522058a969828e54d78f2c1ff35c5b61769c92fc70afc32", "62b4cd5d5306a4d9b762e3c88a48766be394846e75efbac863651c0402307451"),
    ("assist", 2, 2, "f9e65286baf972e794b15a28e453524c3b4a1a46a5f3b506e3eba1d543b963a8", "0a4c3f5dedb9db1e1098a5e152534c3703075656d31235277071cfb325441704"),
    ("ednet", 1, 3, "b549b5e2b2c106c53d6b84ae021b03d16ab53af979f6d24b68b65580ff3304af", "4ea0f5cf2996bc53afaeb32749b3f6cc1efa9811f8078a542990558777b57935"),
    ("ednet", 2, 2, "4190dbbcd4939496b29e2b1e9673afcb840e7c4aac32f6bf761dc2c4c7f1bcf4", "eaee2e5d1975f13a7466d413943eb6cf1a32096a614a20f36534dd23e82b698b"),
)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def tensor_digest(state):
    h = hashlib.sha256()
    for name, tensor in sorted(state.items()):
        if not isinstance(name, str) or not isinstance(tensor, torch.Tensor):
            raise ValueError("model_state must contain named tensors only")
        a = tensor.detach().cpu().contiguous().numpy()
        h.update(json.dumps([name, str(a.dtype), list(a.shape)], separators=(",", ":")).encode())
        h.update(a.tobytes())
    return h.hexdigest()


def compare_states(left, right):
    if not left or not right:
        raise ValueError("Empty model_state")
    common = sorted(set(left) & set(right))
    differences = []
    for name in common:
        a, b = left[name], right[name]
        if not isinstance(a, torch.Tensor) or not isinstance(b, torch.Tensor):
            raise ValueError("Unexpected non-tensor state entry: " + name)
        if a.shape != b.shape or a.dtype != b.dtype:
            differences.append({"name": name, "reason": "shape_or_dtype", "left_shape": list(a.shape),
                                "right_shape": list(b.shape), "left_dtype": str(a.dtype), "right_dtype": str(b.dtype)})
        elif not torch.isfinite(a).all().item() or not torch.isfinite(b).all().item():
            differences.append({"name": name, "reason": "nonfinite"})
        elif not torch.equal(a, b):
            differences.append({"name": name, "reason": "values", "max_absolute_difference": float((a.double() - b.double()).abs().max())})
    missing_left, missing_right = sorted(set(right) - set(left)), sorted(set(left) - set(right))
    return {
        "success": not differences and not missing_left and not missing_right,
        "comparison": "Exact torch.equal values plus identical keys, shapes, dtypes; no tolerance",
        "left_tensor_digest": tensor_digest(left), "right_tensor_digest": tensor_digest(right),
        "left_tensor_count": len(left), "right_tensor_count": len(right),
        "missing_from_left": missing_left, "missing_from_right": missing_right,
        "different_tensors": differences,
    }


def load_pinned(path, expected):
    actual = sha(path)
    if actual != expected:
        raise ValueError(f"Checkpoint file identity changed: {path}; expected={expected}; actual={actual}")
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    if not isinstance(checkpoint, dict) or "model_state" not in checkpoint:
        raise ValueError("Invalid checkpoint schema: " + str(path))
    return checkpoint


def paths(base, dataset, seed):
    old_run = "server_assist_baselines_e20_p5_v1_rerun01" if dataset == "assist" else "server_ednet_baselines_e20_p5_v1"
    old = base / "uctp_cd_clean_research/outputs" / old_run / f"unit_write_seed{seed}/best_model.pt"
    new = base / f"uctp_cd_time_factorial_v1/outputs/server_{dataset}_full_factorial_e20_p5_01/unit_write_none_seed{seed}/best_model.pt"
    return old, new


def check_metadata(old, new, dataset, epoch):
    for checkpoint in (old, new):
        if checkpoint.get("data_fingerprint") != FINGERPRINTS[dataset] or checkpoint.get("epoch") != epoch:
            raise ValueError("Dataset or best epoch changed")
        if checkpoint["model_config"].get("variant") != "unit_write":
            raise ValueError("Not unit_write")
    config = new["model_config"]
    if new.get("model_family") != "time_factorial_v1" or config.get("time_mode") != "none" or config.get("decay_rate_per_hour") != 0:
        raise ValueError("Not factorial-none")
    for key in ("num_students", "num_items", "num_knowledges", "ncd_hidden_dim", "variant"):
        if key not in old["model_config"] or old["model_config"][key] != config.get(key):
            raise ValueError("Shared architecture mismatch: " + key)


def save_new(path, report):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2, allow_nan=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-dir", type=Path, default=Path(BASE))
    parser.add_argument("--output-json", type=Path, required=True)
    args = parser.parse_args()
    if args.output_json.exists() or not args.output_json.parent.is_dir():
        raise SystemExit("Use a NEW report path in an existing directory; no overwriting or directory creation.")
    torch.set_num_threads(2)
    start = time.monotonic()
    report = {"scope": "Checkpoint tensor identity only; not model-function or performance equivalence",
              "device": "cpu", "torch": str(torch.__version__), "python": sys.version,
              "script_sha256": sha(__file__), "trained": False, "test_evaluated": False,
              "model_constructed": False, "data_loaded": False, "inputs_modified": False, "pairs": []}
    for dataset, seed, epoch, oldsha, newsha in PINS:
        oldpath, newpath = paths(args.base_dir.resolve(), dataset, seed)
        entry = {"dataset": dataset, "seed": seed, "old_checkpoint": str(oldpath), "new_checkpoint": str(newpath),
                 "expected_old_file_sha256": oldsha, "expected_new_file_sha256": newsha}
        print(f"Checking {dataset} seed{seed}: CPU read only", flush=True)
        try:
            old, new = load_pinned(oldpath, oldsha), load_pinned(newpath, newsha)
            check_metadata(old, new, dataset, epoch)
            entry.update(compare_states(old["model_state"], new["model_state"]))
            if sha(oldpath) != oldsha or sha(newpath) != newsha:
                raise ValueError("Input file changed during inspection")
            entry["input_files_unchanged"] = True
            del old, new
        except Exception as exc:
            entry.update(success=False, error=f"{type(exc).__name__}: {exc}")
        report["pairs"].append(entry)
        print(f"  {'PASS' if entry['success'] else 'FAIL'} {dataset} seed{seed}", flush=True)
    report["success"] = all(row["success"] for row in report["pairs"])
    report["seconds"] = time.monotonic() - start
    save_new(args.output_json, report)
    print(f"{'ALL_4_PAIRS_EXACT' if report['success'] else 'IDENTITY_CHECK_FAILED'}; report: {args.output_json.resolve()}", flush=True)
    raise SystemExit(0 if report["success"] else 1)


if __name__ == "__main__":
    main()
