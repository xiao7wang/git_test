"""Bounded EDNet upstream-source collection. Read only; no training or imports.

Writes one NEW ZIP. Does not enter raw-user folders, read pickle objects, read
full interaction CSVs, change source data, rebuild splits, or run found scripts.
"""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import time
import zipfile

CODE_ROOTS = [
    ("top_sci_repro/scripts", 4),
    ("top_sci_repro/unified_experiments/scripts", 4),
    ("top_sci_repro/unified_experiments", 1),
    ("top_sci_repro", 0),
    ("qccdm\u6539\u8fdb\u4ee3\u7801/scripts", 4),
    ("qccdm\u6539\u8fdb\u4ee3\u7801", 0),
    ("", 0),
]
META_DIRS = [
    "top_sci_repro/unified_experiments/data/ednet",
    "top_sci_repro/unified_experiments/splits/ednet",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet",
    "qccdm\u6539\u8fdb\u4ee3\u7801/data/ednet_kt1_time",
]
SKIP = {"data", "data_raw", "raw", "KT1", "KT2", "KT3", "KT4", "splits",
        "trace_cd_data", "outputs", "logs", "results", "repos", "__pycache__", "node_modules"}
TERMS = ("solving_id", "raw_user_map", "raw_item_map", "question_id", "user_mapping",
         "item_mapping", "TotalData", "interactions_raw", "unified_experiments",
         "to_csv", "read_csv", "meta.pkl", "train_ratio", "valid_ratio")
MAX_TOTAL = 32 * 1024 * 1024
MAX_FILE = 8 * 1024 * 1024


def collect(root, output):
    root = Path(root).resolve(strict=True)
    output = Path(output)
    if not root.is_dir() or root == Path(root.anchor):
        raise ValueError("Expected a concrete project root")
    if output.exists():
        raise FileExistsError("Output exists: refusing overwrite. Send that ZIP or choose a new output name.")
    if not output.parent.is_dir():
        raise ValueError("Output parent must exist")
    started = time.monotonic()
    report = {"date": "2026-10-27", "scope_root": str(root), "read_only_sources": True,
              "trained": False, "pickle_loaded": False, "candidate_scripts_executed": False,
              "feedback_boundaries_verified": False, "files": [], "issues": [], "directories": [],
              "code_scopes": [], "candidate_scripts": [], "source_bytes_included": 0,
              "notes": ["Bounded source search, not exhaustive server inventory.",
                        "Missing paths are reported, not replaced by guessed files.",
                        "Directory listings may name pickle files, but pickle contents are not read.",
                        "CSV samples are prefixes only. Their rows are not automatically aligned to raw KT1."]}
    seen = set()

    def error(path, exc):
        report["issues"].append({"path": str(path), "error": str(exc)})

    def safe(path):
        p = path.resolve(strict=True)
        p.relative_to(root)
        return p

    def put(z, path, data, kind="complete_file", member=None):
        rel = path.relative_to(root).as_posix()
        member = member or "sources/" + rel
        if member in seen:
            return
        if len(data) > MAX_FILE or report["source_bytes_included"] + len(data) > MAX_TOTAL:
            raise ValueError("Pack size budget exceeded; not included")
        z.writestr(member, data)
        seen.add(member)
        report["source_bytes_included"] += len(data)
        report["files"].append({"source": str(path), "member": member, "kind": kind,
                                "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

    def read_small(path, limit=MAX_FILE):
        p = safe(path)
        if not p.is_file() or p.stat().st_size > limit:
            raise ValueError("Not a regular file or exceeds read ceiling")
        with p.open("rb") as f:
            data = f.read(limit + 1)
        if len(data) > limit:
            raise ValueError("File exceeded read ceiling")
        return data

    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as z:
        for rel in META_DIRS:
            folder = root / rel
            entry = {"path": str(folder), "exists": folder.is_dir(), "entries": []}
            report["directories"].append(entry)
            if not folder.is_dir():
                continue
            try:
                safe(folder)
                # These are small metadata directories; never raw-user directories.
                with os.scandir(folder) as stream:
                    items = []
                    for i, e in enumerate(stream):
                        if i >= 500:
                            error(folder, "Directory listing capped at 500 entries")
                            break
                        items.append(e)
                for e in sorted(items, key=lambda x: x.name):
                    path = folder / e.name
                    if e.is_symlink():
                        entry["entries"].append({"name": e.name, "symlink_skipped": True})
                        continue
                    entry["entries"].append({"name": e.name, "directory": e.is_dir(follow_symlinks=False),
                                              "bytes": e.stat(follow_symlinks=False).st_size})
                    if not e.is_file(follow_symlinks=False):
                        continue
                    try:
                        lower = e.name.lower()
                        if lower.endswith(".json") and any(t in lower for t in ("config", "map", "summary", "manifest", "meta")):
                            put(z, path, read_small(path))
                        elif e.name in {"q.csv", "q_matrix.npy"}:
                            put(z, path, read_small(path))
                        elif lower.endswith(".csv"):
                            buffer = io.StringIO(newline="")
                            with safe(path).open("r", encoding="utf-8-sig", newline="") as f:
                                reader = csv.reader(f)
                                writer = csv.writer(buffer)
                                for _ in range(6):
                                    row = next(reader, None)
                                    if row is None:
                                        break
                                    writer.writerow(row)
                            put(z, path, buffer.getvalue().encode("utf-8"), "header_plus_at_most_5_rows",
                                "samples/" + path.relative_to(root).as_posix())
                    except (OSError, ValueError, csv.Error) as exc:
                        error(path, exc)
            except (OSError, ValueError) as exc:
                error(folder, exc)

        visited = set()
        scanned = 0
        stop = False
        for rel, max_depth in CODE_ROOTS:
            folder = root / rel
            report["code_scopes"].append({"path": str(folder), "max_depth": max_depth, "exists": folder.is_dir()})
            if not folder.is_dir() or stop:
                continue
            try:
                safe(folder)
            except (OSError, ValueError) as exc:
                error(folder, exc)
                continue
            for current, dirs, files in os.walk(folder, topdown=True, followlinks=False,
                                                onerror=lambda e: error(folder, e)):
                here = Path(current)
                depth = len(here.relative_to(folder).parts)
                dirs[:] = sorted(d for d in dirs if d not in SKIP and not d.startswith(".")
                                 and not (here / d).is_symlink()) if depth < max_depth else []
                for name in sorted(files):
                    path = here / name
                    if path.suffix.lower() not in {".py", ".sh"} or str(path) in visited:
                        continue
                    visited.add(str(path))
                    scanned += 1
                    if scanned > 3000 or time.monotonic() - started > 60:
                        error(folder, "Source search file/time budget reached")
                        stop = True
                        break
                    try:
                        body = read_small(path, 512 * 1024)
                        text = body.decode("utf-8-sig", errors="replace")
                        lower = text.lower()
                        name_hit = any(t in name.lower() for t in ("preprocess", "prepare", "convert", "split", "unified"))
                        if not (("ednet" in lower and any(t.lower() in lower for t in TERMS)) or
                                (name_hit and "student_id" in lower and "exercise_id" in lower)):
                            continue
                        put(z, path, body)
                        report["candidate_scripts"].append({"path": str(path),
                            "line_numbers": {term: [i for i, line in enumerate(text.splitlines(), 1) if term in line][:20]
                                             for term in TERMS if term in text}})
                    except (OSError, ValueError) as exc:
                        error(path, exc)
                if stop:
                    break
        report["code_files_examined"] = scanned
        report["seconds"] = time.monotonic() - started
        report["status"] = "complete_with_gaps" if report["issues"] else "complete_in_declared_scope"
        z.writestr("lineage_report.json", json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8"))
    with zipfile.ZipFile(output) as z:
        if z.testzip() is not None:
            raise ValueError("Output ZIP CRC check failed")
    return report


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", default="/home/wangxiao/QCCDM")
    p.add_argument("--output", required=True)
    args = p.parse_args()
    try:
        report = collect(args.root, args.output)
    except (OSError, ValueError) as exc:
        raise SystemExit(str(exc))
    print("LINEAGE_PACK_CREATED", args.output)
    print(json.dumps({"status": report["status"], "included_files": len(report["files"]),
                      "candidate_scripts": len(report["candidate_scripts"]), "issues": len(report["issues"]),
                      "seconds": report["seconds"]}))
    print("No training; no source changes; no pickle loading. Download this ZIP even if there are gaps.")


if __name__ == "__main__":
    main()
