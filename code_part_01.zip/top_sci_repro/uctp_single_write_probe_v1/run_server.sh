#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RUN_NAME="${1:-server_a2_01}"
if [[ ! "$RUN_NAME" =~ ^[A-Za-z0-9_-]+$ ]]; then
  printf 'Run name must contain only letters, digits, underscore, or hyphen.\n' >&2
  exit 2
fi
PYTHON=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research
A1=/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_02/a1_results.zip
OUT="$ROOT/outputs/$RUN_NAME"
mkdir -p "$ROOT/outputs"
if [[ -e "$OUT" ]]; then
  printf 'Output already exists; refusing overwrite: %s\n' "$OUT" >&2
  exit 2
fi
for INPUT in "$PYTHON" "$PROJECT/src/model.py" "$PROJECT/src/metrics.py" "$A1"; do
  if [[ ! -f "$INPUT" ]]; then
    printf 'Required input missing: %s\n' "$INPUT" >&2
    exit 2
  fi
done
CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}" \
  "$PYTHON" -B -u "$ROOT/run_suite.py" \
    --project-dir "$PROJECT" \
    --a1-archive "$A1" \
    --output-root "$OUT" \
    --device cuda \
    --full \
    --ack-row-feedback 2>&1 | tee "$ROOT/outputs/$RUN_NAME.log"
