"""Show A2 progress and the frozen-validation comparison without rerunning jobs."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from probe_core import JOBS


def read(path):
    return json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None


def fmt(x):
    return "-" if x is None else f"{x:+.6f}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-root", required=True)
    args = parser.parse_args()
    root = Path(args.output_root)
    if not root.is_dir():
        raise SystemExit(f"Output directory does not exist: {root}")
    suite = read(root / "suite_status.json") or {}
    print(f"Suite status: {suite.get('status', 'unknown')}; active job: {suite.get('active_job', '-')}")
    print("A saved running status does not prove a live process; check pgrep/tmux if progress is stale.")
    for job in suite.get("jobs", []):
        print(f"{job['name']:<39} returncode={job['returncode']}")
    print(f"{'Full job':<30} {'State':<10} {'Pairs':>8} {'Students':>8} {'half-full NLL':>15} {'zero-full NLL':>15}")
    for job in JOBS:
        folder = root / (job + "_full")
        status = read(folder / "status.json") or {}
        summary = read(folder / "summary.json") or {}
        comp = summary.get("groups", {}).get("all_pairs", {}).get("comparisons", {})
        half = (comp.get("half_minus_full") or {}).get("delta_nll")
        zero = (comp.get("zero_minus_full") or {}).get("delta_nll")
        print(f"{job:<30} {status.get('status', '-'):<10} {status.get('pairs', '-'):>8} "
              f"{status.get('students', '-'):>8} {fmt(half):>15} {fmt(zero):>15}")
        if status.get("status") == "failed":
            print(f"  Failure: {status.get('error')}")
    result = root / "a2_results.zip"
    print(f"\nArchive: {result if result.is_file() else 'not ready'}")
    print("Negative delta NLL means the weaker single write predicted that selected next-KC event better.")
    print("This conditional, frozen validation diagnostic is not an online treatment result or a test-set claim.")


if __name__ == "__main__":
    main()
