# A2 服务器操作（先不要覆盖任何旧目录）

本地上传的压缩包是 `uctp_single_write_probe_v1.zip`。A1 归档必须位于服务器实际路径：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_02/a1_results.zip`

如果你的实际 A1 归档不在那里，**先停下并告诉我实际路径**，不要复制或覆盖旧结果来凑路径。

## 1. 上传、解压

把压缩包上传到 `/home/wangxiao/QCCDM/top_sci_repro/`，在服务器执行：

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
/home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_single_write_probe_v1.zip
if [ -e uctp_single_write_probe_v1 ]; then
  echo '同名目录已存在，停止，勿覆盖'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_single_write_probe_v1.zip .
fi
```

## 2. 一条命令启动全部测试和完整诊断

建议进入一个**新的** tmux 会话，避免断开 SSH 中止作业：

```bash
tmux new-session -s a2write
cd /home/wangxiao/QCCDM/top_sci_repro/uctp_single_write_probe_v1
bash run_server.sh server_a2_01
```

第三行是一条完整运行命令；会自动顺序完成合成测试、两个数据集 × 两个 seed 的预检和 batch17 检查，再运行四个 full 作业。若输出目录已存在，脚本会拒绝覆盖。离开 tmux 时按 `Ctrl+b`，松开，再按 `d`；**不要按 Ctrl+c**。重新连接可执行 `tmux attach -t a2write`。

## 3. 看进度与结果

在另一个终端：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B \
  /home/wangxiao/QCCDM/top_sci_repro/uctp_single_write_probe_v1/show_results.py \
  --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_single_write_probe_v1/outputs/server_a2_01
```

如果进度长时间不变，可确认进程：

```bash
pgrep -a -u wangxiao -f 'uctp_single_write_probe_v1/run_suite[.]py'
tail -n 50 /home/wangxiao/QCCDM/top_sci_repro/uctp_single_write_probe_v1/outputs/server_a2_01.log
```

只有 `Suite status: complete`、4 个 full job 均 `complete`、`a2_results.zip` 已生成，才是完成。若 `failed`，不要盲目重跑同一输出目录；先把 `server_a2_01.log` 末尾、`suite_status.json` 和失败 job 的 `status.json` 发给我。完成后下载：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_single_write_probe_v1/outputs/server_a2_01/a2_results.zip`

## 4. 我会重点核对什么

- A1 原始 `u0` 桥接差值和 batch128/batch17 一致性是否 `≤1e−6`；
- 两个数据集、两个 seed 的 `half−full`/`zero−full` NLL 是否方向一致，学生宏平均是否同向；
- 不同正确性、KC 历史和时间间隔分层是否有可解释且稳定的异质性；
- 排除同时间事件后覆盖率是否仍足够，并保留 row-immediate feedback 限制。

只有这些诊断成立，下一阶段才考虑训练一个简单的“事后反馈可靠性 → 写入强度”模型；否则要重新审视问题设定，不继续堆模块。
