"""A2: one-interaction write intervention on frozen unit-write checkpoints.

The target is the *next* same-KC validation event.  Its current label is used
only for scoring, never to form its pre-prediction state.
"""
from __future__ import annotations

import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import zipfile

import numpy as np
import pandas as pd
import torch

ARCHIVE_SHA256 = "69e9fdebc5ae054492c0f7650b3cabd879cda38e7a210f3fe79e7ecbc4463c50"
JOBS = tuple(f"{dataset}_unit_write_seed{seed}" for dataset in ("assist", "ednet") for seed in (1, 2))
MODES = ("full", "half", "zero")
MAX_GAP_SECONDS = 7 * 24 * 3600
ATOL = 1e-6


def require(condition, message):
    if not bool(condition):
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def archive_json(archive, name, manifest=None):
    data = archive.read(name)
    if manifest is not None:
        require(hashlib.sha256(data).hexdigest() == manifest[name], f"A1 member hash changed: {name}")
    return json.loads(data)


def validate_archive(path):
    require(sha(path) == ARCHIVE_SHA256, "A1 archive SHA256 differs from accepted server_a1_02 result")
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "A1 archive CRC failed")
        require(len(archive.namelist()) == len(set(archive.namelist())), "Duplicate A1 archive member")
        manifest = archive_json(archive, "results_manifest.json")["files"]
        status = archive_json(archive, "suite_status.json", manifest)
        require(status["status"] == "complete" and status["full_validations_completed"] == 4,
                "A1 suite is not complete")
        require(not status["trained"] and not status["test_evaluated"], "Unexpected A1 scope")
        completed = {job["name"]: job["returncode"] for job in status["jobs"]}
        for name in JOBS:
            require(completed.get(name + "_full") == 0, f"A1 full job failed: {name}")
            for suffix in ("run_config.json", "status.json", "predictions.csv.gz", "input_hashes.json"):
                require(f"{name}_full/{suffix}" in manifest, f"Missing A1 artifact {name}/{suffix}")
        batch = archive_json(archive, "batch_comparison.json", manifest)
        require(all(batch[name]["success"] for name in JOBS), "A1 batch comparison failed")
    return {"archive_sha256": ARCHIVE_SHA256, "jobs": list(JOBS), "a1_status": "complete"}


def read_a1_job(archive_path, job):
    require(job in JOBS, "Job outside fixed A2 matrix")
    with zipfile.ZipFile(archive_path) as archive:
        manifest = archive_json(archive, "results_manifest.json")["files"]
        prefix = job + "_full/"
        config = archive_json(archive, prefix + "run_config.json", manifest)
        status = archive_json(archive, prefix + "status.json", manifest)
        input_hashes = archive_json(archive, prefix + "input_hashes.json", manifest)
        require(status["status"] == "complete" and status["reference_gate"]["success"], "A1 reference gate failed")
        require(not status["trained"] and not status["test_evaluated"], "A1 job scope changed")
        member = prefix + "predictions.csv.gz"
        payload = archive.read(member)
        require(hashlib.sha256(payload).hexdigest() == manifest[member], "A1 prediction hash changed")
        with gzip.GzipFile(fileobj=io.BytesIO(payload)) as stream:
            frame = pd.read_csv(stream, float_precision="round_trip")
    require(len(frame) == config["job"]["n"] == status["n"], "A1 validation coverage mismatch")
    return frame, config, input_hashes


def select_pairs(frame, max_students=0):
    """Pair each validation anchor with its next strictly-later same-KC valid row.

    Tied timestamp rows are excluded at either endpoint.  Future availability is
    a *diagnostic selection criterion*, never a deployable gate feature.
    """
    needed = {"record_idx", "student_idx", "item_idx", "timestamp", "label", "kc",
              "positive", "negative", "kc_count_before", "student_count_before",
              "same_time", "split", "u0_probability"}
    require(needed.issubset(frame.columns), "A1 prediction columns missing")
    require(frame.record_idx.is_unique and frame.record_idx.notna().all(), "Duplicate record identity")
    require((frame.split == 1).all(), "Only validation rows may enter A2")
    require(frame.label.isin((0, 1)).all() and frame.u0_probability.between(0, 1).all(), "Invalid label/probability")
    require(frame.same_time.isin((True, False)).all(), "Invalid same-time flag")
    require(np.issubdtype(frame.timestamp.dtype, np.integer), "Timestamp must be integer Unix seconds")
    require(np.issubdtype(frame.record_idx.dtype, np.integer), "Record order must be integer")
    require((frame[["positive", "negative", "kc_count_before"]] >= 0).all().all(), "Negative evidence count")
    ordered = frame.sort_values(["student_idx", "kc", "record_idx"], kind="stable").reset_index(drop=True)
    group = ordered.groupby(["student_idx", "kc"], sort=False)
    previous = group[["record_idx", "timestamp", "label", "positive", "negative",
                      "kc_count_before", "student_count_before", "same_time"]].shift(1)
    candidate = previous.record_idx.notna()
    gap = ordered.timestamp - previous.timestamp
    untied = (~ordered.same_time.astype(bool)) & previous.same_time.eq(False)
    eligible = candidate & gap.gt(0) & gap.le(MAX_GAP_SECONDS) & untied
    pair = ordered.loc[eligible].copy()
    prev = previous.loc[eligible]
    for column in previous.columns:
        pair["anchor_" + column] = prev[column].to_numpy()
    pair["gap_seconds"] = gap.loc[eligible].to_numpy()
    pair = pair.sort_values("record_idx").reset_index(drop=True)
    if max_students:
        require(max_students > 0, "Invalid max_students")
        selected = np.sort(pair.student_idx.unique())[:max_students]
        pair = pair[pair.student_idx.isin(selected)].reset_index(drop=True)
    require(len(pair) > 0, "No eligible next-KC pairs")
    require((pair.record_idx > pair.anchor_record_idx).all(), "Anchor is not before target")
    require((pair.kc_count_before >= pair.anchor_kc_count_before + 1).all(), "KC count order")
    require((pair.positive >= pair.anchor_positive + pair.anchor_label).all(), "Positive count excludes anchor")
    require((pair.negative >= pair.anchor_negative + 1 - pair.anchor_label).all(), "Negative count excludes anchor")
    require(pair.record_idx.is_unique, "One target matched to multiple anchors")
    stats = {"validation_rows": int(len(frame)), "candidate_adjacent_valid_pairs": int(candidate.sum()),
             "eligible_pairs": int(eligible.sum()), "selected_pairs": int(len(pair)),
             "selected_students": int(pair.student_idx.nunique()),
             "excluded_tie_or_gap": int(candidate.sum() - eligible.sum()),
             "rule": "next strictly later same-KC valid row within 7d; untied endpoints"}
    return pair, stats


def load_model(project_dir, config, input_hashes, device):
    job = config["job"]
    checkpoint = Path(job["checkpoint"])
    source = Path(project_dir) / "src/model.py"
    metrics = Path(project_dir) / "src/metrics.py"
    expected_source = next((value for key, value in input_hashes.items() if key.endswith("/src/model.py")), None)
    expected_metrics = next((value for key, value in input_hashes.items() if key.endswith("/src/metrics.py")), None)
    require(expected_source is not None and sha(source) == expected_source, "Clean model source identity changed")
    require(expected_metrics is not None and sha(metrics) == expected_metrics, "Clean metrics source identity changed")
    require(checkpoint.is_file() and sha(checkpoint) == job["checkpoint_sha256"], "Checkpoint identity changed")
    require(config["model_family"] == "original clean" and job["variant"] == "unit_write", "Wrong model family")
    spec = importlib.util.spec_from_file_location("a2_pinned_clean_model", source)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    checkpoint_data = torch.load(checkpoint, map_location="cpu", weights_only=True)
    # A1 already reference-bridged this checkpoint; verify its identity again.
    require(checkpoint_data.get("model_family") is None, "Converted checkpoint rejected")
    require(checkpoint_data["epoch"] == job["best_epoch"] and
            checkpoint_data["data_fingerprint"] == job["data_fingerprint"], "Checkpoint metadata changed")
    require(checkpoint_data["source_code"]["src/model.py"] == expected_source,
            "Checkpoint model source changed")
    require(checkpoint_data["model_config"]["variant"] == "unit_write", "Wrong checkpoint variant")
    model = module.CleanCD(**checkpoint_data["model_config"])
    model.load_state_dict(checkpoint_data["model_state"], strict=True)
    model.eval().requires_grad_(False).to(device)
    return model, module.State, checkpoint_data["model_config"]


@torch.inference_mode()
def predict_pairs(pair, model, State, model_config, device="cpu", batch_size=128):
    require(batch_size > 0, "Invalid batch_size")
    require(model.variant == "unit_write" and not model.training and
            not any(p.requires_grad for p in model.parameters()), "Frozen unit-write model required")
    k_count = model_config["num_knowledges"]
    require(pair.kc.between(0, k_count - 1).all(), "KC outside model vocabulary")
    require(pair.student_idx.between(0, model_config["num_students"] - 1).all() and
            pair.item_idx.between(0, model_config["num_items"] - 1).all(), "ID outside model vocabulary")
    output = {mode: np.empty(len(pair), np.float64) for mode in MODES}
    for start in range(0, len(pair), batch_size):
        batch = pair.iloc[start:start + batch_size]
        size = len(batch)
        u = torch.as_tensor(batch.student_idx.to_numpy(), device=device, dtype=torch.long)
        item = torch.as_tensor(batch.item_idx.to_numpy(), device=device, dtype=torch.long)
        kc = torch.as_tensor(batch.kc.to_numpy(), device=device, dtype=torch.long)
        y_anchor = torch.as_tensor(batch.anchor_label.to_numpy(), device=device, dtype=torch.float32)
        pos = torch.as_tensor(batch.positive.to_numpy(), device=device, dtype=torch.float32)
        neg = torch.as_tensor(batch.negative.to_numpy(), device=device, dtype=torch.float32)
        q = torch.zeros(size, k_count, device=device)
        q[torch.arange(size, device=device), kc] = 1
        for mode, factor in (("full", 1.), ("half", .5), ("zero", 0.)):
            p = pos - (1 - factor) * y_anchor
            n = neg - (1 - factor) * (1 - y_anchor)
            require(torch.all(p >= 0).item() and torch.all(n >= 0).item(), "Negative counterfactual evidence")
            state = State(p.unsqueeze(-1) * q, n.unsqueeze(-1) * q)
            output[mode][start:start + size] = model.predict(state, u, item, q)["probability"].cpu().numpy()
    max_diff = float(np.max(np.abs(output["full"] - pair.u0_probability.to_numpy(dtype=np.float32).astype(float))))
    require(max_diff <= ATOL, f"Full-write replay does not match A1 U0: {max_diff}")
    for mode in MODES:
        require(np.isfinite(output[mode]).all() and ((output[mode] >= 0) & (output[mode] <= 1)).all(),
                f"Invalid probability in {mode}")
        pair[mode + "_probability"] = output[mode]
    return pair, {"success": True, "full_vs_a1_u0_max": max_diff, "atol": ATOL,
                  "label_use": "anchor label only for post-response state; target label only for metrics"}


def summarize(pair, metrics_fn, reps=1000):
    require(reps > 0, "bootstrap repetitions must be positive")
    y = pair.label.to_numpy(dtype=float)
    users = pair.student_idx.to_numpy()
    masks = {"all_pairs": np.ones(len(pair), bool),
             "anchor_first_kc": pair.anchor_kc_count_before.to_numpy() == 0,
             "anchor_nonfirst_kc": pair.anchor_kc_count_before.to_numpy() >= 1,
             "anchor_correct": pair.anchor_label.to_numpy() == 1,
             "anchor_incorrect": pair.anchor_label.to_numpy() == 0,
             "anchor_student_lt50": pair.anchor_student_count_before.to_numpy() < 50,
             "anchor_student_ge50": pair.anchor_student_count_before.to_numpy() >= 50,
             "gap_le1h": pair.gap_seconds.to_numpy() <= 3600,
             "gap_1h_1d": (pair.gap_seconds.to_numpy() > 3600) & (pair.gap_seconds.to_numpy() <= 86400),
             "gap_1d_7d": pair.gap_seconds.to_numpy() > 86400}
    clipped = {mode: np.clip(pair[mode + "_probability"].to_numpy(), 1e-7, 1-1e-7) for mode in MODES}
    losses = {mode: -y * np.log(p) - (1-y) * np.log1p(-p) for mode, p in clipped.items()}
    result = {"scope": "frozen validation, conditional on future same-KC observation; not a deployable gate",
              "bootstrap_reps": reps, "intervals": "exploratory student-cluster paired, not training-seed uncertainty",
              "groups": {}}
    rng = np.random.default_rng(20261012)
    for name, mask in masks.items():
        sub_users, inv = np.unique(users[mask], return_inverse=True)
        entry = {"n": int(mask.sum()), "students": len(sub_users), "metrics": {}, "comparisons": {}}
        for mode in MODES:
            met = metrics_fn(y[mask], clipped[mode][mask])
            if len(sub_users):
                sums = np.bincount(inv, weights=losses[mode][mask], minlength=len(sub_users))
                counts = np.bincount(inv, minlength=len(sub_users))
                met["student_macro_nll"] = float(np.mean(sums / counts))
            else:
                met["student_macro_nll"] = None
            entry["metrics"][mode] = met
        for mode in ("half", "zero"):
            difference = (losses[mode] - losses["full"])[mask]
            if len(sub_users):
                sums = np.bincount(inv, weights=difference, minlength=len(sub_users))
                counts = np.bincount(inv, minlength=len(sub_users))
                means = sums / counts
                event_boot, macro_boot = [], []
                for _ in range(reps):
                    weights = np.bincount(rng.integers(len(sub_users), size=len(sub_users)),
                                          minlength=len(sub_users))
                    event_boot.append(float(weights @ sums / (weights @ counts)))
                    macro_boot.append(float(weights @ means / weights.sum()))
                entry["comparisons"][mode + "_minus_full"] = {
                    "delta_nll": float(difference.mean()), "delta_student_macro_nll": float(means.mean()),
                    "event_ci95": np.quantile(event_boot, [.025, .975]).tolist(),
                    "macro_ci95": np.quantile(macro_boot, [.025, .975]).tolist()}
            else:
                entry["comparisons"][mode + "_minus_full"] = None
        result["groups"][name] = entry
    return result
