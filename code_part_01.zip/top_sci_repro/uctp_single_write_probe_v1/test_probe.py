"""Synthetic protocol tests.  No checkpoint, training data, or network needed."""
from __future__ import annotations

import argparse
import importlib.util
from pathlib import Path
import sys
import unittest

import numpy as np
import pandas as pd
import torch

from probe_core import MAX_GAP_SECONDS, predict_pairs, select_pairs, summarize


def clean_model(project):
    spec = importlib.util.spec_from_file_location("a2_test_clean", Path(project) / "src/model.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    torch.manual_seed(71)
    model = module.CleanCD(2, 3, 2, variant="unit_write", ncd_hidden_dim=8)
    model.eval().requires_grad_(False)
    return model, module.State


def fixture():
    # One learner, one KC; the final row is too far away to qualify.
    return pd.DataFrame({
        "record_idx": [10, 11, 12, 13, 14, 15],
        "student_idx": [0] * 6,
        "item_idx": [0] * 6,
        "timestamp": [100, 110, 120, 120, 130, 130 + MAX_GAP_SECONDS + 1],
        "label": [1, 0, 1, 0, 1, 1],
        "kc": [0] * 6,
        "positive": [0, 1, 1, 2, 2, 3],
        "negative": [0, 0, 1, 1, 2, 2],
        "kc_count_before": [0, 1, 2, 3, 4, 5],
        "student_count_before": [0, 1, 2, 3, 4, 5],
        "same_time": [False, False, True, True, False, False],
        "split": [1] * 6,
        "u0_probability": [0.5] * 6,
    })


class A2Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.model, cls.State = clean_model(PROJECT)
        cls.config = {"num_knowledges": 2, "num_students": 2, "num_items": 3}

    def make_pairs(self):
        pair, stats = select_pairs(fixture())
        self.assertEqual(pair.record_idx.tolist(), [11])
        self.assertEqual(pair.anchor_record_idx.tolist(), [10.0])
        self.assertEqual(stats["selected_pairs"], 1)
        with torch.inference_mode():
            q = torch.tensor([[1., 0.]])
            state = self.State(torch.tensor([[1., 0.]]), torch.zeros(1, 2))
            pair.loc[:, "u0_probability"] = float(self.model.predict(state, torch.tensor([0]),
                                                            torch.tensor([0]), q)["probability"].item())
        return pair

    def test_pair_selection_excludes_ties_and_far_gap(self):
        pair = self.make_pairs()
        self.assertEqual(int(pair.iloc[0].gap_seconds), 10)
        bad = fixture()
        bad.loc[1, "record_idx"] = 10
        with self.assertRaisesRegex(ValueError, "Duplicate record"):
            select_pairs(bad)

    def test_other_kc_between_anchor_and_target_is_not_the_anchor(self):
        data = pd.DataFrame({
            "record_idx": [1, 2, 3], "student_idx": [0, 0, 0],
            "item_idx": [0, 1, 0], "timestamp": [100, 105, 110],
            "label": [1, 0, 0], "kc": [0, 1, 0],
            "positive": [0, 0, 1], "negative": [0, 0, 0],
            "kc_count_before": [0, 0, 1], "student_count_before": [0, 1, 2],
            "same_time": [False] * 3, "split": [1] * 3,
            "u0_probability": [.5] * 3,
        })
        pair, _ = select_pairs(data)
        self.assertEqual(pair.record_idx.tolist(), [3])
        self.assertEqual(pair.anchor_record_idx.tolist(), [1.0])

    def test_single_write_intervention_and_original_bridge(self):
        pair, gate = predict_pairs(self.make_pairs(), self.model, self.State, self.config, batch_size=1)
        self.assertTrue(gate["success"])
        self.assertLessEqual(gate["full_vs_a1_u0_max"], 1e-6)
        with torch.inference_mode():
            q = torch.tensor([[1., 0.]])
            u, item = torch.tensor([0]), torch.tensor([0])
            for mode, amount in (("full", 1.), ("half", .5), ("zero", 0.)):
                expected = self.model.predict(self.State(torch.tensor([[amount, 0.]]),
                                                            torch.zeros(1, 2)), u, item, q)["probability"].item()
                self.assertAlmostEqual(float(pair.iloc[0][mode + "_probability"]), expected, places=7)

    def test_target_label_is_not_a_prediction_input(self):
        pair = self.make_pairs()
        original, _ = predict_pairs(pair.copy(), self.model, self.State, self.config, batch_size=1)
        changed = pair.copy()
        changed.loc[:, "label"] = 1 - changed.label
        alternate, _ = predict_pairs(changed, self.model, self.State, self.config, batch_size=1)
        for mode in ("full", "half", "zero"):
            np.testing.assert_array_equal(original[mode + "_probability"], alternate[mode + "_probability"])

    def test_batch_invariance_and_both_anchor_outcomes(self):
        pair = self.make_pairs()
        negative_anchor = pair.copy()
        negative_anchor.loc[:, "record_idx"] = 21
        negative_anchor.loc[:, "anchor_record_idx"] = 20
        negative_anchor.loc[:, "anchor_label"] = 0
        negative_anchor.loc[:, "positive"] = 0
        negative_anchor.loc[:, "negative"] = 1
        with torch.inference_mode():
            q = torch.tensor([[1., 0.]])
            state = self.State(torch.zeros(1, 2), torch.tensor([[1., 0.]]))
            negative_anchor.loc[:, "u0_probability"] = self.model.predict(
                state, torch.tensor([0]), torch.tensor([0]), q)["probability"].item()
        both = pd.concat([pair, negative_anchor], ignore_index=True)
        a, _ = predict_pairs(both.copy(), self.model, self.State, self.config, batch_size=1)
        b, _ = predict_pairs(both.copy(), self.model, self.State, self.config, batch_size=2)
        for mode in ("full", "half", "zero"):
            np.testing.assert_allclose(a[mode + "_probability"], b[mode + "_probability"], atol=1e-7)

    def test_metrics_use_target_label_only_for_scoring(self):
        pair, _ = predict_pairs(self.make_pairs(), self.model, self.State, self.config)
        def metric(y, p):
            return {"n": len(y), "nll": float((-y*np.log(p)-(1-y)*np.log1p(-p)).mean())} if len(y) else {"n": 0, "nll": None}
        result = summarize(pair, metric, reps=10)
        self.assertEqual(result["groups"]["all_pairs"]["n"], 1)
        self.assertEqual(result["groups"]["anchor_nonfirst_kc"]["n"], 0)
        self.assertTrue(np.isfinite(result["groups"]["all_pairs"]["comparisons"]["half_minus_full"]["delta_nll"]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", required=True)
    args = parser.parse_args()
    PROJECT = Path(args.project_dir)
    unittest.main(argv=[sys.argv[0]], verbosity=2)
