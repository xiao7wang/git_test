"""Run the fixed A2 frozen single-interaction write diagnostic."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

sys.dont_write_bytecode = True
os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
import numpy as np
import pandas as pd
import torch

from probe_core import (ARCHIVE_SHA256, ATOL, JOBS, archive_json, load_model,
                        predict_pairs, read_a1_job, require, save_json, select_pairs,
                        sha, summarize, validate_archive)

ROOT = Path(__file__).resolve().parent
DEFAULT_PROJECT = "/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research"
DEFAULT_A1 = "/home/wangxiao/QCCDM/top_sci_repro/uctp_update_scale_probe_v1/outputs/server_a1_02/a1_results.zip"


def check_package():
    manifest = ROOT / "PACKAGE_MANIFEST.json"
    require(manifest.is_file(), "Package manifest missing; use the released ZIP")
    for name, expected in json.loads(manifest.read_text(encoding="utf-8"))["files"].items():
        require(sha(ROOT / name) == expected, f"A2 package file changed: {name}")


def metrics_function(project):
    import importlib.util
    source = Path(project) / "src/metrics.py"
    spec = importlib.util.spec_from_file_location("a2_pinned_metrics", source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.compute_metrics


def run_one(job, output, args, max_students, batch_size, bootstrap_reps):
    require(not output.exists(), f"Refusing overwrite: {output}")
    output.mkdir(parents=True, exist_ok=False)
    save_json(output / "status.json", {"status": "running", "job": job, "pid": os.getpid()})
    started = time.perf_counter()
    try:
        frame, config, input_hashes = read_a1_job(args.a1_archive, job)
        pair, selection = select_pairs(frame, max_students=max_students)
        model, State, model_config = load_model(args.project_dir, config, input_hashes, args.device)
        before = {name: tensor.detach().cpu().clone() for name, tensor in model.state_dict().items()}
        pair, gate = predict_pairs(pair, model, State, model_config, args.device, batch_size)
        require(all(torch.equal(before[name], tensor.detach().cpu()) for name, tensor in model.state_dict().items()),
                "Frozen model parameter changed")
        summary = summarize(pair, metrics_function(args.project_dir), bootstrap_reps)
        pair.to_csv(output / "pair_predictions.csv.gz", index=False, float_format="%.17g", compression="gzip")
        save_json(output / "summary.json", summary)
        save_json(output / "selection.json", selection)
        save_json(output / "reference_gate.json", gate)
        model_source_key = next(key for key in input_hashes if key.endswith("/src/model.py"))
        save_json(output / "run_config.json", {
            "job": job, "checkpoint": config["job"]["checkpoint"],
            "checkpoint_sha256": config["job"]["checkpoint_sha256"],
            "a1_archive_sha256": ARCHIVE_SHA256, "a1_job_policy_sha256": config["policy_sha256"],
            "source_model_sha256": input_hashes[model_source_key],
            "device": args.device, "batch_size": batch_size, "max_students": max_students,
            "bootstrap_reps": bootstrap_reps, "trained": False, "test_evaluated": False,
            "parameters_changed": False, "feedback_boundaries_verified": False,
            "selection": "validation anchor, next strictly later same-KC validation event <=7d, untied endpoints",
            "branches": {"full": 1.0, "half": 0.5, "zero": 0.0},
            "primary": "paired next-same-KC event and student-macro NLL, half/zero minus full",
            "note": "Only the anchor write is changed; all later observed feedback remains as recorded."})
        metrics_source_key = next(key for key in input_hashes if key.endswith("/src/metrics.py"))
        require(sha(args.a1_archive) == ARCHIVE_SHA256 and
                sha(config["job"]["checkpoint"]) == config["job"]["checkpoint_sha256"] and
                sha(Path(args.project_dir) / "src/model.py") == input_hashes[model_source_key] and
                sha(Path(args.project_dir) / "src/metrics.py") == input_hashes[metrics_source_key],
                "Pinned inputs changed during A2 probe")
        result = {"status": "complete", "job": job, "pairs": len(pair),
                  "students": int(pair.student_idx.nunique()), "seconds": time.perf_counter() - started,
                  "trained": False, "test_evaluated": False, "source_inputs_unchanged": True,
                  "reference_gate": gate}
        save_json(output / "status.json", result)
        print(f"{job}: pairs={len(pair)} students={result['students']} "
              f"deltaNLL(half-full)={summary['groups']['all_pairs']['comparisons']['half_minus_full']['delta_nll']:.6f} "
              f"deltaNLL(zero-full)={summary['groups']['all_pairs']['comparisons']['zero_minus_full']['delta_nll']:.6f}",
              flush=True)
        return result
    except BaseException as exc:
        save_json(output / "status.json", {"status": "failed", "job": job,
                                          "error": repr(exc), "seconds": time.perf_counter() - started})
        raise


def compare_preflight(left, right):
    a = pd.read_csv(left / "pair_predictions.csv.gz", float_precision="round_trip")
    b = pd.read_csv(right / "pair_predictions.csv.gz", float_precision="round_trip")
    require(len(a) == len(b) > 0 and a.record_idx.equals(b.record_idx) and
            a.anchor_record_idx.equals(b.anchor_record_idx), "A2 preflight pair identity changed")
    differences = {mode: float(np.max(np.abs(a[mode + "_probability"] - b[mode + "_probability"])))
                   for mode in ("full", "half", "zero")}
    require(all(v <= ATOL for v in differences.values()), f"A2 batch invariance failed: {differences}")
    return {"success": True, "pairs": len(a), "atol": ATOL, "max_absolute_difference": differences}


def make_archive(root):
    result = root / "a2_results.zip"
    partial = root / "a2_results.zip.partial"
    require(not result.exists() and not partial.exists(), "A2 result archive already exists")
    files = sorted(p for p in root.rglob("*") if p.is_file() and p not in (result, partial))
    save_json(root / "results_manifest.json", {"files": {p.relative_to(root).as_posix(): sha(p) for p in files}})
    files.append(root / "results_manifest.json")
    with zipfile.ZipFile(partial, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for file in files:
            archive.write(file, file.relative_to(root).as_posix())
    with zipfile.ZipFile(partial) as archive:
        require(archive.testzip() is None, "A2 output archive CRC failed")
    partial.rename(result)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project-dir", default=DEFAULT_PROJECT)
    p.add_argument("--a1-archive", default=DEFAULT_A1)
    p.add_argument("--output-root", required=True)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--full", action="store_true")
    p.add_argument("--ack-row-feedback", action="store_true")
    args = p.parse_args()
    check_package()
    require(args.ack_row_feedback, "Explicit row-immediate feedback assumption acknowledgment required")
    root = Path(args.output_root).resolve()
    allowed = (ROOT / "outputs").resolve()
    require(root != allowed and root.is_relative_to(allowed) and not root.exists(),
            "Output must be a new child of this package's outputs directory")
    require(Path(args.project_dir).is_dir(), "Clean project directory missing")
    require(Path(args.a1_archive).is_file(), "A1 server_a1_02 archive missing")
    require(args.device == "cpu" or torch.cuda.is_available(), "CUDA unavailable")
    torch.set_num_threads(4)
    torch.use_deterministic_algorithms(True)
    torch.backends.cudnn.benchmark = False
    torch.backends.cuda.matmul.allow_tf32 = False
    root.mkdir(parents=True, exist_ok=False)
    status = {"status": "running", "active_job": "archive_check", "jobs": [],
              "trained": False, "test_evaluated": False, "pid": os.getpid()}
    save_json(root / "suite_status.json", status)
    started = time.perf_counter()
    try:
        archive_info = validate_archive(args.a1_archive)
        save_json(root / "suite_config.json", {"args": vars(args), "a1": archive_info,
                  "selection": "next same-KC valid event <=7d, untied endpoints",
                  "modes": ["full", "half", "zero"], "training": False, "test_evaluated": False})
        log = root / "tests.log"
        status["active_job"] = "tests"
        save_json(root / "suite_status.json", status)
        with log.open("x", encoding="utf-8") as stream:
            command = [sys.executable, "-B", str(ROOT / "test_probe.py"), "--project-dir", args.project_dir]
            completed = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, check=False)
        status["jobs"].append({"name": "tests", "returncode": completed.returncode})
        save_json(root / "suite_status.json", status)
        require(completed.returncode == 0, f"A2 tests failed: {log}")
        comparisons = {}
        for job in JOBS:
            for tag, batch in (("preflight", 128), ("batch17", 17)):
                name = job + "_" + tag
                status["active_job"] = name
                save_json(root / "suite_status.json", status)
                run_one(job, root / name, args, max_students=32, batch_size=batch, bootstrap_reps=100)
                status["jobs"].append({"name": name, "returncode": 0})
                save_json(root / "suite_status.json", status)
            comparisons[job] = compare_preflight(root / (job + "_preflight"), root / (job + "_batch17"))
        save_json(root / "batch_comparison.json", comparisons)
        if args.full:
            for job in JOBS:
                name = job + "_full"
                status["active_job"] = name
                save_json(root / "suite_status.json", status)
                run_one(job, root / name, args, max_students=0, batch_size=128, bootstrap_reps=1000)
                status["jobs"].append({"name": name, "returncode": 0})
                save_json(root / "suite_status.json", status)
        status.update(status="complete", active_job=None, seconds=time.perf_counter() - started,
                      full_jobs=4 if args.full else 0)
        save_json(root / "suite_status.json", status)
        result = make_archive(root)
        print(f"ALL_RUNS_COMPLETED\nResults archive: {result}", flush=True)
    except BaseException as exc:
        status.update(status="failed", active_job=None, error=repr(exc),
                      seconds=time.perf_counter() - started)
        save_json(root / "suite_status.json", status)
        raise


if __name__ == "__main__":
    main()
