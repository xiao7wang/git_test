"""Build a fail-if-existing, hash-manifested server ZIP of only this A2 source."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
FILES = (
    "probe_core.py", "run_suite.py", "test_probe.py", "show_results.py",
    "run_server.sh", "package_project.py", "README.md", "SERVER_GUIDE.md",
)


def main():
    target = ROOT.parent / (ROOT.name + ".zip")
    if target.exists():
        raise SystemExit(f"Refusing overwrite: {target}")
    contents = {name: (ROOT / name).read_bytes() for name in FILES}
    manifest = {"package": ROOT.name, "files": {
        name: hashlib.sha256(data).hexdigest() for name, data in contents.items()}}
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in contents.items():
            archive.writestr(f"{ROOT.name}/{name}", data)
        archive.writestr(f"{ROOT.name}/PACKAGE_MANIFEST.json",
                         json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None or len(archive.namelist()) != len(FILES) + 1:
            raise RuntimeError("Package verification failed")
    print(target)
    print("sha256=" + hashlib.sha256(target.read_bytes()).hexdigest())


if __name__ == "__main__":
    main()
