import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if not (d/'status.json').exists():raise SystemExit('No status file: check launch log')
s=json.loads((d/'status.json').read_text(encoding='utf8'));print('status:',s.get('status'),'phase:',s.get('phase'),'epoch:',s.get('epoch'),'best_epoch:',s.get('best_epoch'),'error:',s.get('error','-'))
print('Saved running status does not prove a live process.')
if (d/'history.json').exists():
 for h in json.loads((d/'history.json').read_text(encoding='utf8')):print('epoch',h['epoch'],'dev_NLL',round(h['dev']['nll'],6),'dev_AUC',round(h['dev']['auc'],6) if h['dev']['auc'] is not None else None,'train_seconds',round(h['train_seconds'],1),'dev_seconds',round(h['dev_seconds'],1),'best',h['best_epoch'])
if (d/'summary.json').exists():
 r=json.loads((d/'summary.json').read_text(encoding='utf8'));print('stop:',r['stop_reason'],'epochs:',r['epochs'],'best:',r['best_epoch'])
 print('bias NLL:',r['best_dev']['nll'],'original DKVMN NLL:',r['original_dkvmn_dev']['nll'],'count R2 NLL:',r['reference_log_count_R2_dev']['nll'])
 print('bias - original paired:',r['bias_minus_original_conditional']);print('bias - R2 paired:',r['bias_minus_R2_conditional'])
 print('Development only, one seed; bias changes available information and optimization.')
if (d/'dkvmn_bias_results.zip').exists():print('Results archive:',d/'dkvmn_bias_results.zip')
