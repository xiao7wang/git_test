import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import sha,write
from count_core import dev_users
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='dkvmn_bias_') as temp:
  root=Path(temp);pkg=root/'pkg';pkg.mkdir();p1=root/'p1';p1.mkdir();orig=root/'orig';orig.mkdir()
  names=('run_training.py','bias_adapter.py','run_pilot.py','streaming_dkvmn.py','source_manifest.json','LICENSE','count_core.py','cross_core.py','review_stats.py','package_results.py','show_results.py')
  for n in names:shutil.copy2(ROOT/n,pkg/n)
  (pkg/'pykt/models').mkdir(parents=True);shutil.copy2(ROOT/'pykt/models/dkvmn.py',pkg/'pykt/models/dkvmn.py')
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  a=fixture.data.arrays;dev=dev_users(a['student_idx'][a['split']==1]);ids=np.flatnonzero((a['split']==1)&np.isin(a['student_idx'],list(dev)))
  common={'record_idx':ids,'student_idx':a['student_idx'][ids],'label':a['label'][ids]}
  pd.DataFrame({**common,'R2':.5}).to_csv(p1/'dev_predictions.csv.gz',index=False,compression='gzip')
  write(p1/'config.json',{'data_fingerprint':fixture.data.fingerprint,'test_evaluated':False,'holdout_evaluated':False});write(p1/'status.json',{'status':'complete'});write(p1/'summary.json',{'status':'complete'})
  p1files={n:sha(p1/n) for n in ('status.json','config.json','summary.json','dev_predictions.csv.gz')};write(pkg/'locked_p1.json',{'p1_files':p1files})
  src=json.loads((pkg/'source_manifest.json').read_text())
  write(orig/'config.json',{'data_fingerprint':fixture.data.fingerprint,'test_evaluated':False,'holdout_evaluated':False,'source_p1_files':p1files,
   'batch_size':2,'chunk_size':3,'epochs_max':2,'patience':1,'seed':0,'optimizer':'Adam','lr':.001,
   'train_expected_events':int((a['split']==0).sum()),'development_events':len(ids),'source_archive_sha256':src['archive_sha256'],
   'source_dkvmn_sha256':sha(pkg/'pykt/models/dkvmn.py'),'code_sha256':{n:sha(pkg/n) for n in ('run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')}})
  write(orig/'status.json',{'status':'complete'});write(orig/'summary.json',{'status':'complete'});write(orig/'history.json',[])
  pd.DataFrame({**common,'probability':.5,'reference_log_count_R2':.5}).to_csv(orig/'best_dev_predictions.csv.gz',index=False,compression='gzip')
  write(pkg/'locked_original.json',{'files':{n:sha(orig/n) for n in ('status.json','config.json','summary.json','history.json','best_dev_predictions.csv.gz')}})
  cmd=[sys.executable,'-B',str(pkg/'run_training.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--p1-dir',str(p1),'--original-dir',str(orig),'--output-dir',str(root/'out'),'--device','cpu','--batch-size','2','--chunk-size','3','--epochs','2','--patience','1','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8');assert q.returncode==0,q.stdout
  s=json.loads((root/'out/summary.json').read_text());h=json.loads((root/'out/history.json').read_text())
  assert s['zero_bias_bridge_max_abs']<=1e-6 and s['chunk17_max_abs']<=1e-6 and not s['test_evaluated'] and not s['holdout_evaluated']
  assert s['best_epoch']==min(h,key=lambda x:x['dev']['nll'])['epoch'] and len(h)<=2
  assert all(x['train_events']==int((a['split']==0).sum()) for x in h)
  assert (root/'out/best_model.pt').is_file() and (root/'out/last_epoch.pt').is_file()
  assert np.array_equal(pd.read_csv(root/'out/best_dev_predictions.csv.gz').record_idx.to_numpy(),ids)
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  with zipfile.ZipFile(root/'out/dkvmn_bias_results.zip') as z:
   m=json.loads(z.read('manifest.json'));assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items())
  q=subprocess.run([sys.executable,str(pkg/'show_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  with (orig/'status.json').open('a') as f:f.write(' ')
  bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((root/'bad/status.json').read_text())['status']=='failed'
  print('PASS synthetic training, zero-bias bridge, dev alignment, chunk consistency, selection and provenance guards')
finally:fixture.tearDown()
