"""Single-seed DKVMN with student/item bias, compared with locked original."""
import argparse,json,os,platform,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write
from review_stats import metrics,losses,cluster_intervals
from streaming_dkvmn import initial_memory
from bias_adapter import BiasDKVMN
from run_pilot import load_upstream,selected_sequences,batches
ROOT=Path(__file__).resolve().parent

def save_checkpoint(out,name,contents):
 tmp=out/(name+'.pending');torch.save(contents,tmp);tmp.replace(out/name)

def evaluate(model,data,users,device,chunk_size,batch_size):
 model.eval();records=[];start=time.monotonic()
 with torch.no_grad():
  for chosen,seq in batches(data,users,'valid',batch_size):
   state=initial_memory(model.base,len(chosen))
   for b,idx in data.chunks(chosen,seq,'valid',chunk_size,device):
    p,state=model.forward_chunk(b['student_idx'],b['item_idx'],b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state)
    mask=b['target_mask'].cpu().numpy()
    if mask.any():
     ids=idx[mask];records.append(pd.DataFrame({'record_idx':ids,'student_idx':data.arrays['student_idx'][ids],
       'label':data.arrays['label'][ids],'probability':p.cpu().numpy()[mask]}))
 if not records:raise ValueError('No development events')
 return pd.concat(records,ignore_index=True).sort_values('record_idx').reset_index(drop=True),time.monotonic()-start

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 if min(a.batch_size,a.chunk_size,a.epochs,a.patience)<1:raise ValueError('Invalid settings')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);begin=time.monotonic()
 status={'status':'running','phase':'source_verify','epoch':0,'test_evaluated':False,'holdout_evaluated':False};write(out/'status.json',status)
 try:
  orig=Path(a.original_dir);p1=Path(a.p1_dir);lock=read(ROOT/'locked_original.json');lock1=read(ROOT/'locked_p1.json')
  for name,digest in lock['files'].items():
   if sha(orig/name)!=digest:raise ValueError('Original DKVMN source changed: '+name)
  for name,digest in lock1['p1_files'].items():
   if sha(p1/name)!=digest:raise ValueError('P1 source changed: '+name)
  old=read(orig/'config.json');summary=read(orig/'summary.json');prev=read(p1/'config.json')
  if read(orig/'status.json')['status']!='complete' or read(p1/'status.json')['status']!='complete':raise ValueError('Prior result incomplete')
  if old['test_evaluated'] or old['holdout_evaluated'] or prev['test_evaluated'] or prev['holdout_evaluated'] or old['source_p1_files']!=lock1['p1_files']:raise ValueError('Prior protocol mismatch')
  if (old['batch_size'],old['chunk_size'],old['epochs_max'],old['patience'],old['seed'],old['optimizer'],old['lr'])!=(a.batch_size,a.chunk_size,a.epochs,a.patience,0,'Adam',.001):raise ValueError('Original training settings differ')
  for name in ('run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py'):
   if sha(ROOT/name)!=old['code_sha256'][name]:raise ValueError('Shared implementation changed: '+name)
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint'] or old['data_fingerprint']!=spec['data_fingerprint'] or prev['data_fingerprint']!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  DKVMN,source=load_upstream()
  if source['archive_sha256']!=old['source_archive_sha256'] or sha(ROOT/'pykt/models/dkvmn.py')!=old['source_dkvmn_sha256']:raise ValueError('Upstream source differs')
  data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires binary single-KC items')
  train_users=np.unique(arr['student_idx'][arr['split']==0]).astype(np.int64);dev=np.asarray(sorted(dev_users(arr['student_idx'][arr['split']==1])),dtype=np.int64)
  ids=np.flatnonzero((arr['split']==1)&np.isin(arr['student_idx'],dev));p1ref=pd.read_csv(p1/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip');ref=pd.read_csv(orig/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
   expected=ids if key=='record_idx' else arr[key][ids]
   if not np.array_equal(ref[col].to_numpy(),expected) or not np.array_equal(p1ref[col].to_numpy(),expected):raise ValueError('Development identity mismatch: '+col)
  if not np.array_equal(ref.reference_log_count_R2.to_numpy(dtype=np.float32),p1ref.R2.to_numpy(dtype=np.float32)):raise ValueError('Count reference predictions differ')
  train_expected=int(np.sum(arr['split']==0))
  if train_expected!=old['train_expected_events'] or len(ids)!=old['development_events']:raise ValueError('Event coverage differs')
  device=torch.device(a.device);torch.set_num_threads(4);torch.manual_seed(0)
  if device.type=='cuda':torch.cuda.manual_seed_all(0)
  torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  dims=data.manifest['summary'];base=DKVMN(num_c=int(dims['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
  model=BiasDKVMN(base,int(dims['students']),int(dims['items'])).to(device)
  cfg={'purpose':'one-seed exploratory student/item bias extension of prior pyKT DKVMN','data_fingerprint':data.fingerprint,'student_partition_salt':SALT,
   'feedback':'row immediate assumption; predict before feedback; train history plus selected development users prior validation answers',
   'model':'pyKT DKVMN with streaming adapter and zero-initialized additive student+item logits; explicit extension, not official DKVMN',
   'difference_from_original':'added trainable student and item intercepts; otherwise matched core architecture, seed, row order, optimizer, clip, batch, chunk, epochs, patience and early stopping; gradient clipping now includes biases',
   'features':'KC and prior answers plus student ID and item ID; no time or response-time',
   'source_archive_sha256':source['archive_sha256'],'source_version':source['version_from_setup'],'source_commit':source['git_commit'],
   'source_original_files':lock['files'],'source_p1_files':lock1['p1_files'],'source_dkvmn_sha256':sha(ROOT/'pykt/models/dkvmn.py'),
   'code_sha256':{n:sha(ROOT/n) for n in ('run_training.py','bias_adapter.py','run_pilot.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')},
   'dim_s':32,'memory_slots':20,'dropout':.2,'optimizer':'Adam','lr':.001,'batch_size':a.batch_size,'chunk_size':a.chunk_size,'gradient_clip':5,
   'epochs_max':a.epochs,'patience':a.patience,'selection':'development event NLL, strict improvement; patience',
   'seed':0,'train_students':len(train_users),'train_expected_events':train_expected,'development_students':len(dev),'development_events':len(ids),
   'device':a.device,'torch':str(torch.__version__),'python':platform.python_version(),'test_evaluated':False,'holdout_evaluated':False}
  write(out/'config.json',cfg)
  # Zero bias should reproduce the official forward on a real training prefix.
  status['phase']='zero_bias_bridge';write(out/'status.json',status);model.eval();check=next((x[:64] for x in selected_sequences(data,train_users,'train') if len(x)>=2),None)
  if check is None:raise ValueError('No suitable train sequence')
  kt=torch.as_tensor(q.argmax(1)[arr['item_idx'][check]][None,:],device=device,dtype=torch.long);it=torch.as_tensor(arr['item_idx'][check][None,:],device=device,dtype=torch.long)
  yt=torch.as_tensor(arr['label'][check][None,:],device=device,dtype=torch.long);ut=torch.as_tensor([arr['student_idx'][check[0]]],device=device,dtype=torch.long);mask=torch.ones_like(kt,dtype=torch.bool)
  with torch.no_grad():official=base(kt,yt);adapted,_=model.forward_chunk(ut,it,kt,yt,mask,mask,initial_memory(base,1))
  bridge=float(torch.max(torch.abs(official-adapted)).item())
  if bridge>1e-6:raise ValueError(f'Zero-bias upstream bridge differs: {bridge}')
  opt=torch.optim.Adam(model.parameters(),lr=.001);history=[];best=float('inf');best_epoch=None;stale=0
  for epoch in range(1,a.epochs+1):
   status.update(phase='training',epoch=epoch,best_epoch=best_epoch);write(out/'status.json',status);print(json.dumps({'phase':'training_start','epoch':epoch}),flush=True)
   users=np.random.default_rng(epoch-1).permutation(train_users);model.train()
   if device.type=='cuda':torch.cuda.synchronize()
   start=time.monotonic();total=0.;train_n=0;steps=0;batch_n=0
   for chosen,seq in batches(data,users,'train',a.batch_size):
    batch_n+=1;state=initial_memory(base,len(chosen))
    for b,_ in data.chunks(chosen,seq,'train',a.chunk_size,device):
     opt.zero_grad(set_to_none=True);p,state=model.forward_chunk(b['student_idx'],b['item_idx'],b['q'].argmax(-1),b['label'].long(),b['active_mask'],b['active_mask'],state);m=b['target_mask'];n=int(m.sum().item())
     if n:
      loss=F.binary_cross_entropy(p[m].clamp(1e-6,1-1e-6),b['label'][m])
      if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite training loss')
      loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5,error_if_nonfinite=True);opt.step();total+=float(loss.detach())*n;train_n+=n;steps+=1
     state=state.detach()
    if batch_n%40==0:print(json.dumps({'phase':'training','epoch':epoch,'batch':batch_n,'total_batches':int((len(users)+a.batch_size-1)//a.batch_size),'train_events':train_n,'elapsed_seconds':time.monotonic()-start}),flush=True)
   if device.type=='cuda':torch.cuda.synchronize()
   train_sec=time.monotonic()-start
   if train_n!=train_expected:raise ValueError(f'Training coverage mismatch: {train_n}')
   status['phase']='development_replay';write(out/'status.json',status);print(json.dumps({'phase':'development_replay','epoch':epoch,'train_seconds':train_sec}),flush=True)
   frame,eval_sec=evaluate(model,data,dev,device,a.chunk_size,a.batch_size)
   for col in ('record_idx','student_idx','label'):
    if not np.array_equal(frame[col].to_numpy(),ref[col].to_numpy()):raise ValueError('Development identity mismatch: '+col)
   met=metrics(frame.label.to_numpy(),frame.probability.to_numpy());nll=float(met['nll'])
   if not np.isfinite(nll):raise FloatingPointError('Nonfinite development NLL')
   improved=nll<best
   if improved:
    best=nll;best_epoch=epoch;stale=0
    save_checkpoint(out,'best_model.pt',{'model_state':model.state_dict(),'epoch':epoch,'data_fingerprint':data.fingerprint,'dev_nll':nll,'model':'dkvmn_student_item_bias'})
    frame.assign(original_dkvmn=ref.probability.to_numpy(dtype=np.float32),reference_log_count_R2=ref.reference_log_count_R2.to_numpy(dtype=np.float32)).to_csv(out/'best_dev_predictions.csv.gz',index=False,compression='gzip')
   else:stale+=1
   h={'epoch':epoch,'train_events':train_n,'optimizer_steps':steps,'train_bce':total/train_n,'train_seconds':train_sec,'dev':met,'dev_seconds':eval_sec,'improved':improved,'best_epoch':best_epoch,'stale':stale}
   history.append(h);write(out/'history.json',history)
   save_checkpoint(out,'last_epoch.pt',{'model_state':model.state_dict(),'optimizer_state':opt.state_dict(),'epoch':epoch,'best_epoch':best_epoch,'best_nll':best,'stale':stale,'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if device.type=='cuda' else None,'data_fingerprint':data.fingerprint})
   print(json.dumps({'phase':'epoch_complete',**h}),flush=True)
   if stale>=a.patience:break
  status['phase']='chunk_preflight';write(out/'status.json',status);sample=dev[:min(32,len(dev))]
  f50,_=evaluate(model,data,sample,device,a.chunk_size,a.batch_size);f17,_=evaluate(model,data,sample,device,17,a.batch_size)
  for col in ('record_idx','student_idx','label'):
   if not np.array_equal(f50[col].to_numpy(),f17[col].to_numpy()):raise ValueError('Chunk preflight identity mismatch')
  chunk_diff=float(np.max(np.abs(f50.probability.to_numpy(float)-f17.probability.to_numpy(float)),initial=0))
  if chunk_diff>1e-6:raise ValueError(f'Chunk preflight discrepancy: {chunk_diff}')
  status['phase']='summary';write(out/'status.json',status);df=pd.read_csv(out/'best_dev_predictions.csv.gz',compression='gzip',float_precision='round_trip');y=df.label.to_numpy();students=df.student_idx.to_numpy()
  p=df.probability.to_numpy(dtype=np.float32);o=df.original_dkvmn.to_numpy(dtype=np.float32);r=df.reference_log_count_R2.to_numpy(dtype=np.float32)
  lp=losses(y,p)[:,0];lo=losses(y,o)[:,0];lr=losses(y,r)[:,0];paired=cluster_intervals(students,np.stack((lp-lo,lp-lr),axis=1),1000,20261110)['comparisons']
  _,inv,counts=np.unique(students,return_inverse=True,return_counts=True)
  result={'status':'complete','epochs':len(history),'best_epoch':best_epoch,'best_dev':metrics(y,p),'best_student_macro_nll':float(np.mean(np.bincount(inv,weights=lp)/counts)),
   'original_dkvmn_dev':metrics(y,o),'reference_log_count_R2_dev':metrics(y,r),'bias_minus_original_conditional':paired[0],'bias_minus_R2_conditional':paired[1],
   'zero_bias_bridge_max_abs':bridge,'chunk_preflight_students':len(sample),'chunk17_max_abs':chunk_diff,'stop_reason':'early_stopping' if stale>=a.patience else 'epoch_limit',
   'scope':'exploratory reused development, one seed; added ID biases change information and optimization; no test or holdout',
   'confidence_interval':'student-cluster bootstrap conditional on trained selected models; excludes training and selection uncertainty',
   'best_checkpoint_sha256':sha(out/'best_model.pt'),'last_checkpoint_sha256':sha(out/'last_epoch.pt'),'test_evaluated':False,'holdout_evaluated':False,'seconds':time.monotonic()-begin}
  write(out/'summary.json',result);status.update(status='complete',phase=None,epoch=len(history),best_epoch=best_epoch,seconds=time.monotonic()-begin);write(out/'status.json',status);print('DKVMN BIAS TRAINING COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for key in ('project-dir','data-dir','p1-dir','original-dir','output-dir'):p.add_argument('--'+key,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--batch-size',type=int,default=8);p.add_argument('--chunk-size',type=int,default=50);p.add_argument('--epochs',type=int,default=20);p.add_argument('--patience',type=int,default=5);p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
