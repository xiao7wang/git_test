import hashlib,json,re
from pathlib import Path
root=Path(__file__).resolve().parent
for n,d in json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
 p=root/n
 if p.parent!=root or hashlib.sha256(p.read_bytes()).hexdigest()!=d:raise ValueError('Changed package file: '+n)
lock=json.loads((root/'locked_inputs.json').read_text(encoding='utf8'))
hashes=[lock['count']['checkpoint_sha256'],lock['count']['model_state_sha256'],lock['count']['data_fingerprint'],lock['holdout']['data_fingerprint']]
hashes += list(lock['count']['files'].values())+list(lock['holdout']['files'].values())
if any(re.fullmatch('[0-9a-f]{64}',x) is None for x in hashes):raise ValueError('Invalid SHA256 lock')
print('Package integrity verified',flush=True)
