"""Synthetic count training, independent audit, bridge, pairing and packaging."""
import json,os,shutil,subprocess,sys,tempfile,zipfile,hashlib
from pathlib import Path
import numpy as np,pandas as pd
from cross_core import write,sha,long_followup
from count_core import dev_users
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='p0_audit_test_') as temp:
  root=Path(temp);pkg=root/'pkg';pkg.mkdir();hold=root/'hold';hold.mkdir()
  for n in ('run_audit.py','audit_core.py','count_core.py','cross_core.py','review_stats.py','package_results.py'):
   shutil.copy2(ROOT/n,pkg/n)
  shutil.copy2(ROOT.parent/'uctp_count_baseline_v1/run_baseline.py',pkg/'run_baseline.py')
  cproj=root/'count_project';cproj.mkdir()
  for n in ('run_baseline.py','count_core.py','cross_core.py','review_stats.py'):shutil.copy2(pkg/n,cproj/n)
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  a=fixture.data.arrays;valid=np.flatnonzero(a['split']==1);dev=dev_users(a['student_idx'][valid]);held=set(map(int,np.unique(a['student_idx'][valid])))-dev
  did=valid[np.isin(a['student_idx'][valid],list(dev))];hid=valid[np.isin(a['student_idx'][valid],list(held))]
  ref=root/'ref.csv.gz';pd.DataFrame({'record_idx':did,'student_idx':a['student_idx'][did],'label':a['label'][did]}).to_csv(ref,index=False,compression='gzip')
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  count=cproj/'outputs'/'run'
  cmd=[sys.executable,'-B',str(pkg/'run_baseline.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),
       '--output-dir',str(count),'--reference-dev',str(ref),'--device','cpu','--epochs','2','--patience','1','--ack-row-feedback']
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  frame=pd.DataFrame({'record_idx':hid,'student_idx':a['student_idx'][hid],'label':a['label'][hid]})
  frame.to_csv(hold/'events.csv.gz',index=False,compression='gzip')
  preds={'record_idx':hid}
  for r in 'ABC':
   for seed in (0,1,2):preds[f'{r}_seed{seed}']=np.full(len(hid),.6,dtype=np.float32)
  np.savez_compressed(hold/'predictions.npz',**preds)
  pairs=long_followup(fixture.data,valid);pairs=pairs[np.isin(pairs[:,0],hid)&np.isin(pairs[:,1],hid)]
  np.save(hold/'selected_pairs.npy',pairs,allow_pickle=False)
  write(hold/'status.json',{'status':'complete'});write(hold/'config.json',{'data_fingerprint':fixture.data.fingerprint,'partition_salt':'decision-v1-20261105:','test_evaluated':False,'trained':False,'feedback':'row immediate assumption'});write(hold/'summary.json',{'synthetic':True})
  cs=json.loads((count/'summary.json').read_text())
  cnames=['status.json','config.json','summary.json','history.json','dev_predictions.csv.gz']
  hnames=['status.json','config.json','summary.json','events.csv.gz','predictions.npz','selected_pairs.npy']
  lock={'count':{'files':{n:sha(count/n) for n in cnames},'data_fingerprint':fixture.data.fingerprint,'checkpoint_sha256':cs['checkpoint_sha256'],'model_state_sha256':cs['checkpoint_model_state_sha256'],'best_epoch':cs['best_epoch']},
        'holdout':{'files':{n:sha(hold/n) for n in hnames},'data_fingerprint':fixture.data.fingerprint}}
  write(pkg/'locked_inputs.json',lock)
  cmd=[sys.executable,'-B',str(pkg/'run_audit.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),
       '--count-dir',str(count),'--holdout-dir',str(hold),'--output-dir',str(root/'out'),'--device','cpu','--ack-row-feedback']
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  result=json.loads((root/'out/summary.json').read_text());audit=json.loads((root/'out/count_audit.json').read_text())
  assert result['count_audit_passed'] and audit['development']['mismatches']==0 and audit['holdout']['mismatches']==0
  assert result['n']==len(hid) and not result['trained'] and not result['test_evaluated']
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert q.returncode==0,q.stdout
  with zipfile.ZipFile(root/'out/count_audit_results.zip') as z:
   assert z.testzip() is None;manifest=json.loads(z.read('manifest.json'))
   assert all(hashlib.sha256(z.read(k)).hexdigest()==v for k,v in manifest.items())
  with (hold/'selected_pairs.npy').open('ab') as stream:stream.write(b'tamper')
  bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  print(json.dumps({'synthetic_training_and_p0':True,'independent_audit':True,'bridge':True,'pairing':True,'archive':True,'tamper_guard':True,'real_server_tested':False}))
finally:fixture.tearDown()
