"""Independent sequential historical count audit and frozen model comparisons."""
import numpy as np
import pandas as pd
from review_stats import metrics,losses,cluster_intervals

def audit_sequential(arrays,features,allowed_validation_users,examples_limit=4):
    """Independent dictionary loop in original event order, comparing all selected rows.

    No test or other-student validation outcomes are read. Current labels update
    counts only after comparing the feature row. This does not call the production
    feature builder and shares no cumulative-count implementation with it.
    """
    split=arrays['split'];user=arrays['student_idx'];item=arrays['item_idx'];q=arrays['item_q']
    labels=arrays['label'];timestamps=arrays['timestamp'];ids=features['record_idx']
    if any(np.count_nonzero(row)!=1 for row in q):raise ValueError('Single-KC only')
    kcs=[int(np.flatnonzero(row)[0]) for row in q]
    train_item=set(map(int,np.unique(item[split==0])))
    count={};last_kc_time={};first_validation=set();last_user=None;pos=0;mismatches=0;mismatch_examples=[]
    example_names=('first_kc','first_validation_for_student','same_kc_timestamp','long_gap_gt_7d','long_sequence','unseen_item_in_train','student_boundary')
    examples={x:[] for x in example_names};strata={x:0 for x in example_names}
    for i in range(len(split)):
        code=int(split[i]);student=int(user[i])
        if code>1 or (code==1 and student not in allowed_validation_users):continue
        if pos>=len(ids) or int(ids[pos])!=i:raise AssertionError('Feature selection or event ordering mismatch')
        item_id=int(item[i]);kc=kcs[item_id];key=(student,kc)
        success,failure=count.get(key,(0,0));timestamp=float(timestamps[i]);previous=last_kc_time.get(key)
        same_time=previous is not None and timestamp==previous
        long_gap=previous is not None and timestamp-previous>168*3600
        flags={'first_kc':key not in count,'first_validation_for_student':code==1 and student not in first_validation,
               'same_kc_timestamp':same_time,'long_gap_gt_7d':long_gap,
               'long_sequence':int(arrays['student_count_before'][i])>=1000,
               'unseen_item_in_train':item_id not in train_item,'student_boundary':student!=last_user}
        matches=(int(features['student'][pos])==student and int(features['item'][pos])==item_id and
                 int(features['kc'][pos])==kc and int(features['success'][pos])==success and int(features['failure'][pos])==failure)
        if not matches:
            mismatches+=1
            if len(mismatch_examples)<20:
                mismatch_examples.append({'record_idx':i,'student_idx':student,'kc_idx':kc,
                  'expected_success':success,'actual_success':int(features['success'][pos]),
                  'expected_failure':failure,'actual_failure':int(features['failure'][pos]),
                  'actual_student':int(features['student'][pos]),'actual_item':int(features['item'][pos]),'actual_kc':int(features['kc'][pos])})
        for name,flag in flags.items():
            if flag:
                strata[name]+=1
                if len(examples[name])<examples_limit:
                    examples[name].append({'record_idx':i,'student_idx':student,'kc_idx':kc,'split':code,
                      'success_before':success,'failure_before':failure,'same_timestamp':same_time,
                      'gap_hours':None if previous is None else (timestamp-previous)/3600.0,'feature_matches':matches})
        y=labels[i]
        if y not in (0,1):raise ValueError('Invalid legal-history label')
        count[key]=(success+int(y),failure+int(1-y));last_kc_time[key]=timestamp
        if code==1:first_validation.add(student)
        last_user=student;pos+=1
    if pos!=len(ids):raise AssertionError('Feature coverage mismatch')
    return {'events_checked':pos,'mismatches':mismatches,'mismatch_examples':mismatch_examples,'strata_counts':strata,'examples':examples,
            'comparison':'independent dictionary loop; event-order read before current feedback',
            'test_labels_read':False,'other_partition_validation_labels_read':False}

def compare_models(frame,count_prob,prior,pairs,reps=2000):
    ids=frame.record_idx.to_numpy();y=frame.label.to_numpy();u=frame.student_idx.to_numpy()
    if not np.array_equal(ids,prior['record_idx']):raise ValueError('Prior prediction IDs differ')
    if len(ids)==0 or np.any(np.diff(ids)<=0):raise ValueError('Invalid sorted event IDs')
    if not np.isin(pairs,ids).all():raise ValueError('Pair outside holdout')
    left=np.searchsorted(ids,pairs[:,0]);right=np.searchsorted(ids,pairs[:,1])
    if len(pairs) and not np.array_equal(u[left],u[right]):raise ValueError('Pair student mismatch')
    p={'count_seed0':count_prob}
    for r in 'ABC':
        for seed in (0,1,2):p[f'{r}_seed{seed}']=prior[f'{r}_seed{seed}']
    _,inv=np.unique(u,return_inverse=True);rows={};ls={}
    for name,probs in p.items():
        loss=losses(y,probs)[:,0];ls[name]=loss;row=metrics(y,probs)
        row['student_macro_nll']=float(np.mean(np.bincount(inv,weights=loss)/np.bincount(inv)))
        row['pair_n']=len(pairs)
        for label,values in [('current_nll',loss[left]),('next_nll',loss[right]),('two_event_mean_nll',(loss[left]+loss[right])/2)]:
            row[label]=float(values.mean()) if len(values) else None
        rows[name]=row
    paired={}
    for rule in 'ABC':
        d=np.stack([ls['count_seed0']-ls[f'{rule}_seed{s}'] for s in (0,1,2)],axis=1)
        matrix=np.column_stack((d,d.mean(axis=1)))
        overall=cluster_intervals(u,matrix,reps,20261109)
        row={'seed0':overall['comparisons'][0],'seed1':overall['comparisons'][1],
             'seed2':overall['comparisons'][2],'fixed_three_seed_mean':overall['comparisons'][3]}
        if len(pairs):
            for n,v in [('current',matrix[left]),('next',matrix[right]),('two_event_mean',(matrix[left]+matrix[right])/2)]:
                row[n]=cluster_intervals(u[left],v,reps,20261109)['comparisons'][3]
        paired['count_minus_'+rule]=row
    return {'n':len(ids),'students':len(np.unique(u)),'pair_n':len(pairs),'rows':rows,'paired':paired,
            'scope':'exploratory reused ASSIST validation holdout; fixed models; no test or training',
            'bootstrap':'cluster students; count seed0 vs mean loss of three fixed candidates; does not include parameter selection or training randomness'}
