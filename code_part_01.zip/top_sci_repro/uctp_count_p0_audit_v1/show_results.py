import argparse
from pathlib import Path
from cross_core import read
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);root=Path(p.parse_args().output_dir)
if not (root/'status.json').exists():print('Not started or tests still running; check launch log.')
else:
 s=read(root/'status.json');print('status:',s['status'],'phase:',s.get('phase'),'error:',s.get('error','-'))
 print('A saved running status does not prove a live process.')
 if (root/'count_audit.json').exists():
  a=read(root/'count_audit.json');print('Count audit:', 'PASS' if a['passed'] else 'FAIL', 'development mismatches:',a['development']['mismatches'],'holdout mismatches:',a['holdout']['mismatches'])
 if (root/'summary.json').exists():
  q=read(root/'summary.json');print('events:',q['n'],'students:',q['students'],'pairs:',q['pair_n'])
  for name in ('count_seed0','A_seed0','B_seed0','C_seed0'):
   x=q['rows'][name];print(name,'NLL:',x['nll'],'student_NLL:',x['student_macro_nll'],'AUC:',x['auc'])
  print('Fixed-model student bootstrap:',q['paired']['count_minus_C']['fixed_three_seed_mean'])
 if (root/'count_audit_results.zip').exists():print('Results archive:',root/'count_audit_results.zip')
