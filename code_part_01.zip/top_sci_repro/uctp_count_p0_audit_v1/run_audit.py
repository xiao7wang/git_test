"""Independent full-data count audit and fixed-checkpoint holdout comparison."""
import argparse,io,json,os,time
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
from cross_core import import_project,read,sha,write,model_digest,long_followup
from count_core import CountModel,dev_users,prior_count_features,SALT
from audit_core import audit_sequential,compare_models

ROOT=Path(__file__).resolve().parent

def check_source(root,lock,kind):
    for name,digest in lock[kind]['files'].items():
        if sha(root/name)!=digest:raise ValueError(f'{kind} source changed: {name}')
    if read(root/'status.json')['status']!='complete':raise ValueError(kind+' source incomplete')

def main():
 p=argparse.ArgumentParser()
 for n in ('project-dir','data-dir','count-dir','holdout-dir','output-dir'):p.add_argument('--'+n,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--ack-row-feedback',action='store_true')
 a=p.parse_args()
 if not a.ack_row_feedback:p.error('Acknowledge row-immediate feedback assumption')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False)
 begin=time.monotonic();status={'status':'running','phase':'source_audit','trained':False,'test_evaluated':False}
 write(out/'status.json',status)
 try:
  lock=read(ROOT/'locked_inputs.json');count=Path(a.count_dir);holdout=Path(a.holdout_dir)
  check_source(count,lock,'count');check_source(holdout,lock,'holdout')
  if sha(count/'best_model.pt')!=lock['count']['checkpoint_sha256']:raise ValueError('Count checkpoint changed')
  cfg=read(count/'config.json');prior_cfg=read(holdout/'config.json')
  training_root=count.parent.parent
  for name,digest in cfg['code_sha256'].items():
   if sha(training_root/name)!=digest:raise ValueError('Training source changed or missing: '+name)
  if cfg['code_sha256']['count_core.py']!=sha(ROOT/'count_core.py'):raise ValueError('Count feature source differs from training')
  if cfg['data_fingerprint']!=lock['count']['data_fingerprint'] or prior_cfg['data_fingerprint']!=cfg['data_fingerprint']:
   raise ValueError('Different data fingerprints')
  if cfg['student_partition_salt']!=SALT or prior_cfg['partition_salt']!=SALT:raise ValueError('Partition differs')
  if cfg['feedback']!='row immediate assumption' or prior_cfg['feedback']!='row immediate assumption':raise ValueError('Feedback assumption differs')
  if cfg['test_evaluated'] or cfg['holdout_evaluated'] or prior_cfg['test_evaluated'] or prior_cfg['trained']:
   raise ValueError('Prior protocol differs')
  if cfg['time_features_used'] or cfg['evaluation']!='development only; NLL selects epoch':raise ValueError('Count training information protocol differs')
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol']
  Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=cfg['data_fingerprint']:raise ValueError('Data manifest differs')
  data=Data(a.data_dir);valid=np.flatnonzero(data.arrays['split']==1)
  all_students=np.unique(data.arrays['student_idx'][valid]);dev=dev_users(all_students);held=set(map(int,all_students))-dev
  if not dev or not held:raise ValueError('Partition empty')
  status['phase']='full_development_count_audit';write(out/'status.json',status);print('START full development count audit',flush=True)
  fd=prior_count_features(data.arrays,dev);ad=audit_sequential(data.arrays,fd,dev)
  if int(np.sum(fd['split']==0))!=cfg['train_rows'] or int(np.sum(fd['split']==1))!=cfg['dev_rows']:
   raise ValueError('Count training or development event coverage differs')
  write(out/'count_audit_development.json',ad)
  if ad['mismatches']!=0:raise AssertionError(f"Development count audit mismatches: {ad['mismatches']}")
  status['phase']='full_holdout_count_audit';write(out/'status.json',status);print('START full holdout count audit',flush=True)
  fh=prior_count_features(data.arrays,held);ah=audit_sequential(data.arrays,fh,held)
  write(out/'count_audit_holdout.json',ah)
  if ah['mismatches']!=0:raise AssertionError(f"Holdout count audit mismatches: {ah['mismatches']}")
  audit={'development':ad,'holdout':ah,'passed':True,
         'parameter_information_audit':{'training_source_hashes_match':True,'training_rows_match':True,
          'development_rows_match':True,'training_data_fingerprint_match':True,'time_features_used':False,
          'training_protocol':'train labels only; development NLL for epoch selection; source and config checked',
          'limitation':'source/config check is not an independent replay of optimizer or direct measurement of real feedback timing'},
         'note':'Counts checked before scoring; actual feedback timing remains assumed.'};write(out/'count_audit.json',audit)
  device=torch.device(a.device);torch.set_num_threads(4);torch.use_deterministic_algorithms(True)
  checkpoint=torch.load(count/'best_model.pt',map_location='cpu',weights_only=True)
  if checkpoint['data_fingerprint']!=cfg['data_fingerprint'] or checkpoint['epoch']!=lock['count']['best_epoch'] or checkpoint['model']!='pfa_inspired_log_count':raise ValueError('Checkpoint metadata differs')
  dims=data.manifest['summary'];model=CountModel(dims['students'],dims['items'],dims['knowledges'])
  model.load_state_dict(checkpoint['model_state'],strict=True);model=model.to(device).eval();model.requires_grad_(False)
  before=model_digest(model.state_dict())
  if before!=lock['count']['model_state_sha256']:raise ValueError('Checkpoint tensor digest differs')
  def predict(features):
   idx=np.flatnonzero(features['split']==1)
   with torch.no_grad():
    args=[torch.as_tensor(features[k][idx],dtype=torch.long if k in ('student','item','kc') else torch.float32,device=device) for k in ('student','item','kc','success','failure')]
    prob=torch.sigmoid(model(*args)).cpu().numpy()
   return idx,prob
  dv,dprob=predict(fd);ref=pd.read_csv(count/'dev_predictions.csv.gz',compression='gzip',float_precision='round_trip')
  if not np.array_equal(ref.record_idx,fd['record_idx'][dv]) or not np.array_equal(ref.student_idx,fd['student'][dv]) or not np.array_equal(ref.label,fd['label'][dv]):raise ValueError('Development bridge identity differs')
  diff=float(np.max(np.abs(ref.probability.to_numpy(dtype=np.float32).astype(float)-dprob.astype(float)),initial=0))
  if diff>1e-6:raise ValueError(f'Development prediction bridge differs: {diff}')
  status['phase']='holdout_prediction';write(out/'status.json',status);print('Development bridge passed; starting holdout',flush=True)
  hv,hprob=predict(fh);frame=pd.read_csv(holdout/'events.csv.gz',compression='gzip',float_precision='round_trip')
  for col,key in [('record_idx','record_idx'),('student_idx','student'),('label','label')]:
   if not np.array_equal(frame[col].to_numpy(),fh[key][hv]):raise ValueError('Holdout identity mismatch: '+col)
  with np.load(holdout/'predictions.npz',allow_pickle=False) as z:prior={k:z[k] for k in z.files}
  pairs=np.load(holdout/'selected_pairs.npy',allow_pickle=False)
  all_pairs=long_followup(data,valid);expected_pairs=all_pairs[np.isin(all_pairs[:,0],frame.record_idx)&np.isin(all_pairs[:,1],frame.record_idx)]
  if not np.array_equal(pairs,expected_pairs):raise ValueError('Long-gap pair selection differs')
  summary=compare_models(frame,hprob,prior,pairs)
  if model_digest(model.state_dict())!=before:raise ValueError('Model changed during evaluation')
  summary.update(trained=False,test_evaluated=False,development_bridge={'n':len(dv),'max_abs_difference':diff,'atol':1e-6},
                 count_audit_passed=True,seconds=time.monotonic()-begin)
  pd.DataFrame({'record_idx':fh['record_idx'][hv],'student_idx':fh['student'][hv],'label':fh['label'][hv],
                'split':fh['split'][hv],'probability':hprob}).to_csv(out/'count_holdout_predictions.csv.gz',index=False,compression='gzip')
  write(out/'config.json',{'source_locks':lock,'data_fingerprint':data.fingerprint,'partition_salt':SALT,
        'trained':False,'test_evaluated':False,'feedback':'row immediate assumption',
        'audit':'independent sequential check for all training and selected validation events in each partition',
        'code_sha256':{n:sha(ROOT/n) for n in ('run_audit.py','audit_core.py','count_core.py','cross_core.py','review_stats.py')}})
  write(out/'summary.json',summary);status.update(status='complete',phase=None,seconds=time.monotonic()-begin);write(out/'status.json',status)
  print('AUDIT AND HOLDOUT COMPLETE',flush=True)
 except BaseException as exc:
  status.update(status='failed',error=repr(exc),seconds=time.monotonic()-begin);write(out/'status.json',status);raise

if __name__=='__main__':main()
