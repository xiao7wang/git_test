import tempfile,unittest
from pathlib import Path
import numpy as np
import pandas as pd
from count_core import prior_count_features
from audit_core import audit_sequential,compare_models

def sample():
 return {'student_idx':np.array([0,0,0,0,0,1,1,1,1]),'item_idx':np.array([0,0,1,0,0,0,0,0,0]),
         'split':np.array([0,0,0,1,2,0,0,1,2]),'timestamp':np.array([0,0,2,800000,900000,0,1,800000,900000],dtype=float),
         'label':np.array([1,0,1,1,0,1,0,1,1],dtype=float),'item_q':np.array([[1,0],[0,1]]),
         'student_count_before':np.array([0,1,2,3,4,0,1,2,3])}

class AuditTests(unittest.TestCase):
 def test_independent_loop_detects_wrong_count_and_boundaries(self):
  a=sample();f=prior_count_features(a,{0});r=audit_sequential(a,f,{0})
  self.assertEqual(r['mismatches'],0);self.assertEqual(r['events_checked'],6)
  self.assertGreater(r['strata_counts']['same_kc_timestamp'],0)
  self.assertGreater(r['strata_counts']['first_validation_for_student'],0)
  self.assertGreater(r['strata_counts']['long_gap_gt_7d'],0)
  bad={k:v.copy() for k,v in f.items()};bad['success'][1]+=1
  self.assertGreater(audit_sequential(a,bad,{0})['mismatches'],0)
 def test_other_partition_and_test_labels_do_not_enter(self):
  a=sample();f=prior_count_features(a,{0});a['label'][4]=np.nan;a['label'][7:]=np.nan
  self.assertEqual(audit_sequential(a,f,{0})['mismatches'],0)
 def test_paired_loss_aligns_events_and_not_probabilities(self):
  frame=pd.DataFrame({'record_idx':[1,2,3,4],'student_idx':[0,0,1,1],'label':[1,0,1,0]})
  pred={'record_idx':np.array([1,2,3,4])}
  for r in 'ABC':
   for s in (0,1,2):pred[f'{r}_seed{s}']=np.array([.7,.3,.7,.3],dtype=np.float32)
  out=compare_models(frame,np.array([.7,.3,.7,.3],dtype=np.float32),pred,np.array([[1,2],[3,4]]),reps=20)
  self.assertEqual(out['paired']['count_minus_A']['fixed_three_seed_mean']['delta'],0)
  self.assertEqual(out['paired']['count_minus_C']['two_event_mean']['delta'],0)
  pred['record_idx']=np.array([1,2,4,3])
  with self.assertRaises(ValueError):compare_models(frame,np.ones(4)*.5,pred,np.array([[1,2]]),reps=20)

if __name__=='__main__':unittest.main(verbosity=2)
