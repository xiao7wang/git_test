#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
NAME="${1:-server_p0_01}"
if [[ ! "$NAME" =~ ^[A-Za-z0-9_-]+$ ]];then echo 'Invalid name' >&2;exit 2;fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data/assist_full
COUNT=/home/wangxiao/QCCDM/top_sci_repro/uctp_count_baseline_v1/outputs/server_count_01
HOLDOUT=/home/wangxiao/QCCDM/top_sci_repro/uctp_retrain_holdout_v1/outputs/server_holdout_01
OUT="$DIR/outputs/$NAME";LOG="$DIR/outputs/$NAME.launch.log"
mkdir -p "$DIR/outputs"
if [[ -e "$OUT" || -e "$LOG" ]];then echo 'Existing output preserved' >&2;exit 2;fi
(set -o noclobber; : > "$LOG")
exec > >(tee -a "$LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$DIR/verify_package.py"
"$PY" -B "$DIR/test_audit.py"
for DEVICE in cpu cuda;do
 echo "Starting $DEVICE tests"
 "$PY" -B "$DIR/test_core.py" --device "$DEVICE"
done
"$PY" -B -u "$DIR/run_audit.py" --project-dir "$PROJECT" --data-dir "$DATA" --count-dir "$COUNT" --holdout-dir "$HOLDOUT" --output-dir "$OUT" --device cuda --ack-row-feedback
"$PY" -B "$DIR/package_results.py" --output-dir "$OUT"
