"""Serial fail-fast diagnostic suite. Never trains or overwrites an old run."""
import argparse
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from cross_core import read, write, sha, check_hash
from step_core import ROOT, audit


def main():
    p = argparse.ArgumentParser()
    for key in ('project-dir', 'data-root', 'cache-root', 'output-root'):
        p.add_argument('--' + key, required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), default='cuda')
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Both feedback/time-proxy acknowledgements required')
    for name, digest in read(ROOT / 'PACKAGE_MANIFEST.json').items():
        check_hash(ROOT / name, digest)
    for dataset in ('assist', 'ednet'):
        for seed in range(3):
            audit(args.project_dir, args.data_root, args.cache_root, dataset, seed)
    print('Six frozen none checkpoints and accepted NN/NS cached outputs verified.', flush=True)
    out = Path(args.output_root).resolve()
    out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    status = {'status': 'running', 'active_job': None, 'jobs': [], 'pid': os.getpid(),
              'trained': False, 'test_evaluated': False, 'inputs_modified': False}
    write(out / 'suite_config.json', {'args': vars(args), 'package_hashes': read(ROOT / 'PACKAGE_MANIFEST.json')})
    write(out / 'suite_status.json', status)
    env = dict(os.environ, CUBLAS_WORKSPACE_CONFIG=':4096:8', PYTHONDONTWRITEBYTECODE='1')

    def job(name, command):
        status['active_job'] = name
        write(out / 'suite_status.json', status)
        log = out / (name + '.log')
        print(f'Starting {name}; log: {log}', flush=True)
        begin = time.monotonic()
        with log.open('x', encoding='utf-8') as stream:
            child = subprocess.Popen([sys.executable, '-B', '-u'] + command, cwd=ROOT, env=env,
                                     stdout=stream, stderr=subprocess.STDOUT)
            status['child_pid'] = child.pid
            write(out / 'suite_status.json', status)
            try:
                rc = child.wait()
            except BaseException:
                if child.poll() is None:
                    child.terminate()
                    child.wait()
                raise
        status['jobs'].append({'name': name, 'returncode': rc, 'seconds': time.monotonic()-begin})
        write(out / 'suite_status.json', status)
        if rc != 0:
            raise RuntimeError(f'{name} failed; read {log}. Old outputs preserved.')
        print(f'Completed {name} ({status["jobs"][-1]["seconds"]:.1f}s)', flush=True)

    try:
        for device in (('cpu', 'cuda') if args.device == 'cuda' else ('cpu',)):
            job('tests_' + device, [str(ROOT / 'test_step.py'), '--project-dir', args.project_dir,
                                   '--device', device, '--report', str(out / ('tests_' + device + '.json'))])
        for preflight in (True, False):
            for dataset in ('assist', 'ednet'):
                for seed in range(3):
                    name = f'{dataset}_seed{seed}_' + ('preflight' if preflight else 'full')
                    command = [str(ROOT / 'run_job.py'), '--project-dir', args.project_dir, '--data-root', args.data_root,
                               '--cache-root', args.cache_root, '--output-dir', str(out / name), '--dataset', dataset,
                               '--seed', str(seed), '--device', args.device, '--ack-row-feedback', '--ack-time-proxy']
                    if preflight:
                        command.append('--preflight')
                    job(name, command)
        job('summary', [str(ROOT / 'summarize.py'), '--output-root', str(out)])
        status.update(status='complete', active_job=None, child_pid=None, seconds=time.monotonic()-start)
        write(out / 'suite_status.json', status)
        files = sorted(p for p in out.rglob('*') if p.is_file())
        write(out / 'result_manifest.json', {p.relative_to(out).as_posix(): sha(p) for p in files})
        archive = out / 'fixed_step_results.zip'
        with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
            for file in files + [out / 'result_manifest.json']:
                z.write(file, file.relative_to(out).as_posix())
        with zipfile.ZipFile(archive) as z:
            if z.testzip() is not None:
                raise RuntimeError('Archive integrity failure')
        print('ALL_COMPLETED. Download: ' + str(archive), flush=True)
    except BaseException as exc:
        status.update(status='failed', error=repr(exc), seconds=time.monotonic()-start)
        write(out / 'suite_status.json', status)
        raise


if __name__ == '__main__':
    main()
