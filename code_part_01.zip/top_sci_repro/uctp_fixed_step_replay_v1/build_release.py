"""Build a separate pinned release from accepted local artifacts, never old sources."""
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'uctp_frozen_cross_replay_v1'
ARCHIVE = ROOT.parent / 'cross_replay_results.zip'
ARCHIVE_SHA = '2734b9a8a4cf396a406c7cb57ad0d49ae060fc6c1d8146e3f3b7f8dda024328a'
WEIGHTS = ROOT.parent / 'a1_cross_weights_check_01.json'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf-8')


def main():
    if digest(ARCHIVE.read_bytes()) != ARCHIVE_SHA:
        raise ValueError('Unexpected cross-replay archive')
    w = json.loads(WEIGHTS.read_text(encoding='utf-8'))
    checker = ROOT.parent / 'a1_cross_alignment_20261026/check_a1_cross_weights.py'
    if w['script_sha256'] != digest(checker.read_bytes()) or not w['success'] or len(w['pairs']) != 4:
        raise ValueError('Invalid returned weight identity report')
    alignment = json.loads((ROOT.parent / 'a1_cross_alignment_20261026/alignment_results.json').read_text(encoding='utf-8'))
    expected_pairs = {(d, r['seed']): r for d, obj in alignment['datasets'].items() for r in obj['identities']}
    for row in w['pairs']:
        source = expected_pairs.pop((row['dataset'], row['seed']))
        if (not row['success'] or not row['input_files_unchanged'] or row['left_tensor_digest'] != row['right_tensor_digest'] or
            row['left_tensor_count'] != 20 or row['right_tensor_count'] != 20 or
            any(row[k] for k in ('missing_from_left', 'missing_from_right', 'different_tensors')) or
            row['expected_old_file_sha256'] != source['a1_checkpoint_sha256'] or
            row['expected_new_file_sha256'] != source['factorial_checkpoint_sha256']):
            raise ValueError('Weight report/pinned identity mismatch')
    if expected_pairs or any(w[k] for k in ('trained', 'test_evaluated', 'inputs_modified', 'data_loaded', 'model_constructed')):
        raise ValueError('Missing pair or unexpected work in identity report')
    with zipfile.ZipFile(ARCHIVE) as z:
        if z.testzip() is not None:
            raise ValueError('Bad archive CRC')
        manifest = json.loads(z.read('result_manifest.json'))
        for name, h in manifest.items():
            if digest(z.read(name)) != h:
                raise ValueError(name)
        cfg = json.loads(z.read('suite_config.json'))
        for name in ('cross_core.py', 'review_stats.py', 'expected_inputs.json'):
            blob = (OLD / name).read_bytes()
            if digest(blob) != cfg['package_hashes'][name]:
                raise ValueError('Original dependency changed: ' + name)
            (ROOT / name).write_bytes(blob)  # Mechanical copy of verified, unchanged helpers.
        pins = {'cross_archive_sha256': ARCHIVE_SHA, 'files': {}}
        for dataset in ('assist', 'ednet'):
            for seed in range(3):
                name = f'{dataset}_seed{seed}_full'
                pins['files'][name] = {k[len(name)+1:]: h for k, h in manifest.items() if k.startswith(name + '/')}
                if not pins['files'][name]:
                    raise ValueError('Missing full cached run')
        save(ROOT / 'cached_inputs.json', pins)
    (ROOT / 'weight_identity_report.json').write_bytes(WEIGHTS.read_bytes())
    save(ROOT.parent / 'a1_cross_alignment_20261026/weight_identity_acceptance.json', {
        'accepted': True, 'date': '2026-10-27', 'report_sha256': digest(WEIGHTS.read_bytes()),
        'matched_checker_sha256': w['script_sha256'], 'pairs': 4, 'tensors_per_model': 20,
        'all_exact': True, 'seconds_on_server': w['seconds'],
        'note': 'Resolves checkpoint tensor identity; prior baseline output bridge remains valid. Not proof of temporal benefit.'})
    if '--prepare-only' in sys.argv:
        print('Verified weight report and prepared pinned dependencies/cache identities.')
        return
    for filename in ('LOCAL_TEST_REPORT.json', 'LOCAL_INTEGRATION_REPORT.json'):
        report = json.loads((ROOT / filename).read_text(encoding='utf-8'))
        if not report['success']:
            raise ValueError('Local validation missing or failed: ' + filename)
    files = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name != 'PACKAGE_MANIFEST.json')
    save(ROOT / 'PACKAGE_MANIFEST.json', {p.name: digest(p.read_bytes()) for p in files})
    target = Path('C:/Users/xwsws/Desktop/uctp_fixed_step_replay_v1.zip')
    with zipfile.ZipFile(target, 'x', zipfile.ZIP_DEFLATED) as z:
        for p in files + [ROOT / 'PACKAGE_MANIFEST.json']:
            z.write(p, ROOT.name + '/' + p.name)
    with zipfile.ZipFile(target) as z:
        if z.testzip() is not None:
            raise ValueError('Release archive CRC failed')
    print(target)
    print('sha256:', digest(target.read_bytes()))


if __name__ == '__main__':
    main()
