"""Fixed-per-positive-gap support discount: one new frozen control, no fitting.

The actual length of a positive interval never reaches the fixed transition.
Zero-gap and first-KC protections deliberately still use timestamps.
"""
import math
from pathlib import Path

import numpy as np
import pandas as pd

from cross_core import RATE, KEYS, read, sha, check_hash, frozen_model, compare, validation_frame

ROOT = Path(__file__).resolve().parent
BRANCHES = ("NN", "NS", "NF")  # Same none-trained weights: none, real-time, fixed-step.


def calibrate(split, student, item, timestamp, item_q):
    """Train-only label-free mean retention. No label/RT parameter exists.

Use exact timestamp differences of repeated (student, KC) train queries;
exclude first encounters and zero intervals. Every eligible event has one vote.
This matches average TRAIN retention, not all future support/learning-rate paths.
"""
    q = np.asarray(item_q)
    if q.ndim != 2 or not np.isin(q, [0, 1]).all() or not (q.sum(1) == 1).all():
        raise ValueError("This release requires verified single-KC Q")
    ids = np.flatnonzero(np.asarray(split) == 0)
    if not len(ids):
        raise ValueError("No train events")
    u, it, t = np.asarray(student)[ids], np.asarray(item)[ids], np.asarray(timestamp)[ids]
    if t.dtype != np.float64 or not np.isfinite(t).all():
        raise ValueError("Train timestamp must be finite float64 seconds")
    if not np.issubdtype(u.dtype, np.integer) or not np.issubdtype(it.dtype, np.integer):
        raise ValueError("Integer identifiers required")
    if (u < 0).any() or (it < 0).any() or (it >= len(q)).any():
        raise ValueError("Invalid train IDs")
    if (np.diff(u) < 0).any() or (np.diff(t)[np.diff(u) == 0] < 0).any():
        raise ValueError("Train history not chronological by student")
    kc = q.argmax(1)[it]
    key = u.astype(np.int64) * q.shape[1] + kc
    order = np.lexsort((ids, key))
    repeated = key[order][1:] == key[order][:-1]
    gaps = np.diff(t[order])[repeated] / 3600.0
    if (gaps < 0).any():
        raise ValueError("Backward KC clock")
    positive = gaps[gaps > 0]
    if not len(positive):
        raise ValueError("No positive repeated train KC gaps: do not invent a coefficient")
    # Native time model uses exp in float64, then casts retention to float32.
    retention = np.exp(-RATE * positive).astype(np.float32)
    mean = float(retention.astype(np.float64).mean())
    applied = float(np.float32(mean))
    if not 0 <= applied <= 1:
        raise AssertionError("Invalid retention")
    return {
        "formula": "float32(mean(float32(exp(-ln(2)*positive_train_KC_gap_hours/168))))",
        "half_life_hours": 168, "train_rows": len(ids), "repeat_train_gaps": len(gaps),
        "zero_train_gaps_excluded": int((gaps == 0).sum()), "eligible_positive_train_gaps": len(positive),
        "mean_retention_float64": mean, "fixed_retention_float32": applied,
        "train_retention_quantiles": np.quantile(retention, [0, .25, .5, .75, 1]).tolist(),
        "train_gap_hours_quantiles": np.quantile(positive, [0, .25, .5, .75, 1]).tolist(),
        "labels_used": False, "validation_used": False, "test_used": False,
        "matches": "Average eligible train retention only; not realized support or update-rate trajectories",
    }


def calibrate_data(data):
    a = data.arrays
    return calibrate(a['split'], a['student_idx'], a['item_idx'], a['timestamp'], a['item_q'])


def fixed_class(Base):
    """Reuse the pinned head/observe/chunk loop; replace only the time transition."""
    import torch
    from src.temporal_model import BetaEvidence, Clock, TemporalState

    class FixedStepCD(Base):
        def __init__(self, *args, fixed_retention, **kwargs):
            value = float(fixed_retention)
            if not math.isfinite(value) or not 0 <= value <= 1:
                raise ValueError("Fixed retention must be in [0,1]")
            kwargs.update(time_mode="support_only", decay_rate_per_hour=RATE)
            super().__init__(*args, **kwargs)
            if self.variant != "unit_write":
                raise ValueError("Only unit_write is allowed")
            self.fixed_retention = value  # Not a parameter/buffer; never optimized.

        def _advance_time_unchecked(self, state, q, timestamp, active_mask):
            clock, evidence = state.clock, state.evidence
            if not isinstance(evidence, BetaEvidence):
                raise TypeError("Fixed support requires BetaEvidence")
            now = torch.where(active_mask, timestamp, clock.last_event_seconds)
            selected = active_mask[:, None] & (q > 0)
            # Read only the sign of an elapsed interval; not its magnitude.
            positive_gap = now[:, None] > clock.last_kc_seconds
            support = evidence.alpha + evidence.beta
            changed = selected & clock.seen_kc & positive_gap & (support > 2.0)
            next_support = 2.0 + (support - 2.0) * self.fixed_retention
            factor = next_support / support
            next_evidence = BetaEvidence(
                torch.where(changed, evidence.alpha * factor, evidence.alpha),
                torch.where(changed, evidence.beta * factor, evidence.beta))
            next_clock = Clock(torch.where(selected, now[:, None], clock.last_kc_seconds),
                               clock.seen_kc | selected, now, clock.seen_event | active_mask)
            return TemporalState(next_evidence, next_clock)

    return FixedStepCD


def make_fixed(Base, checkpoint, device, fingerprint, sources, retention):
    def factory(**kwargs):
        return fixed_class(Base)(fixed_retention=retention, **kwargs)
    return frozen_model(factory, checkpoint, 'support_only', device, fingerprint, sources)


def audit(project, data_root, cache_root, dataset, seed):
    expected, cache = read(ROOT / 'expected_inputs.json'), read(ROOT / 'cached_inputs.json')
    spec = expected['datasets'][dataset]
    run = next(r for r in spec['runs'] if r['mode'] == 'none' and r['seed'] == seed)
    sources = spec['shared_protocol']['source']
    for name, digest in sources.items():
        check_hash(Path(project) / name, digest)
    check_hash(Path(data_root) / f'{dataset}_full/manifest.json', spec['shared_protocol']['data_fingerprint'])
    folder = Path(project) / run['relative_run_dir']
    check_hash(folder / 'best_model.pt', run['checkpoint_sha256'])
    for name, digest in run['input_hashes'].items():
        check_hash(folder / name, digest)
    cfg = read(folder / 'run_config.json')
    a = cfg['args']
    if (read(folder / 'status.json')['status'] != 'complete' or a['time_mode'] != 'none' or
        a['variant'] != 'unit_write' or a['seed'] != seed or a['eval_update_targets'] != 1 or a['evaluate_test']):
        raise ValueError('Frozen none checkpoint protocol changed')
    name = f'{dataset}_seed{seed}_full'
    for member, digest in cache['files'][name].items():
        check_hash(Path(cache_root) / name / member, digest)
    old = Path(cache_root) / name
    if read(old / 'status.json')['status'] != 'complete' or not read(old / 'status.json')['all_gates_passed']:
        raise ValueError('Cached run not accepted')
    oldcfg = read(old / 'run_config.json')
    if oldcfg['selected_inputs']['none'] != run or oldcfg['data_fingerprint'] != spec['shared_protocol']['data_fingerprint']:
        raise ValueError('Cached parameter/data provenance changed')
    return run, sources, old


def cached_arrays(folder, data, users=None):
    frame = pd.read_csv(folder / 'events.csv.gz', compression='gzip', float_precision='round_trip')
    ids = np.flatnonzero(data.arrays['split'] == 1)
    wanted = validation_frame(data, ids)
    if frame.columns.tolist() != wanted.columns.tolist():
        raise AssertionError('Cached event schema changed')
    for key in wanted:
        if not np.array_equal(frame[key].to_numpy(), wanted[key].to_numpy()):
            raise AssertionError('Cached event identity changed: ' + key)
    with np.load(folder / 'predictions.npz', allow_pickle=False) as z:
        if not np.array_equal(z['record_idx'], ids):
            raise AssertionError('Cached prediction record order changed')
        result = {}
        for branch in ('NN', 'NS'):
            result[branch] = {'record_idx': ids}
            for key in KEYS:
                v = z[f'{branch}_{key}']
                if v.dtype != np.float32 or not np.isfinite(v).all() or v.shape != ids.shape:
                    raise AssertionError('Invalid cached FP32 output')
                result[branch][key] = v
    if users is not None:
        mask = np.isin(frame.student_idx.to_numpy(), users)
        result = {b: {k: v[mask] for k, v in r.items()} for b, r in result.items()}
        frame = frame.loc[mask].reset_index(drop=True)
    return frame, result


def cold_compare(results, data):
    ids = results['NN']['record_idx']
    cold = data.arrays['kc_count_before'][ids] == 0
    left = {k: v[cold] for k, v in results['NN'].items()}
    right = {k: v[cold] for k, v in results['NF'].items()}
    return compare(left, right)
