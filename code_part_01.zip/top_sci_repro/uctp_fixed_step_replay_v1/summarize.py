"""Summarize every seed and group; fail on missing, mixed, or changed runs."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import read, write, sha, KEYS
from step_stats import BRANCHES, summarize_group, all_groups, pair_window


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output-root', type=Path, required=True)
    args = p.parse_args()
    report = {'datasets': {}, 'bootstrap_reps': 2000, 'bootstrap_seed': 20261027,
              'primary_contrast': 'NS-NF event NLL; report student-macro NLL jointly',
              'scope': 'Frozen validation, pointwise student-cluster intervals conditional on chosen checkpoints; no multiplicity correction',
              'trained': False, 'test_evaluated': False}
    for dataset in ('assist', 'ednet'):
        frames, pred, evidence, calibrations, pp = [], [], [], [], []
        for seed in range(3):
            folder = args.output_root / f'{dataset}_seed{seed}_full'
            for name, digest in read(folder / 'artifact_manifest.json').items():
                if sha(folder / name) != digest:
                    raise AssertionError('Run artifact changed')
            st, cfg = read(folder / 'status.json'), read(folder / 'run_config.json')
            if st['status'] != 'complete' or not st['all_gates_passed'] or cfg['args']['dataset'] != dataset or cfg['args']['seed'] != seed:
                raise ValueError('Incomplete or mixed run')
            frame = pd.read_csv(folder / 'events.csv.gz', compression='gzip', float_precision='round_trip')
            if not frame.record_idx.is_unique or not (frame.split == 1).all() or not frame.single_kc.all():
                raise ValueError('Invalid validation coverage')
            with np.load(folder / 'predictions.npz', allow_pickle=False) as z:
                if not np.array_equal(z['record_idx'], frame.record_idx.to_numpy()):
                    raise ValueError('Prediction order mismatch')
                pred.append(np.stack([z[b + '_probability'] for b in BRANCHES]))
                evidence.append(np.stack([z[b + '_evidence'] for b in BRANCHES]))
            calibrations.append(read(folder / 'calibration.json'))
            frames.append(frame)
            pp.append(np.load(folder / 'long_gap_next_single_kc_pairs.npy', allow_pickle=False))
        if not all(f.equals(frames[0]) for f in frames) or not all(np.array_equal(v, pp[0]) for v in pp):
            raise ValueError('Seed event/window identities differ')
        if not all(v == calibrations[0] for v in calibrations):
            raise ValueError('The train-only constant must be seed independent')
        frame, arrays, pairs = frames[0], np.stack(pred), pp[0]
        output = {'calibration': calibrations[0], 'groups': {}, 'state_scale_diagnostics': {}}
        for name, mask in all_groups(frame, pairs).items():
            print(f'Summarizing {dataset}/{name}', flush=True)
            output['groups'][name] = summarize_group(frame, arrays, mask)
        output['matched_two_event_window'] = pair_window(frame, arrays, pairs)
        # Both mechanisms' actual support/update scales are reported, not assumed matched.
        support = np.stack(evidence).astype(float) + 2
        for b, branch in enumerate(BRANCHES):
            v = support[:, b]
            if not np.isfinite(v).all() or (v < 2 - 1e-5).any():
                raise ValueError('Invalid effective support')
            output['state_scale_diagnostics'][branch] = {
                'support_mean_per_seed': v.mean(1).tolist(),
                'support_q0_q50_q90_q99_q100_per_seed': np.quantile(v, [0, .5, .9, .99, 1], axis=1).T.tolist(),
                'unit_feedback_gain_mean_per_seed': (1 / (v + 1)).mean(1).tolist(),
                'scope': 'Validation pre-feedback effective support = evidence+2; gain=1/(support+1), single KC only; not calibrated confidence'}
        report['datasets'][dataset] = output
    write(args.output_root / 'summary.json', report)
    lines = ['# Fixed-step versus real-time frozen replay', '',
             'NS minus NF: negative NLL favors real time. All results are validation-only.', '']
    for dataset, ds in report['datasets'].items():
        lines += [f'## {dataset}', '', f"Train-only fixed retention: {ds['calibration']['fixed_retention_float32']}", '']
        for name, group in ds['groups'].items():
            lines += [f"### {name}: n={group['n']} students={group['students']}", '']
            if not group['n']:
                continue
            for b in BRANCHES:
                m = group['means'][b]
                lines.append(f"- {b}: AUC={m['auc']['mean']} NLL={m['nll']['mean']:.9f}; macroNLL={m['student_macro_nll']['mean']:.9f}")
            c = group['paired']['seed_mean/real_time_minus_fixed_step/nll']
            lines += [f"- NS-NF: deltaNLL={c['delta']:+.9f}; CI={c['ci95']}; macro={c['student_macro_delta']:+.9f}; macroCI={c['student_macro_ci95']}", '']
    (args.output_root / 'REPORT.md').write_text('\n'.join(lines), encoding='utf-8')


if __name__ == '__main__':
    main()
