"""Actual CLI suite on tiny synthetic inputs in a temporary independent tree.

Does not alter production pins or read real server checkpoints. The temporary
fixture replaces pins only inside its own temporary package, then exercises
the same run_suite/run_job/summarize/archive path.
"""
import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
import numpy as np
import torch
import test_step
from cross_core import read, write, sha, frozen_model, replay, validation_frame, long_followup, KEYS

ROOT = Path(__file__).resolve().parent


def main():
    start = time.monotonic()
    project = ROOT.parent / 'uctp_cd_time_factorial_v1'
    test_step.PROJECT = str(project)
    test_step.DEVICE = 'cpu'
    test_step.StepTests.setUpClass()
    fixture = test_step.StepTests()
    fixture.setUp()
    torch.set_num_threads(2)
    report = {'success': False, 'synthetic_only': True, 'device': 'cpu',
              'real_checkpoints_tested': False, 'real_GPU_tested': False}
    try:
        with tempfile.TemporaryDirectory(prefix='fixed_step_integration_') as directory:
            base = Path(directory)
            pkg, proj, data, cache, out = [base / x for x in ('package', 'project', 'data', 'cache', 'output')]
            for d in (pkg, proj, data, cache): d.mkdir()
            for p in ROOT.iterdir():
                if p.is_file() and p.suffix in ('.py', '.json', '.md', '.sh') and p.name != 'PACKAGE_MANIFEST.json':
                    shutil.copy2(p, pkg / p.name)
            sources = fixture.sources
            for name in sources:
                target = proj / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(project / name, target)
            expected, cachepins = {'datasets': {}}, {'files': {}}
            for dataset in ('assist', 'ednet'):
                folder = data / (dataset + '_full')
                shutil.copytree(fixture.path, folder)
                prepared = fixture.Data(folder)
                ds = {'shared_protocol': {'source': sources, 'data_fingerprint': prepared.fingerprint}, 'runs': []}
                expected['datasets'][dataset] = ds
                for seed in range(3):
                    torch.manual_seed(seed)
                    model = fixture.Base(**fixture.ckpt['model_config'])
                    ckpt = dict(fixture.ckpt, model_state=model.state_dict())
                    rel = f'outputs/{dataset}_none_seed{seed}'
                    runfolder = proj / rel
                    runfolder.mkdir(parents=True)
                    torch.save(ckpt, runfolder / 'best_model.pt')
                    cfg = {'model_family':'time_factorial_v1','model_config':ckpt['model_config'],
                           'args': {'time_mode':'none','variant':'unit_write','seed':seed,'eval_update_targets':1,'evaluate_test':False}}
                    write(runfolder / 'run_config.json', cfg)
                    write(runfolder / 'status.json', {'status':'complete'})
                    results = {}
                    for branch, mode in (('NN', 'none'), ('NS', 'support_only')):
                        m = frozen_model(fixture.Base, ckpt, mode, torch.device('cpu'), prepared.fingerprint, sources)
                        with contextlib.redirect_stdout(io.StringIO()):
                            results[branch] = replay(m,prepared,type(fixture).forward_fn,torch.device('cpu'),branch)
                    frame = validation_frame(prepared, results['NN']['record_idx'])
                    ref = frame.copy()
                    for k in KEYS: ref[k] = results['NN'][k]
                    ref.to_csv(runfolder / 'validation_predictions.csv', index=False)
                    run = {'dataset':dataset,'mode':'none','seed':seed,'best_epoch':2,
                           'checkpoint_sha256':sha(runfolder/'best_model.pt'),'relative_run_dir':rel,
                           'input_hashes': {p.name:sha(p) for p in runfolder.iterdir() if p.name!='best_model.pt'}}
                    ds['runs'].append(run)
                    name = f'{dataset}_seed{seed}_full';cached = cache / name;cached.mkdir()
                    frame.to_csv(cached/'events.csv.gz',index=False,compression='gzip')
                    arrays={'record_idx':results['NN']['record_idx']}
                    arrays.update({b+'_'+k:results[b][k] for b in results for k in KEYS})
                    np.savez_compressed(cached/'predictions.npz',**arrays)
                    np.save(cached/'long_gap_next_single_kc_pairs.npy',long_followup(prepared,arrays['record_idx']),allow_pickle=False)
                    write(cached/'status.json',{'status':'complete','all_gates_passed':True})
                    write(cached/'run_config.json',{'selected_inputs':{'none':run},'data_fingerprint':prepared.fingerprint})
                    cachepins['files'][name]={p.name:sha(p) for p in cached.iterdir()}
            write(pkg/'expected_inputs.json', expected)
            write(pkg/'cached_inputs.json', cachepins)
            write(pkg/'PACKAGE_MANIFEST.json',{p.name:sha(p) for p in pkg.iterdir() if p.is_file()})
            command=[sys.executable,'-B','-u',str(pkg/'run_suite.py'),'--project-dir',str(proj),'--data-root',str(data),
                     '--cache-root',str(cache),'--output-root',str(out),'--device','cpu','--ack-row-feedback','--ack-time-proxy']
            env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
            proc=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=env)
            (ROOT/'LOCAL_INTEGRATION_LOG.txt').write_text(proc.stdout,encoding='utf-8')
            if proc.returncode:
                for p in out.glob('*.log'):
                    with (ROOT/'LOCAL_INTEGRATION_LOG.txt').open('a',encoding='utf-8') as stream:
                        stream.write('\n'+p.name+'\n'+p.read_text(encoding='utf-8'))
                raise RuntimeError('Synthetic CLI suite failed; read LOCAL_INTEGRATION_LOG.txt')
            status = read(out/'suite_status.json')
            summary=read(out/'summary.json')
            assert status['status']=='complete' and len(status['jobs'])==14
            assert all(j['returncode']==0 for j in status['jobs'])
            display = subprocess.run([sys.executable, '-B', str(pkg/'show_results.py'), '--output-root', str(out)],
                                     stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding='utf-8', env=env)
            assert display.returncode == 0 and 'Results ready:' in display.stdout
            import zipfile
            with zipfile.ZipFile(out/'fixed_step_results.zip') as z:
                assert z.testzip() is None
                for name,digest in json.loads(z.read('result_manifest.json')).items():
                    import hashlib
                    assert hashlib.sha256(z.read(name)).hexdigest()==digest
            second=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=env)
            assert second.returncode!=0 and read(out/'suite_status.json')==status
            # Deliberately alter a pinned cached array in the disposable fixture.
            victim=cache/'assist_seed0_full/predictions.npz'
            with victim.open('ab') as stream: stream.write(b'corruption')
            bad=list(command);bad[bad.index('--output-root')+1]=str(base/'bad_output')
            rejected=subprocess.run(bad,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',env=env)
            assert rejected.returncode!=0 and not (base/'bad_output').exists()
            report.update(success=True,jobs_completed=len(status['jobs']),datasets=list(summary['datasets']),
                          all_six_seeds_passed=True,summary_and_archive_verified=True,
                          result_display_passed=True,
                          existing_output_rejected=True,corrupt_cache_rejected_before_output=True,
                          unit_tests=read(out/'tests_cpu.json')['tests_run'])
    except BaseException as exc:
        report['error']=repr(exc)
        raise
    finally:
        fixture.tearDown()
        report['seconds']=time.monotonic()-start
        write(ROOT/'LOCAL_INTEGRATION_REPORT.json',report)
        print(json.dumps(report,ensure_ascii=False,indent=2),flush=True)


if __name__=='__main__': main()
