# 实现与验证记录

日期：2026-10-27；发布目录：uctp_fixed_step_replay_v1。

## 已接收的材料

1. 已核验的 cross_replay_results.zip：SHA256 `2734b9a8a4cf396a406c7cb57ad0d49ae060fc6c1d8146e3f3b7f8dda024328a`。构建时再次逐文件核对结果 manifest 与 ZIP CRC。
2. a1_cross_weights_check_01.json：四对模型、每模型 20 个张量，严格数值一致；脚本 SHA 与本地发出的核验程序匹配；输入文件身份与先前 A1/cross 对齐表匹配。服务器核验用时约 1.74 秒。不是重新训练或评测。
3. 原 factorial_time_v1 源码和 checkpoint/数据身份来自已验收的清单，不根据文件名猜测、自动选“最新”目录或替换失败结果。

## 改动范围

- 新建独立诊断目录；原训练模型、训练脚本、四格结果、A0/A1/A2、交叉回放结果均不修改。
- step_core.py：训练集无标签固定系数计算；继承原模型，只替换支持量衰减系数；缓存/输入身份验证。
- run_job.py：原生 FP32 冻结回放、预检/全量一致性、逐事件输出和冻结参数校验。
- step_stats.py、summarize.py：同事件同学生配对统计；三个固定种子；学生整簇区间；实际支持量/增益审计。
- run_suite.py、run_server.sh：单命令串行执行、失败即停、启动日志、防覆盖、自动打包。
- show_results.py：显示进度、分支指标及主对照；无 AUC 的单类别子组显示 NA。
- cross_core.py、review_stats.py、expected_inputs.json：从旧交叉回放包逐字节复制，并与旧结果中的包哈希核对，没有改写这些公共规则。
- cached_inputs.json：固定旧 NN/NS 全量缓存的文件哈希；只重新执行小样本桥接，不再重复旧全量分支。

没有新增可训练参数、没有 optimizer、没有优化 d、没有根据 validation/test 的指标挑选系数。只比较预先写定的三个分支。

## 本地测试

本地 Python 3.12 / PyTorch 2.11.0+cpu，使用合成小数据，不是服务器真实 checkpoint，也不是本机 GPU 验收。

- 32 项单元测试，涵盖训练系数/标签隔离、时间类型/顺序、零间隔与首次 KC、支持量下限、均值保持、时钟跨块、改变间隔长度的对照行为、chunk/batch 一致性、预测先于反馈、test 标签不消费、冻结参数、缓存损坏拒绝、损失平均而非预测集成、配对统计等。
- 真实命令行集成流程：在独立临时目录生成六个合成 checkpoint 和缓存、执行 CPU 测试 + 六个预检 + 六个全量 + 汇总，共 14 个任务；核验结果显示、ZIP CRC 和结果 manifest；重复输出被拒绝、损坏缓存在创建新输出前被拒绝。
- `LOCAL_TEST_REPORT.json`、`LOCAL_INTEGRATION_REPORT.json`、`LOCAL_INTEGRATION_LOG.txt` 保存实际验证结果。耗时以这些机器记录为准。

Windows 本地没有执行 Linux tmux 启动；服务器的真实数据、真实 checkpoint、CUDA 与 yydw/Pandas 版本验证由新包的 CPU/CUDA 测试和预检负责。不能把本地通过说成服务器已经通过。

## 未改变的限制

仍沿用逐行即时反馈假设、未核验反馈边界与 timestamp 代理语义。多次验证集探索不构成独立确认；固定系数对照只匹配训练均值，不能覆盖所有事件驱动机制。支持量不是已经校准的置信度。保留全部分支、种子、分组与不利结果，不以指标获胜为验收标准。

最终是否值得继续设计正式方法，要等真实服务器结果、当前/后续事件取舍及其他强对照共同决定。
