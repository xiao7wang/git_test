# 服务器操作：上传一个包，启动一次，完成后取回一个结果包

本包不是新的训练工程。它读取原项目、原数据和之前完成的交叉回放结果，不要移动或删除这些目录，也不要复制新代码覆盖它们。无需安装依赖，继续用 yydw。

## 1. 上传、解压

将 `uctp_fixed_step_replay_v1.zip` 上传到服务器：

`/home/wangxiao/QCCDM/top_sci_repro/`

下面每个代码框只复制**框内命令**。不要复制 ```bash、终端提示符、运行输出或额外的 `>`。

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
if [ -e uctp_fixed_step_replay_v1 ]; then
  echo '目录已存在，保留原目录；不要覆盖，先检查是否已经运行'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_fixed_step_replay_v1.zip &&
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_fixed_step_replay_v1.zip .
fi
```

确认文件存在：

```bash
ls -lh /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/run_server.sh
```

## 2. 一条命令在 tmux 后台启动

只执行一次：

```bash
tmux new-session -d -s fixed_step_01 "bash /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/run_server.sh server_step_01"
```

默认 GPU 0。这条命令正常时通常没有文字输出；它创建后台会话，不要求你先进入 tmux。不要在已有 tmux 里层层新建窗口。

随后查看启动日志，确认不是仅创建了空会话：

```bash
tail -n 30 /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/outputs/server_step_01.launch.log
```

应看到输入核验和 `Starting tests_cpu` 等信息。若出现 `duplicate session` 或 `Output exists`，不要重复启动或删目录；先查看原日志。

本包依赖的旧路径：

```
/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data
/home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/outputs/server_cross_01
```

若路径或 SHA 核验失败，把 launch.log 发来。不要绕过核验，不要自行编辑包后强行运行。本包拒绝覆盖已有输出；失败结果会保留。

## 3. 随时查看进度或结果

在任意新终端复制：

```bash
/home/wangxiao/miniconda3/envs/yydw/bin/python -B /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/show_results.py --output-root /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/outputs/server_step_01
```

正常有 15 个任务：CPU/CUDA 两组测试、六个预检、六个全量回放、一个汇总。`active job` 表示保存的阶段；单凭 running 不证明进程还活着。

怀疑停止时，只检查，不重启：

```bash
pgrep -a -u wangxiao -f 'uctp_fixed_step_replay_v1/(run_suite[.]py|run_job[.]py|test_step[.]py|summarize[.]py)'
tail -n 30 /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/outputs/server_step_01.launch.log
```

具体全量回放会把批次进度写在对应作业日志，例如：

```bash
tail -n 30 /home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/outputs/server_step_01/assist_seed0_full.log
```

同一个文件暂时还不存在，可能只是阶段未到；先看总日志。若 `suite_status.json` 尚不存在，也先看 launch.log：输入核验在创建 suite_status 之前进行。

可选进入会话：`tmux attach -t fixed_step_01`。想离开时先按 Ctrl+B，松开，再按 D；不要用 Ctrl+C 退出正在运行的程序。程序完成后会话可能自动消失，这是正常的，最终以 complete 和结果包为准。

## 4. 完成后下载

只有显示 `Suite status: complete` 且 `Results ready` 后，下载：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_fixed_step_replay_v1/outputs/server_step_01/fixed_step_results.zip`

把这个 ZIP 发回即可。不需要下载 checkpoint，也不需要把全部终端输出逐段粘贴。

## 5. 预计时长、空间与结果含义

它只新增六次单分支全量回放，没有反向传播，比此前多分支全量回放工作量小。不能用“本地合成测试约几分钟”估计真实数据时长；实际预计为小时级，受服务器负载影响，以首个 full 作业时间再估算剩余时间。summary 是 CPU 统计阶段，GPU 空闲不等于卡死。

所有新输出写在本包 outputs 下，会保存逐事件预测与结果 ZIP；留足可写空间，磁盘满会导致失败。脚本不清理任何旧数据。

查看结果时最重要的是 `NS-NF NLL`：负值表示真实时间优于本轮固定折扣；正值相反。还要同时看 macroNLL、三个种子和区间。不要把它说成已经获得新模型 test 提升。
