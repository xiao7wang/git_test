"""New fixed-step validation replay; accepted NN/NS outputs are reused."""
import argparse
import os
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import platform
import time
from pathlib import Path
import numpy as np
import torch
from cross_core import (read, write, sha, import_project, frozen_model, replay, compare,
                        selected_users, reference_bridge, model_digest, KEYS)
from step_core import ROOT, audit, cached_arrays, calibrate_data, make_fixed, cold_compare


def main():
    p = argparse.ArgumentParser()
    for key in ('project-dir', 'data-root', 'cache-root', 'output-dir'):
        p.add_argument('--' + key, required=True)
    p.add_argument('--dataset', choices=('assist', 'ednet'), required=True)
    p.add_argument('--seed', type=int, choices=(0, 1, 2), required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), required=True)
    p.add_argument('--preflight', action='store_true')
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Both feedback/time-proxy acknowledgements required')
    out = Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=False)
    start = time.monotonic()
    write(out / 'status.json', {'status': 'running', 'pid': os.getpid()})
    try:
        run, sources, cached = audit(args.project_dir, args.data_root, args.cache_root, args.dataset, args.seed)
        Data, Base, forward = import_project(args.project_dir, sources)
        data = Data(Path(args.data_root) / f'{args.dataset}_full')
        calibration = calibrate_data(data)
        write(out / 'calibration.json', calibration)
        print('Train-only fixed retention:', calibration['fixed_retention_float32'], flush=True)
        torch.set_num_threads(4)
        torch.manual_seed(0)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.use_deterministic_algorithms(True)
        if args.device == 'cuda' and not torch.cuda.is_available():
            raise RuntimeError('CUDA unavailable; no fallback or skipped GPU check')
        device = torch.device(args.device)
        users = selected_users(data) if args.preflight else None
        frame, results = cached_arrays(cached, data, users)
        folder = Path(args.project_dir) / run['relative_run_dir']
        checkpoint = torch.load(folder / 'best_model.pt', weights_only=True, map_location='cpu')
        if checkpoint['epoch'] != run['best_epoch'] or checkpoint['model_config']['time_mode'] != 'none':
            raise AssertionError('Selected checkpoint changed')
        write(out / 'run_config.json', {'args': vars(args), 'selected_input': run, 'data_fingerprint': data.fingerprint,
              'source_hashes': sources, 'cache_pins': read(ROOT / 'cached_inputs.json')['files'][cached.name],
              'checkpoint_tensor_digest': model_digest(checkpoint['model_state']),
              'calibration': calibration, 'batch_size': 8, 'chunk_size': 100, 'atol': 1e-6,
              'native_precision': 'float32', 'timestamp_precision': 'float64',
              'trained': False, 'test_evaluated': False, 'labels_used_for_calibration': False,
              'replay_scope': 'train+valid history, predict then observe; score valid only',
              'preflight_users': None if users is None else users.tolist(),
              'environment': {'python': platform.python_version(), 'torch': str(torch.__version__),
                              'numpy': np.__version__, 'device': str(device)}})
        gates = {}
        def accept(name, gate):
            gates[name] = gate
            write(out / 'gates.json', gates)
            if not gate['success']:
                raise AssertionError(name + ' failed; no tolerance relaxation')
        if args.preflight:
            # Re-execute native none and real-time rules on full original batches.
            for branch, mode in (('NN', 'none'), ('NS', 'support_only')):
                model = frozen_model(Base, checkpoint, mode, device, data.fingerprint, sources)
                current = replay(model, data, forward, device, branch + '_bridge', users=users)
                accept(branch + '_cached_bridge', compare(current, results[branch]))
                if branch == 'NN':
                    accept('NN_original_csv_bridge', reference_bridge(current, data, folder / 'validation_predictions.csv'))
                del model
        else:
            preflight = out.parent / f'{args.dataset}_seed{args.seed}_preflight'
            for name, digest in read(preflight / 'artifact_manifest.json').items():
                if sha(preflight / name) != digest:
                    raise AssertionError('Preflight artifact changed')
            pstatus = read(preflight / 'status.json')
            if pstatus['status'] != 'complete' or not pstatus.get('all_gates_passed'):
                raise AssertionError('Accepted preflight required')
            pcfg = read(preflight / 'run_config.json')
            if pcfg['selected_input'] != run or pcfg['calibration'] != calibration or pcfg['cache_pins'] != read(ROOT / 'cached_inputs.json')['files'][cached.name]:
                raise AssertionError('Preflight/full provenance mismatch')
        model = make_fixed(Base, checkpoint, device, data.fingerprint, sources, calibration['fixed_retention_float32'])
        write(out / 'status.json', {'status': 'running', 'branch': 'NF', 'pid': os.getpid()})
        results['NF'] = replay(model, data, forward, device, 'NF_fixed_step', users=users)
        if args.preflight:
            alternate = replay(model, data, forward, device, 'NF_batch17_chunk17', batch_size=17, chunk_size=17, users=users)
            accept('NF_batch17_chunk17', compare(results['NF'], alternate))
        else:
            with np.load(preflight / 'predictions.npz', allow_pickle=False) as z:
                small = {'record_idx': z['record_idx']}
                small.update({k: z['NF_' + k] for k in KEYS})
            indices = np.searchsorted(results['NF']['record_idx'], small['record_idx'])
            accept('NF_full_vs_preflight', compare({k: v[indices] for k, v in results['NF'].items()}, small))
        accept('cold_KC_same_weights', cold_compare(results, data))
        ids = results['NN']['record_idx']
        if any(not np.array_equal(ids, r['record_idx']) for r in results.values()):
            raise AssertionError('Branch identity mismatch')
        arrays = {'record_idx': ids}
        arrays.update({b + '_' + k: r[k] for b, r in results.items() for k in KEYS})
        np.savez_compressed(out / 'predictions.npz', **arrays)
        frame.to_csv(out / 'events.csv.gz', index=False, compression='gzip')
        if not args.preflight:
            pair = np.load(cached / 'long_gap_next_single_kc_pairs.npy', allow_pickle=False)
            if pair.ndim != 2 or pair.shape[1] != 2 or not np.isin(pair, ids).all():
                raise AssertionError('Pair coverage changed')
            np.save(out / 'long_gap_next_single_kc_pairs.npy', pair, allow_pickle=False)
        audit(args.project_dir, args.data_root, args.cache_root, args.dataset, args.seed)
        write(out / 'artifact_manifest.json', {p.name: sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name != 'status.json'})
        write(out / 'status.json', {'status': 'complete', 'n': len(ids), 'all_gates_passed': True,
              'seconds': time.monotonic()-start, 'trained': False, 'test_evaluated': False, 'inputs_modified': False})
    except BaseException as exc:
        write(out / 'status.json', {'status': 'failed', 'error': repr(exc), 'seconds': time.monotonic()-start})
        raise


if __name__ == '__main__':
    main()
