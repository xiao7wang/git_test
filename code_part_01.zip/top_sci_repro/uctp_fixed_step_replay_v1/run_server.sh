#!/usr/bin/env bash
set -euo pipefail
TASK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RUN_NAME="${1:-server_step_01}"
if [[ ! "$RUN_NAME" =~ ^[A-Za-z0-9_-]+$ ]]; then
  echo 'Invalid output name' >&2
  exit 2
fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data
CACHE=/home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/outputs/server_cross_01
if [[ -e "$TASK_DIR/outputs/$RUN_NAME" ]]; then
  echo "Output exists; preserved: $TASK_DIR/outputs/$RUN_NAME" >&2
  exit 2
fi
mkdir -p "$TASK_DIR/outputs"
LAUNCH_LOG="$TASK_DIR/outputs/$RUN_NAME.launch.log"
if [[ -e "$LAUNCH_LOG" ]]; then
  echo "Launch log exists; inspect it first: $LAUNCH_LOG" >&2
  exit 2
fi
(set -o noclobber; : > "$LAUNCH_LOG")
exec > >(tee -a "$LAUNCH_LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
exec "$PY" -B -u "$TASK_DIR/run_suite.py" \
  --project-dir "$PROJECT" --data-root "$DATA" --cache-root "$CACHE" \
  --output-root "$TASK_DIR/outputs/$RUN_NAME" --device cuda \
  --ack-row-feedback --ack-time-proxy
