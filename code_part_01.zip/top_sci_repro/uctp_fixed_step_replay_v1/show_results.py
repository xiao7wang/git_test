import argparse
from pathlib import Path
from cross_core import read


def fmt(value):
    return 'NA' if value is None else f'{value:.6f}'


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output-root', type=Path, required=True)
    root = p.parse_args().output_root
    if not (root / 'suite_status.json').is_file():
        raise SystemExit('No suite_status.json. Check output name and ' + str(root) + '.launch.log; do not assume a job is running.')
    s = read(root / 'suite_status.json')
    print(f"Suite status: {s['status']}; active job: {s.get('active_job')}")
    print('Saved running status does NOT prove a live process.')
    for j in s['jobs']:
        print(f"{j['name']:<30} returncode={j['returncode']} seconds={j['seconds']:.1f}")
    if s['status'] == 'failed':
        print('FAILED:', s.get('error'))
        return
    if s['status'] != 'complete' or not (root / 'fixed_step_results.zip').is_file():
        print('Accepted archive not ready yet; inspect the active job log if progress seems stale.')
        return
    summary = read(root / 'summary.json')
    for dataset, ds in summary['datasets'].items():
        print('\n', dataset.upper(), 'train-only fixed retention=', ds['calibration']['fixed_retention_float32'])
        for name in ('all', 'repeated_kc_proxy', 'repeat_gap_gt168h', 'long_gap_matched_current', 'long_gap_next_event'):
            g = ds['groups'][name]
            print(f"{name}: n={g['n']} students={g['students']}")
            if not g['n']:
                continue
            for b, row in g['means'].items():
                print(f"  {b}: AUC={fmt(row['auc']['mean'])} NLL={fmt(row['nll']['mean'])} macroNLL={fmt(row['student_macro_nll']['mean'])}")
            c = g['paired']['seed_mean/real_time_minus_fixed_step/nll']
            print(f"  NS-NF NLL={c['delta']:+.7f} CI={c['ci95']}; macro={c['student_macro_delta']:+.7f} macroCI={c['student_macro_ci95']}")
    print('\nNegative NS-NF favors real-time retention, conditional on frozen validation protocol.')
    print('Results ready:', root / 'fixed_step_results.zip')


if __name__ == '__main__':
    main()
