import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if not (d/'status.json').exists():raise SystemExit('No status file: check launch log')
s=json.loads((d/'status.json').read_text(encoding='utf8'));print('status:',s.get('status'),'phase:',s.get('phase'),'active:',s.get('active_model'),'completed:',len(s.get('completed',[])),'/6','error:',s.get('error','-'))
print('Saved running status does not prove a live process.')
if (d/'summary.json').exists():
 r=json.loads((d/'summary.json').read_text(encoding='utf8'));print('events:',r['n'],'students:',r['students'],'long-gap pairs:',r['pair_n'])
 for n in ('original','bias'):
  v=r['seed_aggregates'][n]['overall'];print(n,'mean NLL:',v['nll']['mean'],'macro NLL:',v['student_macro_nll']['mean'],'AUC:',v['auc']['mean'])
 c=r['rows']['count_R2_seed0']['overall'];print('count R2 seed0 NLL:',c['nll'],'macro NLL:',c['student_macro_nll'],'AUC:',c['auc'])
 for w in ('overall','current','next','two_event_mean'):
  x=r['paired'][w]['bias_mean_loss_three_fixed_seeds_minus_count_seed0'];print(w,'bias mean − count NLL:',x['delta'],'CI95:',x['ci95'],'macro:',x['student_macro_delta'])
 print('Exploratory reused holdout; fixed checkpoints; count seed0 only; not independent confirmation.')
if (d/'dkvmn_holdout_results.zip').exists():print('Results archive:',d/'dkvmn_holdout_results.zip')
