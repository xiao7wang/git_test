"""Frozen six-checkpoint ASSIST internal holdout replay with full dev bridges."""
import argparse,hashlib,io,json,os,time,zipfile
from pathlib import Path
os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
import numpy as np
import pandas as pd
import torch
from count_core import dev_users,SALT
from cross_core import import_project,read,sha,write,model_digest,long_followup
from review_stats import metrics
from bias_adapter import BiasDKVMN
from run_pilot import load_upstream
from run_job import evaluate
from analysis_core import analyze
ROOT=Path(__file__).resolve().parent
MODES=('original','bias');SEEDS=(0,1,2)

def check_files(root,entries):
 for n,h in entries.items():
  if sha(root/n)!=h:raise ValueError(f'Source changed: {root/n}')

def read_count_archive(path,lock):
 if sha(path)!=lock['archive_sha256']:raise ValueError('P0 result archive changed')
 with zipfile.ZipFile(path) as z:
  if z.testzip() is not None:raise ValueError('P0 archive CRC failed')
  manifest=json.loads(z.read('manifest.json'))
  for n,h in manifest.items():
   if hashlib.sha256(z.read(n)).hexdigest()!=h:raise ValueError('P0 archived file changed: '+n)
  for n,h in lock['files'].items():
   if hashlib.sha256(z.read(n)).hexdigest()!=h:raise ValueError('P0 locked file changed: '+n)
  status=json.loads(z.read('status.json'));summary=json.loads(z.read('summary.json'));cfg=json.loads(z.read('config.json'))
  if status['status']!='complete' or not summary['count_audit_passed'] or status['trained'] or status['test_evaluated']:raise ValueError('P0 audit incomplete or protocol mismatch')
  frame=pd.read_csv(io.BytesIO(z.read('count_holdout_predictions.csv.gz')),compression='gzip',float_precision='round_trip')
 return frame,summary,cfg

def run(a):
 if not a.ack_row_feedback:raise ValueError('Row-immediate feedback acknowledgement required')
 if a.device=='cuda' and not torch.cuda.is_available():raise RuntimeError('CUDA unavailable')
 out=Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=False);start=time.monotonic()
 status={'status':'running','phase':'source_verify','active_model':None,'completed':[],'trained':False,'test_evaluated':False};write(out/'status.json',status)
 try:
  locks=read(ROOT/'locked_inputs.json');roots={k:Path(getattr(a,k+'_dir')) for k in ('seedrep','original0','bias0','holdout')}
  for k,root in roots.items():
   check_files(root,locks[k]['files'])
   if read(root/'status.json')['status']!='complete':raise ValueError(k+' source incomplete')
  seedcfg=read(roots['seedrep']/'config.json')
  for n in ('run_job.py','bias_adapter.py','streaming_dkvmn.py','run_pilot.py','count_core.py','cross_core.py','review_stats.py'):
   if sha(ROOT/n)!=seedcfg['code_sha256'][n]:raise ValueError('Replay implementation differs from training: '+n)
  count,cs,ccfg=read_count_archive(Path(a.p0_archive),locks['count_p0'])
  spec=read(ROOT/'expected_inputs.json')['datasets']['assist']['shared_protocol'];Data,_,_=import_project(a.project_dir,spec['source'])
  if sha(Path(a.data_dir)/'manifest.json')!=spec['data_fingerprint']:raise ValueError('Data fingerprint differs')
  data=Data(a.data_dir);arr=data.arrays;q=arr['item_q']
  if not np.isin(q,[0,1]).all() or not (q.sum(1)==1).all():raise ValueError('Requires binary single-KC items')
  if ccfg['data_fingerprint']!=data.fingerprint or ccfg['partition_salt']!=SALT or ccfg['feedback']!='row immediate assumption':raise ValueError('P0 data or feedback protocol differs')
  valid=np.flatnonzero(arr['split']==1);all_users=set(map(int,np.unique(arr['student_idx'][valid])));dev=dev_users(arr['student_idx'][valid]);held=np.asarray(sorted(all_users-dev),dtype=np.int64);dev=np.asarray(sorted(dev),dtype=np.int64)
  if not len(held) or not len(dev):raise ValueError('Empty partition')
  dev_ref=pd.read_csv(roots['seedrep']/'events.csv.gz',compression='gzip',float_precision='round_trip');hold_ref=pd.read_csv(roots['holdout']/'events.csv.gz',compression='gzip',float_precision='round_trip')
  dev_ids=valid[np.isin(arr['student_idx'][valid],dev)];hold_ids=valid[np.isin(arr['student_idx'][valid],held)]
  for frame,ids in ((dev_ref,dev_ids),(hold_ref,hold_ids),(count,hold_ids)):
   for col,key in [('record_idx','record_idx'),('student_idx','student_idx'),('label','label')]:
    expected=ids if key=='record_idx' else arr[key][ids]
    if not np.array_equal(frame[col].to_numpy(),expected):raise ValueError('Selected event identity differs: '+col)
  with np.load(roots['seedrep']/'predictions.npz',allow_pickle=False) as z:dev_probs={k:z[k] for k in z.files}
  if not np.array_equal(dev_probs['record_idx'],dev_ids):raise ValueError('Seedrep predictions do not match dev identities')
  pairs=np.load(roots['holdout']/'selected_pairs.npy',allow_pickle=False)
  all_pairs=long_followup(data,valid);expected_pairs=all_pairs[np.isin(all_pairs[:,0],hold_ids)&np.isin(all_pairs[:,1],hold_ids)]
  if not np.array_equal(pairs,expected_pairs):raise ValueError('Long-gap matched pairs changed')
  cp=count.probability.to_numpy(dtype=np.float32);count_nll=metrics(count.label.to_numpy(),cp)['nll']
  if abs(count_nll-cs['rows']['count_seed0']['nll'])>1e-7:raise ValueError('Frozen count prediction metric differs from P0')
  device=torch.device(a.device);torch.set_num_threads(4);torch.use_deterministic_algorithms(True);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
  DKVMN,source=load_upstream();dims=data.manifest['summary'];pred={'count_R2_seed0':cp};bridges={};jobs=[]
  for mode in MODES:
   for seed in SEEDS:
    name=f'{mode}_seed{seed}';ckroot=roots[mode+'0'] if seed==0 else roots['seedrep']/name
    checkpoint_path=ckroot/'best_model.pt'
    if sha(checkpoint_path)!=locks['checkpoints'][name]:raise ValueError('Checkpoint changed: '+name)
    ck=torch.load(checkpoint_path,map_location='cpu',weights_only=True)
    if ck['data_fingerprint']!=data.fingerprint:raise ValueError('Checkpoint data mismatch: '+name)
    if seed>0 and (ck['seed']!=seed or ck['variant']!=mode):raise ValueError('Checkpoint seed/variant mismatch: '+name)
    base=DKVMN(num_c=int(dims['knowledges']),dim_s=32,size_m=20,dropout=.2).to(device)
    model=base if mode=='original' else BiasDKVMN(base,int(dims['students']),int(dims['items'])).to(device)
    model.load_state_dict(ck['model_state'],strict=True);model.eval();model.requires_grad_(False);before=model_digest(model.state_dict())
    status.update(phase='development_bridge',active_model=name);write(out/'status.json',status);print('Starting full development bridge:',name,flush=True)
    dframe,dsec=evaluate(model,base,mode,data,dev,device,50,8)
    for col in ('record_idx','student_idx','label'):
     if not np.array_equal(dframe[col].to_numpy(),dev_ref[col].to_numpy()):raise ValueError('Development bridge identity mismatch: '+name+'/'+col)
    dmax=float(np.max(np.abs(dframe.probability.to_numpy(np.float32).astype(float)-dev_probs[name].astype(float)),initial=0))
    if dmax>1e-6:raise ValueError(f'Development bridge failed: {name} max={dmax}')
    status['phase']='holdout_replay';write(out/'status.json',status);print('Starting full holdout replay:',name,flush=True)
    hframe,hsec=evaluate(model,base,mode,data,held,device,50,8)
    for col in ('record_idx','student_idx','label'):
     if not np.array_equal(hframe[col].to_numpy(),hold_ref[col].to_numpy()):raise ValueError('Holdout identity mismatch: '+name+'/'+col)
    sample=held[:min(32,len(held))];f17,_=evaluate(model,base,mode,data,sample,device,17,8);f50,_=evaluate(model,base,mode,data,sample,device,50,8)
    for col in ('record_idx','student_idx','label'):
     if not np.array_equal(f17[col].to_numpy(),f50[col].to_numpy()):raise ValueError('Chunk identity mismatch: '+name)
    chunk_max=float(np.max(np.abs(f17.probability.to_numpy(float)-f50.probability.to_numpy(float)),initial=0))
    if chunk_max>1e-6:raise ValueError(f'Chunk check failed: {name} max={chunk_max}')
    if model_digest(model.state_dict())!=before:raise ValueError('Frozen model changed: '+name)
    pred[name]=hframe.probability.to_numpy(dtype=np.float32);bridges[name]={'dev_n':len(dframe),'dev_max_abs':dmax,'dev_seconds':dsec,'holdout_n':len(hframe),'holdout_seconds':hsec,'chunk_sample_students':len(sample),'chunk_max_abs':chunk_max,'checkpoint_sha256':sha(checkpoint_path),'model_state_sha256':before,'epoch':int(ck['epoch'])}
    jobs.append(name);status['completed']=jobs.copy();write(out/'status.json',status);write(out/'bridges.json',bridges);print('Completed',name,flush=True)
  status.update(phase='paired_analysis',active_model=None);write(out/'status.json',status)
  result=analyze(hold_ref,pred,pairs,reps=1000)
  result.update(status='complete',trained=False,test_evaluated=False,bridges=bridges,
   count_source='frozen P0 audit checkpoint, seed0; count archived predictions, not retrained',
   note='validation holdout reused in earlier exploratory analysis; student/item inputs differ between model families',seconds=time.monotonic()-start)
  hold_ref[['record_idx','student_idx','label']].to_csv(out/'events.csv.gz',index=False,compression='gzip');np.save(out/'selected_pairs.npy',pairs,allow_pickle=False)
  np.savez_compressed(out/'predictions.npz',record_idx=hold_ids,**pred)
  write(out/'config.json',{'scope':'frozen heldout validation replay only, not independent test','data_fingerprint':data.fingerprint,'partition_salt':SALT,
   'feedback':'row immediate assumption','trained':False,'test_evaluated':False,'source_locks':locks,
   'code_sha256':{n:sha(ROOT/n) for n in ('run_holdout.py','analysis_core.py','run_job.py','run_pilot.py','bias_adapter.py','streaming_dkvmn.py','count_core.py','cross_core.py','review_stats.py')}})
  write(out/'summary.json',result);status.update(status='complete',phase=None,active_model=None,seconds=time.monotonic()-start);write(out/'status.json',status);print('HOLDOUT REPLAY COMPLETE',flush=True)
 except BaseException as e:
  status.update(status='failed',error=repr(e),seconds=time.monotonic()-start);write(out/'status.json',status);raise

def main():
 p=argparse.ArgumentParser()
 for n in ('project-dir','data-dir','seedrep-dir','original0-dir','bias0-dir','holdout-dir','p0-archive','output-dir'):p.add_argument('--'+n,required=True)
 p.add_argument('--device',choices=('cpu','cuda'),default='cuda');p.add_argument('--ack-row-feedback',action='store_true');run(p.parse_args())
if __name__=='__main__':main()
