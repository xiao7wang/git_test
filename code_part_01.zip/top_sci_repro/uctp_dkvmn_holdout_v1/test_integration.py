"""Synthetic frozen weights, full dev bridges, heldout pairs, and P0 lock."""
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from cross_core import sha,write,long_followup
from count_core import dev_users
from run_pilot import load_upstream
from run_job import evaluate
from bias_adapter import BiasDKVMN
from review_stats import metrics
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='dkvmn_holdout_') as temp:
  r=Path(temp);pkg=r/'pkg';pkg.mkdir();roots={k:r/k for k in ('seedrep','original0','bias0','holdout')}
  for d in roots.values():d.mkdir()
  names=('run_holdout.py','analysis_core.py','run_job.py','run_pilot.py','streaming_dkvmn.py','bias_adapter.py','source_manifest.json','LICENSE','count_core.py','cross_core.py','review_stats.py','package_results.py','show_results.py')
  for n in names:shutil.copy2(ROOT/n,pkg/n)
  (pkg/'pykt/models').mkdir(parents=True);shutil.copy2(ROOT/'pykt/models/dkvmn.py',pkg/'pykt/models/dkvmn.py')
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  data=fixture.data;arr=data.arrays;valid=np.flatnonzero(arr['split']==1);du=dev_users(arr['student_idx'][valid]);hu=set(map(int,np.unique(arr['student_idx'][valid])))-du
  dev=np.array(sorted(du),dtype=np.int64);held=np.array(sorted(hu),dtype=np.int64);assert len(dev) and len(held)
  did=valid[np.isin(arr['student_idx'][valid],dev)];hid=valid[np.isin(arr['student_idx'][valid],held)]
  def frame(ids):return pd.DataFrame({'record_idx':ids,'student_idx':arr['student_idx'][ids],'label':arr['label'][ids]})
  frame(did).to_csv(roots['seedrep']/'events.csv.gz',index=False,compression='gzip');frame(hid).to_csv(roots['holdout']/'events.csv.gz',index=False,compression='gzip')
  pairs=long_followup(data,valid);pairs=pairs[np.isin(pairs[:,0],hid)&np.isin(pairs[:,1],hid)];assert len(pairs)
  np.save(roots['holdout']/'selected_pairs.npy',pairs,allow_pickle=False);np.savez_compressed(roots['holdout']/'predictions.npz',record_idx=hid)
  for x in roots.values():write(x/'status.json',{'status':'complete'})
  write(roots['holdout']/'config.json',{});write(roots['holdout']/'summary.json',{})
  write(roots['original0']/'config.json',{});write(roots['bias0']/'config.json',{})
  DKVMN,src=load_upstream();dims=data.manifest['summary'];pred={'record_idx':did};checks={};jobs={}
  for mode in ('original','bias'):
   for seed in (0,1,2):
    name=f'{mode}_seed{seed}';torch.manual_seed(seed);base=DKVMN(num_c=dims['knowledges'],dim_s=32,size_m=20,dropout=.2)
    model=base if mode=='original' else BiasDKVMN(base,dims['students'],dims['items'])
    folder=roots[mode+'0'] if seed==0 else roots['seedrep']/name;folder.mkdir(exist_ok=True)
    ck={'model_state':model.state_dict(),'data_fingerprint':data.fingerprint,'epoch':3}
    if seed:ck.update(seed=seed,variant=mode)
    torch.save(ck,folder/'best_model.pt');checks[name]=sha(folder/'best_model.pt')
    if seed:write(folder/'summary.json',{'status':'complete'})
    f,_=evaluate(model,base,mode,data,dev,torch.device('cpu'),50,2);pred[name]=f.probability.to_numpy(np.float32)
  np.savez_compressed(roots['seedrep']/'predictions.npz',**pred)
  write(roots['seedrep']/'config.json',{'code_sha256':{n:sha(pkg/n) for n in ('run_job.py','bias_adapter.py','streaming_dkvmn.py','run_pilot.py','count_core.py','cross_core.py','review_stats.py')}})
  write(roots['seedrep']/'summary.json',{});write(roots['original0']/'summary.json',{});write(roots['bias0']/'summary.json',{})
  p0=r/'p0.zip';cf=frame(hid);cf['probability']=np.full(len(hid),.5,dtype=np.float32)
  import io
  buf=io.BytesIO();cf.to_csv(buf,index=False,compression='gzip');countfile=buf.getvalue()
  files={'status.json':json.dumps({'status':'complete','trained':False,'test_evaluated':False}).encode(),
   'config.json':json.dumps({'data_fingerprint':data.fingerprint,'partition_salt':'decision-v1-20261105:','feedback':'row immediate assumption'}).encode(),
   'summary.json':json.dumps({'count_audit_passed':True,'rows':{'count_seed0':{'nll':metrics(cf.label,cf.probability.to_numpy(np.float32))['nll']}}}).encode(),
   'count_audit.json':b'{"passed": true}','count_holdout_predictions.csv.gz':countfile}
  with zipfile.ZipFile(p0,'w') as z:
   for n,v in files.items():z.writestr(n,v)
   z.writestr('manifest.json',json.dumps({n:hashlib.sha256(v).hexdigest() for n,v in files.items()}))
  lock={}
  for k,d in roots.items():
   ns=['status.json','config.json','summary.json']
   if k=='seedrep':ns+=['events.csv.gz','predictions.npz']+[f'{m}_seed{s}/summary.json' for m in ('original','bias') for s in (1,2)]
   if k=='holdout':ns+=['events.csv.gz','predictions.npz','selected_pairs.npy']
   lock[k]={'files':{n:sha(d/n) for n in ns}}
  lock['checkpoints']=checks;lock['count_p0']={'archive_sha256':sha(p0),'files':{n:hashlib.sha256(files[n]).hexdigest() for n in ('status.json','config.json','summary.json','count_audit.json')}}
  write(pkg/'locked_inputs.json',lock)
  cmd=[sys.executable,'-B',str(pkg/'run_holdout.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--seedrep-dir',str(roots['seedrep']),'--original0-dir',str(roots['original0']),'--bias0-dir',str(roots['bias0']),'--holdout-dir',str(roots['holdout']),'--p0-archive',str(p0),'--output-dir',str(r/'out'),'--device','cpu','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1');q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  result=json.loads((r/'out/summary.json').read_text());assert result['n']==len(hid) and result['pair_n']==len(pairs) and len(result['bridges'])==6
  assert not result['trained'] and not result['test_evaluated'] and all(x['dev_max_abs']<=1e-6 and x['chunk_max_abs']<=1e-6 for x in result['bridges'].values())
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(r/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8');assert q.returncode==0,q.stdout
  with zipfile.ZipFile(r/'out/dkvmn_holdout_results.zip') as z:
   m=json.loads(z.read('manifest.json'));assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items())
  q=subprocess.run([sys.executable,str(pkg/'show_results.py'),'--output-dir',str(r/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8');assert q.returncode==0,q.stdout
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  with (roots['bias0']/'best_model.pt').open('ab') as f:f.write(b'tamper')
  bad=cmd.copy();bad[bad.index(str(r/'out'))]=str(r/'bad');assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((r/'bad/status.json').read_text())['status']=='failed'
  print('PASS six frozen checkpoints, dev bridges, heldout alignment, P0 lock, paired windows and tamper guards')
finally:fixture.tearDown()
