import unittest
import numpy as np
import pandas as pd
from analysis_core import analyze
from review_stats import losses

class Tests(unittest.TestCase):
 def test_paired_windows_and_seed_loss_average(self):
  f=pd.DataFrame({'record_idx':[2,5,7,9],'student_idx':[1,1,2,2],'label':[1,0,1,0]});pairs=np.array([[2,5],[7,9]])
  p={'count_R2_seed0':np.full(4,.5)}
  for s in (0,1,2):p[f'original_seed{s}']=np.full(4,.5);p[f'bias_seed{s}']=np.full(4,[.1,.9,.5][s])
  r=analyze(f,p,pairs,reps=20)
  expected=np.mean([losses(f.label,p[f'bias_seed{s}'])[:,0]-losses(f.label,p[f'original_seed{s}'])[:,0] for s in (0,1,2)],axis=0)
  self.assertAlmostEqual(r['paired']['overall']['bias_minus_original_mean_loss_three_fixed_seeds']['delta'],expected.mean())
  self.assertAlmostEqual(r['paired']['two_event_mean']['bias_minus_original_mean_loss_three_fixed_seeds']['delta'],expected.mean())
  self.assertEqual(r['pair_students'],2);self.assertGreater(expected.mean(),0.1)
 def test_reject_different_student_pair(self):
  f=pd.DataFrame({'record_idx':[2,5],'student_idx':[1,2],'label':[1,0]});p={'count_R2_seed0':np.full(2,.5)}
  for s in (0,1,2):p[f'original_seed{s}']=p[f'bias_seed{s}']=np.full(2,.5)
  with self.assertRaises(ValueError):analyze(f,p,np.array([[2,5]]),reps=5)
if __name__=='__main__':unittest.main()
