"""Fixed-model paired student bootstrap, overall and matched long-gap windows."""
import numpy as np
from review_stats import metrics,losses,cluster_intervals

MODES=('original','bias')
SEEDS=(0,1,2)

def macro(student,values):
    _,inv,counts=np.unique(student,return_inverse=True,return_counts=True)
    return float(np.mean(np.bincount(inv,weights=values)/counts))

def analyze(frame,predictions,pairs,reps=1000):
    ids=frame.record_idx.to_numpy(np.int64);user=frame.student_idx.to_numpy(np.int64);y=frame.label.to_numpy()
    if not len(ids) or np.any(np.diff(ids)<=0) or not np.isin(y,[0,1]).all():raise ValueError('Invalid event identities/labels')
    pairs=np.asarray(pairs,dtype=np.int64)
    if pairs.ndim!=2 or pairs.shape[1]!=2 or not len(pairs) or not np.isin(pairs,ids).all():raise ValueError('Invalid or empty long-gap pairs')
    left=np.searchsorted(ids,pairs[:,0]);right=np.searchsorted(ids,pairs[:,1])
    if not np.array_equal(user[left],user[right]) or len(np.unique(pairs[:,1]))!=len(pairs):raise ValueError('Invalid pair membership')
    required={'count_R2_seed0'}|{f'{m}_seed{s}' for m in MODES for s in SEEDS}
    if set(predictions)!=required:raise ValueError('Wrong prediction keys')
    ls={k:losses(y,v)[:,0] for k,v in predictions.items()};rows={}
    for key,p in predictions.items():
        l=ls[key];row={'overall':metrics(y,p)};row['overall']['student_macro_nll']=macro(user,l)
        for name,values in [('current',l[left]),('next',l[right]),('two_event_mean',(l[left]+l[right])/2)]:
            row[name]={'n':len(values),'students':len(np.unique(user[left])),'nll':float(np.mean(values)),'student_macro_nll':macro(user[left],values)}
        rows[key]=row
    columns=[];names=[]
    for seed in SEEDS:
        for baseline in (f'original_seed{seed}','count_R2_seed0'):
            columns.append(ls[f'bias_seed{seed}']-ls[baseline]);names.append(f'bias_seed{seed}_minus_{baseline}')
    columns.append(np.mean([ls[f'bias_seed{s}']-ls[f'original_seed{s}'] for s in SEEDS],axis=0));names.append('bias_minus_original_mean_loss_three_fixed_seeds')
    columns.append(np.mean([ls[f'bias_seed{s}']-ls['count_R2_seed0'] for s in SEEDS],axis=0));names.append('bias_mean_loss_three_fixed_seeds_minus_count_seed0')
    matrix=np.stack(columns,axis=1);paired={}
    for name,students,values in [('overall',user,matrix),('current',user[left],matrix[left]),('next',user[left],matrix[right]),('two_event_mean',user[left],(matrix[left]+matrix[right])/2)]:
        out=cluster_intervals(students,values,reps,20261111);paired[name]=dict(zip(names,out['comparisons']))
    aggregates={}
    for mode in MODES:
        aggregates[mode]={}
        for window in ('overall','current','next','two_event_mean'):
            aggregates[mode][window]={}
            for metric in (('nll','student_macro_nll','auc','brier') if window=='overall' else ('nll','student_macro_nll')):
                values=[rows[f'{mode}_seed{s}'][window][metric] for s in SEEDS]
                aggregates[mode][window][metric]={'mean':float(np.mean(values)),'sample_sd':float(np.std(values,ddof=1)),'per_seed':values}
    return {'n':len(ids),'students':len(np.unique(user)),'pair_n':len(pairs),'pair_students':len(np.unique(user[left])),
            'rows':rows,'seed_aggregates':aggregates,'paired':paired,
            'scope':'exploratory previously reused ASSIST holdout, frozen models; no training or test',
            'confidence_interval':'student-cluster bootstrap conditional on fixed selected models; three-seed mean is mean per-event losses, not averaged probabilities; excludes training and selection uncertainty'}
