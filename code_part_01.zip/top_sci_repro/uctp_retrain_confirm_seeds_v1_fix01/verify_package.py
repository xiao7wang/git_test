import hashlib
import json
import re
from pathlib import Path
root=Path(__file__).resolve().parent
for name, expected in json.loads((root/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
    path=root/name
    if path.parent != root or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise ValueError('Missing or changed package member: '+name)
lock=json.loads((root/'locked_selection.json').read_text(encoding='utf8'))
hashes=[lock['seed0_summary_sha256'],lock['seed0_config_sha256']]
hashes += [x['checkpoint_sha256'] for x in lock['selected'].values()]
if any(re.fullmatch(r'[0-9a-f]{64}',x) is None for x in hashes):
    raise ValueError('Invalid seed-0 SHA256 in locked selection')
print('Package integrity verified',flush=True)
