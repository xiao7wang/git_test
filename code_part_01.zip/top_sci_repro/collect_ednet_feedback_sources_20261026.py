"""Collect a SMALL EDNet feedback-source audit pack; standard library only.

Reads named source files and CSV prefixes; writes one NEW ZIP, refusing overwrite.
No training, source changes, archive extraction, or full raw-data traversal.
The pack includes pseudonymous response examples. It does not verify alignment.
"""
import argparse
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import time
import zipfile

RAW = "qccdm\u6539\u8fdb\u4ee3\u7801/data_raw/ednet"
FIXED = [
    "top_sci_repro/ednet_feedback_inventory_20261026.json",
    "top_sci_repro/uctp_cd_clean_research/data/ednet_full/manifest.json",
    "top_sci_repro/uctp_cd_clean_research/data/ednet_full/vocabulary.json",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet/item_mapping.json",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet/user_mapping.json",
    "top_sci_repro/unified_experiments/trace_cd_data/ednet/config.json",
    "qccdm\u6539\u8fdb\u4ee3\u7801/preprocess_ednet_kt1_for_tcqccdm.py",
    RAW + "/EdNet-Contents.zip",
    RAW + "/KT1/KT1/u1.csv",
    RAW + "/KT1/KT1/u10.csv",
    RAW + "/KT1/KT1/u100.csv",
]
SCRIPT_DIR = "top_sci_repro/work_support_20260912/ednet_scripts"
SPLIT_DIR = "top_sci_repro/unified_experiments/splits/ednet"
MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 64 * 1024 * 1024
SAMPLE_ROWS = 128


def collect(root, output):
    root = Path(root).resolve(strict=True)
    output = Path(output)
    if not root.is_dir() or root == Path(root.anchor):
        raise ValueError("Use an existing concrete project directory, not a drive root")
    if output.exists():
        raise FileExistsError("Output already exists; refusing overwrite: " + str(output))
    if not output.parent.is_dir():
        raise ValueError("Output parent directory must already exist")
    started = time.monotonic()
    report = {
        "scope_root": str(root), "trained": False, "read_only_sources": True,
        "response_examples_exported": True, "feedback_boundaries_verified": False,
        "event_alignment_verified": False, "full_dataset_exported": False,
        "source_bytes_included": 0, "files": [], "issues": [],
        "notes": [
            "Named KT1 samples and unified CSV prefixes may not represent the same students/events.",
            "This pack is source material, not evidence that real feedback availability is verified.",
            "No action logs are collected; this does not establish that KT2/KT3 are absent.",
            "EdNet-Contents.zip is copied as a small nested archive, never extracted.",
            "The full EdNet-KT1.zip and complete train/valid/test CSVs are NOT included.",
        ],
    }
    members = set()

    def source(rel):
        path = root / rel
        # Never follow a source outside the explicitly selected project.
        resolved = path.resolve(strict=True)
        resolved.relative_to(root)
        if not resolved.is_file():
            raise ValueError("Not a regular file")
        return resolved

    def put(archive, rel, member, data, kind, extra=None):
        if member in members:
            return
        if len(data) > MAX_FILE or report["source_bytes_included"] + len(data) > MAX_TOTAL:
            raise ValueError("Audit pack size budget exceeded; file not included")
        archive.writestr(member, data)
        members.add(member)
        report["source_bytes_included"] += len(data)
        report["files"].append({
            "source": str(root / rel), "member": member, "kind": kind,
            "bytes_included": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            **(extra or {}),
        })

    def full_file(archive, rel):
        try:
            path = source(rel)
            if path.stat().st_size > MAX_FILE:
                raise ValueError("File exceeds 16 MiB ceiling; not included")
            with path.open("rb") as stream:
                data = stream.read(MAX_FILE + 1)
            put(archive, rel, "sources/" + rel, data, "complete_named_file")
        except (OSError, ValueError) as exc:
            report["issues"].append({"source": str(root / rel), "error": str(exc)})

    # Exclusive mode also protects against another process creating this name.
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for rel in FIXED:
            full_file(archive, rel)

        folder = root / SCRIPT_DIR
        if not folder.is_dir():
            report["issues"].append({"source": str(folder), "error": "Script directory missing"})
        else:
            folder.resolve().relative_to(root)
            count = 0
            for current, dirs, files in os.walk(folder, followlinks=False,
                                                onerror=lambda e: report["issues"].append({"error": str(e)})):
                here = Path(current)
                depth = len(here.relative_to(folder).parts)
                if depth >= 4 and dirs:
                    report["issues"].append({"source": str(here), "error": "Script depth limit reached"})
                dirs[:] = sorted(d for d in dirs if not d.startswith(".")
                                 and d not in {"__pycache__", "outputs", "data", "logs"}
                                 and not (here / d).is_symlink()) if depth < 4 else []
                for name in sorted(files):
                    count += 1
                    if count > 2000:
                        break
                    path = here / name
                    if path.suffix.lower() in {".py", ".sh", ".json", ".yaml", ".yml", ".md"}:
                        full_file(archive, path.relative_to(root).as_posix())
                if count > 2000:
                    report["issues"].append({"source": str(folder), "error": "Script file-count limit reached"})
                    break

        for split in ("train", "valid", "test"):
            rel = SPLIT_DIR + "/" + split + ".csv"
            try:
                path = source(rel)
                buffer = io.StringIO(newline="")
                writer = csv.writer(buffer)
                with path.open("r", encoding="utf-8-sig", newline="") as stream:
                    reader = csv.reader(stream)
                    header = next(reader)
                    writer.writerow(header)
                    n = 0
                    for _ in range(SAMPLE_ROWS):
                        row = next(reader, None)
                        if row is None:
                            break
                        writer.writerow(row)
                        n += 1
                put(archive, rel, "samples/unified_" + split + "_first128.csv",
                    buffer.getvalue().encode("utf-8"), "prefix_sample_not_full_file",
                    {"sample_rows": n, "header": header, "source_file_bytes": path.stat().st_size})
            except (OSError, ValueError, csv.Error, StopIteration, UnicodeError) as exc:
                report["issues"].append({"source": str(root / rel), "error": str(exc)})

        report["collection_status"] = "complete_with_gaps" if report["issues"] else "complete"
        report["seconds"] = time.monotonic() - started
        archive.writestr("collection_report.json", json.dumps(report, ensure_ascii=False, indent=2).encode("utf-8"))
    with zipfile.ZipFile(output, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError("ZIP verification failed: " + bad)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default="/home/wangxiao/QCCDM")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    try:
        report = collect(args.root, args.output)
    except (OSError, ValueError, RuntimeError) as exc:
        raise SystemExit(str(exc))
    print("SOURCE_PACK_CREATED", args.output)
    print(json.dumps({"status": report["collection_status"], "included_files": len(report["files"]),
                      "source_bytes": report["source_bytes_included"], "issues": len(report["issues"]),
                      "seconds": report["seconds"]}))
    print("No training; no source changes. Download this ZIP, including if status is complete_with_gaps.")


if __name__ == "__main__":
    main()
