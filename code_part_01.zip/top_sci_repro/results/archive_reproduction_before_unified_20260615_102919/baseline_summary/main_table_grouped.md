# Grouped Baseline Main Table

Important: datasets/splits are grouped separately. Do not directly compare rows from different splits.

## ASSIST09_official

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| NeuralCDM | 3 | 0.714055 | 0.693899 |  | 0.446463 |  |  |  |  |  | val_best_epoch=3; validation_auc=0.717255; official NeuralCDM ASSIST09 setting |

## ASSIST09_official_converted

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| CausalCDF-NCDM-logit-fix | 10 | 0.723440 | 0.702426 | 0.792463 | 0.440536 |  | 0.723577 ± 0.000192 | 0.701923 ± 0.000699 | 0.791195 ± 0.002378 | 0.440475 ± 0.000146 | logit residual fixed reproduction; 5seed AUC=0.723577±0.000192; multiplicative version was dominated by item-ease prior |

## ASSIST09_repo_default

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| DisenGCD-fixed | 28 | 0.775880 | 0.736866 | 0.812769 | 0.419371 |  | 0.774802 ± 0.000840 | 0.734627 ± 0.001334 | 0.810845 ± 0.001206 | 0.420054 ± 0.000559 | repo-default split; CPU DGL reproduction; 5seed AUC=0.774802±0.000840, ACC=0.734627±0.001334, F1=0.810845±0.001206, RMSE=0.420054±0.000559; graph files regenerated and code bugs fixed |

## ASSIST2017

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| HO-NCD | 5fold-epoch5 | 0.749145 | 0.685232 | 0.608929 | 0.453257 |  |  |  |  |  | 5-fold final result; precision=0.669763; recall=0.571943 |

## assist_sample5000_item12000

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| ORCDF | 2 | 0.753800 | 0.743200 | 0.833100 | 0.417400 | 0.692000 | 0.753480 ± 0.001486 | 0.745100 ± 0.003323 | 0.832700 ± 0.004815 | 0.416900 ± 0.001311 | sample split; 5seed AUC=0.753480±0.001486, ACC=0.745100±0.003323, F1=0.832700±0.004815, RMSE=0.416900±0.001311, DOA=0.688480±0.013667; best epoch selected by AUC within 3 epochs |

## assistments_time_sample5000_item12000

| Model | Best epoch | AUC seed0 | ACC seed0 | F1 seed0 | RMSE seed0 | DOA | AUC 5-seed | ACC 5-seed | F1 5-seed | RMSE 5-seed | Note |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| HyperCDM | rerun_current | 0.746149 | 0.742392 | 0.833148 |  | 0.646806 |  |  |  |  | rerun result; previous run had AUC around 0.7488; need multi-seed average |

