# Current Reproduced Baselines, seed0

| Model | Dataset | Best epoch | AUC | ACC | F1 | RMSE | DOA | Note |
|---|---|---:|---:|---:|---:|---:|---:|---|
| ORCDF | assist_sample5000_item12000 | 2 | 0.7538 | 0.7432 | 0.8331 | 0.4174 | 0.692 | 12 epoch run; best AUC at epoch 2; later epochs decrease |
| HyperCDM | assistments_time_sample5000_item12000 | rerun_current | 0.746149 | 0.742392 | 0.833148 |  | 0.646806 | rerun result; previous run had AUC around 0.7488; need multi-seed average |
| NeuralCDM | ASSIST09_official | 3 | 0.714055 | 0.693899 |  | 0.446463 |  | val_best_epoch=3; validation_auc=0.717255; official NeuralCDM ASSIST09 setting |
| HO-NCD | ASSIST2017 | 5fold-epoch5 | 0.749145 | 0.685232 | 0.608929 | 0.453257 |  | 5-fold final result; precision=0.669763; recall=0.571943 |
| CausalCDF-NCDM-fixed | ASSIST09_official_converted | 10 | 0.701447 | 0.694373 | 0.796030 | 0.445850 |  | fixed reproduction under unified protocol; diff uses train item ease=correct_rate normalized to [0.5,1.5]; original difficulty direction caused positive-class collapse |
