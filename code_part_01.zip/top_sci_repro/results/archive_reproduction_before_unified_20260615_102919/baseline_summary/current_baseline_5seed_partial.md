# Current 5-seed Baseline Summary

## CausalCDF-NCDM-logit-fix / ASSIST09_official_converted

| Metric | Mean ± Std |
|---|---:|
| AUC | 0.723577 ± 0.000192 |
| ACC | 0.701923 ± 0.000699 |
| F1 | 0.791195 ± 0.002378 |
| RMSE | 0.440475 ± 0.000146 |
| Precision | 0.737291 ± 0.003603 |
| Recall | 0.853708 ± 0.010316 |

Note: Original multiplicative CausalCDF-NCDM collapsed or became dominated by item-ease prior under the unified ASSIST09 protocol. The logit residual fix keeps item ease as a correction term rather than multiplying the prediction score directly.

## DisenGCD-fixed / ASSIST09_repo_default

| Metric | Mean ± Std |
|---|---:|
| AUC | 0.774802 ± 0.000840 |
| ACC | 0.734627 ± 0.001334 |
| F1 | 0.810845 ± 0.001206 |
| RMSE | 0.420054 ± 0.000559 |
| Precision | 0.763066 ± 0.000752 |
| Recall | 0.865010 ± 0.002730 |

Note: Repository-default split. The reproduction used CPU DGL. Missing graph files were regenerated from item-concept relations, and import/device/forward/output bugs were fixed. Results are reported under the repository evaluation protocol.

## ORCDF / assist_sample5000_item12000

| Metric | Mean ± Std |
|---|---:|
| AUC | 0.753480 ± 0.001486 |
| ACC | 0.745100 ± 0.003323 |
| F1 | 0.832700 ± 0.004815 |
| RMSE | 0.416900 ± 0.001311 |
| DOA | 0.688480 ± 0.013667 |
| AP | 0.866020 ± 0.001506 |
| MAD | 0.063380 ± 0.005402 |

Note: Sample split. The 5-seed run used the same parameter setting as the previous successful ORCDF reproduction: method=orcdf-w|o-, data_type=assist_sample5000_item12000, if_type=ncd, gcn_layers=3, batch_size=4096, lr=0.004, ssl_temp=0.5, ssl_weight=0.001, flip_ratio=0.15. Best epoch was selected by AUC within 3 epochs.

## ORCDF / assist_sample5000_item12000

| Metric | Mean ± Std |
|---|---:|
| AUC | 0.753480 ± 0.001486 |
| ACC | 0.745100 ± 0.003323 |
| F1 | 0.832700 ± 0.004815 |
| RMSE | 0.416900 ± 0.001311 |
| DOA | 0.688480 ± 0.013667 |
| AP | 0.866020 ± 0.001506 |
| MAD | 0.063380 ± 0.005402 |

Note: Sample split. The 5-seed run used method=orcdf-w|o-, data_type=assist_sample5000_item12000, if_type=ncd, gcn_layers=3, batch_size=4096, lr=0.004, ssl_temp=0.5, ssl_weight=0.001, flip_ratio=0.15. Best epoch was selected by AUC within 3 epochs.
