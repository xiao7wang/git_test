"""Synthetic end-to-end test; no production checkpoint or data are used."""
import contextlib
import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import torch
import test_step
from cross_core import KEYS, frozen_model, long_followup, read, replay, sha, validation_frame, write

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent / 'uctp_cd_time_factorial_v1'


def main():
    test_step.PROJECT, test_step.DEVICE = str(PROJECT), 'cpu'
    test_step.StepTests.setUpClass()
    fixture = test_step.StepTests()
    fixture.setUp()
    torch.set_num_threads(2)
    try:
        with tempfile.TemporaryDirectory(prefix='decision_integration_') as tmp:
            base = Path(tmp)
            pkg, proj, data, cache, out = [base / n for n in ('package', 'project', 'data', 'cache', 'output')]
            for d in (pkg, proj, data, cache):
                d.mkdir()
            for name in ('run_decision.py', 'decision_core.py', 'step_core.py', 'cross_core.py', 'review_stats.py', 'package_results.py'):
                shutil.copy2(ROOT / name, pkg / name)
            sources = fixture.sources
            for name in sources:
                target = proj / name
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(PROJECT / name, target)
            folder = data / 'assist_full'
            shutil.copytree(fixture.path, folder)
            prepared = fixture.Data(folder)
            runfolder = proj / 'outputs/assist_none_seed0'
            runfolder.mkdir(parents=True)
            ckpt = fixture.ckpt
            torch.save(ckpt, runfolder / 'best_model.pt')
            write(runfolder / 'run_config.json', {'args': {'time_mode': 'none', 'variant': 'unit_write',
                  'seed': 0, 'eval_update_targets': 1, 'evaluate_test': False}})
            write(runfolder / 'status.json', {'status': 'complete'})
            results = {}
            for branch, mode in [('NN', 'none'), ('NS', 'support_only')]:
                model = frozen_model(fixture.Base, ckpt, mode, torch.device('cpu'), prepared.fingerprint, sources)
                with contextlib.redirect_stdout(io.StringIO()):
                    results[branch] = replay(model, prepared, type(fixture).forward_fn, torch.device('cpu'), branch)
            frame = validation_frame(prepared, results['NN']['record_idx'])
            reference = frame.copy()
            for key in KEYS:
                reference[key] = results['NN'][key]
            reference.to_csv(runfolder / 'validation_predictions.csv', index=False)
            run = {'dataset': 'assist', 'mode': 'none', 'seed': 0, 'best_epoch': 2,
                   'checkpoint_sha256': sha(runfolder / 'best_model.pt'),
                   'relative_run_dir': 'outputs/assist_none_seed0',
                   'input_hashes': {p.name: sha(p) for p in runfolder.iterdir() if p.name != 'best_model.pt'}}
            write(pkg / 'expected_inputs.json', {'datasets': {'assist': {
                'shared_protocol': {'source': sources, 'data_fingerprint': prepared.fingerprint}, 'runs': [run]}}})
            cached = cache / 'assist_seed0_full'
            cached.mkdir()
            frame.to_csv(cached / 'events.csv.gz', index=False, compression='gzip')
            arrays = {'record_idx': results['NN']['record_idx']}
            arrays.update({b+'_'+k: results[b][k] for b in results for k in KEYS})
            np.savez_compressed(cached / 'predictions.npz', **arrays)
            np.save(cached / 'long_gap_next_single_kc_pairs.npy', long_followup(prepared, arrays['record_idx']), allow_pickle=False)
            write(cached / 'status.json', {'status': 'complete', 'all_gates_passed': True})
            write(cached / 'run_config.json', {'selected_inputs': {'none': run}, 'data_fingerprint': prepared.fingerprint})
            write(pkg / 'cached_inputs.json', {'files': {'assist_seed0_full': {p.name: sha(p) for p in cached.iterdir()}}})
            cmd = [sys.executable, '-B', str(pkg / 'run_decision.py'), '--project-dir', str(proj),
                   '--data-root', str(data), '--cache-root', str(cache), '--output-root', str(out),
                   '--device', 'cpu', '--ack-row-feedback', '--ack-time-proxy']
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
            for mode in ('preflight', 'full'):
                result = subprocess.run(cmd + ['--mode', mode], env=env, text=True,
                                        encoding='utf-8', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                if result.returncode:
                    raise RuntimeError(mode + ' failed:\n' + result.stdout)
            report = read(out / 'full/summary.json')
            assert set(report['chosen_on_dev']) == {'B', 'Bplus', 'C', 'D'}
            assert read(out / 'full/status.json')['status'] == 'complete'
            assert not report['trained'] and not report['test_evaluated']
            with np.load(out / 'full/predictions.npz', allow_pickle=False) as z:
                assert 'NN_probability' in z and 'C_168_probability' in z and 'D_0.1_probability' in z
            second = subprocess.run(cmd + ['--mode', 'full'], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            assert second.returncode != 0
            packaged = subprocess.run([sys.executable, str(pkg / 'package_results.py'), '--output-root', str(out)],
                                      env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            assert packaged.returncode == 0, packaged.stdout
            import hashlib, zipfile
            with zipfile.ZipFile(out / 'decision_results.zip') as archive:
                assert archive.testzip() is None
                manifest = json.loads(archive.read('result_manifest.json'))
                assert all(hashlib.sha256(archive.read(name)).hexdigest() == value for name, value in manifest.items())
            print(json.dumps({'success': True, 'synthetic_only': True, 'dataset': 'assist',
                              'real_checkpoints_tested': False, 'real_cuda_tested': False,
                              'preflight_full_summary_overwrite_guard_and_archive': True}, indent=2))
    finally:
        fixture.tearDown()


if __name__ == '__main__':
    main()
