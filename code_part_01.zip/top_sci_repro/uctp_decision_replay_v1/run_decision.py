"""ASSIST seed-0 screening, frozen weights; never trains or consumes test events."""
import argparse
import hashlib
import json
import os
import time
from pathlib import Path

os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
import numpy as np
import torch

from cross_core import (KEYS, compare, frozen_model, import_project, model_digest,
                        read, reference_bridge, replay, selected_users, sha, write)
from decision_core import make_decision
from review_stats import cluster_intervals, losses, metrics
from step_core import audit, cached_arrays, calibrate_data

ROOT = Path(__file__).resolve().parent
SALT = 'decision-v1-20261105:'
GRID = {'B': ('fixed_all', [0.8, 0.9, 0.97]),
        'Bplus': ('fixed_positive', [0.8, 0.9, 0.97]),
        'C': ('real_time', [48, 168, 672]),
        'D': ('fixed_gain', [0.02, 0.10, 0.30])}


def dev_users(values):
    return {int(u) for u in np.unique(values)
            if hashlib.sha256((SALT + str(int(u))).encode()).digest()[-1] % 2 == 0}


def score(frame, probability, mask, pairs):
    y = frame.label.to_numpy()[mask]
    p = probability[mask]
    if not len(y):
        raise ValueError('Empty selected student partition')
    student = frame.student_idx.to_numpy()[mask]
    _, inverse = np.unique(student, return_inverse=True)
    ls = losses(y, p)[:, 0]
    row = metrics(y, p)
    row['student_macro_nll'] = float(np.mean(np.bincount(inverse, weights=ls) / np.bincount(inverse)))
    ids = frame.record_idx.to_numpy()
    selected = np.isin(pairs[:, 0], ids[mask]) & np.isin(pairs[:, 1], ids[mask])
    pair = pairs[selected]
    if len(pair):
        left, right = np.searchsorted(ids, pair[:, 0]), np.searchsorted(ids, pair[:, 1])
        full_loss = losses(frame.label.to_numpy(), probability)[:, 0]
        row.update(pair_n=len(pair), current_nll=float(full_loss[left].mean()),
                   next_nll=float(full_loss[right].mean()),
                   two_event_mean_nll=float(((full_loss[left] + full_loss[right]) / 2).mean()))
    else:
        row.update(pair_n=0, current_nll=None, next_nll=None, two_event_mean_nll=None)
    return row


def main():
    p = argparse.ArgumentParser()
    for name in ('project-dir', 'data-root', 'cache-root', 'output-root'):
        p.add_argument('--' + name, required=True)
    p.add_argument('--device', choices=('cpu', 'cuda'), default='cuda')
    p.add_argument('--mode', choices=('preflight', 'full'), required=True)
    p.add_argument('--ack-row-feedback', action='store_true')
    p.add_argument('--ack-time-proxy', action='store_true')
    args = p.parse_args()
    if not args.ack_row_feedback or not args.ack_time_proxy:
        p.error('Both feedback/time-proxy acknowledgements are required')
    if args.device == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable')
    root = Path(args.output_root).resolve()
    if args.mode == 'preflight':
        root.mkdir(parents=True, exist_ok=False)
    elif not (root / 'preflight' / 'accepted.json').is_file():
        raise FileNotFoundError('Accepted preflight is required first')
    out = root / args.mode
    out.mkdir(exist_ok=False)
    start = time.monotonic()
    status = {'status': 'running', 'mode': args.mode, 'pid': os.getpid(),
              'dataset': 'assist', 'seed': 0, 'trained': False, 'test_evaluated': False}
    write(out / 'status.json', status)
    try:
        run, sources, cached = audit(args.project_dir, args.data_root, args.cache_root, 'assist', 0)
        Data, Base, forward = import_project(args.project_dir, sources)
        data = Data(Path(args.data_root) / 'assist_full')
        if not (data.arrays['item_q'].sum(1) == 1).all():
            raise ValueError('Require verified single-KC data')
        cal = calibrate_data(data)
        folder = Path(args.project_dir) / run['relative_run_dir']
        checkpoint = torch.load(folder / 'best_model.pt', weights_only=True, map_location='cpu')
        if checkpoint['epoch'] != run['best_epoch'] or checkpoint['model_config']['time_mode'] != 'none':
            raise AssertionError('Checkpoint epoch or mode changed')
        device = torch.device(args.device)
        torch.set_num_threads(4)
        torch.manual_seed(0)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.use_deterministic_algorithms(True)
        users = selected_users(data) if args.mode == 'preflight' else None
        frame, results = cached_arrays(cached, data, users)
        config = {'dataset': 'assist', 'seed': 0, 'grid': GRID, 'calibration': cal,
                  'checkpoint': run, 'source_hashes': sources, 'fingerprint': data.fingerprint,
                  'cache_hashes': read(ROOT / 'cached_inputs.json')['files'][cached.name],
                  'diagnostic_source_hashes': {name: sha(ROOT / name) for name in
                      ('run_decision.py', 'decision_core.py', 'step_core.py', 'cross_core.py', 'review_stats.py')},
                  'checkpoint_tensor_digest': model_digest(checkpoint['model_state']),
                  'device': args.device, 'salt': SALT, 'scope': 'train+validation replay, validation scoring',
                  'trained': False, 'test_evaluated': False}
        write(out / 'config.json', config)
        if args.mode == 'full':
            accepted = read(root / 'preflight' / 'accepted.json')
            if read(root / 'preflight' / 'status.json')['status'] != 'complete':
                raise AssertionError('Preflight is not complete')
            if accepted['config_sha256'] != sha(out / 'config.json'):
                raise AssertionError('Full configuration differs from accepted preflight')
            if accepted['predictions_sha256'] != sha(root / 'preflight' / 'predictions.npz'):
                raise AssertionError('Accepted preflight predictions changed')
        else:
            for branch, mode in [('NN', 'none'), ('NS', 'support_only')]:
                model = frozen_model(Base, checkpoint, mode, device, data.fingerprint, sources)
                actual = replay(model, data, forward, device, branch + '_bridge', users=users)
                if not compare(actual, results[branch])['success']:
                    raise AssertionError(branch + ' cache bridge failed')
                if branch == 'NN' and not reference_bridge(actual, data, folder / 'validation_predictions.csv')['success']:
                    raise AssertionError('Original CSV bridge failed')

        branches = [('B', x) for x in GRID['B'][1]] + [('Bplus', x) for x in GRID['Bplus'][1]]
        branches += [('C', x) for x in GRID['C'][1]] + [('D', x) for x in GRID['D'][1]]
        branches += [('Bmatched', cal['fixed_retention_float32'])]
        for group, value in branches:
            name = group + '_' + str(value)
            status['active_branch'] = name
            write(out / 'status.json', status)
            rule = 'fixed_positive' if group == 'Bmatched' else GRID[group][0]
            model = make_decision(Base, checkpoint, device, data.fingerprint, sources, rule, value)
            result = replay(model, data, forward, device, name, users=users)
            if args.mode == 'preflight':
                alternative = replay(model, data, forward, device, name + '_alternate',
                                     users=users, batch_size=17, chunk_size=17)
                if not compare(result, alternative)['success']:
                    raise AssertionError(name + ' batch/chunk comparison failed')
            else:
                with np.load(root / 'preflight' / 'predictions.npz', allow_pickle=False) as z:
                    small = {'record_idx': z['record_idx']}
                    small.update({key: z[name + '_' + key] for key in KEYS})
                ix = np.searchsorted(result['record_idx'], small['record_idx'])
                if (ix >= len(result['record_idx'])).any() or not compare({k: v[ix] for k, v in result.items()}, small)['success']:
                    raise AssertionError(name + ' full/preflight mismatch')
            results[name] = result
        if not compare(results['C_168'], results['NS'])['success']:
            raise AssertionError('C 168 must match accepted NS')
        ids = results['NN']['record_idx']
        if any(not np.array_equal(ids, result['record_idx']) for result in results.values()):
            raise AssertionError('Branch record identity changed')
        arrays = {'record_idx': ids}
        arrays.update({name + '_' + key: result[key] for name, result in results.items() for key in KEYS})
        np.savez_compressed(out / 'predictions.npz', **arrays)
        frame.to_csv(out / 'events.csv.gz', index=False, compression='gzip')
        if args.mode == 'full':
            pairs = np.load(cached / 'long_gap_next_single_kc_pairs.npy', allow_pickle=False)
            if pairs.ndim != 2 or pairs.shape[1] != 2 or not np.isin(pairs, ids).all():
                raise AssertionError('Invalid paired-event identity')
            ix0, ix1 = np.searchsorted(ids, pairs[:, 0]), np.searchsorted(ids, pairs[:, 1])
            if not np.array_equal(frame.student_idx.to_numpy()[ix0], frame.student_idx.to_numpy()[ix1]):
                raise AssertionError('Paired students differ')
            dev = np.isin(frame.student_idx.to_numpy(), list(dev_users(frame.student_idx.to_numpy())))
            chosen, candidates = {}, {}
            for group, (_, values) in GRID.items():
                names = [group + '_' + str(v) for v in values]
                values_nll = [score(frame, results[n]['probability'], dev, pairs)['nll'] for n in names]
                candidates[group] = dict(zip(names, values_nll))
                chosen[group] = names[int(np.argmin(values_nll))]
            names = ['NN'] + list(chosen.values()) + ['Bmatched_' + str(cal['fixed_retention_float32'])]
            holdout = {name: score(frame, results[name]['probability'], ~dev, pairs) for name in names}
            mask = ~dev
            y = frame.label.to_numpy()[mask]
            diffs = np.column_stack([losses(y, results[chosen['C']]['probability'][mask])[:, 0] -
                                     losses(y, results[chosen[g]]['probability'][mask])[:, 0] for g in ('B', 'D')])
            ci = cluster_intervals(frame.student_idx.to_numpy()[mask], diffs, 2000, 20261105)
            write(out / 'summary.json', {'scope': 'seed0 exploratory validation; previously inspected dataset; no independent confirmation',
                  'dev_candidate_nll': candidates, 'chosen_on_dev': chosen, 'holdout_metrics': holdout,
                  'holdout_paired_C_minus_B_D': dict(zip(('C_minus_B','C_minus_D'), ci['comparisons'])),
                  'trained': False, 'test_evaluated': False})
        audit(args.project_dir, args.data_root, args.cache_root, 'assist', 0)
        status.update(status='complete', active_branch=None, seconds=time.monotonic()-start)
        write(out / 'status.json', status)
        if args.mode == 'preflight':
            write(out / 'accepted.json', {'config_sha256': sha(out / 'config.json'),
                                         'predictions_sha256': sha(out / 'predictions.npz'),
                                         'n': len(ids), 'all_gates_passed': True})
        print('COMPLETED:', out, flush=True)
    except BaseException as exc:
        status.update(status='failed', error=repr(exc), seconds=time.monotonic()-start)
        write(out / 'status.json', status)
        raise


if __name__ == '__main__':
    main()
