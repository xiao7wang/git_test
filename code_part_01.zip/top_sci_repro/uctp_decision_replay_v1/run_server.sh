#!/usr/bin/env bash
set -euo pipefail
TASK_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
RUN_NAME="${1:-server_decision_01}"
if [[ ! "$RUN_NAME" =~ ^[A-Za-z0-9_-]+$ ]]; then echo 'Invalid output name' >&2; exit 2; fi
PY=/home/wangxiao/miniconda3/envs/yydw/bin/python
PROJECT=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
DATA=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research/data
CACHE=/home/wangxiao/QCCDM/top_sci_repro/uctp_frozen_cross_replay_v1/outputs/server_cross_01
OUTPUT="$TASK_DIR/outputs/$RUN_NAME"
LAUNCH_LOG="$TASK_DIR/outputs/$RUN_NAME.launch.log"
mkdir -p "$TASK_DIR/outputs"
if [[ -e "$OUTPUT" || -e "$LAUNCH_LOG" ]]; then echo 'Existing output or log; preserved.' >&2; exit 2; fi
(set -o noclobber; : > "$LAUNCH_LOG")
exec > >(tee -a "$LAUNCH_LOG") 2>&1
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export CUBLAS_WORKSPACE_CONFIG=:4096:8
export PYTHONDONTWRITEBYTECODE=1
"$PY" -B "$TASK_DIR/verify_package.py"
for DEVICE in cpu cuda; do
  echo "Starting $DEVICE tests"
  "$PY" -B "$TASK_DIR/test_step.py" --project-dir "$PROJECT" --device "$DEVICE" --report "$TASK_DIR/outputs/${RUN_NAME}_tests_${DEVICE}.json"
  "$PY" -B "$TASK_DIR/test_decision.py" --project-dir "$PROJECT" --device "$DEVICE"
done
for MODE in preflight full; do
  echo "Starting $MODE"
  "$PY" -B -u "$TASK_DIR/run_decision.py" --project-dir "$PROJECT" --data-root "$DATA" --cache-root "$CACHE" --output-root "$OUTPUT" --device cuda --mode "$MODE" --ack-row-feedback --ack-time-proxy
done
"$PY" -B "$TASK_DIR/package_results.py" --output-root "$OUTPUT"
