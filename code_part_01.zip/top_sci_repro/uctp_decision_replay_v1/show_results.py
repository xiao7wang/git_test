"""Display seed-0 state and the fixed-screening result."""
import argparse
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--output-root', type=Path, required=True)
a = p.parse_args()
for mode in ('preflight', 'full'):
    path = a.output_root / mode / 'status.json'
    if not path.exists():
        print(mode + ': not started')
        continue
    status = json.loads(path.read_text(encoding='utf-8'))
    print(f"{mode}: {status['status']}; active={status.get('active_branch', '-')}; error={status.get('error', '-')}")
print('A saved running status is not proof of a live process.')
summary = a.output_root / 'full/summary.json'
if summary.exists():
    obj = json.loads(summary.read_text(encoding='utf-8'))
    print('Exploratory seed 0, not an independent confirmation:')
    print('Selected on development students:', obj['chosen_on_dev'])
    for name, row in obj['holdout_metrics'].items():
        print(f"{name:20s} NLL={row['nll']:.6f} student_NLL={row['student_macro_nll']:.6f} "
              f"AUC={row['auc']} pairs={row['pair_n']} current={row['current_nll']} next={row['next_nll']}")
    print('Paired C-B/C-D:', obj['holdout_paired_C_minus_B_D'])
    archive = a.output_root / 'decision_results.zip'
    if archive.exists():
        print('Results archive:', archive)
