"""Synthetic train/evaluate bridge, no-overwrite and provenance checks."""
import hashlib,json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from cross_core import sha,write
from count_core import dev_users
ROOT=Path(__file__).resolve().parent;PROJECT=ROOT.parent/'uctp_cd_time_factorial_v1'
sys.path.insert(0,str(ROOT.parent/'uctp_retrain_holdout_v1'))
import test_step
test_step.PROJECT=str(PROJECT);test_step.StepTests.setUpClass();fixture=test_step.StepTests();fixture.setUp()
try:
 with tempfile.TemporaryDirectory(prefix='dkvmn_pilot_') as temp:
  root=Path(temp);pkg=root/'pkg';pkg.mkdir();p1=root/'p1';p1.mkdir()
  for n in ('run_pilot.py','streaming_dkvmn.py','source_manifest.json','LICENSE','count_core.py','cross_core.py','review_stats.py','package_results.py','show_results.py'):shutil.copy2(ROOT/n,pkg/n)
  (pkg/'pykt/models').mkdir(parents=True);shutil.copy2(ROOT/'pykt/models/dkvmn.py',pkg/'pykt/models/dkvmn.py')
  write(pkg/'expected_inputs.json',{'datasets':{'assist':{'shared_protocol':{'source':fixture.sources,'data_fingerprint':fixture.data.fingerprint}}}})
  a=fixture.data.arrays;dev=dev_users(a['student_idx'][a['split']==1]);ids=np.flatnonzero((a['split']==1)&np.isin(a['student_idx'],list(dev)))
  pd.DataFrame({'record_idx':ids,'student_idx':a['student_idx'][ids],'label':a['label'][ids]}).to_csv(p1/'dev_predictions.csv.gz',index=False,compression='gzip')
  write(p1/'config.json',{'data_fingerprint':fixture.data.fingerprint,'test_evaluated':False,'holdout_evaluated':False,'feedback':'row immediate assumption'})
  write(p1/'status.json',{'status':'complete'});write(p1/'summary.json',{'status':'complete'})
  write(pkg/'locked_p1.json',{'p1_files':{n:sha(p1/n) for n in ('status.json','config.json','summary.json','dev_predictions.csv.gz')}})
  n=min(len(dev),2);assert n>=2
  cmd=[sys.executable,'-B',str(pkg/'run_pilot.py'),'--project-dir',str(PROJECT),'--data-dir',str(fixture.path),'--p1-dir',str(p1),'--output-dir',str(root/'out'),'--device','cpu','--students',str(n),'--batch-size','2','--chunk-size','3','--ack-row-feedback']
  env=dict(os.environ,PYTHONIOENCODING='utf8',PYTHONDONTWRITEBYTECODE='1')
  q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf8')
  if q.returncode:raise RuntimeError(q.stdout)
  s=json.loads((root/'out/summary.json').read_text());assert s['pilot_only'] and not s['test_evaluated'] and not s['holdout_evaluated']
  assert s['upstream_bridge_max_abs']<=1e-6 and s['chunk17_max_abs']<=1e-6 and s['train_events']>0
  cfg=json.loads((root/'out/config.json').read_text());selected=set(cfg['sample_student_ids'])
  expected=ids[np.isin(a['student_idx'][ids],list(selected))];actual=pd.read_csv(root/'out/pilot_predictions.csv.gz')
  assert np.array_equal(actual.record_idx.to_numpy(),expected)
  q=subprocess.run([sys.executable,str(pkg/'package_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  with zipfile.ZipFile(root/'out/dkvmn_pilot_results.zip') as z:
   m=json.loads(z.read('manifest.json'));assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in m.items())
  q=subprocess.run([sys.executable,str(pkg/'show_results.py'),'--output-dir',str(root/'out')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert q.returncode==0,q.stdout
  assert subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  with (p1/'status.json').open('a') as f:f.write(' ')
  bad=cmd.copy();bad[bad.index(str(root/'out'))]=str(root/'bad')
  assert subprocess.run(bad,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT).returncode!=0
  assert json.loads((root/'bad/status.json').read_text())['status']=='failed'
  print('PASS sampled training, P1 identity, upstream bridge, chunk consistency, archive and provenance guards')
finally:fixture.tearDown()
