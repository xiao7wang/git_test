import hashlib,json
from pathlib import Path
d=Path(__file__).resolve().parent
for n,h in json.loads((d/'PACKAGE_MANIFEST.json').read_text(encoding='utf8')).items():
 p=(d/n).resolve()
 if not p.is_relative_to(d) or hashlib.sha256(p.read_bytes()).hexdigest()!=h:raise ValueError('Package changed: '+n)
source=json.loads((d/'source_manifest.json').read_text(encoding='utf8'))
for n in ('LICENSE','pykt/models/dkvmn.py'):
 if hashlib.sha256((d/n).read_bytes()).hexdigest()!=source['files'][n]:raise ValueError('Upstream source changed: '+n)
print('Package and upstream source integrity verified')
