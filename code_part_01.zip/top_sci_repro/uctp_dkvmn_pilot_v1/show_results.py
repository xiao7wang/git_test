import argparse,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output-dir',required=True);a=p.parse_args();d=Path(a.output_dir)
if not (d/'status.json').exists():raise SystemExit('No status file: check launch log')
s=json.loads((d/'status.json').read_text(encoding='utf8'));print('status:',s.get('status'),'phase:',s.get('phase'),'error:',s.get('error','-'))
print('Saved running status does not prove a live process.')
if (d/'summary.json').exists():
 r=json.loads((d/'summary.json').read_text(encoding='utf8'))
 for key in ('train_students','train_events','optimizer_steps','train_seconds','validation_events','validation_seconds','validation_chunk17_seconds','upstream_bridge_max_abs','chunk17_max_abs','seconds'):print(key,r[key])
 print('Pilot only: subset and one epoch; not full-data performance comparison.')
if (d/'dkvmn_pilot_results.zip').exists():print('Results archive:',d/'dkvmn_pilot_results.zip')
