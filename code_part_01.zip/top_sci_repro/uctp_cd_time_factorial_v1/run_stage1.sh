#!/usr/bin/env bash
# One-shot, validation-only server acceptance. Never overwrites a prior output.
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python_bin=/home/wangxiao/miniconda3/envs/yydw/bin/python
old_dir=/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_clean_research
run_name="${1:-server_stage1_01}"
case "$run_name" in
  *[!a-zA-Z0-9_-]*|'') printf '%s\n' 'Use a simple new run name (letters, digits, _ or -).' >&2; exit 2;;
esac
run_root="$project_dir/outputs/$run_name"

test -x "$python_bin"
test -f "$old_dir/data/assist_smoke/manifest.json"
test -f "$old_dir/data/ednet_smoke/manifest.json"
test -f "$old_dir/outputs/server_assist_smoke_seed0/best_model.pt"
test -f "$old_dir/outputs/server_ednet_smoke_seed0/best_model.pt"
if test -e "$run_root"; then
  printf 'Existing output, refusing to overwrite: %s\n' "$run_root" >&2
  exit 2
fi
mkdir -p "$run_root"
cd "$project_dir"
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

"$python_bin" -u scripts/check_environment.py --device cuda \
  --output-dir "$run_root/environment"
"$python_bin" -u scripts/run_tests.py --device cpu \
  --output-dir "$run_root/tests_cpu"
"$python_bin" -u scripts/run_tests.py --device cuda \
  --output-dir "$run_root/tests_cuda"

"$python_bin" -u scripts/check_baseline_equivalence.py \
  --checkpoint "$old_dir/outputs/server_assist_smoke_seed0/best_model.pt" \
  --data-dir "$old_dir/data/assist_smoke" \
  --output-dir "$run_root/assist_bridge" \
  --view valid --batch-size 8 --chunk-size 100 --atol 1e-6 \
  --device cuda --ack-row-feedback
"$python_bin" -u scripts/check_baseline_equivalence.py \
  --checkpoint "$old_dir/outputs/server_ednet_smoke_seed0/best_model.pt" \
  --data-dir "$old_dir/data/ednet_smoke" \
  --output-dir "$run_root/ednet_bridge" \
  --view valid --batch-size 8 --chunk-size 100 --atol 1e-6 \
  --device cuda --ack-row-feedback

for dataset in assist ednet; do
  "$python_bin" -u scripts/run_factorial_matrix.py \
    --data-dir "$old_dir/data/${dataset}_smoke" \
    --output-root "$run_root/${dataset}_smoke_matrix" \
    --variants unit_write \
    --time-modes none mean_only support_only joint \
    --seeds 0 --half-life-hours 168 \
    --epochs 1 --patience 1 --batch-size 8 --chunk-size 17 \
    --eval-chunk-size 17 --device cuda \
    --ack-row-feedback --ack-time-proxy
done

printf '\nSTAGE1_COMPLETE: %s\n' "$run_root"
