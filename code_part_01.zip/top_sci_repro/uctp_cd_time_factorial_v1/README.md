# UCTP-CD Time Factorial V1

**当前工程入口：先阅读 `FACTORIAL_EXPERIMENT_PLAN.md` 和 `SERVER_FACTORIAL_GUIDE.md`。下文是复制来源 temporal_v1 的历史说明，模式定义与服务器路径已过时，不要据此运行。新四组为 none / mean_only / support_only / joint；新 joint 不等于旧 joint。验证集配对对照脚本为 `scripts/analyze_factorial.py`。**

## 以下为历史材料，仅供回溯

独立的第二阶段开发版本，不替换 uctp_cd_clean_research，不修改旧数据或输出。
先阅读 SERVER_TEST_GUIDE.md。本轮仅验证实现与协议，尚未证明论文创新或性能提升。

## 三种时间模式，两个写入规则

- none：不衰减，保留原基线 P/N 累积算术。
- joint：预测前按每个 KC 的经过时间衰减 P/N，动态均值向 0.5 回缩。
- mass：预测前缩减 alpha+beta，保留 alpha/(alpha+beta)，反馈后再更新。
- 写入规则为 dynamic_only 或 unit_write，不按不同数据集的 test 指标选择规则。
- 新模块没有增加可学习参数。默认 168 小时半衰期是固定的工程试验值，不是已选出的最优参数。
- 没有 RT 网络、rho、双时间尺度、surprise、selective consolidation 或额外损失。

## 数据流

读取事件时间和 Q → 推进当前 Q 相关 KC 的时间 → 用历史状态预测 →
观察当前答案 → 按原写入规则更新 → 用于后续交互。
当前答案和 RT 不进入当前预测。

时间戳保持 float64 Unix 秒。每名学生每个 KC 都有独立时钟，不共用多 KC 平均 gap。
未查询 KC 延迟推进；当前预测头只读取当前 Q，因此不提前更新无关 KC 不改变结果。
冻结答案写入不会冻结时间；padding 不推进时钟；跨 chunk 保存完整状态与时钟。

## 文件入口

- src/model.py：原基线及共用预测头/写入函数，公式未改变。
- src/temporal_model.py：三模式、时钟、支持量状态。
- src/data.py、src/engine.py：原数据包读取与 float64 timestamp 传入。
- train.py：训练，默认仅验证集选模并输出验证结果。
- evaluate.py：默认评测 valid；test 必须显式确认。
- scripts/check_baseline_equivalence.py：旧 checkpoint 与新 none 模式桥接检查。
- scripts/run_temporal_matrix.py：写入规则 × 时间模式 × 种子的顺序作业。
- scripts/show_progress.py：只读状态表，无需复制长 Python 查询代码。
- scripts/summarize_runs.py：默认汇总 valid，隔离模式、衰减率，拒绝混合公共协议。
- tests：原 38 项回归测试及新增时序测试。

## 重要默认变化

train.py 默认不评测 test，生成 validation_metrics.json、validation_predictions.csv。
只有显式 --evaluate-test 才执行测试。evaluate.py --view test 还需 --ack-test-evaluation。
复用旧项目已冻结的数据包，不重新 prepare_data，不复制大数据、不改变词表或切分。
新 checkpoint 使用新版本 evaluate.py；旧 checkpoint 使用旧项目或专用桥接脚本。

## 不变的边界

仍为 row-immediate feedback assumption，真实反馈组未核实。
--ack-time-proxy 只承认事件时间代理，不恢复题组反馈。同时间 delta=0 不解决组内提前反馈风险。
支持量不是经过外部校准的认知置信度；这是学生状态在线更新，不是参数持续学习。
具体公式和本地验证见 IMPLEMENTATION_REPORT.md；服务器步骤见 SERVER_TEST_GUIDE.md。
