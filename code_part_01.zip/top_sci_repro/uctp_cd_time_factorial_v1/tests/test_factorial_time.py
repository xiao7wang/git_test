"""Mechanism and online-order checks for the new 2 x 2 time experiment."""
import inspect
import math
import os
import unittest

import torch

from src.factorial_time_model import FactorialTimeCD
from src.temporal_model import BetaEvidence, TemporalCD
from tests.test_model import example
from tests.test_temporal import times


DEVICE = torch.device(os.environ.get("UCTP_TEST_DEVICE", "cpu"))


class FactorialTimeTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(31)
        self.x = example()

    def model(self, mode="joint", rate=math.log(2), variant="unit_write"):
        return FactorialTimeCD(2, 3, 2, variant=variant, ncd_hidden_dim=16,
                               time_mode=mode, decay_rate_per_hour=rate).to(DEVICE)

    def seeded(self, model):
        state = model.init_state(2, DEVICE)
        if isinstance(state.evidence, BetaEvidence):
            state.evidence.alpha.fill_(9)
            state.evidence.beta.fill_(1)
        else:
            state.evidence.positive.fill_(8)
        state.clock.seen_kc.fill_(True)
        state.clock.seen_event.fill_(True)
        return state

    def forecast(self, model, state, hours, q=None):
        q = torch.ones((2, 2), device=DEVICE) if q is None else q
        stamp = torch.full((2,), hours * 3600, dtype=torch.float64, device=DEVICE)
        active = torch.ones(2, dtype=torch.bool, device=DEVICE)
        return model.advance_time(state, q, stamp, active)

    def test_none_exact_archived_none_predictions_and_state(self):
        reference = TemporalCD(2, 3, 2, variant="unit_write", ncd_hidden_dim=16,
                               time_mode="none", decay_rate_per_hour=0).to(DEVICE)
        candidate = self.model("none", 0)
        candidate.load_state_dict(reference.state_dict(), strict=True)
        before, old_state = reference.forward_chunk(reference.init_state(2, DEVICE),
                                                    *self.x, timestamp=times())
        after, new_state = candidate.forward_chunk(candidate.init_state(2, DEVICE),
                                                   *self.x, timestamp=times())
        for key in before:
            torch.testing.assert_close(before[key], after[key], rtol=0, atol=0)
        for left, right in zip(reference.components(old_state), candidate.components(new_state)):
            torch.testing.assert_close(left, right, rtol=0, atol=0)

    def test_factorial_components_are_separable(self):
        expected = {
            "mean_only": (.225, 10.0),
            "support_only": (.9, 4.0),
            "joint": (.225, 4.0),
        }
        for mode, (wanted_mean, wanted_support) in expected.items():
            with self.subTest(mode=mode):
                model = self.model(mode)
                mean, support = model.components(self.forecast(model, self.seeded(model), 2))
                torch.testing.assert_close(mean, torch.full_like(mean, wanted_mean))
                torch.testing.assert_close(support, torch.full_like(support, wanted_support))

    def test_all_four_cells_share_the_same_trainable_parameters(self):
        signatures = []
        for mode in FactorialTimeCD.TIME_MODES:
            model = self.model(mode, 0 if mode == "none" else .1)
            signatures.append([(name, tuple(parameter.shape))
                               for name, parameter in model.named_parameters()])
        self.assertTrue(all(signature == signatures[0] for signature in signatures[1:]))

    def test_support_only_current_readout_and_later_feedback(self):
        model = self.model("support_only")
        initial = self.seeded(model)
        short = self.forecast(model, initial, 0)
        long = self.forecast(model, initial, 2)
        users, items, q, _, _ = self.x
        p_short = model.predict(short, users, items[:, 0], q[:, 0])["probability"]
        p_long = model.predict(long, users, items[:, 0], q[:, 0])["probability"]
        torch.testing.assert_close(p_short, p_long, rtol=1e-6, atol=1e-7)
        wrong = model.observe(long, torch.ones((2, 2), device=DEVICE),
                              torch.zeros(2, device=DEVICE),
                              torch.full((2,), .5, device=DEVICE),
                              torch.ones(2, dtype=torch.bool, device=DEVICE))
        mean, support = model.components(wrong)
        torch.testing.assert_close(mean, torch.full_like(mean, .72))
        torch.testing.assert_close(support, torch.full_like(support, 5.0))

    def test_mean_only_changes_current_prediction_without_losing_support(self):
        model = self.model("mean_only")
        initial = self.seeded(model)
        short = self.forecast(model, initial, 0)
        long = self.forecast(model, initial, 2)
        users, items, q, _, _ = self.x
        p_short = model.predict(short, users, items[:, 0], q[:, 0])["probability"]
        p_long = model.predict(long, users, items[:, 0], q[:, 0])["probability"]
        self.assertGreater(float((p_short - p_long).abs().max().detach()), 0)
        torch.testing.assert_close(model.components(long)[1], model.components(short)[1])

    def test_zero_gap_and_zero_rate_exact_noop(self):
        baseline = self.model("none", 0)
        expected, _ = baseline.forward_chunk(baseline.init_state(2, DEVICE),
                                             *self.x, timestamp=times())
        for mode in ("mean_only", "support_only", "joint"):
            with self.subTest(mode=mode):
                model = self.model(mode)
                old = self.seeded(model)
                same = self.forecast(model, old, 0)
                for left, right in zip(model.components(old), model.components(same)):
                    torch.testing.assert_close(left, right, rtol=0, atol=0)
                zero = self.model(mode, 0)
                zero.load_state_dict(baseline.state_dict(), strict=True)
                actual, _ = zero.forward_chunk(zero.init_state(2, DEVICE),
                                               *self.x, timestamp=times())
                for key in expected:
                    torch.testing.assert_close(expected[key], actual[key], rtol=0, atol=0)

    def test_first_visit_and_unobserved_prior_do_not_invent_forgetting(self):
        model = self.model("joint")
        first = model.init_state(2, DEVICE)
        after = self.forecast(model, first, 1e7)
        for left, right in zip(model.components(first), model.components(after)):
            torch.testing.assert_close(left, right, rtol=0, atol=0)
        after_again = self.forecast(model, after, 1e7 + 2)
        for left, right in zip(model.components(first), model.components(after_again)):
            torch.testing.assert_close(left, right, rtol=0, atol=0)

    def test_joint_semigroup_and_per_kc_lazy_clock(self):
        model = self.model("joint", .1)
        initial = self.seeded(model)
        direct = self.forecast(model, initial, 3)
        staged = self.forecast(model, self.forecast(model, initial, 1), 3)
        for left, right in zip(model.components(direct), model.components(staged)):
            torch.testing.assert_close(left, right, rtol=1e-5, atol=1e-6)
        q0 = torch.tensor([[1., 0.], [1., 0.]], device=DEVICE)
        partial = self.forecast(model, initial, 1, q=q0)
        torch.testing.assert_close(partial.evidence.alpha[:, 1], initial.evidence.alpha[:, 1],
                                   rtol=0, atol=0)
        self.assertEqual(float(partial.clock.last_kc_seconds[0, 1]), 0)

    def test_current_response_cannot_affect_current_or_past_prediction(self):
        for mode in FactorialTimeCD.TIME_MODES:
            with self.subTest(mode=mode):
                model = self.model(mode, 0 if mode == "none" else .1)
                initial = model.init_state(2, DEVICE)
                before, _ = model.forward_chunk(initial, *self.x, timestamp=times())
                x = list(self.x)
                x[3] = x[3].clone()
                x[3][0, 1:] = 1 - x[3][0, 1:]
                after, _ = model.forward_chunk(model.init_state(2, DEVICE),
                                               *x, timestamp=times())
                torch.testing.assert_close(before["probability"][:, :2],
                                           after["probability"][:, :2], rtol=0, atol=0)
                for method in (model.advance_time, model.predict):
                    for field in ("label", "response_time", "rt_residual"):
                        self.assertNotIn(field, inspect.signature(method).parameters)

    def test_whole_chunked_exact_and_finite_backward(self):
        for mode in FactorialTimeCD.TIME_MODES:
            with self.subTest(mode=mode):
                model = self.model(mode, 0 if mode == "none" else .1)
                whole, end = model.forward_chunk(model.init_state(2, DEVICE),
                                                 *self.x, timestamp=times())
                state = model.init_state(2, DEVICE)
                parts = []
                users, items, q, y, active = self.x
                for lo, hi in ((0, 1), (1, 3), (3, 5)):
                    result, state = model.forward_chunk(state, users, items[:, lo:hi],
                                                        q[:, lo:hi], y[:, lo:hi],
                                                        active[:, lo:hi],
                                                        timestamp=times()[:, lo:hi])
                    parts.append(result)
                    state = state.detach()
                for key in whole:
                    torch.testing.assert_close(whole[key], torch.cat([p[key] for p in parts], 1),
                                               rtol=0, atol=0)
                for left, right in zip(model.components(end), model.components(state)):
                    torch.testing.assert_close(left, right, rtol=0, atol=0)
                loss = torch.nn.functional.binary_cross_entropy(
                    whole["probability"][active], y[active])
                loss.backward()
                self.assertTrue(bool(torch.isfinite(loss)))
                self.assertTrue(all(p.grad is None or bool(torch.isfinite(p.grad).all())
                                    for p in model.parameters()))

    def test_invalid_configuration_rejected(self):
        for mode, rate in (("bad", 0), ("joint", -1), ("mean_only", math.inf),
                           ("support_only", math.nan), ("none", .1)):
            with self.assertRaises(ValueError):
                self.model(mode, rate)
        with self.assertRaises(ValueError):
            self.model("joint", .1, "static")


if __name__ == "__main__":
    unittest.main()
