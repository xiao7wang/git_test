"""Named entry point for the four-cell mean/support experiment."""
try:
    from .run_temporal_matrix import main
except ImportError:
    from run_temporal_matrix import main


if __name__ == "__main__":
    main()
