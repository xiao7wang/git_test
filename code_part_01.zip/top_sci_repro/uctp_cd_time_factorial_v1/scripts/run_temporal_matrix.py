"""Sequential, validation-only by default: writing rule x factorial time mode x seed."""
import argparse
import math
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, new_output_dir, write_json
from src.data import PreparedData
from src.factorial_time_model import FactorialTimeCD


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-root", required=True)
    p.add_argument("--variants", nargs="+", choices=("dynamic_only", "unit_write"),
                   default=["unit_write"])
    p.add_argument("--time-modes", nargs="+", choices=FactorialTimeCD.TIME_MODES,
                   default=list(FactorialTimeCD.TIME_MODES))
    p.add_argument("--seeds", nargs="+", type=int, default=[0])
    p.add_argument("--half-life-hours", type=float, default=168.0)
    p.add_argument("--epochs", type=int, default=20)
    p.add_argument("--patience", type=int, default=5)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=50)
    p.add_argument("--eval-chunk-size", type=int, default=100)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--ack-row-feedback", action="store_true")
    p.add_argument("--ack-time-proxy", action="store_true")
    p.add_argument("--evaluate-test", action="store_true")
    a = p.parse_args()
    if not a.ack_row_feedback or (set(a.time_modes) != {"none"} and not a.ack_time_proxy):
        p.error("Feedback and event-time proxy acknowledgments are required")
    if min(a.epochs, a.patience, a.batch_size, a.chunk_size, a.eval_chunk_size) < 1:
        p.error("Training sizes must be positive")
    if not math.isfinite(a.half_life_hours) or a.half_life_hours <= 0:
        p.error("half-life-hours must be positive and finite")
    for values in (a.variants, a.time_modes, a.seeds):
        if len(values) != len(set(values)):
            p.error("Duplicate matrix entries")
    # Fail on invalid inputs/device before reserving a run directory.
    data_dir = str(Path(a.data_dir).resolve())
    PreparedData(data_dir)
    from train import choose_device
    choose_device(a.device)
    out = new_output_dir(a.output_root)
    plan = []
    for variant in a.variants:
        for mode in a.time_modes:
            for seed in a.seeds:
                name = f"{variant}_{mode}_seed{seed}"
                command = [sys.executable, "-u", str(ROOT / "train.py"), "--data-dir", data_dir,
                           "--output-dir", str(out / name), "--variant", variant, "--time-mode", mode,
                           "--seed", str(seed), "--epochs", str(a.epochs), "--patience", str(a.patience),
                           "--batch-size", str(a.batch_size), "--chunk-size", str(a.chunk_size),
                           "--eval-chunk-size", str(a.eval_chunk_size), "--device", a.device,
                           "--ack-row-feedback"]
                if mode != "none":
                    command += ["--half-life-hours", str(a.half_life_hours), "--ack-time-proxy"]
                if a.evaluate_test:
                    command += ["--evaluate-test"]
                plan.append({"name": name, "command": command})
    write_json(out / "plan.json", plan)
    write_json(out / "matrix_config.json", vars(a))
    completed = []
    for job in plan:
        print(f"Starting {job['name']}; log: {out / (job['name'] + '.log')}", flush=True)
        with open(out / (job["name"] + ".log"), "x", encoding="utf-8") as log:
            result = subprocess.run(job["command"], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        completed.append({"name": job["name"], "returncode": result.returncode})
        write_json(out / "jobs.json", completed)
        if result.returncode:
            raise SystemExit(f"Stopped on {job['name']}; preserve results and inspect its log")
        print(f"Completed {job['name']}", flush=True)


if __name__ == "__main__":
    main()
