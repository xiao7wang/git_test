"""Bridge audit: frozen stage-1 checkpoint versus time-mode none. No training."""
import argparse
import os
import sys
from pathlib import Path
import numpy as np
import torch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, read_json, new_output_dir, write_json, sha256, source_hashes
from src.data import PreparedData
from src.engine import evaluate
from src.factorial_time_model import FactorialTimeCD
from tests.fixtures.frozen_clean_model import CleanCD as FrozenCleanCD
from train import choose_device, set_seed


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--view", choices=("valid", "test"), default="valid")
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=100)
    p.add_argument("--atol", type=float, default=1e-6)
    p.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    p.add_argument("--ack-row-feedback", action="store_true")
    a = p.parse_args()
    if not a.ack_row_feedback:
        p.error("--ack-row-feedback required")
    if min(a.batch_size, a.chunk_size) < 1 or not np.isfinite(a.atol) or a.atol < 0:
        p.error("Invalid sizes/tolerance")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(4)
    set_seed(0)
    device = choose_device(a.device)
    data = PreparedData(a.data_dir)
    ckpt = torch.load(a.checkpoint, map_location=device, weights_only=True)
    if ckpt.get("model_family") is not None:
        raise ValueError("Expected a frozen stage-1 checkpoint")
    if ckpt["data_fingerprint"] != data.fingerprint:
        raise ValueError("Checkpoint data fingerprint differs")
    original = {x["path"]: x["sha256"] for x in read_json(ROOT / "BASELINE_SOURCE_MANIFEST.json")["files"]}
    for name, digest in original.items():
        if name.startswith("src/") or name == "train.py":
            if ckpt["source_code"].get(name) != digest:
                raise ValueError(f"Not the frozen baseline source: {name}")
    if sha256(ROOT / "tests/fixtures/frozen_clean_model.py") != original["src/model.py"]:
        raise ValueError("Frozen reference model changed")
    reference = FrozenCleanCD(**ckpt["model_config"]).to(device)
    candidate = FactorialTimeCD(**ckpt["model_config"], time_mode="none", decay_rate_per_hour=0).to(device)
    reference.load_state_dict(ckpt["model_state"], strict=True)
    candidate.load_state_dict(ckpt["model_state"], strict=True)
    left_metrics, left, _ = evaluate(reference, data, device, a.view, a.batch_size, a.chunk_size, True)
    right_metrics, right, _ = evaluate(candidate, data, device, a.view, a.batch_size, a.chunk_size, True)
    if not np.array_equal(left.record_idx, right.record_idx):
        raise ValueError("Event identity mismatch")
    differences = {key: float(np.max(np.abs(left[key].to_numpy() - right[key].to_numpy())))
                   for key in ("probability", "uncertainty", "evidence")}
    success = all(np.isfinite(x) and x <= a.atol for x in differences.values())
    out = new_output_dir(a.output_dir)
    report = {"success": bool(success), "n": len(left), "atol": a.atol,
              "max_absolute_difference": differences, "reference": left_metrics, "none": right_metrics,
              "args": vars(a), "checkpoint_sha256": sha256(a.checkpoint),
              "data_fingerprint": data.fingerprint, "source_code": source_hashes()}
    write_json(out / "comparison.json", report)
    print(report)
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    main()
