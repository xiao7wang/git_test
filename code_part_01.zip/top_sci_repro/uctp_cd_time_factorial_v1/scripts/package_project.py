"""Package portable source/tests/docs only; no datasets, checkpoints or local venv."""
import argparse
import sys
import zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import ROOT, new_output_dir, write_json, sha256


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    files = [p for p in ROOT.iterdir() if p.is_file() and p.suffix in (".py", ".md", ".txt", ".json", ".sh")]
    files += [ROOT / ".gitignore"]
    for name in ("src", "scripts", "tests", "configs"):
        files += [p for p in (ROOT/name).rglob("*") if p.is_file() and p.suffix in (".py", ".json", ".md") and "__pycache__" not in p.parts]
    out = new_output_dir(a.output_dir)
    archive_path = out / "uctp_cd_time_factorial_v1.zip"
    with zipfile.ZipFile(archive_path, "x", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(files)):
            archive.write(path, "uctp_cd_time_factorial_v1/" + path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"ZIP integrity check failed: {bad}")
    write_json(out / "package_manifest.json", {"zip": archive_path.name, "sha256": sha256(archive_path),
               "files": {p.relative_to(ROOT).as_posix(): sha256(p) for p in sorted(set(files))}})
    print(archive_path)


if __name__ == "__main__":
    main()
