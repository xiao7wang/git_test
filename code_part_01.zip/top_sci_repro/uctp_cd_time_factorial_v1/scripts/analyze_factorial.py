"""Validation-only paired 2x2 contrasts; never reads test metrics."""
import argparse
import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.common import new_output_dir, read_json, write_json


MODES = ("none", "mean_only", "support_only", "joint")
METRICS = {"auc": 1.0, "nll": -1.0, "brier": -1.0}


def contrasts(values):
    """Positive values always favor the named factor; interaction is nonadditivity."""
    n, m, s, j = (values[mode] for mode in MODES)
    return {"mean_main": ((m - n) + (j - s)) / 2.0,
            "support_main": ((s - n) + (j - m)) / 2.0,
            "interaction": j - m - s + n,
            "joint_vs_none": j - n,
            "mean_only_vs_none": m - n,
            "support_only_vs_none": s - n}


def main():
    p = argparse.ArgumentParser(description="Paired validation contrasts for the 2x2 time experiment")
    p.add_argument("--run-root", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--expected-seeds", type=int, default=3)
    a = p.parse_args()
    if a.expected_seeds < 1:
        p.error("expected-seeds must be positive")
    root = Path(a.run_root)
    plan = read_json(root / "plan.json")
    if len(plan) != 4 * a.expected_seeds:
        raise ValueError("Plan must contain exactly four modes per seed for one writing rule")

    cells = {}
    shared = None
    positive_rates = set()
    for job in plan:
        name = job["name"]
        if Path(name).name != name:
            raise ValueError("Unsafe run name")
        folder = root / name
        status = read_json(folder / "status.json")
        if status.get("status") != "complete":
            raise ValueError(f"Incomplete run: {name}")
        config = read_json(folder / "run_config.json")
        if config.get("model_family") != "time_factorial_v1":
            raise ValueError(f"Wrong model family: {name}")
        args = config["args"]
        mode, seed = args["time_mode"], args["seed"]
        if mode not in MODES or (mode, seed) in cells:
            raise ValueError(f"Duplicate or unexpected cell: {name}")
        if args.get("evaluate_test") or status.get("test_evaluated"):
            raise ValueError("Development comparison must remain validation-only")
        signature = {
            "variant": args["variant"], "epochs": args["epochs"],
            "patience": args["patience"], "batch_size": args["batch_size"],
            "chunk_size": args["chunk_size"], "eval_chunk_size": args["eval_chunk_size"],
            "ncd_hidden_dim": args["ncd_hidden_dim"], "lr": args["lr"],
            "weight_decay": args["weight_decay"], "eval_update_targets": args["eval_update_targets"],
            "data_fingerprint": config["data_fingerprint"], "parameters": config["parameters"],
            "core_source": {k: v for k, v in config["source_code"].items()
                            if k.startswith("src/") or k == "train.py"},
        }
        if shared is None:
            shared = signature
        elif shared != signature:
            raise ValueError("Mixed writing rule, data, parameters, source or training budget")
        rate = float(args["decay_rate_per_hour"])
        if mode == "none":
            if rate != 0:
                raise ValueError("none must have zero time rate")
        elif rate <= 0:
            raise ValueError("Active time mode must have a positive rate")
        else:
            positive_rates.add(rate)
        metrics = read_json(folder / "validation_metrics.json")
        if any(metrics.get(metric) is None for metric in METRICS):
            raise ValueError(f"Missing validation metric in {name}")
        cells[(mode, seed)] = metrics
    if len(positive_rates) != 1:
        raise ValueError("Three active modes must share one fixed time rate")
    seeds = {seed for mode, seed in cells if mode == "none"}
    if len(seeds) != a.expected_seeds or any({s for mode, s in cells if mode == cell} != seeds
                                                  for cell in MODES):
        raise ValueError("All four modes require the same paired seeds")

    report = {"scope": "validation_only", "shared_protocol": shared,
              "active_decay_rate_per_hour": next(iter(positive_rates)),
              "seeds": sorted(seeds), "metrics": {},
              "note": "Seed SD is descriptive, not a student-cluster confidence interval or a significance test. Interaction is nonadditivity, not proof of a causal learning mechanism."}
    for metric, direction in METRICS.items():
        paired = []
        for seed in sorted(seeds):
            scores = {mode: direction * float(cells[(mode, seed)][metric]) for mode in MODES}
            paired.append({"seed": seed, "raw": {mode: cells[(mode, seed)][metric] for mode in MODES},
                           "contrast": contrasts(scores)})
        summary = {}
        for key in paired[0]["contrast"]:
            values = [row["contrast"][key] for row in paired]
            summary[key] = {"mean": statistics.mean(values),
                            "sample_sd": statistics.stdev(values) if len(values) > 1 else None}
        report["metrics"][metric] = {"positive_means_better": True,
                                      "paired_seed_rows": paired, "summary": summary}
    out = new_output_dir(a.output_dir)
    write_json(out / "factorial_validation.json", report)
    print(json.dumps({metric: value["summary"] for metric, value in report["metrics"].items()}, indent=2))


if __name__ == "__main__":
    main()
