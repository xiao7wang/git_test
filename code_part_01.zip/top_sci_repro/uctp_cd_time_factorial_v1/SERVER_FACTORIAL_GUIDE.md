# 四组时间作用实验：服务器第一阶段操作

这次是**新的独立工程** `uctp_cd_time_factorial_v1`。先做验收，不直接跑完整训练。旧项目、A0/A1/A2 和其 outputs 都不修改。新版本的 `joint` 含义与旧 temporal_v1 不同，不能将旧 checkpoint 当成新四组的一格。

## 1. 上传、核对、解压

把交付的 `uctp_cd_time_factorial_v1.zip` 上传到服务器：

`/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1.zip`

在服务器终端逐条执行（不要复制提示符；行尾 `\` 后不要有空格）：

```bash
cd /home/wangxiao/QCCDM/top_sci_repro
/home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -t uctp_cd_time_factorial_v1.zip
if [ -e uctp_cd_time_factorial_v1 ]; then
  echo '同名目录已存在，停止；勿覆盖旧版本或结果'
else
  /home/wangxiao/miniconda3/envs/yydw/bin/python -m zipfile -e uctp_cd_time_factorial_v1.zip .
fi
```

解压后应看到 `/home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1/run_stage1.sh`。如果同名目录已存在，先核对，不要删除或覆盖。服务器旧数据包应仍在 `uctp_cd_clean_research/data/{assist,ednet}_smoke`。

## 2. tmux 中一条命令做完第一阶段

已有同名 tmux 会话时用 `tmux attach -t time_factorial_01`，不要新建重复作业。首次运行：

```bash
tmux new -s time_factorial_01
```

进入 tmux 后执行：

```bash
cd /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
df -h .
nvidia-smi
CUDA_VISIBLE_DEVICES=0 bash run_stage1.sh server_stage1_01
```

本脚本按顺序运行：GPU 环境检查 → CPU/GPU 全部单元测试 → ASSIST/EDNet 旧 checkpoint 与新 `none` 桥接 → 两数据集各四组 `unit_write`、seed0、1 epoch smoke；全部默认 **validation-only**，不会访问 test 指标。每一步失败就停止并保留已有输出，不覆盖同名结果。半衰期统一 168 小时。若 GPU 0 不是分配给你的卡，先把命令中的 `0` 改为实际编号。

离开 tmux：`Ctrl+b`、松开、按 `d`。重新连接：`tmux attach -t time_factorial_01`。不要按 `Ctrl+c` 当作“复制”，它会中断当前作业。若只想复制文本，用 VS Code 的复制菜单或 `Ctrl+Shift+C`（依终端设置）。

如果脚本因旧 checkpoint 路径不存在而立刻退出，先提供 `server_assist_smoke_seed0/best_model.pt` 和 `server_ednet_smoke_seed0/best_model.pt` 的实际绝对路径；不要替换成不同预处理版本的 checkpoint。

## 3. 第二天检查

```bash
cd /home/wangxiao/QCCDM/top_sci_repro/uctp_cd_time_factorial_v1
ls -lh outputs/server_stage1_01
/home/wangxiao/miniconda3/envs/yydw/bin/python scripts/show_progress.py --run-root outputs/server_stage1_01/assist_smoke_matrix
/home/wangxiao/miniconda3/envs/yydw/bin/python scripts/show_progress.py --run-root outputs/server_stage1_01/ednet_smoke_matrix
```

**通过门槛**：CPU 和 GPU 的 `test_results.json` 均 `success=true` 且无失败/跳过；两个 bridge 的 `comparison.json` 均 `success=true` 且输出差≤`1e-6`；两套 smoke 各 `4/4 complete`，所有输出 finite、无 OOM。`none` 与旧基线等价不代表另外三组已有效；smoke AUC 不能当论文结论。

如果没有出现 `STAGE1_COMPLETE`，检查当前最后一条报错及对应 `.log`；旧结果保留。保存失败日志发给我，**不要**改容差、跳过断言或直接启动 full。若重跑，给 `run_stage1.sh` 一个新名字，例如 `server_stage1_02`，并先确认原作业没有仍在运行。

## 4. 暂不执行的后续 full 实验

验收通过后，我会根据这批日志确认是否进入 `assist_full`/`ednet_full` 各 `4模式×3 seeds`。正式实验上限预设 20 epochs、patience 5、同一个半衰期与训练预算，**只看 validation**。不会把 test 结果用于选择模式或时间尺度。正式命令待第一阶段验收后给出，以免服务器先跑长作业再发现实现或协议问题。
