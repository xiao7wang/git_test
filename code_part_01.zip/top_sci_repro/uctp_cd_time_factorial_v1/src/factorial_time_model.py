"""Four fixed-rate, per-KC time interventions on mastery mean and support.

This is a new experiment family, not a rename of temporal_v1's ``joint`` mode.
All four modes share the same learned prediction and writing parameters.  The
fixed half-life is a protocol choice, not a learned parameter.  The transition
occurs before prediction and never receives the current response.

The two factors are:
  mean:    m = alpha / (alpha + beta); elapsed time lowers m toward zero.
  support: S = alpha + beta; elapsed time lowers S toward its floor of two.

The state support is an operational pseudo-count, not calibrated predictive
confidence or a directly observed psychological mastery label.
"""
import math

import torch

from .temporal_model import BetaEvidence, Clock, TemporalCD, TemporalState


class FactorialTimeCD(TemporalCD):
    TIME_MODES = ("none", "mean_only", "support_only", "joint")

    def __init__(self, num_students, num_items, num_knowledges,
                 variant="unit_write", ncd_hidden_dim=128,
                 time_mode="none", decay_rate_per_hour=0.0):
        rate = float(decay_rate_per_hour)
        if time_mode not in self.TIME_MODES or not math.isfinite(rate) or rate < 0:
            raise ValueError("Invalid factorial time mode or finite nonnegative rate")
        if time_mode == "none" and rate != 0:
            raise ValueError("none requires decay_rate_per_hour=0")
        if variant == "static" and time_mode != "none":
            raise ValueError("Temporal interventions require a dynamic writing rule")
        # Initialize the unchanged prediction head.  Passing none/zero avoids
        # accidentally invoking the archived temporal_v1 transition.
        super().__init__(num_students, num_items, num_knowledges,
                         variant=variant, ncd_hidden_dim=ncd_hidden_dim,
                         time_mode="none", decay_rate_per_hour=0.0)
        self.time_mode = time_mode
        self.decay_rate_per_hour = rate
        # Zero-rate and none retain the exact baseline P/N arithmetic.
        self.mass_representation = time_mode != "none" and rate > 0

    def _advance_time_unchecked(self, state, q, timestamp, active_mask):
        if not self.mass_representation:
            return super()._advance_time_unchecked(state, q, timestamp, active_mask)

        clock, evidence = state.clock, state.evidence
        if not isinstance(evidence, BetaEvidence):
            raise TypeError("Active factorial transition requires BetaEvidence")
        now = torch.where(active_mask, timestamp, clock.last_event_seconds)
        selected = active_mask[:, None] & (q > 0)
        elapsed = torch.where(selected & clock.seen_kc,
                              (now[:, None] - clock.last_kc_seconds) / 3600.0, 0.0)
        support = evidence.alpha + evidence.beta
        # A prior-only KC has no observed cognitive evidence to age.  A query
        # without visible feedback still advances its clock, as in temporal_v1.
        changed = selected & clock.seen_kc & (elapsed > 0) & (support > 2.0)
        decay = torch.exp(-self.decay_rate_per_hour * elapsed).to(evidence.alpha.dtype)

        mean = evidence.alpha / support
        next_mean = mean * decay if self.time_mode in ("mean_only", "joint") else mean
        next_support = (2.0 + (support - 2.0) * decay
                        if self.time_mode in ("support_only", "joint") else support)
        if self.time_mode == "support_only":
            # Match temporal_v1 mass's ratio-preserving operation; do not
            # clamp alpha/beta to one or reinterpret them as nonnegative P/N.
            factor = next_support / support
            next_alpha, next_beta = evidence.alpha * factor, evidence.beta * factor
        else:
            next_alpha = next_mean * next_support
            next_beta = (1.0 - next_mean) * next_support
        next_evidence = BetaEvidence(
            torch.where(changed, next_alpha, evidence.alpha),
            torch.where(changed, next_beta, evidence.beta))
        next_clock = Clock(
            torch.where(selected, now[:, None], clock.last_kc_seconds),
            clock.seen_kc | selected, now, clock.seen_event | active_mask)
        return TemporalState(next_evidence, next_clock)
