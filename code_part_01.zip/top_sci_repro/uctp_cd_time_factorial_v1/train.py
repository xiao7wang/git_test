import argparse
import json
import math
import os
import platform
import random
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from src.common import new_output_dir, write_json, source_hashes, sha256
from src.data import PreparedData
from src.model import CleanCD
from src.factorial_time_model import FactorialTimeCD
from src.engine import train_epoch, evaluate


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)


def choose_device(name):
    if name == "auto":
        name = "cuda" if torch.cuda.is_available() else "cpu"
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable. Run scripts/check_environment.py --device cuda")
    return torch.device(name)


def main():
    p = argparse.ArgumentParser(description="Mean/support factorial time experiment; validation-only by default")
    p.add_argument("--data-dir", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--variant", choices=CleanCD.VARIANTS, default="unit_write")
    p.add_argument("--time-mode", choices=FactorialTimeCD.TIME_MODES, default="none")
    rate_group = p.add_mutually_exclusive_group()
    rate_group.add_argument("--half-life-hours", type=float)
    rate_group.add_argument("--decay-rate-per-hour", type=float)
    p.add_argument("--ack-time-proxy", action="store_true",
                   help="Acknowledge event timestamps are proxies, not verified feedback times")
    p.add_argument("--evaluate-test", action="store_true",
                   help="Explicit final/smoke test evaluation; do not use for model selection")
    p.add_argument("--epochs", type=int, default=5)
    p.add_argument("--batch-size", type=int, default=8)
    p.add_argument("--chunk-size", type=int, default=50)
    p.add_argument("--eval-chunk-size", type=int, default=100)
    p.add_argument("--ncd-hidden-dim", type=int, default=128)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--weight-decay", type=float, default=1e-5)
    p.add_argument("--patience", type=int, default=5)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--device", choices=("auto", "cpu", "cuda"), default="auto")
    p.add_argument("--threads", type=int, default=4)
    p.add_argument("--ack-row-feedback", action="store_true", help="Acknowledge unverified immediate-feedback assumption")
    p.add_argument("--eval-update-targets", type=int, choices=(0, 1), default=1)
    args = p.parse_args()
    if min(args.epochs, args.batch_size, args.chunk_size, args.eval_chunk_size, args.patience, args.threads) < 1 or args.lr <= 0 or args.weight_decay < 0:
        p.error("Invalid positive hyperparameter")
    if not args.ack_row_feedback:
        p.error("Add --ack-row-feedback only after reading SERVER_FACTORIAL_GUIDE.md. True feedback boundaries are unverified.")
    if args.half_life_hours is not None:
        if not math.isfinite(args.half_life_hours) or args.half_life_hours <= 0:
            p.error("half-life-hours must be finite and positive")
        args.decay_rate_per_hour = math.log(2.0) / args.half_life_hours
    elif args.decay_rate_per_hour is None:
        args.decay_rate_per_hour = 0.0 if args.time_mode == "none" else math.log(2.0) / 168.0
    if not math.isfinite(args.decay_rate_per_hour) or args.decay_rate_per_hour < 0:
        p.error("decay-rate-per-hour must be finite and nonnegative")
    if args.time_mode == "none" and args.decay_rate_per_hour != 0:
        p.error("none mode requires zero decay; omit half-life-hours")
    if args.variant == "static" and args.time_mode != "none":
        p.error("static supports only none mode")
    if args.time_mode != "none" and not args.ack_time_proxy:
        p.error("--ack-time-proxy required for temporal interventions")
    if Path(args.output_dir).resolve().exists():
        raise FileExistsError("Output already exists: choose a new run name, never overwrite old results")
    os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    torch.set_num_threads(args.threads)
    set_seed(args.seed)
    device = choose_device(args.device)
    data = PreparedData(args.data_dir)
    summary = data.manifest["summary"]
    model_config = {"num_students": summary["students"], "num_items": summary["items"],
                    "num_knowledges": summary["knowledges"], "variant": args.variant,
                    "ncd_hidden_dim": args.ncd_hidden_dim, "time_mode": args.time_mode,
                    "decay_rate_per_hour": args.decay_rate_per_hour}
    model = FactorialTimeCD(**model_config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    out = new_output_dir(args.output_dir)
    config = {"model_family": "time_factorial_v1", "args": vars(args), "model_config": model_config, "data_fingerprint": data.fingerprint,
              "data_manifest": data.manifest, "source_code": source_hashes(),
              "environment": {"python": platform.python_version(), "torch": str(torch.__version__),
                              "numpy": np.__version__, "pandas": pd.__version__, "cuda": torch.version.cuda,
                              "device": str(device), "gpu": torch.cuda.get_device_name(device) if device.type == "cuda" else None},
              "selection": "validation AUC; negative NLL if validation has only one label class",
              "parameters": sum(x.numel() for x in model.parameters()),
              "protocol": "offline parameters; row-immediate feedback assumption; test includes train+valid history",
              "temporal_protocol": {"event_time_proxy": True, "feedback_boundaries_verified": False,
                                    "per_kc_lazy_clock": True, "forecast_before_prediction": True,
                                    "shared_fixed_half_life_for_both_factors": True,
                                    "mean_decay_target": 0.0, "support_floor": 2.0,
                                    "rate_learned": False, "time_advances_when_target_writes_disabled": True},
              "test_policy": "explicit opt-in" if args.evaluate_test else "not evaluated"}
    write_json(out / "run_config.json", config)
    write_json(out / "status.json", {"status": "running"})
    history, best, stale, best_epoch = [], -float("inf"), 0, None
    print(json.dumps({"device": str(device), "variant": args.variant, "time_mode": args.time_mode,
                      "decay_rate_per_hour": args.decay_rate_per_hour, **summary}), flush=True)
    print("WARNING: row-immediate feedback assumption; NOT verified real bundle feedback causality.", flush=True)
    try:
        for epoch in range(1, args.epochs+1):
            print(f"epoch={epoch} phase=train", flush=True)
            stats = train_epoch(model, data, optimizer, device, args.batch_size, args.chunk_size, args.seed+epoch)
            print(f"epoch={epoch} phase=validation (history replay; may be silent)", flush=True)
            valid, _, _ = evaluate(model, data, device, "valid", args.batch_size, args.eval_chunk_size, bool(args.eval_update_targets))
            history.append({"epoch": epoch, "train": stats, "valid": valid})
            write_json(out / "history.json", history)
            score = valid["auc"] if valid["auc"] is not None else -valid["nll"]
            print(f"epoch={epoch} train_bce={stats['bce']:.6f} valid_auc={valid['auc']} valid_nll={valid['nll']:.6f}", flush=True)
            if score > best:
                best, stale, best_epoch = score, 0, epoch
                checkpoint = {"model_family": "time_factorial_v1", "model_state": model.state_dict(), "optimizer_state": optimizer.state_dict(),
                              "model_config": model_config, "epoch": epoch, "selection_score": score,
                              "data_fingerprint": data.fingerprint, "source_code": config["source_code"],
                              "torch_rng": torch.get_rng_state(), "python_rng": random.getstate(),
                              "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else []}
                temporary = out / "best_model.pending.pt"
                torch.save(checkpoint, temporary)
                temporary.replace(out / "best_model.pt")
            else:
                stale += 1
            if stale >= args.patience:
                break
        if best_epoch is None:
            raise RuntimeError("No valid checkpoint selected")
        ckpt = torch.load(out / "best_model.pt", map_location=device, weights_only=True)
        model.load_state_dict(ckpt["model_state"], strict=True)
        print("phase=best_checkpoint_validation", flush=True)
        valid, predictions, groups = evaluate(model, data, device, "valid", args.batch_size,
                                              args.eval_chunk_size, bool(args.eval_update_targets))
        predictions.to_csv(out / "validation_predictions.csv", index=False)
        write_json(out / "validation_metrics.json", valid)
        write_json(out / "validation_subgroup_metrics.json", groups)
        test = None
        if args.evaluate_test:
            print("phase=final_test", flush=True)
            test, predictions, groups = evaluate(model, data, device, "test", args.batch_size,
                                                 args.eval_chunk_size, bool(args.eval_update_targets))
            predictions.to_csv(out / "test_predictions.csv", index=False)
            write_json(out / "test_metrics.json", test)
            write_json(out / "subgroup_metrics.json", groups)
        write_json(out / "status.json", {"status": "complete", "best_epoch": best_epoch,
                   "test_evaluated": args.evaluate_test,
                   "checkpoint_sha256": sha256(out / "best_model.pt"), "finished_unix": time.time()})
        print(json.dumps({"best_epoch": best_epoch, "validation": valid, "test": test}, indent=2), flush=True)
    except BaseException as exc:
        write_json(out / "status.json", {"status": "failed", "error": repr(exc), "best_epoch": best_epoch})
        raise


if __name__ == "__main__":
    main()
