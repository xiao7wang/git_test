from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=str, default="synthetic_data")
    parser.add_argument("--students", type=int, default=80)
    parser.add_argument("--items", type=int, default=100)
    parser.add_argument("--knowledges", type=int, default=12)
    parser.add_argument("--interactions", type=int, default=60)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    rng = np.random.default_rng(args.seed)
    item_kc = rng.integers(0, args.knowledges, size=args.items)
    item_diff = rng.normal(0.0, 0.7, size=args.items)
    rows = []
    for student in range(args.students):
        mastery = rng.normal(0.0, 0.6, size=args.knowledges)
        speed = rng.normal(0.0, 0.25)
        timestamp = 1_700_000_000 + int(rng.integers(0, 200_000))
        for index in range(args.interactions):
            item = int(rng.integers(0, args.items))
            kc = int(item_kc[item])
            gap = int(max(20, np.exp(rng.normal(np.log(1800), 1.1))))
            timestamp += gap
            probability = 1.0 / (1.0 + np.exp(-(mastery[kc] - item_diff[item])))
            correct = int(rng.random() < probability)
            expected_rt = max(5.0, 30.0 + 15.0 * item_diff[item])
            response_time = float(np.exp(np.log(expected_rt) + speed + rng.normal(0.0, 0.35)))
            mastery[kc] += 0.04 * (1.0 - probability)
            split = "train" if index < int(0.7 * args.interactions) else "valid" if index < int(0.8 * args.interactions) else "test"
            rows.append(
                {
                    "student_id": student,
                    "item_id": item,
                    "knowledge_ids": kc,
                    "correct": correct,
                    "timestamp": timestamp,
                    "response_time": response_time,
                    "split": split,
                }
            )
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(output / "all_with_split.csv", index=False)
    print(output / "all_with_split.csv")


if __name__ == "__main__":
    main()
