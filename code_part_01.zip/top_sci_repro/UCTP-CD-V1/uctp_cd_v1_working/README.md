# UCTP-CD V1 Working Code

This first working version implements only the two contributions requested by the supervisor:

1. **Innovation 1**: real-time-evidence-driven dynamic knowledge-state update.
2. **Innovation 3**: joint mastery and diagnostic-uncertainty output/calibration.

The directed prerequisite graph is intentionally excluded from V1. This keeps the first experiment interpretable: any change comes from the temporal/evidential chain rather than graph quality.

## 1. Implemented modules

- Existing train/valid/test split is preserved; no random re-splitting.
- Overall time gap and same-KC time gap.
- Train-only student/item RT residual statistics.
- Reliability gate using answer, RT residual, time gaps, item difficulty, history count, short/long rate, and prior uncertainty.
- Dual-timescale positive/negative evidence memory.
- Beta evidence mastery and uncertainty.
- Uncertainty-gated dynamic residual over a static NeuralCD baseline.
- Monotonic NeuralCD head.
- BCE, Brier, evidence penalty, and uncertainty calibration losses.
- AUC, ACC, F1, RMSE, NLL, Brier, ECE, and long-tail subgroup metrics.
- Online or frozen target-state evaluation.

## 2. Important model variants

- `baseline`: static NeuralCD reference implementation in this repository.
- `time`: innovation 1 only; temporal/reliability/dual-timescale modules are enabled.
- `time_unc`: innovation 1 + innovation 3; uncertainty gate and calibration losses are enabled.

The `baseline` is an internal reference baseline. It is not guaranteed to reproduce a different existing repository's NeuralCD implementation exactly. Compare it with the user's existing baseline results, and later integrate the modules into that repository for the final paper experiment.

## 3. Install

Install base packages:

```bash
python -m pip install -r requirements.txt
```

Install PyTorch separately using the build matching the server and RTX 5090 driver/CUDA environment. Verify:

```bash
python -c "import torch; print(torch.__version__); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"
```

## 4. Synthetic smoke test

```bash
python generate_synthetic.py --output-dir synthetic_data

python train_v1.py \
  --config configs/generic.json \
  --data synthetic_data/all_with_split.csv \
  --variant time_unc \
  --output-dir outputs/smoke \
  --epochs 2 \
  --batch-size 8 \
  --bptt-steps 50 \
  --device auto
```

## 5. Use the existing split files

If the dataset is already split into three files:

```bash
python train_v1.py \
  --config configs/assistments_time_example.json \
  --train /path/train.csv \
  --valid /path/valid.csv \
  --test /path/test.csv \
  --variant time_unc \
  --output-dir outputs/assist_time_unc/seed_42 \
  --epochs 20 \
  --batch-size 8 \
  --bptt-steps 100 \
  --seed 42 \
  --device cuda
```

If a single CSV already has a split column:

```bash
python train_v1.py \
  --config configs/generic.json \
  --data /path/all_with_split.csv \
  --variant time_unc \
  --output-dir outputs/time_unc/seed_42 \
  --device cuda
```

## 6. First experiment order

Run the three versions with exactly the same data and seed:

```bash
bash scripts/run_three_variants.sh \
  configs/generic.json \
  /path/all_with_split.csv \
  outputs/ablation \
  42
```

Then compare:

- `outputs/ablation/baseline/seed_42/test_metrics.json`
- `outputs/ablation/time/seed_42/test_metrics.json`
- `outputs/ablation/time_unc/seed_42/test_metrics.json`

Run seed 0 first for screening. After the implementation is stable, run five fixed seeds.

## 7. Column configuration

Edit a JSON config rather than editing code. For ASSISTments-like files, the example uses:

- `user_id`
- `problem_id`
- `skill_id`
- `correct`
- `start_time`
- `ms_first_response`

These names must be checked against the actual CSV. The code will fail with a clear list of available columns if a name is wrong.

`timestamp_unit` supports `auto`, `s`, `ms`, `us`, `ns`, and `datetime`.

`response_time_unit` supports `auto`, `s`, and `ms`.

## 8. Evaluation protocol

By default, validation/test use online sequential evaluation:

1. predict the current interaction from past state;
2. observe its label/RT;
3. update state for the next interaction.

This does not use the current label to predict the current interaction. To prohibit updates on validation/test labels entirely:

```bash
--eval-update-targets 0
```

Report which protocol is used in the paper.

## 9. Output files

- `best_model.pt`
- `history.csv`
- `best_valid_predictions.csv`
- `test_predictions.csv`
- `test_metrics.json`
- `long_tail_metrics.json`
- `run_config.json`
- `metadata.json`
- `processed_data.pkl`

Inspect `test_predictions.csv` for reliability, uncertainty, evidence, RT residual, time gaps, and timescale gate.

## 10. First-pass success criteria

Do not require uncertainty to increase AUC substantially. A reasonable first-pass result is:

- `time` improves AUC/ACC over `baseline`;
- `time_unc` keeps similar or better AUC while improving Brier/ECE/NLL;
- improvement is larger in low-interaction groups;
- reliability and uncertainty are not constant or collapsed.
