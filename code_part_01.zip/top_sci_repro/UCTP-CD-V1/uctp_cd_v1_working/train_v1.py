from __future__ import annotations

import argparse
import json
import math
import os
import random
import sys
from dataclasses import asdict
from functools import partial
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))

from uctp_v1.data import (  # noqa: E402
    DataConfig,
    PreparedData,
    StudentSequenceDataset,
    collate_student_sequences,
    prepare_data,
)
from uctp_v1.metrics import compute_metrics, subgroup_metrics  # noqa: E402
from uctp_v1.model import UCTPCDV1, UCTPState  # noqa: E402


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def move_batch(batch: Dict[str, torch.Tensor], device: torch.device) -> Dict[str, torch.Tensor]:
    return {key: value.to(device, non_blocking=True) for key, value in batch.items()}


def variant_flags(
    variant: str,
) -> Dict[str, bool | float]:
    variants = {
        "baseline": {
            "use_dynamic": False,
            "use_time": False,
            "use_rt": False,
            "use_reliability": False,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False, 
        },
        "dynamic_only": {
            "use_dynamic": True,
            "use_time": False,
            "use_rt": False,
            "use_reliability": False,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_predecay_v2": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": False,
            "use_reliability": False,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
            "use_predict_time_decay_v2": True,
        },
        "dynamic_timegap": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": False,
            "use_reliability": False,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": False,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel_interact_v2": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": False,
            "use_prediction_surprise": False,
            "use_concept_adaptive_decay": False,
            "use_interaction_residual_v2": True,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel_kcdecay": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": False,
            "use_prediction_surprise": False,
            "use_concept_adaptive_decay": True,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel_surprise": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": False,
            "use_prediction_surprise": True,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel_dual_v7_asym": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_selective_consolidation_v3": False,
            "use_uncertainty_gate": False,
            "use_monotonic_dual_v4": False,
            "use_anchor_dual_v5": True,
            "use_bounded_dual_v6": True,
            "use_asymmetric_dual_v7": True,
            "anchor_dual_residual_cap": 0.10,
            "bounded_dual_v6_max_ratio": 8.0,
        },
        "dynamic_timegap_rt_rel_dual_v6_bounded": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_selective_consolidation_v3": False,
            "use_uncertainty_gate": False,
            "use_monotonic_dual_v4": False,
            "use_anchor_dual_v5": True,
            "use_bounded_dual_v6": True,
            "anchor_dual_residual_cap": 0.10,
            "bounded_dual_v6_max_ratio": 8.0,
        },
        "dynamic_timegap_rt_rel_dual_v5_cap10": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_selective_consolidation_v3": False,
            "use_uncertainty_gate": False,
            "use_monotonic_dual_v4": False,
            "use_anchor_dual_v5": True,
            "anchor_dual_residual_cap": 0.10,
        },
        "dynamic_timegap_rt_rel_dual_v5": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_selective_consolidation_v3": False,
            "use_uncertainty_gate": False,
            "use_monotonic_dual_v4": False,
            "use_anchor_dual_v5": True,
        },
        "dynamic_timegap_rt_rel_dual_v4": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_selective_consolidation_v3": False,
            "use_uncertainty_gate": False,
            "use_monotonic_dual_v4": True,
        },
        "dynamic_timegap_rt_rel_dual_v3": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_prediction_surprise": False,
            "use_concept_adaptive_decay": False,
            "use_interaction_residual_v2": False,
            "use_selective_consolidation_v3": True,
            "use_uncertainty_gate": False,
        },
        "dynamic_timegap_rt_rel_unc_update_v2": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": False,
            "use_uncertainty_gate": False,
            "use_uncertainty_update_v2": True,
        },
        "time": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_uncertainty_gate": False,
        },
        "time_unc": {
            "use_dynamic": True,
            "use_time": True,
            "use_rt": True,
            "use_reliability": True,
            "use_dual_timescale": True,
            "use_uncertainty_gate": True,
        },
    }
    if variant not in variants:
        raise ValueError(f"Unknown variant: {variant}")
    return variants[variant]


def build_loaders(prepared: PreparedData, batch_size: int, num_workers: int):
    collate = partial(collate_student_sequences, num_knowledges=prepared.num_knowledges)
    datasets = {
        name: StudentSequenceDataset(prepared, name)
        for name in ["train", "valid", "test"]
    }
    loaders = {
        "train": DataLoader(
            datasets["train"],
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=True,
            collate_fn=collate,
        ),
        "valid": DataLoader(
            datasets["valid"],
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
            collate_fn=collate,
        ),
        "test": DataLoader(
            datasets["test"],
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True,
            collate_fn=collate,
        ),
    }
    return datasets, loaders


def chunk_slices(total_steps: int, bptt_steps: int):
    for start in range(0, total_steps, bptt_steps):
        yield start, min(total_steps, start + bptt_steps)


def masked_losses(
    outputs: Dict[str, torch.Tensor],
    label: torch.Tensor,
    target_mask: torch.Tensor,
    brier_weight: float,
    evidence_weight: float,
    uncertainty_weight: float,
) -> Tuple[torch.Tensor, Dict[str, float]]:
    mask = target_mask
    if not mask.any():
        zero = outputs["probability"].sum() * 0.0
        return zero, {"bce": 0.0, "brier": 0.0, "evidence": 0.0, "uncertainty": 0.0}

    prob = outputs["probability"][mask].clamp(1e-6, 1.0 - 1e-6)
    y = label[mask]
    uncertainty = outputs["uncertainty"][mask]
    evidence = outputs["evidence"][mask]

    bce = F.binary_cross_entropy(prob, y)

    control_bce = None
    if "control_probability" in outputs:
        control_prob = outputs["control_probability"][mask].clamp(
            1e-6,
            1.0 - 1e-6,
        )
        control_bce = F.binary_cross_entropy(
            control_prob,
            y,
        )

    brier = ((prob - y) ** 2).mean()
    error_detached = (prob - y).abs().detach()
    evidence_penalty = (error_detached * evidence).mean()
    uncertainty_target = error_detached
    uncertainty_loss = F.mse_loss(uncertainty, uncertainty_target)
    total = bce + brier_weight * brier + evidence_weight * evidence_penalty + uncertainty_weight * uncertainty_loss
    if control_bce is not None:
        total = total + control_bce
    return total, {
        "bce": float(bce.detach().cpu()),
        "brier": float(brier.detach().cpu()),
        "evidence": float(evidence_penalty.detach().cpu()),
        "uncertainty": float(uncertainty_loss.detach().cpu()),
    }


def train_epoch(
    model: UCTPCDV1,
    loader: DataLoader,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    bptt_steps: int,
    brier_weight: float,
    evidence_weight: float,
    uncertainty_weight: float,
    grad_clip: float,
) -> Dict[str, float]:
    model.train()
    losses: List[float] = []
    component_accumulator: Dict[str, List[float]] = {k: [] for k in ["bce", "brier", "evidence", "uncertainty"]}

    for batch in loader:
        batch = move_batch(batch, device)
        batch_size, total_steps = batch["item_idx"].shape
        state = model.init_state(batch_size, device)

        for start, end in chunk_slices(total_steps, bptt_steps):
            optimizer.zero_grad(set_to_none=True)
            outputs, state = model.forward_chunk(
                state=state,
                student_idx=batch["student_idx"],
                item_idx=batch["item_idx"][:, start:end],
                q=batch["q"][:, start:end],
                label=batch["label"][:, start:end],
                rt_residual=batch["rt_residual"][:, start:end],
                delta_t_hours=batch["delta_t_hours"][:, start:end],
                delta_t_k_hours=batch["delta_t_k_hours"][:, start:end],
                kc_count_before=batch["kc_count_before"][:, start:end],
                active_mask=batch["active_mask"][:, start:end],
                update_mask=batch["active_mask"][:, start:end],
            )
            loss, components = masked_losses(
                outputs,
                batch["label"][:, start:end],
                batch["target_mask"][:, start:end],
                brier_weight,
                evidence_weight,
                uncertainty_weight,
            )
            if batch["target_mask"][:, start:end].any():
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
                optimizer.step()
                losses.append(float(loss.detach().cpu()))
                for key, value in components.items():
                    component_accumulator[key].append(value)
            state = state.detach()

    result = {"loss": float(np.mean(losses)) if losses else float("nan")}
    result.update({key: float(np.mean(values)) if values else float("nan") for key, values in component_accumulator.items()})
    return result


@torch.no_grad()
def evaluate(
    model: UCTPCDV1,
    loader: DataLoader,
    device: torch.device,
    update_targets: bool,
) -> Tuple[Dict[str, float], pd.DataFrame]:
    model.eval()
    rows: List[Dict[str, float]] = []

    for batch in loader:
        batch = move_batch(batch, device)
        batch_size, total_steps = batch["item_idx"].shape
        state = model.init_state(batch_size, device)

        # Context rows always update. Target rows update only in online mode.
        update_mask = batch["active_mask"] & (~batch["target_mask"] | update_targets)
        outputs, _ = model.forward_chunk(
            state=state,
            student_idx=batch["student_idx"],
            item_idx=batch["item_idx"],
            q=batch["q"],
            label=batch["label"],
            rt_residual=batch["rt_residual"],
            delta_t_hours=batch["delta_t_hours"],
            delta_t_k_hours=batch["delta_t_k_hours"],
            kc_count_before=batch["kc_count_before"],
            active_mask=batch["active_mask"],
            update_mask=update_mask,
        )

        target_positions = batch["target_mask"].nonzero(as_tuple=False)
        for b, t in target_positions.tolist():
            rows.append(
                {
                    "student_idx": int(batch["student_idx"][b].cpu()),
                    "item_idx": int(batch["item_idx"][b, t].cpu()),
                    "label": float(batch["label"][b, t].cpu()),
                    "probability": float(outputs["probability"][b, t].cpu()),
                    "uncertainty": float(outputs["uncertainty"][b, t].cpu()),
                    "evidence": float(outputs["evidence"][b, t].cpu()),
                    "reliability": float(outputs["reliability"][b, t].cpu()),
                    "timescale_gate": float(outputs["timescale_gate"][b, t].cpu()),
                    "rt_residual": float(batch["rt_residual"][b, t].cpu()),
                    "delta_t_hours": float(batch["delta_t_hours"][b, t].cpu()),
                    "delta_t_k_hours": float(batch["delta_t_k_hours"][b, t].cpu()),
                    "student_count_before": int(batch["student_count_before"][b, t].cpu()),
                    "train_interaction_count": int(batch["train_interaction_count"][b, t].cpu()),
                }
            )

    frame = pd.DataFrame(rows)
    metrics = compute_metrics(frame["label"], frame["probability"]) if len(frame) else compute_metrics([], [])
    return metrics, frame


def save_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="UCTP-CD V1: innovation 1 + innovation 3")
    parser.add_argument("--config", type=str, required=True, help="JSON data-column configuration")
    parser.add_argument("--data", type=str, default=None, help="Single CSV with split column")
    parser.add_argument("--train", type=str, default=None)
    parser.add_argument("--valid", type=str, default=None)
    parser.add_argument("--test", type=str, default=None)
    parser.add_argument("--variant", choices=["baseline", "dynamic_only", "dynamic_timegap", "dynamic_timegap_predecay_v2", "dynamic_timegap_rt", "dynamic_timegap_rt_rel", "dynamic_timegap_rt_rel_interact_v2", "dynamic_timegap_rt_rel_kcdecay", "dynamic_timegap_rt_rel_surprise", "dynamic_timegap_rt_rel_dual_v3", "dynamic_timegap_rt_rel_dual_v4", "dynamic_timegap_rt_rel_dual_v5", "dynamic_timegap_rt_rel_dual_v5_cap10", "dynamic_timegap_rt_rel_dual_v6_bounded", "dynamic_timegap_rt_rel_dual_v7_asym", "dynamic_timegap_rt_rel_unc_update_v2", "time", "time_unc"], default="time_unc")
    parser.add_argument("--output-dir", type=str, required=True)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--bptt-steps", type=int, default=100)
    parser.add_argument("--hidden-dim", type=int, default=64)
    parser.add_argument("--ncd-hidden-dim", type=int, default=128)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-5)
    parser.add_argument("--grad-clip", type=float, default=5.0)
    parser.add_argument("--brier-weight", type=float, default=None)
    parser.add_argument("--evidence-weight", type=float, default=None)
    parser.add_argument("--uncertainty-weight", type=float, default=None)
    parser.add_argument("--patience", type=int, default=5)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--eval-update-targets", type=int, choices=[0, 1], default=1)
    parser.add_argument("--device", choices=["auto", "cpu", "cuda"], default="auto")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    set_seed(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    config = DataConfig.from_json(args.config)
    prepared = prepare_data(
        config,
        train_path=args.train,
        valid_path=args.valid,
        test_path=args.test,
        data_path=args.data,
    )
    prepared.save_metadata(output_dir)
    prepared.frame.to_pickle(output_dir / "processed_data.pkl")

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but torch.cuda.is_available() is False")

    _, loaders = build_loaders(prepared, args.batch_size, args.num_workers)
    flags = variant_flags(args.variant)
    model = UCTPCDV1(
        num_students=prepared.num_students,
        num_items=prepared.num_items,
        num_knowledges=prepared.num_knowledges,
        hidden_dim=args.hidden_dim,
        ncd_hidden_dim=args.ncd_hidden_dim,
        **flags,
    ).to(device)

    # Innovation 3 losses are enabled by default only for time_unc.
    brier_weight = args.brier_weight if args.brier_weight is not None else (0.1 if args.variant == "time_unc" else 0.0)
    evidence_weight = args.evidence_weight if args.evidence_weight is not None else (0.005 if args.variant == "time_unc" else 0.0)
    uncertainty_weight = args.uncertainty_weight if args.uncertainty_weight is not None else (0.05 if args.variant == "time_unc" else 0.0)

    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    best_auc = -math.inf
    patience_left = args.patience
    best_path = output_dir / "best_model.pt"
    history: List[Dict[str, float]] = []

    print(
        f"device={device} variant={args.variant} students={prepared.num_students} "
        f"items={prepared.num_items} knowledges={prepared.num_knowledges} interactions={len(prepared.frame)}"
    )

    for epoch in range(1, args.epochs + 1):
        train_stats = train_epoch(
            model,
            loaders["train"],
            optimizer,
            device,
            args.bptt_steps,
            brier_weight,
            evidence_weight,
            uncertainty_weight,
            args.grad_clip,
        )
        valid_metrics, valid_predictions = evaluate(
            model,
            loaders["valid"],
            device,
            bool(args.eval_update_targets),
        )
        row = {"epoch": epoch, **{f"train_{k}": v for k, v in train_stats.items()}, **{f"valid_{k}": v for k, v in valid_metrics.items()}}
        history.append(row)
        print(
            f"epoch={epoch:03d} loss={train_stats['loss']:.5f} "
            f"valid_auc={valid_metrics['auc']:.5f} valid_acc={valid_metrics['acc']:.5f} "
            f"valid_brier={valid_metrics['brier']:.5f} valid_ece={valid_metrics['ece']:.5f}"
        )

        auc = valid_metrics["auc"]
        score = auc if np.isfinite(auc) else -math.inf
        if score > best_auc:
            best_auc = score
            patience_left = args.patience
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "args": vars(args),
                    "flags": flags,
                    "num_students": prepared.num_students,
                    "num_items": prepared.num_items,
                    "num_knowledges": prepared.num_knowledges,
                },
                best_path,
            )
            valid_predictions.to_csv(output_dir / "best_valid_predictions.csv", index=False)
        else:
            patience_left -= 1
            if patience_left <= 0:
                print("early stopping")
                break

    pd.DataFrame(history).to_csv(output_dir / "history.csv", index=False)
    checkpoint = torch.load(best_path, map_location=device)
    model.load_state_dict(checkpoint["model_state"])

    test_metrics, test_predictions = evaluate(
        model,
        loaders["test"],
        device,
        bool(args.eval_update_targets),
    )
    long_tail = subgroup_metrics(test_predictions)
    test_predictions.to_csv(output_dir / "test_predictions.csv", index=False)
    save_json(output_dir / "test_metrics.json", test_metrics)
    save_json(output_dir / "long_tail_metrics.json", long_tail)
    save_json(
        output_dir / "run_config.json",
        {
            "args": vars(args),
            "flags": flags,
            "loss_weights": {
                "brier": brier_weight,
                "evidence": evidence_weight,
                "uncertainty": uncertainty_weight,
            },
            "device": str(device),
            "lambda_short": float(model.lambda_short.detach().cpu()),
            "lambda_long": float(model.lambda_long.detach().cpu()),
            "dynamic_scale": float(model.dynamic_scale.detach().cpu()),
            "anchor_dual_residual_cap": float(
                model.anchor_dual_residual_cap
            ),
            "dual_v5_residual_alpha": (
                float(
                    (
                        model.anchor_dual_residual_cap
                        * torch.tanh(
                            model.dual_v5_residual_scale_raw
                        )
                    ).detach().cpu()
                )
                if hasattr(
                    model,
                    "dual_v5_residual_scale_raw",
                )
                else 0.0
            ),
            "bounded_dual_v6_max_ratio": float(
                model.bounded_dual_v6_max_ratio
            ),
            "dual_v6_short_ratio": (
                float(
                    model.dual_v6_short_ratio.detach().cpu()
                )
                if hasattr(model, "raw_dual_v6_short_ratio")
                else 0.0
            ),
            "dual_v6_lambda_short": (
                float(
                    model.dual_v6_lambda_short.detach().cpu()
                )
                if hasattr(model, "raw_dual_v6_short_ratio")
                else 0.0
            ),
            "dual_v7_positive_ratio": (
                float(
                    model.dual_v7_positive_ratio.detach().cpu()
                )
                if hasattr(
                    model,
                    "raw_dual_v7_negative_ratio",
                )
                else 0.0
            ),
            "dual_v7_negative_ratio": (
                float(
                    model.dual_v7_negative_ratio.detach().cpu()
                )
                if hasattr(
                    model,
                    "raw_dual_v7_negative_ratio",
                )
                else 0.0
            ),
            "dual_v7_lambda_positive": (
                float(
                    model.dual_v7_lambda_positive.detach().cpu()
                )
                if hasattr(
                    model,
                    "raw_dual_v7_negative_ratio",
                )
                else 0.0
            ),
            "dual_v7_lambda_negative": (
                float(
                    model.dual_v7_lambda_negative.detach().cpu()
                )
                if hasattr(
                    model,
                    "raw_dual_v7_negative_ratio",
                )
                else 0.0
            ),
            "uncertainty_plasticity_gamma_v2": (
                float(
                    torch.tanh(
                        model.raw_uncertainty_plasticity_v2
                    ).detach().cpu()
                )
                if hasattr(
                    model,
                    "raw_uncertainty_plasticity_v2",
                )
                else 0.0
            ),
        },
    )
    print("test metrics:")
    print(json.dumps(test_metrics, ensure_ascii=False, indent=2))
    print("long-tail metrics:")
    print(json.dumps(long_tail, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
