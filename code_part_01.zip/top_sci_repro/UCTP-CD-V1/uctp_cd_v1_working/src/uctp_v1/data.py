from __future__ import annotations

import ast
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


@dataclass
class DataConfig:
    student_col: str = "student_id"
    item_col: str = "item_id"
    knowledge_col: str = "knowledge_ids"
    label_col: str = "correct"
    timestamp_col: str = "timestamp"
    response_time_col: str = "response_time"
    split_col: str = "split"
    train_name: str = "train"
    valid_name: str = "valid"
    test_name: str = "test"
    timestamp_unit: str = "auto"  # auto|s|ms|us|ns|datetime
    response_time_unit: str = "auto"  # auto|s|ms
    knowledge_separator: str = ","
    max_time_gap_hours: float = 24.0 * 365.0
    rt_clip: float = 5.0

    @classmethod
    def from_json(cls, path: str | Path) -> "DataConfig":
        with open(path, "r", encoding="utf-8") as f:
            values = json.load(f)
        return cls(**values)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RTStatistics:
    global_median: float
    global_scale: float
    item_median: Dict[str, float]
    item_scale: Dict[str, float]
    student_median: Dict[str, float]

    def to_jsonable(self) -> Dict[str, Any]:
        return {
            "global_median": self.global_median,
            "global_scale": self.global_scale,
            "item_median": self.item_median,
            "item_scale": self.item_scale,
            "student_median": self.student_median,
        }


@dataclass
class PreparedData:
    frame: pd.DataFrame
    config: DataConfig
    student_to_idx: Dict[str, int]
    item_to_idx: Dict[str, int]
    knowledge_to_idx: Dict[str, int]
    rt_stats: RTStatistics

    @property
    def num_students(self) -> int:
        return len(self.student_to_idx)

    @property
    def num_items(self) -> int:
        return len(self.item_to_idx)

    @property
    def num_knowledges(self) -> int:
        return len(self.knowledge_to_idx)

    def save_metadata(self, output_dir: str | Path) -> None:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        payload = {
            "config": self.config.to_dict(),
            "student_to_idx": self.student_to_idx,
            "item_to_idx": self.item_to_idx,
            "knowledge_to_idx": self.knowledge_to_idx,
            "rt_stats": self.rt_stats.to_jsonable(),
        }
        with open(out / "metadata.json", "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)


def _normalise_id(value: Any) -> str:
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def parse_knowledge_cell(value: Any, separator: str = ",") -> List[str]:
    if isinstance(value, (list, tuple, set, np.ndarray)):
        return [_normalise_id(v) for v in value if str(v).strip()]
    if pd.isna(value):
        return []
    text = str(value).strip()
    if not text:
        return []
    if text.startswith("[") and text.endswith("]"):
        try:
            parsed = ast.literal_eval(text)
            if isinstance(parsed, (list, tuple, set)):
                return [_normalise_id(v) for v in parsed if str(v).strip()]
        except (ValueError, SyntaxError):
            pass
    if separator and separator in text:
        return [_normalise_id(v) for v in text.split(separator) if str(v).strip()]
    return [_normalise_id(text)]


def _timestamp_to_seconds(series: pd.Series, unit: str) -> pd.Series:
    if unit == "datetime" or not pd.api.types.is_numeric_dtype(series):
        parsed = pd.to_datetime(series, errors="coerce", utc=True)
        return parsed.astype("int64") / 1e9

    values = pd.to_numeric(series, errors="coerce").astype(float)
    if unit == "s":
        return values
    if unit == "ms":
        return values / 1e3
    if unit == "us":
        return values / 1e6
    if unit == "ns":
        return values / 1e9
    if unit != "auto":
        raise ValueError(f"Unsupported timestamp unit: {unit}")

    finite = values[np.isfinite(values)]
    if finite.empty:
        return values
    median_abs = float(np.median(np.abs(finite)))
    if median_abs > 1e17:
        return values / 1e9
    if median_abs > 1e14:
        return values / 1e6
    if median_abs > 1e11:
        return values / 1e3
    return values


def _rt_to_seconds(series: pd.Series, unit: str) -> pd.Series:
    values = pd.to_numeric(series, errors="coerce").astype(float)
    if unit == "s":
        return values
    if unit == "ms":
        return values / 1e3
    if unit != "auto":
        raise ValueError(f"Unsupported response-time unit: {unit}")
    finite = values[(values > 0) & np.isfinite(values)]
    if finite.empty:
        return values
    # Educational response times above 300 are usually milliseconds in these datasets.
    return values / 1e3 if float(finite.median()) > 300.0 else values


def _mad(values: pd.Series) -> float:
    if len(values) == 0:
        return float("nan")
    med = float(values.median())
    return float((values - med).abs().median())


def _fit_rt_statistics(
    frame: pd.DataFrame,
    config: DataConfig,
) -> RTStatistics:
    train = frame[frame[config.split_col] == config.train_name].copy()
    if train.empty:
        raise ValueError("No training rows were found. Check split names and split column.")

    log_rt = train["_log_rt"]
    global_median = float(log_rt.median())
    global_mad = _mad(log_rt)
    global_scale = max(1.4826 * (global_mad if np.isfinite(global_mad) else 0.0), 1e-3)

    item_group = train.groupby("_item_id", sort=False)["_log_rt"]
    item_median = item_group.median().astype(float).to_dict()
    item_mad = item_group.apply(_mad).astype(float)
    item_scale = (1.4826 * item_mad).clip(lower=global_scale * 0.25).to_dict()

    student_median = (
        train.groupby("_student_id", sort=False)["_log_rt"]
        .median()
        .astype(float)
        .to_dict()
    )
    return RTStatistics(
        global_median=global_median,
        global_scale=global_scale,
        item_median={str(k): float(v) for k, v in item_median.items()},
        item_scale={str(k): float(v) for k, v in item_scale.items()},
        student_median={str(k): float(v) for k, v in student_median.items()},
    )


def _apply_rt_residual(frame: pd.DataFrame, stats: RTStatistics, config: DataConfig) -> pd.DataFrame:
    df = frame.copy()
    item_med = df["_item_id"].map(stats.item_median).fillna(stats.global_median)
    student_med = df["_student_id"].map(stats.student_median).fillna(stats.global_median)
    item_scale = df["_item_id"].map(stats.item_scale).fillna(stats.global_scale)
    item_scale = item_scale.clip(lower=stats.global_scale * 0.25)
    residual = (df["_log_rt"] - item_med - student_med + stats.global_median) / item_scale
    df["rt_residual"] = residual.clip(-config.rt_clip, config.rt_clip).astype(np.float32)
    return df


def _add_sequential_features(frame: pd.DataFrame, config: DataConfig) -> pd.DataFrame:
    pieces: List[pd.DataFrame] = []
    max_gap = float(config.max_time_gap_hours)

    for _, group in frame.groupby("_student_id", sort=False):
        g = group.sort_values(["_timestamp_seconds", "_original_order"], kind="mergesort").copy()
        last_global: Optional[float] = None
        last_k: Dict[str, float] = {}
        count_k: Dict[str, int] = {}
        student_count = 0

        delta_global_list: List[float] = []
        delta_k_list: List[float] = []
        kc_count_list: List[float] = []
        student_count_list: List[int] = []

        for _, row in g.iterrows():
            ts = float(row["_timestamp_seconds"])
            kcs: List[str] = row["_knowledge_ids"]
            delta_global = 0.0 if last_global is None else max(0.0, (ts - last_global) / 3600.0)

            kc_gaps: List[float] = []
            kc_counts: List[int] = []
            for kc in kcs:
                kc_gaps.append(
                    delta_global if kc not in last_k else max(0.0, (ts - last_k[kc]) / 3600.0)
                )
                kc_counts.append(count_k.get(kc, 0))

            delta_k = float(np.mean(kc_gaps)) if kc_gaps else delta_global
            kc_count_before = float(np.mean(kc_counts)) if kc_counts else 0.0

            delta_global_list.append(min(delta_global, max_gap))
            delta_k_list.append(min(delta_k, max_gap))
            kc_count_list.append(kc_count_before)
            student_count_list.append(student_count)

            last_global = ts
            student_count += 1
            for kc in kcs:
                last_k[kc] = ts
                count_k[kc] = count_k.get(kc, 0) + 1

        g["delta_t_hours"] = np.asarray(delta_global_list, dtype=np.float32)
        g["delta_t_k_hours"] = np.asarray(delta_k_list, dtype=np.float32)
        g["kc_count_before"] = np.asarray(kc_count_list, dtype=np.float32)
        g["student_count_before"] = np.asarray(student_count_list, dtype=np.int64)
        pieces.append(g)

    return pd.concat(pieces, ignore_index=True)


def _read_inputs(
    train_path: Optional[str],
    valid_path: Optional[str],
    test_path: Optional[str],
    data_path: Optional[str],
    config: DataConfig,
) -> pd.DataFrame:
    if data_path:
        df = pd.read_csv(data_path)
        if config.split_col not in df.columns:
            raise ValueError(
                f"Single-file mode requires split column '{config.split_col}'. "
                f"Available columns: {df.columns.tolist()}"
            )
        return df

    if not (train_path and valid_path and test_path):
        raise ValueError("Provide either --data or all of --train/--valid/--test.")

    train = pd.read_csv(train_path)
    valid = pd.read_csv(valid_path)
    test = pd.read_csv(test_path)
    train[config.split_col] = config.train_name
    valid[config.split_col] = config.valid_name
    test[config.split_col] = config.test_name
    return pd.concat([train, valid, test], ignore_index=True, sort=False)


def prepare_data(
    config: DataConfig,
    train_path: Optional[str] = None,
    valid_path: Optional[str] = None,
    test_path: Optional[str] = None,
    data_path: Optional[str] = None,
) -> PreparedData:
    raw = _read_inputs(train_path, valid_path, test_path, data_path, config)
    required = [
        config.student_col,
        config.item_col,
        config.knowledge_col,
        config.label_col,
        config.timestamp_col,
        config.response_time_col,
        config.split_col,
    ]
    missing = [c for c in required if c not in raw.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}. Available: {raw.columns.tolist()}")

    df = raw[required].copy()
    df["_original_order"] = np.arange(len(df), dtype=np.int64)
    df["_student_id"] = df[config.student_col].map(_normalise_id)
    df["_item_id"] = df[config.item_col].map(_normalise_id)
    df["_knowledge_ids"] = df[config.knowledge_col].map(
        lambda value: parse_knowledge_cell(value, config.knowledge_separator)
    )
    df["label"] = pd.to_numeric(df[config.label_col], errors="coerce")
    df["_timestamp_seconds"] = _timestamp_to_seconds(df[config.timestamp_col], config.timestamp_unit)
    df["response_time_seconds"] = _rt_to_seconds(df[config.response_time_col], config.response_time_unit)

    df = df.dropna(subset=["label", "_timestamp_seconds", "response_time_seconds"])
    df = df[df["label"].isin([0.0, 1.0])]
    df = df[df["response_time_seconds"] > 0]
    df = df[df["_knowledge_ids"].map(len) > 0].copy()
    df["label"] = df["label"].astype(np.float32)
    df["_log_rt"] = np.log1p(df["response_time_seconds"].astype(float)).astype(np.float32)

    allowed_splits = {config.train_name, config.valid_name, config.test_name}
    unknown = sorted(set(df[config.split_col].astype(str)) - allowed_splits)
    if unknown:
        raise ValueError(f"Unexpected split values: {unknown}. Expected: {sorted(allowed_splits)}")

    rt_stats = _fit_rt_statistics(df, config)
    df = _apply_rt_residual(df, rt_stats, config)
    df = _add_sequential_features(df, config)

    students = sorted(df["_student_id"].unique().tolist())
    items = sorted(df["_item_id"].unique().tolist())
    knowledges = sorted({kc for values in df["_knowledge_ids"] for kc in values})
    student_to_idx = {value: idx for idx, value in enumerate(students)}
    item_to_idx = {value: idx for idx, value in enumerate(items)}
    knowledge_to_idx = {value: idx for idx, value in enumerate(knowledges)}

    df["student_idx"] = df["_student_id"].map(student_to_idx).astype(np.int64)
    df["item_idx"] = df["_item_id"].map(item_to_idx).astype(np.int64)
    df["knowledge_indices"] = df["_knowledge_ids"].map(
        lambda values: [knowledge_to_idx[kc] for kc in values]
    )

    # Number of training interactions per student, useful for long-tail evaluation.
    train_counts = (
        df[df[config.split_col] == config.train_name]
        .groupby("student_idx")
        .size()
        .to_dict()
    )
    df["train_interaction_count"] = df["student_idx"].map(train_counts).fillna(0).astype(np.int64)

    return PreparedData(
        frame=df,
        config=config,
        student_to_idx=student_to_idx,
        item_to_idx=item_to_idx,
        knowledge_to_idx=knowledge_to_idx,
        rt_stats=rt_stats,
    )


class StudentSequenceDataset(Dataset):
    def __init__(self, prepared: PreparedData, view: str) -> None:
        if view not in {"train", "valid", "test"}:
            raise ValueError("view must be train, valid, or test")
        self.prepared = prepared
        cfg = prepared.config
        allowed = {
            "train": {cfg.train_name},
            "valid": {cfg.train_name, cfg.valid_name},
            "test": {cfg.train_name, cfg.valid_name, cfg.test_name},
        }[view]
        target = {
            "train": cfg.train_name,
            "valid": cfg.valid_name,
            "test": cfg.test_name,
        }[view]
        self.view = view
        self.target_name = target
        subset = prepared.frame[prepared.frame[cfg.split_col].isin(allowed)].copy()
        self.groups: List[pd.DataFrame] = []
        for _, group in subset.groupby("student_idx", sort=False):
            g = group.sort_values(["_timestamp_seconds", "_original_order"], kind="mergesort")
            if (g[cfg.split_col] == target).any():
                self.groups.append(g.reset_index(drop=True))
        self.lengths = [len(g) for g in self.groups]

    def __len__(self) -> int:
        return len(self.groups)

    def __getitem__(self, index: int) -> Dict[str, Any]:
        g = self.groups[index]
        cfg = self.prepared.config
        return {
            "student_idx": int(g["student_idx"].iloc[0]),
            "item_idx": g["item_idx"].to_numpy(np.int64),
            "knowledge_indices": g["knowledge_indices"].tolist(),
            "label": g["label"].to_numpy(np.float32),
            "rt_residual": g["rt_residual"].to_numpy(np.float32),
            "delta_t_hours": g["delta_t_hours"].to_numpy(np.float32),
            "delta_t_k_hours": g["delta_t_k_hours"].to_numpy(np.float32),
            "kc_count_before": g["kc_count_before"].to_numpy(np.float32),
            "student_count_before": g["student_count_before"].to_numpy(np.int64),
            "train_interaction_count": g["train_interaction_count"].to_numpy(np.int64),
            "target_mask": (g[cfg.split_col].to_numpy() == self.target_name),
            "split": g[cfg.split_col].astype(str).tolist(),
        }


def collate_student_sequences(
    batch: Sequence[Dict[str, Any]],
    num_knowledges: int,
) -> Dict[str, torch.Tensor]:
    batch_size = len(batch)
    max_len = max(len(item["item_idx"]) for item in batch)

    student_idx = torch.zeros(batch_size, dtype=torch.long)
    item_idx = torch.zeros(batch_size, max_len, dtype=torch.long)
    q = torch.zeros(batch_size, max_len, num_knowledges, dtype=torch.float32)
    label = torch.zeros(batch_size, max_len, dtype=torch.float32)
    rt_residual = torch.zeros_like(label)
    delta_t_hours = torch.zeros_like(label)
    delta_t_k_hours = torch.zeros_like(label)
    kc_count_before = torch.zeros_like(label)
    student_count_before = torch.zeros(batch_size, max_len, dtype=torch.long)
    train_interaction_count = torch.zeros(batch_size, max_len, dtype=torch.long)
    active_mask = torch.zeros(batch_size, max_len, dtype=torch.bool)
    target_mask = torch.zeros(batch_size, max_len, dtype=torch.bool)

    for b, item in enumerate(batch):
        length = len(item["item_idx"])
        student_idx[b] = item["student_idx"]
        item_idx[b, :length] = torch.as_tensor(item["item_idx"].copy(), dtype=torch.long)
        label[b, :length] = torch.as_tensor(item["label"].copy(), dtype=torch.float32)
        rt_residual[b, :length] = torch.as_tensor(item["rt_residual"].copy(), dtype=torch.float32)
        delta_t_hours[b, :length] = torch.as_tensor(item["delta_t_hours"].copy(), dtype=torch.float32)
        delta_t_k_hours[b, :length] = torch.as_tensor(item["delta_t_k_hours"].copy(), dtype=torch.float32)
        kc_count_before[b, :length] = torch.as_tensor(item["kc_count_before"].copy(), dtype=torch.float32)
        student_count_before[b, :length] = torch.as_tensor(item["student_count_before"].copy(), dtype=torch.long)
        train_interaction_count[b, :length] = torch.as_tensor(item["train_interaction_count"].copy(), dtype=torch.long)
        active_mask[b, :length] = True
        target_mask[b, :length] = torch.as_tensor(item["target_mask"].copy(), dtype=torch.bool)
        for t, knowledge_indices in enumerate(item["knowledge_indices"]):
            q[b, t, knowledge_indices] = 1.0

    return {
        "student_idx": student_idx,
        "item_idx": item_idx,
        "q": q,
        "label": label,
        "rt_residual": rt_residual,
        "delta_t_hours": delta_t_hours,
        "delta_t_k_hours": delta_t_k_hours,
        "kc_count_before": kc_count_before,
        "student_count_before": student_count_before,
        "train_interaction_count": train_interaction_count,
        "active_mask": active_mask,
        "target_mask": target_mask,
    }
