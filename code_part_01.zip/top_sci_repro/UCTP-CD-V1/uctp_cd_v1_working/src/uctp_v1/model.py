from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import torch
from torch import Tensor, nn
import torch.nn.functional as F


class PositiveLinear(nn.Module):
    """Linear layer with non-negative effective weights for monotonic NCD."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        initial_effective_weight: float = 0.02,
    ) -> None:
        super().__init__()
        if initial_effective_weight <= 0:
            raise ValueError("initial_effective_weight must be positive")
        raw_init = float(torch.log(torch.expm1(torch.tensor(initial_effective_weight))))
        self.raw_weight = nn.Parameter(
            torch.empty(out_features, in_features).normal_(mean=raw_init, std=0.05)
        )
        self.bias = nn.Parameter(torch.zeros(out_features)) if bias else None

    def forward(self, x: Tensor) -> Tensor:
        weight = F.softplus(self.raw_weight)
        return F.linear(x, weight, self.bias)


@dataclass
class UCTPState:
    p_short: Tensor
    n_short: Tensor
    p_long: Tensor
    n_long: Tensor
    mix_gate: Tensor

    def detach(self) -> "UCTPState":
        return UCTPState(
            self.p_short.detach(),
            self.n_short.detach(),
            self.p_long.detach(),
            self.n_long.detach(),
            self.mix_gate.detach(),
        )


class ReliabilityEncoder(nn.Module):
    def __init__(self, hidden_dim: int = 32) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(10, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, features: Tensor) -> Tensor:
        return torch.sigmoid(self.net(features)).squeeze(-1)


class EvidenceStrength(nn.Module):
    def __init__(self, hidden_dim: int = 16) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, features: Tensor) -> Tensor:
        return F.softplus(self.net(features)).squeeze(-1) + 1e-6


class UCTPCDV1(nn.Module):
    """
    Working version for innovation 1 + innovation 3.

    Baseline path:
      static student mastery embedding -> monotonic NeuralCD head.

    Innovation 1:
      RT residual + real time gaps + reliability gate + dual-timescale evidence memory.

    Innovation 3:
      Beta evidence mastery + uncertainty output + uncertainty-gated dynamic residual.
    """

    def __init__(
        self,
        num_students: int,
        num_items: int,
        num_knowledges: int,
        hidden_dim: int = 64,
        ncd_hidden_dim: int = 128,
        use_dynamic: bool = True,
        use_time: bool = True,
        use_rt: bool = True,
        use_reliability: bool = True,
        use_dual_timescale: bool = True,
        use_prediction_surprise: bool = False,
        use_concept_adaptive_decay: bool = False,
        use_interaction_residual_v2: bool = False,
        use_selective_consolidation_v3: bool = False,
        use_uncertainty_gate: bool = True,
        use_uncertainty_update_v2: bool = False,
        use_predict_time_decay_v2: bool = False,
        use_monotonic_dual_v4: bool = False,
        use_anchor_dual_v5: bool = False,
        use_bounded_dual_v6: bool = False,
        use_asymmetric_dual_v7: bool = False,
        anchor_dual_residual_cap: float = 0.05,
        bounded_dual_v6_max_ratio: float = 8.0,
    ) -> None:
        super().__init__()
        self.num_students = num_students
        self.num_items = num_items
        self.num_knowledges = num_knowledges
        self.use_dynamic = use_dynamic
        self.use_time = use_time
        self.use_rt = use_rt
        self.use_reliability = use_reliability
        self.use_dual_timescale = use_dual_timescale
        self.use_prediction_surprise = use_prediction_surprise
        self.use_concept_adaptive_decay = use_concept_adaptive_decay
        self.use_interaction_residual_v2 = use_interaction_residual_v2
        self.use_selective_consolidation_v3 = use_selective_consolidation_v3
        self.use_uncertainty_gate = use_uncertainty_gate
        self.use_uncertainty_update_v2 = use_uncertainty_update_v2
        self.use_predict_time_decay_v2 = use_predict_time_decay_v2
        self.use_monotonic_dual_v4 = use_monotonic_dual_v4
        self.use_anchor_dual_v5 = use_anchor_dual_v5
        self.use_bounded_dual_v6 = use_bounded_dual_v6
        self.use_asymmetric_dual_v7 = use_asymmetric_dual_v7
        self.anchor_dual_residual_cap = float(
            anchor_dual_residual_cap
        )
        self.bounded_dual_v6_max_ratio = float(
            bounded_dual_v6_max_ratio
        )

        if not 0.0 < self.anchor_dual_residual_cap <= 0.20:
            raise ValueError(
                "anchor_dual_residual_cap must be in (0, 0.20]."
            )

        if not 1.0 < self.bounded_dual_v6_max_ratio <= 20.0:
            raise ValueError(
                "bounded_dual_v6_max_ratio must be in (1, 20]."
            )

        if self.use_bounded_dual_v6 and not self.use_anchor_dual_v5:
            raise ValueError(
                "Bounded Dual V6 requires use_anchor_dual_v5=True."
            )

        if (
            self.use_asymmetric_dual_v7
            and not self.use_bounded_dual_v6
        ):
            raise ValueError(
                "Asymmetric Dual V7 requires "
                "use_bounded_dual_v6=True."
            )

        if self.use_selective_consolidation_v3 and not self.use_dual_timescale:
            raise ValueError(
                "Selective consolidation V3 requires use_dual_timescale=True"
            )

        self.student_mastery_logit = nn.Embedding(num_students, num_knowledges)
        self.item_difficulty_logit = nn.Embedding(num_items, num_knowledges)
        self.item_discrimination_raw = nn.Embedding(num_items, 1)
        self.item_bias = nn.Embedding(num_items, 1)
        nn.init.normal_(self.student_mastery_logit.weight, mean=0.0, std=0.1)
        nn.init.normal_(self.item_difficulty_logit.weight, mean=0.0, std=0.1)
        nn.init.constant_(self.item_discrimination_raw.weight, 0.5)
        nn.init.zeros_(self.item_bias.weight)

        self.reliability_encoder = ReliabilityEncoder(hidden_dim=hidden_dim)
        self.positive_strength = EvidenceStrength()
        self.negative_strength = EvidenceStrength()

        # lambda_short = lambda_long + positive gap, guaranteeing short decay is faster.
        self.raw_lambda_long = nn.Parameter(torch.tensor(-4.0))
        self.raw_lambda_gap = nn.Parameter(torch.tensor(-2.5))

        self.timescale_gate = nn.Sequential(
            nn.Linear(4, hidden_dim // 2),
            nn.GELU(),
            nn.Linear(hidden_dim // 2, 1),
        )
        self.raw_dynamic_scale = nn.Parameter(torch.tensor(-1.0))
        self.raw_direct_scale = nn.Parameter(torch.tensor(0.5))

        self.ncd = nn.Sequential(
            PositiveLinear(num_knowledges, ncd_hidden_dim, initial_effective_weight=0.02),
            nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim, ncd_hidden_dim // 2, initial_effective_weight=0.02),
            nn.Sigmoid(),
            PositiveLinear(ncd_hidden_dim // 2, 1, initial_effective_weight=0.02),
        )
        # Centre the initial prediction near 0.5 instead of saturating at 1.0.
        if self.ncd[-1].bias is not None:
            nn.init.constant_(self.ncd[-1].bias, -0.85)

        # Innovation 1 performance V2:
        # prediction-surprise-conditioned reliability correction.
        #
        # This module is created ONLY when enabled, and only after all
        # original V1 modules have been initialized. Thus existing V1
        # variants keep their original shared-parameter RNG stream.
        if self.use_concept_adaptive_decay:
            # Hierarchical concept-adaptive temporal decay.
            #
            # scale_k = exp(0.75 * tanh(s_k))
            # s_k starts from 0 => scale_k = 1 exactly.
            # Therefore the initial model exactly recovers the
            # original global temporal decay.
            self.concept_decay_log_scale = nn.Parameter(
                torch.zeros(num_knowledges)
            )

        if self.use_interaction_residual_v2:
            interaction_hidden = max(16, hidden_dim // 2)

            self.interaction_residual_head = nn.Sequential(
                nn.Linear(10, interaction_hidden),
                nn.LayerNorm(interaction_hidden),
                nn.GELU(),
                nn.Linear(interaction_hidden, interaction_hidden // 2),
                nn.GELU(),
                nn.Linear(interaction_hidden // 2, 1),
            )

            # Exact V1 starting point:
            # the new branch initially contributes zero logit.
            nn.init.zeros_(self.interaction_residual_head[-1].weight)
            nn.init.zeros_(self.interaction_residual_head[-1].bias)

        if self.use_prediction_surprise:
            surprise_hidden = max(8, hidden_dim // 4)
            self.surprise_reliability_adjuster = nn.Sequential(
                nn.Linear(8, surprise_hidden),
                nn.GELU(),
                nn.Linear(surprise_hidden, 1),
            )

            # Start exactly from the original reliability behavior:
            # delta reliability-logit = 0.
            nn.init.zeros_(self.surprise_reliability_adjuster[-1].weight)
            nn.init.zeros_(self.surprise_reliability_adjuster[-1].bias)

        # Dual-Timescale V3 modules are instantiated after all frozen V1
        # modules, so existing variants retain their original RNG stream.
        if self.use_selective_consolidation_v3:
            gate_hidden = max(16, hidden_dim // 2)

            self.consolidation_gate_v3 = nn.Sequential(
                nn.Linear(11, gate_hidden),
                nn.LayerNorm(gate_hidden),
                nn.GELU(),
                nn.Linear(gate_hidden, 1),
            )
            self.residual_read_gate_v3 = nn.Sequential(
                nn.Linear(11, gate_hidden),
                nn.LayerNorm(gate_hidden),
                nn.GELU(),
                nn.Linear(gate_hidden, 1),
            )

            # Near-control initialization:
            # consolidation C starts near 1; residual read gate G near 0.
            nn.init.zeros_(self.consolidation_gate_v3[-1].weight)
            nn.init.constant_(self.consolidation_gate_v3[-1].bias, -4.0)
            nn.init.zeros_(self.residual_read_gate_v3[-1].weight)
            nn.init.constant_(self.residual_read_gate_v3[-1].bias, -4.0)

        # Innovation 3 V2: one bounded global direction parameter.
        # Zero initialization makes V2 exactly match the control initially.
        if self.use_uncertainty_update_v2:
            self.raw_uncertainty_plasticity_v2 = nn.Parameter(
                torch.tensor(0.0)
            )

        # Dual-Timescale V4:
        # control-anchored, current-time monotonic residual read.
        # Scalar initialization consumes no random numbers.
        if self.use_monotonic_dual_v4:
            self.dual_v4_gate_bias = nn.Parameter(
                torch.tensor(-4.0)
            )
            self.dual_v4_time_weight_raw = nn.Parameter(
                torch.tensor(-2.0)
            )
            self.dual_v4_count_weight_raw = nn.Parameter(
                torch.tensor(-4.0)
            )
            self.dual_v4_uncertainty_weight_raw = nn.Parameter(
                torch.tensor(0.0)
            )

        # Dual-Timescale V5: control-anchored detached residual.
        # alpha starts exactly at zero and is bounded.
        if self.use_anchor_dual_v5:
            self.dual_v5_residual_scale_raw = nn.Parameter(
                torch.tensor(0.0)
            )

        if self.use_bounded_dual_v6:
            self.raw_dual_v6_short_ratio = nn.Parameter(
                torch.tensor(0.75)
            )

        if self.use_asymmetric_dual_v7:
            self.raw_dual_v7_negative_ratio = nn.Parameter(
                torch.tensor(0.75)
            )

    @property
    def lambda_long(self) -> Tensor:
        return F.softplus(self.raw_lambda_long) + 1e-8

    @property
    def lambda_short(self) -> Tensor:
        return self.lambda_long + F.softplus(self.raw_lambda_gap) + 1e-8

    @property
    def dual_v6_short_ratio(self) -> Tensor:
        return (
            1.0
            + (self.bounded_dual_v6_max_ratio - 1.0)
            * torch.sigmoid(self.raw_dual_v6_short_ratio)
        )

    @property
    def dual_v6_lambda_short(self) -> Tensor:
        return (
            self.lambda_long.detach()
            * self.dual_v6_short_ratio
        )

    @property
    def dual_v7_positive_ratio(self) -> Tensor:
        return self.dual_v6_short_ratio

    @property
    def dual_v7_negative_ratio(self) -> Tensor:
        return (
            1.0
            + (self.bounded_dual_v6_max_ratio - 1.0)
            * torch.sigmoid(self.raw_dual_v7_negative_ratio)
        )

    @property
    def dual_v7_lambda_positive(self) -> Tensor:
        return self.dual_v6_lambda_short

    @property
    def dual_v7_lambda_negative(self) -> Tensor:
        return (
            self.lambda_long.detach()
            * self.dual_v7_negative_ratio
        )

    @property
    def dynamic_scale(self) -> Tensor:
        return F.softplus(self.raw_dynamic_scale)

    @property
    def direct_scale(self) -> Tensor:
        return F.softplus(self.raw_direct_scale)

    def init_state(self, batch_size: int, device: torch.device) -> UCTPState:
        zeros = torch.zeros(batch_size, self.num_knowledges, device=device)
        return UCTPState(
            p_short=zeros.clone(),
            n_short=zeros.clone(),
            p_long=zeros.clone(),
            n_long=zeros.clone(),
            mix_gate=torch.full_like(zeros, 0.5),
        )

    @staticmethod
    def _beta_from_state(state: UCTPState) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
        p = state.mix_gate * state.p_short + (1.0 - state.mix_gate) * state.p_long
        n = state.mix_gate * state.n_short + (1.0 - state.mix_gate) * state.n_long
        alpha = 1.0 + p.clamp_min(0.0)
        beta = 1.0 + n.clamp_min(0.0)
        mastery = alpha / (alpha + beta)
        uncertainty = 2.0 / (alpha + beta)
        return alpha, beta, mastery, uncertainty

    def _current_mastery(
        self,
        state: UCTPState,
        student_idx: Tensor,
    ) -> Tuple[Tensor, Tensor, Tensor, Tensor]:
        alpha, beta, dynamic_mastery, uncertainty = self._beta_from_state(state)
        base_logit = self.student_mastery_logit(student_idx)
        if not self.use_dynamic:
            return torch.sigmoid(base_logit), uncertainty, alpha, beta

        eps = 1e-5
        dynamic_logit = torch.logit(dynamic_mastery.clamp(eps, 1.0 - eps))
        if self.use_uncertainty_gate:
            dynamic_logit = dynamic_logit * (1.0 - uncertainty).clamp(0.0, 1.0)
        mastery = torch.sigmoid(base_logit + self.dynamic_scale * dynamic_logit)
        return mastery, uncertainty, alpha, beta

    def _dual_v4_prediction_state(
        self,
        state: UCTPState,
        q: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
    ) -> Tuple[UCTPState, Tensor]:
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        dt_k = delta_t_k_hours.clamp_min(0.0)

        # Only short receives a current-time temporary decay.
        # Long remains the frozen rt_rel control anchor.
        short_decay = torch.exp(
            -self.lambda_short * dt_k
        )
        keep_short = (
            1.0 - q
            + q * short_decay.unsqueeze(-1)
        )

        p_short_read = state.p_short * keep_short
        n_short_read = state.n_short * keep_short

        long_alpha = 1.0 + state.p_long.clamp_min(0.0)
        long_beta = 1.0 + state.n_long.clamp_min(0.0)
        long_uncertainty = 2.0 / (
            long_alpha + long_beta
        )
        relevant_long_uncertainty = (
            (long_uncertainty * q).sum(dim=-1)
            / q_sum
        )

        log_dt = torch.log1p(dt_k)
        log_count = torch.log1p(
            kc_count_before.clamp_min(0.0)
        )

        gate_logit = (
            self.dual_v4_gate_bias
            - F.softplus(
                self.dual_v4_time_weight_raw
            ) * log_dt
            + F.softplus(
                self.dual_v4_count_weight_raw
            ) * log_count
            + 0.5
            * torch.tanh(
                self.dual_v4_uncertainty_weight_raw
            )
            * relevant_long_uncertainty
        )

        # Conservative residual range: [0, 0.15].
        gate_scalar = 0.15 * torch.sigmoid(
            gate_logit
        )

        read_gate = (
            state.mix_gate * (1.0 - q)
            + q * gate_scalar.unsqueeze(-1)
        )

        read_state = UCTPState(
            p_short=p_short_read,
            n_short=n_short_read,
            p_long=state.p_long,
            n_long=state.n_long,
            mix_gate=read_gate,
        )
        return read_state, gate_scalar

    def _dual_v5_prediction_state(
        self,
        state: UCTPState,
        q: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
    ) -> Tuple[UCTPState, Tensor, Tensor]:
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        dt_k = delta_t_k_hours.clamp_min(0.0)

        if self.use_asymmetric_dual_v7:
            positive_decay_rate = self.dual_v7_lambda_positive
            negative_decay_rate = self.dual_v7_lambda_negative
            short_p_source = state.p_short
            short_n_source = state.n_short
            long_p_source = state.p_long.detach()
            long_n_source = state.n_long.detach()
        elif self.use_bounded_dual_v6:
            positive_decay_rate = self.dual_v6_lambda_short
            negative_decay_rate = self.dual_v6_lambda_short
            short_p_source = state.p_short
            short_n_source = state.n_short
            long_p_source = state.p_long.detach()
            long_n_source = state.n_long.detach()
        else:
            positive_decay_rate = self.lambda_short.detach()
            negative_decay_rate = self.lambda_short.detach()
            short_p_source = state.p_short
            short_n_source = state.n_short
            long_p_source = state.p_long
            long_n_source = state.n_long

        positive_decay = torch.exp(
            -positive_decay_rate * dt_k
        )
        negative_decay = torch.exp(
            -negative_decay_rate * dt_k
        )
        keep_positive = (
            1.0 - q + q * positive_decay.unsqueeze(-1)
        )
        keep_negative = (
            1.0 - q + q * negative_decay.unsqueeze(-1)
        )
        p_short_read = short_p_source * keep_positive
        n_short_read = short_n_source * keep_negative

        short_alpha = 1.0 + p_short_read.clamp_min(0.0)
        short_beta = 1.0 + n_short_read.clamp_min(0.0)
        long_alpha = 1.0 + long_p_source.clamp_min(0.0)
        long_beta = 1.0 + long_n_source.clamp_min(0.0)

        short_mastery = short_alpha / (
            short_alpha + short_beta
        )
        long_mastery = long_alpha / (
            long_alpha + long_beta
        )
        long_uncertainty = 2.0 / (
            long_alpha + long_beta
        )

        eps = 1e-5
        short_logit = torch.logit(
            short_mastery.clamp(eps, 1.0 - eps)
        )
        long_logit = torch.logit(
            long_mastery.clamp(eps, 1.0 - eps)
        )

        relevant_state_residual = (
            ((short_logit - long_logit) * q).sum(dim=-1)
            / q_sum
        ).clamp(-2.0, 2.0)

        relevant_long_uncertainty = (
            (long_uncertainty * q).sum(dim=-1)
            / q_sum
        )

        # Only pre-response features are used.
        recency = torch.rsqrt(1.0 + dt_k)
        experience = 1.0 - torch.exp(
            -kc_count_before.clamp_min(0.0) / 5.0
        )
        confidence = (
            1.0 - relevant_long_uncertainty
        ).clamp(0.0, 1.0)

        safety_weight = (
            recency * experience * confidence
        ).detach()

        if self.use_bounded_dual_v6:
            residual_feature = (
                relevant_state_residual * safety_weight
            )
        else:
            residual_feature = (
                relevant_state_residual * safety_weight
            ).detach()

        residual_alpha = (
            self.anchor_dual_residual_cap
            * torch.tanh(
                self.dual_v5_residual_scale_raw
            )
        )
        gate_scalar = (
            residual_alpha.abs() * safety_weight
        )

        # Numerically and graph-wise identical long/control read.
        # Do not retain even a zero-weight path through short state.
        control_state = UCTPState(
            p_short=state.p_long,
            n_short=state.n_long,
            p_long=state.p_long,
            n_long=state.n_long,
            mix_gate=torch.zeros_like(state.mix_gate),
        )
        return control_state, residual_feature, gate_scalar

    def _predict_step(
        self,
        state: UCTPState,
        student_idx: Tensor,
        item_idx: Tensor,
        q: Tensor,
        delta_t_k_hours: Optional[Tensor] = None,
        kc_count_before: Optional[Tensor] = None,
    ) -> Dict[str, Tensor]:
        prediction_state = state
        prediction_gate = torch.zeros(
            q.shape[0],
            device=q.device,
            dtype=q.dtype,
        )
        dual_v5_residual_feature = torch.zeros_like(
            prediction_gate
        )

        if self.use_monotonic_dual_v4:
            if (
                delta_t_k_hours is None
                or kc_count_before is None
            ):
                raise ValueError(
                    "Dual V4 prediction requires current "
                    "delta_t_k_hours and kc_count_before."
                )

            prediction_state, prediction_gate = (
                self._dual_v4_prediction_state(
                    state=state,
                    q=q,
                    delta_t_k_hours=delta_t_k_hours,
                    kc_count_before=kc_count_before,
                )
            )
        elif self.use_anchor_dual_v5:
            if (
                delta_t_k_hours is None
                or kc_count_before is None
            ):
                raise ValueError(
                    "Dual V5 prediction requires current "
                    "delta_t_k_hours and kc_count_before."
                )

            (
                prediction_state,
                dual_v5_residual_feature,
                prediction_gate,
            ) = self._dual_v5_prediction_state(
                state=state,
                q=q,
                delta_t_k_hours=delta_t_k_hours,
                kc_count_before=kc_count_before,
            )

        mastery, uncertainty, alpha, beta = (
            self._current_mastery(
                prediction_state,
                student_idx,
            )
        )
        difficulty = torch.sigmoid(self.item_difficulty_logit(item_idx))
        discrimination = F.softplus(self.item_discrimination_raw(item_idx)).squeeze(-1) + 1e-4
        interaction = discrimination.unsqueeze(-1) * (mastery - difficulty) * q
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        # A direct monotonic path prevents the positive MLP from becoming nearly constant
        # during the first epochs; the positive MLP remains as a nonlinear residual.
        direct_logit = self.direct_scale * interaction.sum(dim=-1) / q_sum
        nonlinear_logit = self.ncd(interaction).squeeze(-1)

        relevant_uncertainty = (
            (uncertainty * q).sum(dim=-1) / q_sum
        )
        relevant_evidence = (
            ((alpha + beta - 2.0) * q).sum(dim=-1) / q_sum
        )

        base_prediction_logit = (
            self.item_bias(item_idx).squeeze(-1)
            + direct_logit
            + nonlinear_logit
        )

        if self.use_interaction_residual_v2:
            # ------------------------------------------------
            # Multi-view, pre-response state-item interaction.
            # No current label / RT is used here.
            # ------------------------------------------------
            gap = mastery - difficulty

            mastery_mean = (mastery * q).sum(dim=-1) / q_sum
            difficulty_mean = (difficulty * q).sum(dim=-1) / q_sum
            gap_mean = (gap * q).sum(dim=-1) / q_sum
            abs_gap_mean = (gap.abs() * q).sum(dim=-1) / q_sum

            # Weakest / strongest required-KC gap.
            active_kc = q > 0

            gap_for_min = gap.masked_fill(~active_kc, 1e4)
            gap_for_max = gap.masked_fill(~active_kc, -1e4)

            gap_min = gap_for_min.min(dim=-1).values
            gap_max = gap_for_max.max(dim=-1).values

            residual_features = torch.stack(
                [
                    mastery_mean,
                    difficulty_mean,
                    gap_mean,
                    gap_min,
                    gap_max,
                    abs_gap_mean,
                    relevant_uncertainty,
                    torch.log1p(relevant_evidence.clamp_min(0.0)),
                    discrimination,
                    torch.log1p(q_sum),
                ],
                dim=-1,
            )

            raw_residual = self.interaction_residual_head(
                residual_features
            ).squeeze(-1)

            # Bound the additional correction to avoid calibration
            # collapse during the exploratory performance search.
            interaction_residual = 0.5 * torch.tanh(raw_residual)

            logit = base_prediction_logit + interaction_residual
        else:
            logit = base_prediction_logit

        control_probability = None
        if self.use_anchor_dual_v5:
            control_probability = torch.sigmoid(logit)

            residual_alpha = (
                self.anchor_dual_residual_cap
                * torch.tanh(
                    self.dual_v5_residual_scale_raw
                )
            )
            dual_logit = (
                logit.detach()
                + residual_alpha
                * dual_v5_residual_feature
            )
            probability = torch.sigmoid(dual_logit)
        else:
            probability = torch.sigmoid(logit)

        result = {
            "probability": probability,
            "uncertainty": relevant_uncertainty,
            "evidence": relevant_evidence,
            "difficulty_scalar": (difficulty * q).sum(dim=-1) / q_sum,
            "prediction_timescale_gate": prediction_gate,
        }
        if control_probability is not None:
            result["control_probability"] = (
                control_probability
            )
        return result

    def _decay_state_before_prediction_v2(
        self,
        state: UCTPState,
        active: Tensor,
        q: Tensor,
        delta_t_k_hours: Tensor,
    ) -> UCTPState:
        """Advance queried KC states to current prediction time."""
        if not self.use_time:
            return state

        active_f = active.float().unsqueeze(-1)
        q_active = q * active_f
        dt_k = delta_t_k_hours.clamp_min(0.0)

        if self.use_concept_adaptive_decay:
            concept_scale = torch.exp(
                0.75 * torch.tanh(
                    self.concept_decay_log_scale
                )
            ).unsqueeze(0)

            dt_k_expanded = dt_k.unsqueeze(-1)
            lambda_long_k = (
                self.lambda_long * concept_scale
            )
            lambda_short_k = (
                self.lambda_short * concept_scale
            )

            d_long = torch.exp(
                -dt_k_expanded * lambda_long_k
            )
            d_short = torch.exp(
                -dt_k_expanded * lambda_short_k
            )

            if not self.use_dual_timescale:
                d_short = d_long

            keep_short = (
                1.0 - q_active + q_active * d_short
            )
            keep_long = (
                1.0 - q_active + q_active * d_long
            )
        else:
            d_short = torch.exp(
                -self.lambda_short * dt_k
            )
            d_long = torch.exp(
                -self.lambda_long * dt_k
            )

            if not self.use_dual_timescale:
                d_short = d_long

            keep_short = (
                1.0
                - q_active
                + q_active * d_short.unsqueeze(-1)
            )
            keep_long = (
                1.0
                - q_active
                + q_active * d_long.unsqueeze(-1)
            )

        return UCTPState(
            p_short=state.p_short * keep_short,
            n_short=state.n_short * keep_short,
            p_long=state.p_long * keep_long,
            n_long=state.n_long * keep_long,
            mix_gate=state.mix_gate,
        )

    def _update_step(
        self,
        state: UCTPState,
        active: Tensor,
        q: Tensor,
        y: Tensor,
        rt_residual: Tensor,
        delta_t_hours: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
        difficulty_scalar: Tensor,
        predicted_probability: Tensor,
    ) -> Tuple[UCTPState, Tensor, Tensor, Tensor, Tensor]:
        # V5 module-2 features must be numerically and graph-wise anchored
        # to long/control state. This removes a zero-gradient short path
        # that AdamW could otherwise still weight-decay.
        if self.use_anchor_dual_v5:
            reliability_state = UCTPState(
                p_short=state.p_long,
                n_short=state.n_long,
                p_long=state.p_long,
                n_long=state.n_long,
                mix_gate=torch.zeros_like(state.mix_gate),
            )
        else:
            reliability_state = state

        _, _, _, prev_uncertainty = self._beta_from_state(
            reliability_state
        )
        q_sum = q.sum(dim=-1).clamp_min(1.0)
        prev_u = (prev_uncertainty * q).sum(dim=-1) / q_sum
        short_rate = ((1.0 + state.p_short) / (2.0 + state.p_short + state.n_short) * q).sum(dim=-1) / q_sum
        long_rate = ((1.0 + state.p_long) / (2.0 + state.p_long + state.n_long) * q).sum(dim=-1) / q_sum

        # Keep the frozen reliability backbone anchored to the long state.
        # In the matched non-dual control, short_rate == long_rate.
        reliability_short_rate = (
            long_rate
            if (
                self.use_selective_consolidation_v3
                or self.use_monotonic_dual_v4
                or self.use_anchor_dual_v5
            )
            else short_rate
        )

        used_rt = rt_residual if self.use_rt else torch.zeros_like(rt_residual)
        used_dt = delta_t_hours if self.use_time else torch.zeros_like(delta_t_hours)
        used_dt_k = delta_t_k_hours if self.use_time else torch.zeros_like(delta_t_k_hours)

        reliability_features = torch.stack(
            [
                y,
                used_rt,
                used_rt.abs(),
                torch.log1p(used_dt.clamp_min(0.0)),
                torch.log1p(used_dt_k.clamp_min(0.0)),
                difficulty_scalar,
                torch.log1p(kc_count_before.clamp_min(0.0)),
                reliability_short_rate,
                long_rate,
                prev_u,
            ],
            dim=-1,
        )
        if self.use_reliability:
            reliability = self.reliability_encoder(reliability_features)
        else:
            reliability = torch.ones_like(y)

        # Prediction-surprise-conditioned reliability correction.
        #
        # predicted_probability was produced BEFORE observing current y.
        # detach() prevents the model from manipulating the current
        # prediction merely to control its future state update.
        if self.use_prediction_surprise and self.use_reliability:
            p_pre = predicted_probability.detach().clamp(1e-5, 1.0 - 1e-5)

            signed_surprise = y - p_pre
            abs_surprise = signed_surprise.abs()
            prediction_confidence = (p_pre - 0.5).abs() * 2.0

            surprise_features = torch.stack(
                [
                    p_pre,
                    signed_surprise,
                    abs_surprise,
                    prediction_confidence,
                    used_rt,
                    used_rt.abs(),
                    difficulty_scalar,
                    prev_u,
                ],
                dim=-1,
            )

            surprise_delta = self.surprise_reliability_adjuster(
                surprise_features
            ).squeeze(-1)

            eps = 1e-5
            base_rel_logit = torch.logit(
                reliability.clamp(eps, 1.0 - eps)
            )

            reliability = torch.sigmoid(
                base_rel_logit + surprise_delta
            )

        if self.use_selective_consolidation_v3:
            # Prediction was produced before observing current y.
            # All gate inputs are detached to avoid extra gradient paths
            # into the frozen backbone and current prediction.
            p_pre_v3 = predicted_probability.detach().clamp(
                1e-5, 1.0 - 1e-5
            )
            signed_surprise_v3 = y - p_pre_v3
            abs_surprise_v3 = signed_surprise_v3.abs()
            log_dt_k_v3 = torch.log1p(
                used_dt_k.clamp_min(0.0)
            )
            log_kc_count_v3 = torch.log1p(
                kc_count_before.clamp_min(0.0)
            )
            accumulated_long_evidence_v3 = (
                ((state.p_long + state.n_long) * q).sum(dim=-1)
                / q_sum
            )

            consolidation_features_v3 = torch.stack(
                [
                    reliability,
                    signed_surprise_v3,
                    abs_surprise_v3,
                    short_rate,
                    long_rate,
                    (short_rate - long_rate).abs(),
                    log_dt_k_v3,
                    torch.log1p(
                        accumulated_long_evidence_v3.clamp_min(0.0)
                    ),
                    difficulty_scalar,
                    y,
                    log_kc_count_v3,
                ],
                dim=-1,
            ).detach()

            # C in [0.5, 1.0]; initial C is approximately 0.991.
            consolidation_gate_v3 = 1.0 - 0.5 * torch.sigmoid(
                self.consolidation_gate_v3(
                    consolidation_features_v3
                ).squeeze(-1)
            )

        strength_features = torch.stack(
            [
                difficulty_scalar,
                used_rt,
                used_rt.abs(),
                torch.log1p(used_dt_k.clamp_min(0.0)),
            ],
            dim=-1,
        )
        positive_evidence = reliability * y * self.positive_strength(strength_features)
        negative_evidence = reliability * (1.0 - y) * self.negative_strength(strength_features)

        if self.use_uncertainty_update_v2:
            # This pre-response uncertainty changes only the future write.
            # The gate is in [0.8, 1.2] and starts exactly at 1.0.
            uncertainty_plasticity_v2 = (
                1.0
                + 0.2
                * torch.tanh(self.raw_uncertainty_plasticity_v2)
                * (2.0 * prev_u.detach() - 1.0)
            )
            positive_evidence = (
                positive_evidence * uncertainty_plasticity_v2
            )
            negative_evidence = (
                negative_evidence * uncertainty_plasticity_v2
            )

        active_f = active.float().unsqueeze(-1)
        q_active = q * active_f

        decay_dt_k = (
            torch.zeros_like(used_dt_k)
            if self.use_predict_time_decay_v2
            else used_dt_k
        )

        if self.use_time and self.use_concept_adaptive_decay:
            # Concept-specific decay while retaining a shared global
            # temporal prior.  The bounded multiplicative factor avoids
            # pathological concept-specific forgetting rates.
            concept_decay_scale = torch.exp(
                0.75 * torch.tanh(self.concept_decay_log_scale)
            ).unsqueeze(0)

            dt_k = decay_dt_k.clamp_min(0.0).unsqueeze(-1)

            lambda_long_k = self.lambda_long * concept_decay_scale
            lambda_short_k = self.lambda_short * concept_decay_scale

            d_long_k = torch.exp(-dt_k * lambda_long_k)
            d_short_k = torch.exp(-dt_k * lambda_short_k)

            if not self.use_dual_timescale:
                d_short_k = d_long_k

            keep_short = 1.0 - q_active + q_active * d_short_k
            keep_long = 1.0 - q_active + q_active * d_long_k

        else:
            # Frozen V1 behavior.
            if self.use_time:
                if self.use_asymmetric_dual_v7:
                    d_short_positive = torch.exp(
                        -self.dual_v7_lambda_positive
                        * decay_dt_k.clamp_min(0.0)
                    )
                    d_short_negative = torch.exp(
                        -self.dual_v7_lambda_negative
                        * decay_dt_k.clamp_min(0.0)
                    )
                else:
                    if self.use_bounded_dual_v6:
                        short_decay_rate = (
                            self.dual_v6_lambda_short
                        )
                    elif self.use_anchor_dual_v5:
                        short_decay_rate = (
                            self.lambda_short.detach()
                        )
                    else:
                        short_decay_rate = self.lambda_short

                    d_short = torch.exp(
                        -short_decay_rate
                        * decay_dt_k.clamp_min(0.0)
                    )
                    d_short_positive = d_short
                    d_short_negative = d_short

                d_long = torch.exp(
                    -self.lambda_long
                    * decay_dt_k.clamp_min(0.0)
                )
            else:
                d_short_positive = torch.ones_like(y)
                d_short_negative = torch.ones_like(y)
                d_long = torch.ones_like(y)

            if not self.use_dual_timescale:
                d_short_positive = d_long
                d_short_negative = d_long

            keep_short_positive = (
                1.0 - q_active
                + q_active * d_short_positive.unsqueeze(-1)
            )
            keep_short_negative = (
                1.0 - q_active
                + q_active * d_short_negative.unsqueeze(-1)
            )
            keep_short = keep_short_positive
            keep_long = (
                1.0 - q_active
                + q_active * d_long.unsqueeze(-1)
            )

        # Short memory absorbs all reliable new evidence.
        if self.use_bounded_dual_v6:
            short_positive_evidence = positive_evidence.detach()
            short_negative_evidence = negative_evidence.detach()
        else:
            short_positive_evidence = positive_evidence
            short_negative_evidence = negative_evidence

        if self.use_asymmetric_dual_v7:
            positive_keep = keep_short_positive
            negative_keep = keep_short_negative
        else:
            positive_keep = keep_short
            negative_keep = keep_short

        p_short = (
            state.p_short * positive_keep
            + q_active * short_positive_evidence.unsqueeze(-1)
        )
        n_short = (
            state.n_short * negative_keep
            + q_active * short_negative_evidence.unsqueeze(-1)
        )

        # Long memory receives only selectively consolidated evidence.
        if self.use_selective_consolidation_v3:
            long_positive_evidence = (
                consolidation_gate_v3 * positive_evidence
            )
            long_negative_evidence = (
                consolidation_gate_v3 * negative_evidence
            )
        else:
            # Exact frozen V1/control path.
            long_positive_evidence = positive_evidence
            long_negative_evidence = negative_evidence

        p_long = state.p_long * keep_long + q_active * long_positive_evidence.unsqueeze(-1)
        n_long = state.n_long * keep_long + q_active * long_negative_evidence.unsqueeze(-1)

        if self.use_selective_consolidation_v3:
            post_short_rate_v3 = (
                ((1.0 + p_short) / (2.0 + p_short + n_short) * q)
                .sum(dim=-1)
                / q_sum
            )
            post_long_rate_v3 = (
                ((1.0 + p_long) / (2.0 + p_long + n_long) * q)
                .sum(dim=-1)
                / q_sum
            )
            post_long_evidence_v3 = (
                ((p_long + n_long) * q).sum(dim=-1)
                / q_sum
            )

            read_features_v3 = torch.stack(
                [
                    reliability,
                    signed_surprise_v3,
                    abs_surprise_v3,
                    post_short_rate_v3,
                    post_long_rate_v3,
                    (post_short_rate_v3 - post_long_rate_v3).abs(),
                    log_dt_k_v3,
                    torch.log1p(
                        post_long_evidence_v3.clamp_min(0.0)
                    ),
                    difficulty_scalar,
                    y,
                    log_kc_count_v3,
                ],
                dim=-1,
            ).detach()

            # M = L + G * (S - L), with G in [0, 0.35].
            # Initial G is approximately 0.0063, keeping long as baseline.
            gate_scalar = 0.35 * torch.sigmoid(
                self.residual_read_gate_v3(
                    read_features_v3
                ).squeeze(-1)
            )
        elif (
            self.use_monotonic_dual_v4
            or self.use_anchor_dual_v5
        ):
            # Current pre-response gate is not stored.
            gate_scalar = torch.zeros_like(y)
        elif self.use_dual_timescale:
            # Frozen Dual-Timescale V1 behavior.
            gate_features = torch.stack(
                [
                    torch.log1p(used_dt_k.clamp_min(0.0)),
                    torch.log1p(kc_count_before.clamp_min(0.0)),
                    reliability,
                    prev_u,
                ],
                dim=-1,
            )
            gate_scalar = torch.sigmoid(
                self.timescale_gate(gate_features)
            ).squeeze(-1)
        else:
            gate_scalar = torch.zeros_like(y)

        new_gate = state.mix_gate * (1.0 - q_active) + q_active * gate_scalar.unsqueeze(-1)
        # Preserve all states for padded rows.
        preserve = 1.0 - active_f
        new_state = UCTPState(
            p_short=p_short * active_f + state.p_short * preserve,
            n_short=n_short * active_f + state.n_short * preserve,
            p_long=p_long * active_f + state.p_long * preserve,
            n_long=n_long * active_f + state.n_long * preserve,
            mix_gate=new_gate * active_f + state.mix_gate * preserve,
        )
        return new_state, reliability, positive_evidence, negative_evidence, gate_scalar

    def forward_chunk(
        self,
        state: UCTPState,
        student_idx: Tensor,
        item_idx: Tensor,
        q: Tensor,
        label: Tensor,
        rt_residual: Tensor,
        delta_t_hours: Tensor,
        delta_t_k_hours: Tensor,
        kc_count_before: Tensor,
        active_mask: Tensor,
        update_mask: Optional[Tensor] = None,
    ) -> Tuple[Dict[str, Tensor], UCTPState]:
        """Process [B,T] chunk. Prediction is always made before observing current label."""
        batch_size, steps = item_idx.shape
        if update_mask is None:
            update_mask = active_mask

        outputs: Dict[str, list[Tensor]] = {
            "probability": [],
            "uncertainty": [],
            "evidence": [],
            "reliability": [],
            "positive_evidence": [],
            "negative_evidence": [],
            "timescale_gate": [],
        }
        if self.use_anchor_dual_v5:
            outputs["control_probability"] = []

        current = state
        for t in range(steps):
            active_t = active_mask[:, t]

            if (
                self.use_dynamic
                and self.use_predict_time_decay_v2
            ):
                current = self._decay_state_before_prediction_v2(
                    state=current,
                    active=active_t,
                    q=q[:, t],
                    delta_t_k_hours=delta_t_k_hours[:, t],
                )

            pred = self._predict_step(
                current,
                student_idx,
                item_idx[:, t],
                q[:, t],
                delta_t_k_hours=delta_t_k_hours[:, t],
                kc_count_before=kc_count_before[:, t],
            )
            should_update = active_t & update_mask[:, t]
            if self.use_dynamic:
                current, rho, pos, neg, gate = self._update_step(
                    current,
                    should_update,
                    q[:, t],
                    label[:, t],
                    rt_residual[:, t],
                    delta_t_hours[:, t],
                    delta_t_k_hours[:, t],
                    kc_count_before[:, t],
                    pred["difficulty_scalar"],
                    pred["probability"],
                )
            else:
                rho = torch.ones(batch_size, device=item_idx.device)
                pos = torch.zeros_like(rho)
                neg = torch.zeros_like(rho)
                gate = torch.zeros_like(rho)

            outputs["probability"].append(pred["probability"])
            if self.use_anchor_dual_v5:
                outputs["control_probability"].append(
                    pred["control_probability"]
                )
            outputs["uncertainty"].append(pred["uncertainty"])
            outputs["evidence"].append(pred["evidence"])
            outputs["reliability"].append(rho)
            outputs["positive_evidence"].append(pos)
            outputs["negative_evidence"].append(neg)
            outputs["timescale_gate"].append(
                pred["prediction_timescale_gate"]
                if (
                    self.use_monotonic_dual_v4
                    or self.use_anchor_dual_v5
                )
                else gate
            )

        stacked = {key: torch.stack(values, dim=1) for key, values in outputs.items()}
        return stacked, current
