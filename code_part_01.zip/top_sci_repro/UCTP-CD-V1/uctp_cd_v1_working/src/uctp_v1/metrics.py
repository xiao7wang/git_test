from __future__ import annotations

from typing import Dict, Iterable, Optional

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score


def binary_nll(y_true: np.ndarray, y_prob: np.ndarray) -> float:
    p = np.clip(y_prob, 1e-7, 1.0 - 1e-7)
    return float(-np.mean(y_true * np.log(p) + (1.0 - y_true) * np.log(1.0 - p)))


def expected_calibration_error(y_true: np.ndarray, y_prob: np.ndarray, bins: int = 15) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    ece = 0.0
    for idx, (left, right) in enumerate(zip(edges[:-1], edges[1:])):
        mask = (y_prob >= left) & (y_prob <= right if idx == bins - 1 else y_prob < right)
        if not mask.any():
            continue
        ece += float(mask.mean()) * abs(float(y_true[mask].mean()) - float(y_prob[mask].mean()))
    return float(ece)


def compute_metrics(y_true: Iterable[float], y_prob: Iterable[float]) -> Dict[str, float]:
    y = np.asarray(list(y_true), dtype=float)
    p = np.asarray(list(y_prob), dtype=float)
    if len(y) == 0:
        return {key: float("nan") for key in ["auc", "acc", "f1", "rmse", "nll", "brier", "ece"]} | {"n": 0}
    pred = (p >= 0.5).astype(int)
    auc = float(roc_auc_score(y, p)) if len(np.unique(y)) > 1 else float("nan")
    return {
        "auc": auc,
        "acc": float(accuracy_score(y, pred)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "rmse": float(np.sqrt(np.mean((p - y) ** 2))),
        "nll": binary_nll(y, p),
        "brier": float(np.mean((p - y) ** 2)),
        "ece": expected_calibration_error(y, p),
        "n": int(len(y)),
    }


def subgroup_metrics(frame, group_col: str = "train_interaction_count") -> Dict[str, Dict[str, float]]:
    result: Dict[str, Dict[str, float]] = {}
    for threshold in [5, 10, 20]:
        subset = frame[frame[group_col] <= threshold]
        result[f"le_{threshold}"] = compute_metrics(subset["label"], subset["probability"])
    if len(frame):
        q25 = float(frame[group_col].quantile(0.25))
        subset = frame[frame[group_col] <= q25]
        result["bottom_25pct"] = compute_metrics(subset["label"], subset["probability"])
        result["bottom_25pct"]["threshold"] = q25
    return result
