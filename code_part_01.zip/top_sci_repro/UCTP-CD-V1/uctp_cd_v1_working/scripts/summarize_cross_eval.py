#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


root = Path("outputs/cross_eval")
cases = [
    (
        "update1_ckpt",
        0,
        root / "update1_ckpt_eval0" / "test_metrics.json",
    ),
    (
        "update1_ckpt",
        1,
        root / "equivalence_update1_ckpt_eval1" / "test_metrics.json",
    ),
    (
        "update0_ckpt",
        0,
        root / "equivalence_update0_ckpt_eval0" / "test_metrics.json",
    ),
    (
        "update0_ckpt",
        1,
        root / "update0_ckpt_eval1" / "test_metrics.json",
    ),
]

print(
    f"{'checkpoint':<18}"
    f"{'eval_update':>12}"
    f"{'AUC':>12}"
    f"{'ACC':>12}"
    f"{'RMSE':>12}"
    f"{'F1':>12}"
    f"{'Brier':>12}"
    f"{'ECE':>12}"
)

results = {}
for checkpoint, update, path in cases:
    if not path.exists():
        print(f"{checkpoint:<18}{update:>12}{'未完成':>12}")
        continue
    m = load(path)
    results[(checkpoint, update)] = m
    print(
        f"{checkpoint:<18}"
        f"{update:>12}"
        f"{m['auc']:>12.6f}"
        f"{m['acc']:>12.6f}"
        f"{m['rmse']:>12.6f}"
        f"{m['f1']:>12.6f}"
        f"{m['brier']:>12.6f}"
        f"{m['ece']:>12.6f}"
    )

print("\n固定checkpoint后的在线更新净贡献：")
for checkpoint in ("update1_ckpt", "update0_ckpt"):
    if (checkpoint, 0) in results and (checkpoint, 1) in results:
        delta = (
            results[(checkpoint, 1)]["auc"]
            - results[(checkpoint, 0)]["auc"]
        )
        print(f"{checkpoint}: ΔAUC={delta:+.6f}")

if len(results) == 4:
    ckpt_effect_eval0 = (
        results[("update1_ckpt", 0)]["auc"]
        - results[("update0_ckpt", 0)]["auc"]
    )
    ckpt_effect_eval1 = (
        results[("update1_ckpt", 1)]["auc"]
        - results[("update0_ckpt", 1)]["auc"]
    )
    print("\n固定评估协议后的checkpoint选择影响：")
    print(f"eval0下：ΔAUC={ckpt_effect_eval0:+.6f}")
    print(f"eval1下：ΔAUC={ckpt_effect_eval1:+.6f}")
