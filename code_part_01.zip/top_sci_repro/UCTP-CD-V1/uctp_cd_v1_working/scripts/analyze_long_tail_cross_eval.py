from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, roc_auc_score


FILES = {
    "update1_ckpt_eval0": Path(
        "outputs/cross_eval/update1_ckpt_eval0/"
        "test_predictions.csv"
    ),
    "update1_ckpt_eval1": Path(
        "outputs/cross_eval/equivalence_update1_ckpt_eval1/"
        "test_predictions.csv"
    ),
    "update0_ckpt_eval0": Path(
        "outputs/cross_eval/equivalence_update0_ckpt_eval0/"
        "test_predictions.csv"
    ),
    "update0_ckpt_eval1": Path(
        "outputs/cross_eval/update0_ckpt_eval1/"
        "test_predictions.csv"
    ),
}

OUTPUT_DIR = Path("outputs/cross_eval/long_tail")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

USECOLS = [
    "student_idx",
    "item_idx",
    "label",
    "probability",
    "train_interaction_count",
    "student_count_before",
]

GROUP_ORDER = [
    "train<=5",
    "train6-10",
    "train11-20",
    "train21-50",
    "train>50",
]


def expected_calibration_error(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    n_bins: int = 15,
) -> float:
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    total = len(y_true)
    ece = 0.0

    for i in range(n_bins):
        if i == n_bins - 1:
            mask = (
                (y_prob >= edges[i])
                & (y_prob <= edges[i + 1])
            )
        else:
            mask = (
                (y_prob >= edges[i])
                & (y_prob < edges[i + 1])
            )

        count = int(mask.sum())
        if count == 0:
            continue

        bin_acc = float(y_true[mask].mean())
        bin_conf = float(y_prob[mask].mean())
        ece += count / total * abs(bin_acc - bin_conf)

    return float(ece)


def compute_metrics(frame: pd.DataFrame) -> dict:
    y_true = frame["label"].to_numpy(dtype=np.float64)
    y_prob = frame["probability"].to_numpy(dtype=np.float64)
    y_prob = np.clip(y_prob, 1e-7, 1.0 - 1e-7)
    y_pred = (y_prob >= 0.5).astype(np.int64)

    if np.unique(y_true).size >= 2:
        auc = float(roc_auc_score(y_true, y_prob))
    else:
        auc = float("nan")

    squared_error = (y_prob - y_true) ** 2

    return {
        "n": int(len(frame)),
        "students": int(frame["student_idx"].nunique()),
        "positive_rate": float(y_true.mean()),
        "auc": auc,
        "acc": float((y_pred == y_true).mean()),
        "f1": float(
            f1_score(
                y_true.astype(np.int64),
                y_pred,
                zero_division=0,
            )
        ),
        "rmse": float(np.sqrt(squared_error.mean())),
        "brier": float(squared_error.mean()),
        "nll": float(
            -np.mean(
                y_true * np.log(y_prob)
                + (1.0 - y_true) * np.log(1.0 - y_prob)
            )
        ),
        "ece": expected_calibration_error(y_true, y_prob),
    }


def add_group(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()

    frame["history_group"] = pd.cut(
        frame["train_interaction_count"],
        bins=[-np.inf, 5, 10, 20, 50, np.inf],
        labels=GROUP_ORDER,
        right=True,
    )

    return frame


frames = {}

for name, path in FILES.items():
    if not path.exists():
        raise FileNotFoundError(path)

    frame = pd.read_csv(path, usecols=USECOLS)
    frame = add_group(frame)
    frames[name] = frame

    print(
        f"{name}: rows={len(frame)}, "
        f"students={frame['student_idx'].nunique()}"
    )

# 检查四个实验是否基于完全相同的测试样本和顺序。
reference_name = next(iter(frames))
reference = frames[reference_name][
    [
        "student_idx",
        "item_idx",
        "label",
        "train_interaction_count",
        "student_count_before",
    ]
].reset_index(drop=True)

for name, frame in frames.items():
    current = frame[
        [
            "student_idx",
            "item_idx",
            "label",
            "train_interaction_count",
            "student_count_before",
        ]
    ].reset_index(drop=True)

    if not reference.equals(current):
        raise RuntimeError(
            f"{name}与{reference_name}测试样本或顺序不一致"
        )

print("四组预测文件样本对齐检查：PASS")

rows = []

for experiment, frame in frames.items():
    for group in GROUP_ORDER:
        part = frame[frame["history_group"] == group]

        if part.empty:
            continue

        metrics = compute_metrics(part)
        rows.append(
            {
                "experiment": experiment,
                "history_group": group,
                **metrics,
            }
        )

result = pd.DataFrame(rows)

result.to_csv(
    OUTPUT_DIR / "long_tail_metrics.csv",
    index=False,
)

# 计算固定checkpoint后，在线更新在各长尾组的净贡献。
gain_rows = []

for checkpoint in ["update1_ckpt", "update0_ckpt"]:
    eval0_name = f"{checkpoint}_eval0"
    eval1_name = f"{checkpoint}_eval1"

    for group in GROUP_ORDER:
        row0 = result[
            (result["experiment"] == eval0_name)
            & (result["history_group"] == group)
        ]
        row1 = result[
            (result["experiment"] == eval1_name)
            & (result["history_group"] == group)
        ]

        if row0.empty or row1.empty:
            continue

        m0 = row0.iloc[0]
        m1 = row1.iloc[0]

        gain_rows.append(
            {
                "checkpoint": checkpoint,
                "history_group": group,
                "n": int(m0["n"]),
                "students": int(m0["students"]),
                "auc_eval0": float(m0["auc"]),
                "auc_eval1": float(m1["auc"]),
                "delta_auc": float(m1["auc"] - m0["auc"]),
                "delta_acc": float(m1["acc"] - m0["acc"]),
                "delta_rmse": float(m1["rmse"] - m0["rmse"]),
                "delta_brier": float(
                    m1["brier"] - m0["brier"]
                ),
                "delta_ece": float(m1["ece"] - m0["ece"]),
            }
        )

gain = pd.DataFrame(gain_rows)

gain.to_csv(
    OUTPUT_DIR / "online_gain_by_history.csv",
    index=False,
)

with (
    OUTPUT_DIR / "long_tail_summary.txt"
).open("w", encoding="utf-8") as f:
    f.write("========== 分组完整指标 ==========\n\n")

    for group in GROUP_ORDER:
        f.write(f"[{group}]\n")

        part = result[result["history_group"] == group]

        for _, row in part.iterrows():
            f.write(
                f"{row['experiment']:<25} "
                f"n={int(row['n']):>7} "
                f"students={int(row['students']):>6} "
                f"AUC={row['auc']:.6f} "
                f"ACC={row['acc']:.6f} "
                f"RMSE={row['rmse']:.6f} "
                f"F1={row['f1']:.6f} "
                f"Brier={row['brier']:.6f} "
                f"ECE={row['ece']:.6f}\n"
            )

        f.write("\n")

    f.write(
        "========== 固定checkpoint后的在线更新收益 ==========\n\n"
    )

    for _, row in gain.iterrows():
        f.write(
            f"{row['checkpoint']:<14} "
            f"{row['history_group']:<12} "
            f"students={int(row['students']):>6} "
            f"ΔAUC={row['delta_auc']:+.6f} "
            f"ΔACC={row['delta_acc']:+.6f} "
            f"ΔRMSE={row['delta_rmse']:+.6f} "
            f"ΔBrier={row['delta_brier']:+.6f} "
            f"ΔECE={row['delta_ece']:+.6f}\n"
        )

print()
print(
    (
        OUTPUT_DIR / "long_tail_summary.txt"
    ).read_text(encoding="utf-8")
)

print("结果目录：", OUTPUT_DIR)
