#!/usr/bin/env bash

set -euo pipefail

ROOT="/home/wangxiao/QCCDM/top_sci_repro/UCTP-CD-V1/uctp_cd_v1_working"
LOG_DIR="$ROOT/logs/cross_eval"
STATUS_FILE="$LOG_DIR/baseline_overnight_status.txt"

cd "$ROOT"

mkdir -p "$LOG_DIR" outputs/cross_eval

export CUDA_VISIBLE_DEVICES=0
export PYTHONUNBUFFERED=1

{
    echo "START: $(date '+%F %T')"
    echo "HOST: $(hostname)"
    echo "GPU: ${CUDA_VISIBLE_DEVICES}"
} > "$STATUS_FILE"

run_eval() {
    local update="$1"
    local output_dir="outputs/cross_eval/baseline_ckpt_eval${update}"
    local log_file="$LOG_DIR/baseline_ckpt_eval${update}.log"

    echo
    echo "============================================================"
    echo "开始 baseline checkpoint + eval_update_targets=${update}"
    echo "时间：$(date '+%F %T')"
    echo "============================================================"

    python -u scripts/evaluate_checkpoint.py \
      --project-root "$ROOT" \
      --checkpoint outputs/assist_full_baseline_seed0_e5/best_model.pt \
      --output-dir "$output_dir" \
      --variant baseline \
      --eval-update-targets "$update" \
      --device cuda \
      --allow-existing-result \
      2>&1 | tee "$log_file"

    local code=${PIPESTATUS[0]}

    echo \
      "eval${update}: exit_code=${code}, end=$(date '+%F %T')" \
      >> "$STATUS_FILE"

    if [ "$code" -ne 0 ]; then
        echo "eval${update}失败，停止后续任务。"
        exit "$code"
    fi
}

# 顺序运行，避免两项任务争抢同一张GPU
run_eval 0
run_eval 1

python - <<'PY' \
  2>&1 | tee "$LOG_DIR/baseline_cross_eval_summary.txt"
import json
from pathlib import Path

root = Path(
    "/home/wangxiao/QCCDM/top_sci_repro/"
    "UCTP-CD-V1/uctp_cd_v1_working"
)

paths = {
    "baseline_eval0": (
        root
        / "outputs/cross_eval/baseline_ckpt_eval0"
        / "test_metrics.json"
    ),
    "baseline_eval1": (
        root
        / "outputs/cross_eval/baseline_ckpt_eval1"
        / "test_metrics.json"
    ),
}

results = {}

for name, path in paths.items():
    if not path.exists():
        raise FileNotFoundError(path)

    results[name] = json.loads(
        path.read_text(encoding="utf-8")
    )

print(
    f"{'experiment':<20}"
    f"{'AUC':>12}"
    f"{'ACC':>12}"
    f"{'RMSE':>12}"
    f"{'F1':>12}"
    f"{'Brier':>12}"
    f"{'ECE':>12}"
)

for name, metrics in results.items():
    print(
        f"{name:<20}"
        f"{metrics['auc']:>12.6f}"
        f"{metrics['acc']:>12.6f}"
        f"{metrics['rmse']:>12.6f}"
        f"{metrics['f1']:>12.6f}"
        f"{metrics['brier']:>12.6f}"
        f"{metrics['ece']:>12.6f}"
    )

delta_auc = (
    results["baseline_eval1"]["auc"]
    - results["baseline_eval0"]["auc"]
)

print()
print(f"baseline在线更新净贡献：ΔAUC={delta_auc:+.6f}")
print("time模型在线更新参考：ΔAUC=+0.058612")
print(
    "time相对baseline的额外在线收益："
    f"{0.058612 - delta_auc:+.6f}"
)
PY

{
    echo "END: $(date '+%F %T')"
    echo "STATUS: SUCCESS"
} >> "$STATUS_FILE"

echo
echo "全部实验完成。"
echo "状态：$STATUS_FILE"
echo "汇总：$LOG_DIR/baseline_cross_eval_summary.txt"
