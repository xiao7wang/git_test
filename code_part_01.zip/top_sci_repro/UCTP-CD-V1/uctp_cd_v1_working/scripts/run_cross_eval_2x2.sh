#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/wangxiao/QCCDM/top_sci_repro/UCTP-CD-V1/uctp_cd_v1_working"
cd "$ROOT"

mkdir -p logs/cross_eval outputs/cross_eval

echo "========== 1/3 等价性检查 =========="
python scripts/check_cross_eval_equivalence.py \
  --project-root "$ROOT" \
  2>&1 | tee logs/cross_eval/equivalence.log

echo "========== 2/3 两个非对角交叉评估 =========="

python scripts/evaluate_checkpoint.py \
  --project-root "$ROOT" \
  --checkpoint outputs/assist_full_time_seed0_e5/best_model.pt \
  --output-dir outputs/cross_eval/update1_ckpt_eval0 \
  --variant time \
  --eval-update-targets 0 \
  --device cuda \
  --allow-existing-result \
  2>&1 | tee logs/cross_eval/update1_ckpt_eval0.log

python scripts/evaluate_checkpoint.py \
  --project-root "$ROOT" \
  --checkpoint outputs/assist_full_time_seed0_e5_eval0/best_model.pt \
  --output-dir outputs/cross_eval/update0_ckpt_eval1 \
  --variant time \
  --eval-update-targets 1 \
  --device cuda \
  --allow-existing-result \
  2>&1 | tee logs/cross_eval/update0_ckpt_eval1.log

echo "========== 3/3 汇总 =========="
python scripts/summarize_cross_eval.py \
  2>&1 | tee logs/cross_eval/summary.txt

echo "全部完成。"
