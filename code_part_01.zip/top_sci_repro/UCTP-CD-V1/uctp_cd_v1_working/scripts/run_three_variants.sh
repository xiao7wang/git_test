#!/usr/bin/env bash
set -euo pipefail

# Usage:
# bash scripts/run_three_variants.sh configs/generic.json /path/to/all_with_split.csv outputs 42
CONFIG=${1:?config json required}
DATA=${2:?single CSV with split column required}
OUT=${3:-outputs}
SEED=${4:-42}

for VARIANT in baseline time time_unc; do
  python train_v1.py \
    --config "$CONFIG" \
    --data "$DATA" \
    --variant "$VARIANT" \
    --output-dir "$OUT/$VARIANT/seed_$SEED" \
    --epochs 20 \
    --batch-size 8 \
    --bptt-steps 100 \
    --seed "$SEED" \
    --device auto
 done
