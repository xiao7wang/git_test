#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise TypeError(f"JSON根对象必须是字典：{path}")
    return data


def write_json(path: Path, data: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description=(
            "使用原train_v1.py的最终评估流程，对已有checkpoint进行零训练交叉评估。"
        )
    )
    p.add_argument("--project-root", default=".")
    p.add_argument("--train-script", default="train_v1.py")
    p.add_argument("--config", default="configs/assistments_time.json")
    p.add_argument("--train", default="data/assistments_time/train.csv")
    p.add_argument("--valid", default="data/assistments_time/valid.csv")
    p.add_argument("--test", default="data/assistments_time/test.csv")
    p.add_argument("--checkpoint", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--variant", choices=("baseline", "time", "time_unc"))
    p.add_argument("--eval-update-targets", type=int, choices=(0, 1), required=True)
    p.add_argument("--device", default=None)
    p.add_argument("--batch-size", type=int, default=None)
    p.add_argument("--bptt-steps", type=int, default=None)
    p.add_argument("--num-workers", type=int, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--force", action="store_true")
    p.add_argument(
        "--allow-existing-result",
        action="store_true",
        help="若结果已存在则直接验收，不重新运行。",
    )
    return p


def resolve(root: Path, value: str) -> Path:
    p = Path(value)
    return p if p.is_absolute() else root / p


def get_source_args(checkpoint: Path) -> tuple[dict[str, Any], Path | None]:
    run_config = checkpoint.parent / "run_config.json"
    if not run_config.exists():
        return {}, None
    cfg = read_json(run_config)
    args = cfg.get("args", {})
    if not isinstance(args, dict):
        args = {}
    return args, run_config


def discover_supported_options(python: str, train_script: Path, cwd: Path) -> set[str]:
    proc = subprocess.run(
        [python, str(train_script), "--help"],
        cwd=str(cwd),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "无法读取train_v1.py --help，不能安全构造评估命令。\n"
            + proc.stdout[-4000:]
        )
    return set(re.findall(r"(?<!\w)(--[a-zA-Z0-9][a-zA-Z0-9_-]*)", proc.stdout))


def add_option(
    cmd: list[str],
    supported: set[str],
    option: str,
    value: Any,
    *,
    required: bool = False,
) -> None:
    if value is None:
        if required:
            raise ValueError(f"缺少必需参数：{option}")
        return
    if option not in supported:
        if required:
            raise RuntimeError(f"原train_v1.py不支持必需参数：{option}")
        return
    cmd.extend([option, str(value)])


def stream_process(cmd: list[str], cwd: Path, log_path: Path) -> tuple[int, str]:
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    lines: list[str] = []

    with log_path.open("w", encoding="utf-8") as log:
        log.write("COMMAND:\n" + " ".join(cmd) + "\n\n")
        log.flush()

        proc = subprocess.Popen(
            cmd,
            cwd=str(cwd),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
        )
        assert proc.stdout is not None
        for line in proc.stdout:
            print(line, end="")
            log.write(line)
            log.flush()
            lines.append(line)

        return_code = proc.wait()

    return return_code, "".join(lines)


def main() -> int:
    args = parser().parse_args()
    project_root = Path(args.project_root).resolve()
    train_script = resolve(project_root, args.train_script).resolve()
    checkpoint = resolve(project_root, args.checkpoint).resolve()
    output_dir = resolve(project_root, args.output_dir).resolve()

    for required_path, label in [
        (project_root, "project-root"),
        (train_script, "train-script"),
        (checkpoint, "checkpoint"),
        (resolve(project_root, args.config), "config"),
        (resolve(project_root, args.train), "train"),
        (resolve(project_root, args.valid), "valid"),
        (resolve(project_root, args.test), "test"),
    ]:
        if not required_path.exists():
            raise FileNotFoundError(f"{label}不存在：{required_path}")

    if output_dir == checkpoint.parent:
        raise ValueError("output-dir不能与原checkpoint目录相同，避免覆盖原实验。")

    test_metrics_path = output_dir / "test_metrics.json"
    metadata_path = output_dir / "evaluation_metadata.json"

    if test_metrics_path.exists() and args.allow_existing_result and not args.force:
        print(f"结果已存在，直接验收：{test_metrics_path}")
        print(test_metrics_path.read_text(encoding="utf-8"))
        return 0

    if output_dir.exists() and any(output_dir.iterdir()):
        if not args.force:
            raise FileExistsError(
                f"输出目录非空：{output_dir}\n"
                "请换新目录，或明确使用--force清空后重跑。"
            )
        shutil.rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)

    source_args, source_run_config = get_source_args(checkpoint)
    variant = args.variant or source_args.get("variant")
    if variant not in {"baseline", "time", "time_unc"}:
        raise ValueError(
            "无法确定variant。请传--variant，或确保checkpoint旁存在run_config.json。"
        )

    effective = {
        "batch_size": args.batch_size
        if args.batch_size is not None
        else source_args.get("batch_size", 8),
        "bptt_steps": args.bptt_steps
        if args.bptt_steps is not None
        else source_args.get("bptt_steps", 50),
        "num_workers": args.num_workers
        if args.num_workers is not None
        else source_args.get("num_workers", 0),
        "seed": args.seed if args.seed is not None else source_args.get("seed", 0),
        "device": args.device or source_args.get("device", "cuda"),
        "hidden_dim": source_args.get("hidden_dim", 64),
        "ncd_hidden_dim": source_args.get("ncd_hidden_dim", 128),
        "lr": source_args.get("lr", 0.001),
        "weight_decay": source_args.get("weight_decay", 1e-5),
        "grad_clip": source_args.get("grad_clip", 5.0),
        "brier_weight": source_args.get("brier_weight"),
        "evidence_weight": source_args.get("evidence_weight"),
        "uncertainty_weight": source_args.get("uncertainty_weight"),
    }

    source_hash_before = sha256_file(checkpoint)
    staged_checkpoint = output_dir / "best_model.pt"
    shutil.copy2(checkpoint, staged_checkpoint)

    # 若原实验保存了预处理缓存，一并复制，尽可能保持统计量和映射完全一致。
    source_processed = checkpoint.parent / "processed_data.pkl"
    if source_processed.exists():
        shutil.copy2(source_processed, output_dir / "processed_data.pkl")

    supported = discover_supported_options(sys.executable, train_script, project_root)

    cmd = [sys.executable, str(train_script)]
    add_option(cmd, supported, "--config", args.config, required=True)
    add_option(cmd, supported, "--train", args.train, required=True)
    add_option(cmd, supported, "--valid", args.valid, required=True)
    add_option(cmd, supported, "--test", args.test, required=True)
    add_option(cmd, supported, "--variant", variant, required=True)
    add_option(cmd, supported, "--output-dir", str(output_dir), required=True)

    # 核心：0轮训练。若原脚本不支持该模式，会安全失败，不会伪造结果。
    add_option(cmd, supported, "--epochs", 0, required=True)
    add_option(cmd, supported, "--patience", 0)

    add_option(cmd, supported, "--batch-size", effective["batch_size"])
    add_option(cmd, supported, "--bptt-steps", effective["bptt_steps"])
    add_option(cmd, supported, "--num-workers", effective["num_workers"])
    add_option(cmd, supported, "--seed", effective["seed"])
    add_option(cmd, supported, "--device", effective["device"])
    add_option(
        cmd,
        supported,
        "--eval-update-targets",
        args.eval_update_targets,
        required=True,
    )
    add_option(cmd, supported, "--hidden-dim", effective["hidden_dim"])
    add_option(cmd, supported, "--ncd-hidden-dim", effective["ncd_hidden_dim"])
    add_option(cmd, supported, "--lr", effective["lr"])
    add_option(cmd, supported, "--weight-decay", effective["weight_decay"])
    add_option(cmd, supported, "--grad-clip", effective["grad_clip"])
    add_option(cmd, supported, "--brier-weight", effective["brier_weight"])
    add_option(cmd, supported, "--evidence-weight", effective["evidence_weight"])
    add_option(
        cmd,
        supported,
        "--uncertainty-weight",
        effective["uncertainty_weight"],
    )

    started_at = datetime.now().astimezone().isoformat()
    return_code, combined_output = stream_process(
        cmd, project_root, output_dir / "evaluation.log"
    )
    ended_at = datetime.now().astimezone().isoformat()

    source_hash_after = sha256_file(checkpoint)
    staged_hash_after = (
        sha256_file(staged_checkpoint) if staged_checkpoint.exists() else None
    )

    epoch_lines = re.findall(
        r"(?im)^\s*(?:\[?epoch\]?|epoch=)\s*0*[1-9]\d*.*$",
        combined_output,
    )

    metadata: dict[str, Any] = {
        "mode": "zero_epoch_existing_checkpoint_evaluation",
        "created_at": ended_at,
        "started_at": started_at,
        "ended_at": ended_at,
        "project_root": str(project_root),
        "train_script": str(train_script),
        "source_checkpoint": str(checkpoint),
        "source_run_config": str(source_run_config) if source_run_config else None,
        "source_checkpoint_sha256_before": source_hash_before,
        "source_checkpoint_sha256_after": source_hash_after,
        "staged_checkpoint_sha256_after": staged_hash_after,
        "checkpoint_unchanged": source_hash_before == source_hash_after,
        "staged_checkpoint_matches_source": staged_hash_after == source_hash_before,
        "variant": variant,
        "eval_update_targets": args.eval_update_targets,
        "effective_args": effective,
        "command": cmd,
        "return_code": return_code,
        "training_epoch_lines_detected": epoch_lines,
        "training_epoch_count_detected": len(epoch_lines),
        "optimizer_steps_requested_by_wrapper": 0,
        "backward_calls_requested_by_wrapper": 0,
        "test_metrics_exists": test_metrics_path.exists(),
    }
    write_json(metadata_path, metadata)

    if return_code != 0:
        raise RuntimeError(
            f"原train_v1.py评估失败，退出码={return_code}。"
            f"详见：{output_dir / 'evaluation.log'}"
        )

    if epoch_lines:
        raise RuntimeError(
            "检测到训练epoch输出，拒绝接受结果。"
            f"详见：{metadata_path}"
        )

    if source_hash_before != source_hash_after:
        raise RuntimeError("原checkpoint哈希发生变化，拒绝接受结果。")

    if staged_hash_after != source_hash_before:
        raise RuntimeError(
            "输出目录中的best_model.pt与源checkpoint不一致，拒绝接受结果。"
        )

    if not test_metrics_path.exists():
        raise RuntimeError(
            "train_v1.py完成后没有生成test_metrics.json。\n"
            "这说明当前train_v1.py不支持epochs=0直接进入最终评估；"
            "本包装器已安全停止，没有生成伪结果。"
        )

    metrics = read_json(test_metrics_path)
    metadata["test_metrics"] = metrics
    metadata["accepted"] = True
    write_json(metadata_path, metadata)

    print("\n评估完成且通过安全检查：")
    print(json.dumps(metrics, ensure_ascii=False, indent=2))
    print(f"metadata: {metadata_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\nERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
