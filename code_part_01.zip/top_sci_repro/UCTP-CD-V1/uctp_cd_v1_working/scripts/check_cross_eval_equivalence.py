#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
from pathlib import Path
from typing import Any


METRICS = ("auc", "acc", "f1", "rmse", "nll", "brier", "ece", "n")


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise TypeError(f"JSON根对象必须是字典：{path}")
    return data


def compare(
    actual_path: Path,
    reference_path: Path,
    tolerance: float,
) -> tuple[bool, list[str]]:
    actual = read_json(actual_path)
    reference = read_json(reference_path)
    messages: list[str] = []
    passed = True

    for key in METRICS:
        if key not in actual or key not in reference:
            passed = False
            messages.append(f"{key}: 缺失")
            continue

        a = float(actual[key])
        r = float(reference[key])
        diff = abs(a - r)
        current_ok = diff <= tolerance if key != "n" else int(a) == int(r)
        passed = passed and current_ok
        messages.append(
            f"{key:<8} actual={a:.12f} reference={r:.12f} "
            f"diff={diff:.3e} {'PASS' if current_ok else 'FAIL'}"
        )

    return passed, messages


def run_eval(
    root: Path,
    evaluator: Path,
    checkpoint: str,
    output_dir: str,
    update: int,
    force: bool,
) -> None:
    cmd = [
        sys.executable,
        str(evaluator),
        "--project-root",
        str(root),
        "--checkpoint",
        checkpoint,
        "--output-dir",
        output_dir,
        "--variant",
        "time",
        "--eval-update-targets",
        str(update),
        "--device",
        "cuda",
    ]
    if force:
        cmd.append("--force")
    else:
        cmd.append("--allow-existing-result")

    print("\nRUN:", " ".join(cmd))
    subprocess.run(cmd, cwd=str(root), check=True)


def main() -> int:
    p = argparse.ArgumentParser(description="UCTP交叉评估等价性检查")
    p.add_argument("--project-root", default=".")
    p.add_argument("--tolerance", type=float, default=1e-6)
    p.add_argument("--force", action="store_true")
    args = p.parse_args()

    root = Path(args.project_root).resolve()
    evaluator = Path(__file__).resolve().parent / "evaluate_checkpoint.py"

    cases = [
        {
            "name": "update1 checkpoint + eval1",
            "checkpoint": "outputs/assist_full_time_seed0_e5/best_model.pt",
            "output": "outputs/cross_eval/equivalence_update1_ckpt_eval1",
            "reference": "outputs/assist_full_time_seed0_e5/test_metrics.json",
            "update": 1,
        },
        {
            "name": "update0 checkpoint + eval0",
            "checkpoint": "outputs/assist_full_time_seed0_e5_eval0/best_model.pt",
            "output": "outputs/cross_eval/equivalence_update0_ckpt_eval0",
            "reference": "outputs/assist_full_time_seed0_e5_eval0/test_metrics.json",
            "update": 0,
        },
    ]

    all_passed = True
    for case in cases:
        run_eval(
            root,
            evaluator,
            case["checkpoint"],
            case["output"],
            case["update"],
            args.force,
        )
        actual = root / case["output"] / "test_metrics.json"
        reference = root / case["reference"]
        passed, messages = compare(actual, reference, args.tolerance)

        print(f"\n{case['name']}: {'PASS' if passed else 'FAIL'}")
        for message in messages:
            print("  " + message)
        all_passed = all_passed and passed

    print("\n总结果：", "PASS" if all_passed else "FAIL")
    return 0 if all_passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
