from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd


SOURCE_DIR = Path(
    "/home/wangxiao/QCCDM/top_sci_repro/"
    "unified_experiments/splits/assistments_time"
)

META_DIR = Path(
    "/home/wangxiao/QCCDM/top_sci_repro/"
    "unified_experiments/trace_cd_data/assistments_time"
)

OUTPUT_DIR = Path("data/assistments_time")
CHUNK_SIZE = 250_000

REQUIRED_COLUMNS = [
    "student_id",
    "exercise_id",
    "score",
    "response_time",
    "timestamp",
]


def load_metadata() -> tuple[dict[int, int], list[str]]:
    with open(META_DIR / "item_mapping.json", "r", encoding="utf-8") as f:
        raw_mapping = json.load(f)

    raw_to_compact = {
        int(raw_id): int(compact_id)
        for raw_id, compact_id in raw_mapping.items()
    }

    q_matrix = np.load(META_DIR / "q_matrix.npy")

    if len(raw_to_compact) != q_matrix.shape[0]:
        raise ValueError(
            f"映射数量 {len(raw_to_compact)} 与Q矩阵行数 "
            f"{q_matrix.shape[0]} 不一致"
        )

    compact_ids = sorted(raw_to_compact.values())
    expected_ids = list(range(q_matrix.shape[0]))

    if compact_ids != expected_ids:
        raise ValueError("紧凑题目ID不是完整的零起始连续索引")

    knowledge_lookup: list[str] = []

    for row_id, row in enumerate(q_matrix):
        knowledge_ids = np.flatnonzero(row).astype(int).tolist()

        if not knowledge_ids:
            raise ValueError(f"Q矩阵第 {row_id} 行没有知识点")

        knowledge_lookup.append(
            ",".join(str(k) for k in knowledge_ids)
        )

    return raw_to_compact, knowledge_lookup


def convert_split(
    split_name: str,
    raw_to_compact: dict[int, int],
    knowledge_lookup: list[str],
) -> None:
    source_path = SOURCE_DIR / f"{split_name}.csv"
    output_path = OUTPUT_DIR / f"{split_name}.csv"

    if output_path.exists():
        output_path.unlink()

    total_rows = 0
    first_chunk = True

    for chunk_id, chunk in enumerate(
        pd.read_csv(source_path, chunksize=CHUNK_SIZE),
        start=1,
    ):
        missing_columns = [
            col for col in REQUIRED_COLUMNS
            if col not in chunk.columns
        ]

        if missing_columns:
            raise ValueError(
                f"{source_path} 缺少字段: {missing_columns}"
            )

        if chunk[REQUIRED_COLUMNS].isna().any().any():
            missing = chunk[REQUIRED_COLUMNS].isna().sum()
            missing = missing[missing > 0].to_dict()
            raise ValueError(
                f"{source_path} 存在缺失值: {missing}"
            )

        if not chunk["score"].isin([0, 1]).all():
            invalid = sorted(chunk.loc[
                ~chunk["score"].isin([0, 1]), "score"
            ].unique().tolist())
            raise ValueError(f"发现非二值score: {invalid[:20]}")

        compact_ids = chunk["exercise_id"].map(raw_to_compact)

        if compact_ids.isna().any():
            unknown = (
                chunk.loc[compact_ids.isna(), "exercise_id"]
                .drop_duplicates()
                .head(20)
                .tolist()
            )
            raise ValueError(
                f"item_mapping中找不到题目: {unknown}"
            )

        compact_ids = compact_ids.astype(np.int64)

        converted = pd.DataFrame({
            "student_id": chunk["student_id"].astype(np.int64),
            "item_id": compact_ids,
            "knowledge_ids": [
                knowledge_lookup[item_id]
                for item_id in compact_ids.to_numpy()
            ],
            "correct": chunk["score"].astype(np.int64),
            "timestamp": chunk["timestamp"].astype(np.float64),
            "response_time": chunk["response_time"].astype(np.float64),
        })

        converted.to_csv(
            output_path,
            mode="a",
            header=first_chunk,
            index=False,
        )

        first_chunk = False
        total_rows += len(converted)

        print(
            f"{split_name}: chunk={chunk_id}, "
            f"累计行数={total_rows}"
        )

    print(
        f"{split_name} 转换完成: "
        f"{total_rows} 行 -> {output_path}"
    )


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    raw_to_compact, knowledge_lookup = load_metadata()

    print("映射题目数:", len(raw_to_compact))
    print("知识点数量:", 1 + max(
        int(k)
        for value in knowledge_lookup
        for k in value.split(",")
    ))

    for split_name in ["train", "valid", "test"]:
        convert_split(
            split_name,
            raw_to_compact,
            knowledge_lookup,
        )

    print("\n全部转换完成。")


if __name__ == "__main__":
    main()
