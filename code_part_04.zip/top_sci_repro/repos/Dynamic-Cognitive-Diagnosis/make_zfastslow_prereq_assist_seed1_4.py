from pathlib import Path
import re

base = Path("dneuralcdm_zfastslow_prereq_assistments_unified_seed0.py")
text0 = base.read_text(encoding="utf-8")

for s in range(1, 5):
    text = text0
    text = text.replace("seed0", f"seed{s}")
    text = text.replace("Seed0", f"Seed{s}")

    replacements = [
        (r"seed\s*=\s*0", f"seed = {s}"),
        (r"SEED\s*=\s*0", f"SEED = {s}"),
        (r"random_seed\s*=\s*0", f"random_seed = {s}"),
        (r"cross_idx\s*=\s*0", f"cross_idx = {s}"),
        (r"set_seed\(\s*0\s*\)", f"set_seed({s})"),
        (r"setup_seed\(\s*0\s*\)", f"setup_seed({s})"),
        (r"seed_all\(\s*0\s*\)", f"seed_all({s})"),
        (r"np\.random\.seed\(\s*0\s*\)", f"np.random.seed({s})"),
        (r"random\.seed\(\s*0\s*\)", f"random.seed({s})"),
        (r"torch\.manual_seed\(\s*0\s*\)", f"torch.manual_seed({s})"),
        (r"torch\.cuda\.manual_seed\(\s*0\s*\)", f"torch.cuda.manual_seed({s})"),
        (r"torch\.cuda\.manual_seed_all\(\s*0\s*\)", f"torch.cuda.manual_seed_all({s})"),
    ]

    for pat, repl in replacements:
        text = re.sub(pat, repl, text)

    out = Path(f"dneuralcdm_zfastslow_prereq_assistments_unified_seed{s}.py")
    out.write_text(text, encoding="utf-8")
    print(f"[OK] generated {out}")
