#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis
source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
source ~/anaconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate cd5090

mkdir -p logs

for SEED in 1 2 3 4
do
  echo "===== running dNeuralCDM-unified EDNet seed${SEED} ====="
  date

  rm -rf ws/dneuralcdm/ednet_unified_dynamiccd_original_seed${SEED}_lr001

  CUDA_VISIBLE_DEVICES=0 python -u original_ednet_unified_seed${SEED}.py \
    2>&1 | tee logs/dneuralcdm_unified_ednet_seed${SEED}.log

  echo "===== finished seed${SEED} ====="
  date
done
