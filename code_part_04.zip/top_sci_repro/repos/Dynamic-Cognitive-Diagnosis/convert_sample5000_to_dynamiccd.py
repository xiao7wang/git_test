import json
from pathlib import Path
from collections import defaultdict

SRC = Path("/home/wangxiao/QCCDM/top_sci_repro/converted_data/assistments_time_sample5000_item12000")
OUT_BASE = Path("data/assistments_time_sample5000_item12000_dynamiccd")
OUT_TRG = Path("data/assistments_time_sample5000_item12000_dynamiccd_trg")

def load_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def normalize_kc(kc):
    if isinstance(kc, list):
        return [int(x) for x in kc]
    if isinstance(kc, str):
        try:
            obj = json.loads(kc)
            if isinstance(obj, list):
                return [int(x) for x in obj]
        except Exception:
            pass
        if "," in kc:
            return [int(x) for x in kc.split(",") if x.strip()]
        return [int(kc)]
    return [int(kc)]

def load_records(fname):
    data = load_json(SRC / fname)
    records = []
    for idx, x in enumerate(data):
        records.append({
            "order_id": idx,
            "user_id": int(x["user_id"]),
            "exer_id": int(x["exer_id"]),
            "score": int(float(x["score"])),
            "knowledge_code": normalize_kc(x["knowledge_code"]),
            "response_time": x.get("response_time", 0),
            "timestamp": x.get("timestamp", idx),
        })
    return records

def write_dynamiccd(out_dir, with_rt=False):
    out_dir.mkdir(parents=True, exist_ok=True)

    cfg = load_json(SRC / "config.json")
    student_n = int(cfg["student_n"])
    exer_n = int(cfg["exer_n"])
    knowledge_n = int(cfg["knowledge_n"])

    split_data = {}
    all_records = []

    for fname, outname in [
        ("train_set.json", "train_0.json"),
        ("val_set.json", "val_0.json"),
        ("test_set.json", "test.json"),
    ]:
        recs = load_records(fname)
        split_data[outname] = recs
        all_records.extend(recs)

    combs = {}
    for r in all_records:
        key = "_".join(map(str, sorted(r["knowledge_code"])))
        if key not in combs:
            combs[key] = len(combs)

    with open(out_dir / "skill_comb_map.json", "w", encoding="utf-8") as f:
        json.dump(combs, f, ensure_ascii=False, indent=2)

    for outname, recs in split_data.items():
        users = defaultdict(list)
        for r in recs:
            kc = sorted(r["knowledge_code"])
            key = "_".join(map(str, kc))
            skill_comb = combs[key]

            item = [
                int(r["order_id"]),
                int(r["exer_id"]),
                int(r["score"]),
                kc,
                int(skill_comb),
            ]

            if with_rt:
                item.append(float(r.get("response_time", 0) or 0))

            users[int(r["user_id"])].append(item)

        seqs = []
        for u, logs in users.items():
            logs = sorted(logs, key=lambda z: z[0])
            seqs.append({
                "user_id": int(u),
                "log_num": len(logs),
                "logs": logs
            })

        with open(out_dir / outname, "w", encoding="utf-8") as f:
            json.dump(seqs, f, ensure_ascii=False)

    data_config = {
        "student_n": student_n,
        "exer_n": exer_n,
        "knowledge_n": knowledge_n,
        "skill_comb_n": len(combs),
    }

    with open(out_dir / "config.json", "w", encoding="utf-8") as f:
        json.dump(data_config, f, ensure_ascii=False, indent=2)

    with open(out_dir / "data_config.txt", "w", encoding="utf-8") as f:
        f.write(str(data_config))

    print("saved:", out_dir)
    print("data_config:", data_config)

write_dynamiccd(OUT_BASE, with_rt=False)
write_dynamiccd(OUT_TRG, with_rt=True)
