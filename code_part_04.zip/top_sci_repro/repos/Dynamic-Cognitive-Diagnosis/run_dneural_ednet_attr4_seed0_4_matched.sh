#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis
mkdir -p logs

for SEED in 0 1 2 3 4
do
  echo "===== running dNeuralCDM-unified EDNet attr_idx=4 no-RT matched seed${SEED} ====="
  date
  CUDA_VISIBLE_DEVICES=0 python -u dneuralcdm_ednet_unified_attr4_seed${SEED}.py \
    2>&1 | tee logs/dneuralcdm_unified_ednet_attr4_matched_seed${SEED}.log
  echo "===== finished EDNet attr4 no-RT matched seed${SEED} ====="
  date
done
