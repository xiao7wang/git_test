#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis
mkdir -p logs

for SEED in 1 2 3 4
do
  echo "===== running dNeuralCDM-fastslow-unified ASSIST seed${SEED} ====="
  date
  CUDA_VISIBLE_DEVICES=0 python -u dneuralcdm_fastslow_assistments_unified_seed${SEED}.py \
    2>&1 | tee logs/dneuralcdm_fastslow_unified_assist_seed${SEED}.log
  echo "===== finished seed${SEED} ====="
  date
done
