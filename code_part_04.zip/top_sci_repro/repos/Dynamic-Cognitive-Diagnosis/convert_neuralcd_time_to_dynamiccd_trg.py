import os
import json
import argparse
from collections import defaultdict

def read_config(src_dir):
    cfg_path = os.path.join(src_dir, "config.txt")
    with open(cfg_path, "r", encoding="utf8") as f:
        lines = [x.strip() for x in f.readlines() if x.strip()]
    nums = lines[1].split(",")
    return {
        "student_n_raw": int(nums[0]),
        "exer_n": int(nums[1]),
        "knowledge_n": int(nums[2]),
    }

def load_json(path):
    with open(path, "r", encoding="utf8") as f:
        return json.load(f)

def normalize_to_user_sequences(data):
    """
    支持两种格式：
    1. 平铺格式：[{user_id, exer_id, knowledge_code, score, response_time, timestamp}, ...]
    2. 序列格式：[{user_id, log_num, logs:[...]}, ...]
    """
    if len(data) == 0:
        return []

    # 已经是用户序列格式
    if isinstance(data[0], dict) and "logs" in data[0]:
        seqs = []
        for item in data:
            uid = int(item["user_id"])
            logs = item["logs"]
            logs = sorted(logs, key=lambda x: x.get("timestamp", 0))
            seqs.append((uid, logs))
        return seqs

    # 平铺格式
    user_logs = defaultdict(list)
    for item in data:
        uid = int(item["user_id"])
        user_logs[uid].append(item)

    seqs = []
    for uid, logs in user_logs.items():
        logs = sorted(logs, key=lambda x: x.get("timestamp", 0))
        seqs.append((uid, logs))

    seqs = sorted(seqs, key=lambda x: x[0])
    return seqs

def build_skill_comb_map(all_seqs):
    comb2id = {}
    for _, logs in all_seqs:
        for log in logs:
            skills = tuple(int(x) for x in log["knowledge_code"])
            if skills not in comb2id:
                comb2id[skills] = len(comb2id)
    return comb2id

def convert_split(seqs, comb2id, max_log=200, min_log=15):
    """
    DynamicCD格式：
    [segment_student_id, real_log_len, padded_logs]
    每条log：
    [order_id, exer_id, correct, [skill_id], skill_comb]
    """
    out = []
    seg_uid = 0

    for raw_uid, logs in seqs:
        clean_logs = []
        for idx, log in enumerate(logs):
            exer_id = int(log["exer_id"])
            correct = int(log["score"])
            skills = [int(x) for x in log["knowledge_code"]]
            if len(skills) == 0:
                continue

            timestamp = log.get("timestamp", idx)
            order_id = str(timestamp)
            skill_comb = comb2id[tuple(skills)]
            response_time = float(log.get("response_time", 0.0))

            clean_logs.append([order_id, exer_id, correct, skills, skill_comb, response_time])

        if len(clean_logs) < min_log:
            continue

        # 超过 max_log 就切段
        for start in range(0, len(clean_logs), max_log):
            seg_logs = clean_logs[start:start + max_log]
            real_len = len(seg_logs)

            if real_len < min_log:
                continue

            # 不足 max_log 用最后一条记录 padding，和原仓库数据表现一致
            if real_len < max_log:
                last_log = seg_logs[-1]
                seg_logs = seg_logs + [last_log for _ in range(max_log - real_len)]

            out.append([seg_uid, real_len, seg_logs])
            seg_uid += 1

    return out

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--src_dir", required=True)
    parser.add_argument("--out_name", required=True)
    parser.add_argument("--max_log", type=int, default=200)
    parser.add_argument("--min_log", type=int, default=15)
    args = parser.parse_args()

    src_dir = args.src_dir
    out_dir = os.path.join("data", args.out_name)
    os.makedirs(out_dir, exist_ok=True)

    cfg = read_config(src_dir)

    train_path = os.path.join(src_dir, "train_set.json")
    val_path = os.path.join(src_dir, "val_set.json")
    if not os.path.exists(val_path):
        val_path = os.path.join(src_dir, "valid_set.json")
    test_path = os.path.join(src_dir, "test_set.json")

    print("src_dir:", src_dir)
    print("out_dir:", out_dir)
    print("train_path:", train_path)
    print("val_path:", val_path)
    print("test_path:", test_path)

    train_raw = load_json(train_path)
    val_raw = load_json(val_path)
    test_raw = load_json(test_path)

    train_seqs = normalize_to_user_sequences(train_raw)
    val_seqs = normalize_to_user_sequences(val_raw)
    test_seqs = normalize_to_user_sequences(test_raw)

    print("raw user seqs:")
    print("train:", len(train_seqs))
    print("val:", len(val_seqs))
    print("test:", len(test_seqs))

    comb2id = build_skill_comb_map(train_seqs + val_seqs + test_seqs)

    train_out = convert_split(train_seqs, comb2id, args.max_log, args.min_log)
    val_out = convert_split(val_seqs, comb2id, args.max_log, args.min_log)
    test_out = convert_split(test_seqs, comb2id, args.max_log, args.min_log)

    with open(os.path.join(out_dir, "train_0.json"), "w", encoding="utf8") as f:
        json.dump(train_out, f)
    with open(os.path.join(out_dir, "val_0.json"), "w", encoding="utf8") as f:
        json.dump(val_out, f)
    with open(os.path.join(out_dir, "test.json"), "w", encoding="utf8") as f:
        json.dump(test_out, f)

    data_config = {
        "student_n": len(train_out) + len(val_out) + len(test_out),
        "exer_n": cfg["exer_n"],
        "knowledge_n": cfg["knowledge_n"],
        "skill_comb_n": len(comb2id),
        "min_log": args.min_log,
        "max_log": args.max_log,
        "stu_cnt_train": len(train_out),
    }

    with open(os.path.join(out_dir, "data_config.txt"), "w", encoding="utf8") as f:
        f.write(str(data_config))

    with open(os.path.join(out_dir, "skill_comb_map.json"), "w", encoding="utf8") as f:
        json.dump({"|".join(map(str, k)): v for k, v in comb2id.items()}, f, indent=2)

    print("converted:")
    print("train segments:", len(train_out))
    print("val segments:", len(val_out))
    print("test segments:", len(test_out))
    print("data_config:", data_config)
    print("sample:", train_out[0] if len(train_out) else None)

if __name__ == "__main__":
    main()
