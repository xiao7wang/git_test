#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis
mkdir -p logs

for SEED in 1 2 3 4
do
  echo "===== running dNeuralCDM-fastslow-unified EDNet seed${SEED} ====="
  date
  CUDA_VISIBLE_DEVICES=0 python -u dneuralcdm_fastslow_ednet_unified_seed${SEED}.py \
    2>&1 | tee logs/dneuralcdm_fastslow_unified_ednet_seed${SEED}.log
  echo "===== finished EDNet fastslow seed${SEED} ====="
  date
done
