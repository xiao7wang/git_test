#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis

source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
source ~/anaconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate cd5090

mkdir -p /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg
mkdir -p /home/wangxiao/QCCDM/top_sci_repro/results/final_tables

echo "===== PR-STG overnight started: $(date) ====="

echo "===== Check Assistments script ====="
python -m py_compile dneuralcdm_prstg_assistments.py

echo "===== Run PR-STG Assistments: $(date) ====="
python -u dneuralcdm_prstg_assistments.py \
  > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_assistments_fix.log 2>&1

echo "===== Assistments finished: $(date) ====="

echo "===== Create PR-STG EdNet script ====="
cp dneuralcdm_prstg_assistments.py dneuralcdm_prstg_ednet.py

python - <<'PY'
from pathlib import Path

p = Path("dneuralcdm_prstg_ednet.py")
text = p.read_text(encoding="utf8")

text = text.replace(
    "assistments_time_dynamiccd_prstg_alpha01_lr001",
    "ednet_kt1_time_dynamiccd_prstg_alpha01_lr001"
)

text = text.replace(
    "data_name = 'assistments_time_dynamiccd_trg'",
    "data_name = 'ednet_kt1_time_dynamiccd_trg'"
)

p.write_text(text, encoding="utf8")
print("created", p)
PY

echo "===== Check EdNet script ====="
grep -n "ws =\|data_name\|prstg_alpha\|trg_beta\|def __get_state" dneuralcdm_prstg_ednet.py | head -n 80
python -m py_compile dneuralcdm_prstg_ednet.py

echo "===== Run PR-STG EdNet: $(date) ====="
python -u dneuralcdm_prstg_ednet.py \
  > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_ednet.log 2>&1

echo "===== EdNet finished: $(date) ====="

echo "===== Extract PR-STG results =====" > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_summary.log

for f in \
  /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_assistments_fix.log \
  /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_ednet.log
do
  echo "===== $f =====" >> /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_summary.log
  grep -n "validation\|test\|Traceback\|Error\|nan" "$f" >> /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_summary.log || true
done

cat /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_prstg/prstg_summary.log

echo "===== PR-STG overnight finished: $(date) ====="
