from pathlib import Path

src_path = Path("original_assistments_seed0.py")
template = src_path.read_text(encoding="utf-8")

template = template.replace(
    "from sklearn.metrics import roc_auc_score",
    "from sklearn.metrics import roc_auc_score, precision_score, recall_score, f1_score"
)

old_block = """    pred_auc = roc_auc_score(pred_label_all, pred_all)
    pred_rmse = np.sqrt(np.mean((pred_all - pred_label_all) ** 2))
    pred_acc = 0
    for i in range(len(pred_all)):
        if (pred_label_all[i] == 1) and (pred_all[i] > 0.5):
            pred_acc += 1
        elif (pred_label_all[i] == 0) and (pred_all[i] < 0.5):
            pred_acc += 1
    pred_acc /= len(pred_all)
    print('[{}] stage={}, epoch={}: auc={}, rmse={}, acc={}'.format(dtype, stage, epoch_i, pred_auc, pred_rmse, pred_acc))
    with open(f'{ws}/results.txt', 'a') as o_f:
        o_f.write('[{}] stage={}, epoch={}: auc={}, rmse={}, acc={}\\n'.format(dtype, stage, epoch_i, pred_auc, pred_rmse, pred_acc))
"""

new_block = """    pred_auc = roc_auc_score(pred_label_all, pred_all)
    pred_rmse = np.sqrt(np.mean((pred_all - pred_label_all) ** 2))
    pred_binary = (pred_all >= 0.5).astype(int)
    pred_acc = float(np.mean(pred_binary == pred_label_all))
    pred_precision = precision_score(pred_label_all, pred_binary, zero_division=0)
    pred_recall = recall_score(pred_label_all, pred_binary, zero_division=0)
    pred_f1 = f1_score(pred_label_all, pred_binary, zero_division=0)

    print('[{}] stage={}, epoch={}: auc={}, rmse={}, acc={}, precision={}, recall={}, f1={}'.format(
        dtype, stage, epoch_i, pred_auc, pred_rmse, pred_acc, pred_precision, pred_recall, pred_f1
    ))
    with open(f'{ws}/results.txt', 'a') as o_f:
        o_f.write('[{}] stage={}, epoch={}: auc={}, rmse={}, acc={}, precision={}, recall={}, f1={}\\n'.format(
            dtype, stage, epoch_i, pred_auc, pred_rmse, pred_acc, pred_precision, pred_recall, pred_f1
        ))
"""

if old_block not in template:
    raise RuntimeError("Metric block not found. Need inspect val_test() before patching.")

template = template.replace(old_block, new_block)

main_pos = template.index("if __name__ == '__main__':")
prefix = template[:main_pos]

configs = [
    ("assistments_time_unified_dynamiccd", "assistments_time"),
    ("ednet_unified_dynamiccd", "ednet"),
]

for data_name, short_name in configs:
    for seed in range(5):
        ws = f"ws/dneuralcdm/{data_name}_original_seed{seed}_lr001"
        script_name = f"original_{short_name}_unified_seed{seed}.py"

        main = f"""if __name__ == '__main__':
    set_seed({seed})
    ws = '{ws}'
    device = 'cuda:0'
    cross_idx = 0
    lr = 0.001
    data_name = '{data_name}'

    ws_config_dict = {{
        'stu_ho_dim': 50,
        'rnn_type': 'gru',
        'attr_idx': 1,
        'data': data_name,
        'batch_size': 32
    }}

    with open(f'data/{{data_name}}/data_config.txt', encoding='utf8') as i_f:
        data_config = eval(i_f.readline())

    ws_config_dict['max_log'] = data_config['max_log']
    ws_config_dict['exer_n'] = data_config['exer_n']
    ws_config_dict['knowledge_n'] = data_config['knowledge_n']
    ws_config_dict['student_n'] = data_config['student_n']

    config_ws(ws, ws_config_dict)

    train_stage1(ws, device=device, lr=lr, n_epochs=3)
    test(ws, stage=1, device=device)
"""

        Path(script_name).write_text(prefix + main, encoding="utf-8")
        print("written", script_name)
