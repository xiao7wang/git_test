#!/usr/bin/env bash
set -e

cd /home/wangxiao/QCCDM/top_sci_repro/repos/Dynamic-Cognitive-Diagnosis
source ~/miniconda3/etc/profile.d/conda.sh
conda activate cd5090

mkdir -p /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_multiseed

echo "===== Start multi-seed experiments: $(date) ====="

python - <<'PY'
from pathlib import Path

tasks = [
    {
        "name": "original_assistments",
        "base": "dneuralcdm_assistments_time.py",
        "ws_old": "ws = 'ws/dneuralcdm/assistments_time_dynamiccd_lr001'",
        "ws_new_tpl": "ws = 'ws/dneuralcdm/assistments_time_dynamiccd_original_seed{seed}_lr001'",
    },
    {
        "name": "fastslow_assistments",
        "base": "dneuralcdm_fastslow_assistments.py",
        "ws_old": "ws = 'ws/dneuralcdm/assistments_time_dynamiccd_fastslow_lr001'",
        "ws_new_tpl": "ws = 'ws/dneuralcdm/assistments_time_dynamiccd_fastslow_seed{seed}_lr001'",
    },
    {
        "name": "original_ednet",
        "base": "dneuralcdm_ednet_time.py",
        "ws_old": "ws = 'ws/dneuralcdm/ednet_kt1_time_dynamiccd_lr001'",
        "ws_new_tpl": "ws = 'ws/dneuralcdm/ednet_kt1_time_dynamiccd_original_seed{seed}_lr001'",
    },
    {
        "name": "zscore_ednet",
        "base": "dneuralcdm_zscore_trg_ednet.py",
        "ws_old": "ws = 'ws/dneuralcdm/ednet_kt1_time_dynamiccd_zscore_trg_lr001'",
        "ws_new_tpl": "ws = 'ws/dneuralcdm/ednet_kt1_time_dynamiccd_zscore_seed{seed}_lr001'",
    },
]

seeds = [0, 1, 2]

seed_func = '''
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
'''

for task in tasks:
    base = Path(task["base"])
    if not base.exists():
        raise FileNotFoundError(f"Base script not found: {base}")

    for seed in seeds:
        out = Path(f'{task["name"]}_seed{seed}.py')
        text = base.read_text(encoding="utf8")

        if "def set_seed(seed):" not in text:
            text = text.replace("\n\ndef config_ws", seed_func + "\n\ndef config_ws")

        text = text.replace(
            "if __name__ == '__main__':\n    # global configuration",
            f"if __name__ == '__main__':\n    set_seed({seed})\n    # global configuration"
        )

        if task["ws_old"] not in text:
            print(f"[WARN] workspace pattern not found in {base}: {task['ws_old']}")
        text = text.replace(task["ws_old"], task["ws_new_tpl"].format(seed=seed))

        out.write_text(text, encoding="utf8")
        print("created", out)
PY

for script in original_assistments_seed0.py original_assistments_seed1.py original_assistments_seed2.py \
              fastslow_assistments_seed0.py fastslow_assistments_seed1.py fastslow_assistments_seed2.py \
              original_ednet_seed0.py original_ednet_seed1.py original_ednet_seed2.py \
              zscore_ednet_seed0.py zscore_ednet_seed1.py zscore_ednet_seed2.py
do
  echo "===== py_compile $script ====="
  python -m py_compile "$script"
done

for seed in 0 1 2
do
  echo "===== Run DynamicCD original Assistments seed $seed: $(date) ====="
  python -u original_assistments_seed${seed}.py \
    > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_multiseed/original_assistments_seed${seed}.log 2>&1

  echo "===== Run Fast-Slow Assistments seed $seed: $(date) ====="
  python -u fastslow_assistments_seed${seed}.py \
    > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_multiseed/fastslow_assistments_seed${seed}.log 2>&1

  echo "===== Run DynamicCD original EdNet seed $seed: $(date) ====="
  python -u original_ednet_seed${seed}.py \
    > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_multiseed/original_ednet_seed${seed}.log 2>&1

  echo "===== Run Z-score TRG EdNet seed $seed: $(date) ====="
  python -u zscore_ednet_seed${seed}.py \
    > /home/wangxiao/QCCDM/top_sci_repro/logs/dynamic_cd_multiseed/zscore_ednet_seed${seed}.log 2>&1
done

echo "===== Finished all multi-seed experiments: $(date) ====="
