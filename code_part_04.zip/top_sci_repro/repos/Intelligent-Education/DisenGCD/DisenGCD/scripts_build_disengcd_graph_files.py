import json
from pathlib import Path
from collections import defaultdict
from itertools import combinations

root = Path("data/82")
graph_dir = root / "graph"
graph_dir.mkdir(parents=True, exist_ok=True)

student_n, exer_n, knowledge_n = 4163, 17746, 123
k_offset = exer_n

item2ks = defaultdict(set)

# train_set.json: flat logs
train = json.load(open(root / "train_set.json", "r", encoding="utf-8"))
for r in train:
    eid = int(r["exer_id"])
    for k in r["knowledge_code"]:
        item2ks[eid].add(int(k))

# test_set.json: user grouped logs
test = json.load(open(root / "test_set.json", "r", encoding="utf-8"))
for u in test:
    for r in u["logs"]:
        eid = int(r["exer_id"])
        for k in r["knowledge_code"]:
            item2ks[eid].add(int(k))

# exercise -> knowledge and knowledge -> exercise
k_from_e = set()
e_from_k = set()

for eid, ks in item2ks.items():
    if not (1 <= eid <= exer_n):
        continue
    e_node = eid - 1
    for k in ks:
        if not (1 <= k <= knowledge_n):
            continue
        k_node = k_offset + k - 1
        k_from_e.add((e_node, k_node))
        e_from_k.add((k_node, e_node))

# concept co-occurrence graph
undir = set()
direct = set()

for eid, ks in item2ks.items():
    ks = sorted(k for k in ks if 1 <= k <= knowledge_n)
    for a, b in combinations(ks, 2):
        a0, b0 = a - 1, b - 1
        undir.add((a0, b0))
        undir.add((b0, a0))
        direct.add((a0, b0))

# fallback: if most questions are single-skill, co-occurrence may be empty.
# Add self-loops to prevent DGL empty-edge failure.
if len(undir) == 0:
    for k in range(knowledge_n):
        undir.add((k, k))

if len(direct) == 0:
    for k in range(knowledge_n):
        direct.add((k, k))

def write_edges(path, edges):
    with open(path, "w", encoding="utf-8") as f:
        for a, b in sorted(edges):
            f.write(f"{a}\t{b}\n")

write_edges(graph_dir / "k_from_e.txt", k_from_e)
write_edges(graph_dir / "e_from_k.txt", e_from_k)
write_edges(graph_dir / "K_Undirected.txt", undir)
write_edges(graph_dir / "K_Directed.txt", direct)

print("saved graph dir:", graph_dir.resolve())
print("items with kc:", len(item2ks))
print("k_from_e:", len(k_from_e))
print("e_from_k:", len(e_from_k))
print("K_Undirected:", len(undir))
print("K_Directed:", len(direct))

for p in ["K_Directed.txt", "K_Undirected.txt", "k_from_e.txt", "e_from_k.txt"]:
    q = graph_dir / p
    print(p, q.exists(), q.stat().st_size)
