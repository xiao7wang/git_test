import json
from pathlib import Path

root = Path("data/82")

train = json.load(open(root / "train_set.json", "r", encoding="utf-8"))
test = json.load(open(root / "test_set.json", "r", encoding="utf-8"))

train_smoke = train[:4096]
test_smoke = test[:80]

json.dump(train_smoke, open(root / "train_set_smoke.json", "w", encoding="utf-8"), ensure_ascii=False)
json.dump(test_smoke, open(root / "test_set_smoke.json", "w", encoding="utf-8"), ensure_ascii=False)

print("train_smoke:", len(train_smoke), root / "train_set_smoke.json")
print("test_smoke:", len(test_smoke), root / "test_set_smoke.json")
